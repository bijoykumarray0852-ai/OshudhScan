"use client";
import { useEffect, useState } from "react";
import {
  BarChart3, Bell, ChevronRight, Globe, HeartPulse, Hospital, Home, LayoutGrid, LogIn, LogOut, Map, MapPinned, Menu,
  Pill, ScanLine, Settings, ShieldCheck, Siren, Store, Tag, User, X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAppStore, hydratePrefs, type ViewKey } from "@/lib/store";
import { HomeView } from "@/components/rx/HomeView";
import { ScanView } from "@/components/rx/ScanView";
import { ArchitectureView } from "@/components/rx/ArchitectureView";
import { PortalView } from "@/components/rx/PortalView";
import { PricingView } from "@/components/rx/PricingView";
import { PatientView } from "@/components/rx/PatientView";
import { FindView } from "@/components/rx/FindView";
import { MedicineView } from "@/components/rx/MedicineView";
import { CareView } from "@/components/rx/CareView";
import { AdminView } from "@/components/rx/AdminView";
import { SettingsView } from "@/components/rx/SettingsView";
import { DirectoryView } from "@/components/rx/DirectoryView";
import { EmergencyView } from "@/components/rx/EmergencyView";
import { CoverageView } from "@/components/rx/CoverageView";
import { MapView } from "@/components/rx/MapView";
import { AuthDialog } from "@/components/rx/AuthDialog";
import { useI18n } from "@/hooks/use-i18n";
import { apiFetch } from "@/components/rx/shared";
import { LiteModeToggle } from "@/components/rx/lite-ui";
import type { SessionUser } from "@/lib/auth-types";

const NAV: Array<{ key: ViewKey; label: string }> = [
  { key: "home", label: "nav.home" },
  { key: "scan", label: "nav.scan" },
  { key: "medicines", label: "nav.medicines" },
  { key: "find", label: "nav.find" },
  { key: "directory", label: "nav.directory" },
  { key: "emergency", label: "nav.emergency" },
  { key: "coverage", label: "nav.coverage" },
  { key: "map", label: "nav.map" },
  { key: "patient", label: "nav.patient" },
  { key: "care", label: "nav.care" },
  { key: "portal", label: "nav.portal" },
  { key: "pricing", label: "nav.pricing" },
];

// Desktop header shows the patient-first subset (SOS button always covers
// emergency; the full list stays in the hamburger). Two tiers keep the
// header inside its container at every width: 6 items from xl up, 4 from
// lg to xl.
const DESKTOP_NAV: Array<{ key: ViewKey; label: string }> = NAV.filter((n) =>
  ["home", "scan", "medicines", "find", "directory", "map"].includes(n.key)
);
const COMPACT_NAV: Array<{ key: ViewKey; label: string }> = DESKTOP_NAV.filter((n) =>
  ["home", "scan", "find", "directory"].includes(n.key)
);

// Full navigation in serial order — every entry carries an icon so the
// hamburger panel and the account dropdown render as icon+label rows (the
// ChatGPT menu pattern) instead of a wrapping pill row.
const NAV_ITEMS: Array<{ key: ViewKey; label: string; icon: React.ReactNode }> = [
  { key: "home", label: "nav.home", icon: <Home className="h-4 w-4" /> },
  { key: "scan", label: "nav.scan", icon: <ScanLine className="h-4 w-4" /> },
  { key: "medicines", label: "nav.medicines", icon: <Pill className="h-4 w-4" /> },
  { key: "find", label: "nav.find", icon: <MapPinned className="h-4 w-4" /> },
  { key: "directory", label: "nav.directory", icon: <Hospital className="h-4 w-4" /> },
  { key: "emergency", label: "nav.emergency", icon: <Siren className="h-4 w-4" /> },
  { key: "coverage", label: "nav.coverage", icon: <BarChart3 className="h-4 w-4" /> },
  { key: "map", label: "nav.map", icon: <Map className="h-4 w-4" /> },
  { key: "patient", label: "nav.patient", icon: <User className="h-4 w-4" /> },
  { key: "care", label: "nav.care", icon: <HeartPulse className="h-4 w-4" /> },
  { key: "portal", label: "nav.portal", icon: <Store className="h-4 w-4" /> },
  { key: "pricing", label: "nav.pricing", icon: <Tag className="h-4 w-4" /> },
];

const ROLE_LABEL: Record<string, string> = {
  PATIENT: "auth.rolePatient",
  PHARMACY_OWNER: "auth.rolePharmacy",
  PHARMACY_STAFF: "auth.rolePharmacy",
  PHARMACIST: "auth.rolePharmacy",
  ADMIN: "auth.roleAdmin",
};

/** First letters of the first two words — the ChatGPT-style avatar circle. */
function initials(name: string): string {
  const parts = name.trim().split(/\s+/).slice(0, 2);
  return parts.map((p) => Array.from(p)[0]?.toUpperCase() ?? "").join("") || "?";
}

// thumb-friendly mobile tab bar (desktop hides it)
const BOTTOM_NAV: Array<{ key: ViewKey; label: string; icon: React.ReactNode }> = [
  { key: "home", label: "nav.home", icon: <Home className="h-5 w-5" /> },
  { key: "scan", label: "nav.scan", icon: <ScanLine className="h-5 w-5" /> },
  { key: "medicines", label: "nav.medicines", icon: <Pill className="h-5 w-5" /> },
  { key: "find", label: "nav.find", icon: <MapPinned className="h-5 w-5" /> },
  { key: "patient", label: "nav.patient", icon: <User className="h-5 w-5" /> },
];

function LanguageToggle() {
  const { t } = useI18n();
  const locale = useAppStore((s) => s.locale);
  const setLocale = useAppStore((s) => s.setLocale);
  return (
    <Button
      variant="outline"
      size="sm"
      className="h-9 gap-1.5 rounded-full bg-white/70 shadow-soft backdrop-blur"
      onClick={() => setLocale(locale === "bn" ? "en" : "bn")}
      aria-label={t("app.langLabel")}
    >
      <Globe className="h-4 w-4" />
      {locale === "bn" ? "বাংলা" : "EN"}
    </Button>
  );
}

function AccountButtons() {
  const { t } = useI18n();
  const user = useAppStore((s) => s.user);
  const setUser = useAppStore((s) => s.setUser);
  const openAuth = useAppStore((s) => s.openAuth);
  const setView = useAppStore((s) => s.setView);
  const unread = useAppStore((s) => s.unreadNotifications);

  const signOut = async () => {
    await apiFetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setUser(null);
  };

  if (!user) {
    return (
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" onClick={() => openAuth("signin")}>
          {t("auth.signIn")}
        </Button>
        <Button size="sm" className="btn-brand hidden sm:inline-flex" onClick={() => openAuth("signup")}>
          {t("auth.signUp")}
        </Button>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-1.5">
      {user.role === "PATIENT" && (
        <Button variant="ghost" size="icon" className="relative h-9 w-9" aria-label={t("patient.notifications")} onClick={() => setView("patient")}>
          <Bell className="h-4 w-4" />
          {unread > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-emerald-600 px-1 text-[10px] font-bold text-white">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      )}
      {/* ChatGPT-style account menu: avatar header with name + role, then
          icon rows in serial order, sign-out separated at the bottom. */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="h-9 gap-2 rounded-full bg-white/70 pl-1 pr-3 shadow-soft backdrop-blur" aria-label={t("nav.menu")} aria-haspopup="menu">
            <span aria-hidden="true" className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 text-[11px] font-bold text-white">
              {initials(user.name)}
            </span>
            <span className="max-w-[110px] truncate text-sm font-medium">{user.name}</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel asChild>
            <button
              className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left outline-none focus:bg-accent"
              onClick={() => setView("settings")}
            >
              <span aria-hidden="true" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 text-sm font-bold text-white">
                {initials(user.name)}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold text-foreground">{user.name}</span>
                <span className="block text-xs text-muted-foreground">{t(ROLE_LABEL[user.role] ?? "auth.account")}</span>
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
            </button>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          {user.role === "ADMIN" && (
            <DropdownMenuItem onClick={() => setView("admin")}>
              <ShieldCheck className="h-4 w-4" /> {t("nav.admin")}
            </DropdownMenuItem>
          )}
          {user.role === "PATIENT" && (
            <DropdownMenuItem onClick={() => setView("patient")}>
              <User className="h-4 w-4" /> {t("nav.patient")}
            </DropdownMenuItem>
          )}
          <DropdownMenuItem onClick={() => setView("settings")}>
            <Settings className="h-4 w-4" /> {t("nav.settings")}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => void signOut()} variant="destructive">
            <LogOut className="h-4 w-4" /> {t("auth.signOut")}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

export default function Page() {
  const view = useAppStore((s) => s.view);
  const setView = useAppStore((s) => s.setView);
  const largeText = useAppStore((s) => s.largeText);
  const setAuthLoaded = useAppStore((s) => s.setAuthLoaded);
  const setUser = useAppStore((s) => s.setUser);
  const setUnread = useAppStore((s) => s.setUnreadNotifications);
  const user = useAppStore((s) => s.user);
  const openAuth = useAppStore((s) => s.openAuth);
  const { t } = useI18n();
  const [menuOpen, setMenuOpen] = useState(false);

  const signOut = async () => {
    await apiFetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setUser(null);
    setMenuOpen(false);
  };

  // Esc closes the menu panel (dropdown-like behaviour)
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  useEffect(() => {
    hydratePrefs();
    // bootstrap session
    void (async () => {
      try {
        const res = await apiFetch<{ user: SessionUser | null }>("/api/auth/me");
        setUser(res.user);
        if (res.user) {
          const due = await apiFetch<{ unreadNotifications: number }>("/api/reminders/due").catch(() => null);
          if (due) setUnread(due.unreadNotifications);
        }
      } finally {
        setAuthLoaded();
      }
    })();
  }, []);

  const navBtnClass = (active: boolean) =>
    active
      ? "bg-emerald-600/10 font-semibold text-emerald-900 shadow-[inset_0_0_0_1px_rgba(5,150,105,0.18)]"
      : "text-muted-foreground hover:text-foreground";

  return (
    <div className={`flex min-h-screen flex-col bg-background ${largeText ? "text-[17px] md:text-lg" : ""}`}>
      <AuthDialog />

      {/* click-away backdrop for the mobile menu — a sibling of the header so
          the header (and its hamburger) stay above it and clickable */}
      {menuOpen && <div className="fixed inset-0 z-30 lg:hidden" aria-hidden="true" onClick={() => setMenuOpen(false)} />}

      {/* Header — frosted glass */}
      <header className="sticky top-0 z-40 border-b border-emerald-900/10 bg-background/80 backdrop-blur-xl supports-[backdrop-filter]:bg-background/70">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-2 px-4 sm:gap-3">
          <button className="flex items-center gap-2.5" onClick={() => setView("home")} aria-label="OshudhScan home">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-700 text-white shadow-soft">
              <ScanLine className="h-4 w-4" />
            </span>
            <span className="text-base font-bold tracking-tight">
              Oshudh<span className="text-gradient">Scan</span>
            </span>
          </button>

          {/* Desktop nav — compact tier for lg, full tier from xl up */}
          <nav className="hidden items-center gap-0.5 lg:hidden xl:flex" aria-label="Main navigation">
            {DESKTOP_NAV.map((item) => (
              <Button key={item.key} variant="ghost" size="sm" onClick={() => setView(item.key)} className={`rounded-full px-3 ${navBtnClass(view === item.key)}`}>
                {t(item.label)}
              </Button>
            ))}
          </nav>
          <nav className="hidden items-center gap-0.5 lg:flex xl:hidden" aria-label="Main navigation">
            {COMPACT_NAV.map((item) => (
              <Button key={item.key} variant="ghost" size="sm" onClick={() => setView(item.key)} className={`rounded-full px-3 ${navBtnClass(view === item.key)}`}>
                {t(item.label)}
              </Button>
            ))}
          </nav>

          <div className="flex items-center gap-1.5">
            {/* Emergency SOS — always reachable, one tap, visually distinct */}
            <Button
              size="sm"
              className="h-9 shrink-0 gap-1 rounded-full bg-red-600 px-2.5 text-white shadow-soft hover:bg-red-700 sm:px-3"
              onClick={() => setView("emergency")}
              aria-label={t("emergency.title")}
            >
              <Siren className="h-4 w-4" />
              <span className="hidden min-[430px]:inline">{t("emergency.sos")}</span>
            </Button>
            <LiteModeToggle />
            <LanguageToggle />
            <div className="hidden sm:block">
              <AccountButtons />
            </div>
            <button
              className="flex h-9 w-9 items-center justify-center rounded-lg hover:bg-muted lg:hidden"
              onClick={() => setMenuOpen((o) => !o)}
              aria-label={t("nav.menu")}
              aria-expanded={menuOpen}
            >
              {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile / tablet nav — ChatGPT-style vertical panel: account header,
            icon+label rows in serial order, account actions at the bottom.
            SIZE CAP: the whole panel is limited to 45vh — under half the page —
            and scrolls internally, so it can never take over the viewport. */}
        {menuOpen && (
          <nav
            className="absolute inset-x-0 top-full z-40 border-b bg-background shadow-lift lg:hidden"
            aria-label="Mobile navigation"
          >
              <div className="mx-auto max-h-[45vh] max-w-md overflow-y-auto overscroll-contain">
                {/* account header row */}
                {user ? (
                  <button
                    onClick={() => { setView("settings"); setMenuOpen(false); }}
                    className="flex w-full items-center gap-3 border-b px-4 py-2.5 text-left transition-colors hover:bg-muted/60"
                  >
                    <span aria-hidden="true" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 text-sm font-bold text-white">
                      {initials(user.name)}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold">{user.name}</span>
                      <span className="block text-xs text-muted-foreground">{t(ROLE_LABEL[user.role] ?? "auth.account")}</span>
                    </span>
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                  </button>
                ) : (
                  <div className="flex items-center justify-between gap-2 border-b px-4 py-2.5">
                    <p className="text-sm font-medium">{t("auth.signInToContinue")}</p>
                    <Button size="sm" className="btn-brand shrink-0" onClick={() => { openAuth("signin"); setMenuOpen(false); }}>
                      {t("auth.signIn")}
                    </Button>
                  </div>
                )}

                {/* serial icon+label rows */}
                <div className="px-2 py-1.5">
                  {NAV_ITEMS.map((item) => {
                    const active = view === item.key;
                    return (
                      <button
                        key={item.key}
                        onClick={() => { setView(item.key); setMenuOpen(false); }}
                        aria-current={active ? "page" : undefined}
                        className={`flex min-h-[44px] w-full items-center gap-3 rounded-xl px-3 text-sm transition-colors ${
                          active
                            ? "bg-emerald-600/10 font-semibold text-emerald-900"
                            : "text-foreground/80 hover:bg-muted"
                        }`}
                      >
                        <span className={`shrink-0 ${active ? "text-emerald-700" : "text-muted-foreground"}`}>{item.icon}</span>
                        {t(item.label)}
                      </button>
                    );
                  })}
                  {user?.role === "ADMIN" && (
                    <button
                      onClick={() => { setView("admin"); setMenuOpen(false); }}
                      aria-current={view === "admin" ? "page" : undefined}
                      className={`flex min-h-[44px] w-full items-center gap-3 rounded-xl px-3 text-sm transition-colors ${
                        view === "admin"
                          ? "bg-emerald-600/10 font-semibold text-emerald-900"
                          : "text-foreground/80 hover:bg-muted"
                      }`}
                    >
                      <span className={`shrink-0 ${view === "admin" ? "text-emerald-700" : "text-muted-foreground"}`}><ShieldCheck className="h-4 w-4" /></span>
                      {t("nav.admin")}
                    </button>
                  )}
                </div>

                {/* account actions */}
                <div className="border-t px-2 py-1.5">
                  <button
                    onClick={() => { setView("settings"); setMenuOpen(false); }}
                    className="flex min-h-[44px] w-full items-center gap-3 rounded-xl px-3 text-sm text-foreground/80 transition-colors hover:bg-muted"
                  >
                    <Settings className="h-4 w-4 shrink-0 text-muted-foreground" /> {t("nav.settings")}
                  </button>
                  {user ? (
                    <button
                      onClick={() => void signOut()}
                      className="flex min-h-[44px] w-full items-center gap-3 rounded-xl px-3 text-sm text-destructive transition-colors hover:bg-destructive/5"
                    >
                      <LogOut className="h-4 w-4 shrink-0" /> {t("auth.signOut")}
                    </button>
                  ) : (
                    <button
                      onClick={() => { openAuth("signup"); setMenuOpen(false); }}
                      className="flex min-h-[44px] w-full items-center gap-3 rounded-xl px-3 text-sm text-foreground/80 transition-colors hover:bg-muted"
                    >
                      <LogIn className="h-4 w-4 shrink-0 text-muted-foreground" /> {t("auth.signUp")}
                    </button>
                  )}
                </div>
              </div>
            </nav>
        )}
      </header>

      {/* Main */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-24 py-6 sm:py-8 lg:pb-8">
        {view === "home" && <HomeView />}
        {view === "scan" && <ScanView />}
        {view === "architecture" && <ArchitectureView />}
        {view === "portal" && <PortalView />}
        {view === "pricing" && <PricingView />}
        {view === "patient" && <PatientView />}
        {view === "find" && <FindView />}
        {view === "directory" && <DirectoryView />}
        {view === "emergency" && <EmergencyView />}
        {view === "coverage" && <CoverageView />}
        {view === "map" && <MapView />}
        {view === "medicines" && <MedicineView />}
        {view === "care" && <CareView />}
        {view === "admin" && <AdminView />}
        {view === "settings" && <SettingsView />}
      </main>

      {/* Mobile bottom tab bar */}
      <nav className="bottom-nav fixed inset-x-0 bottom-0 z-40 border-t border-emerald-900/10 lg:hidden" aria-label="Bottom navigation">
        <div className="mx-auto grid max-w-lg grid-cols-5">
          {BOTTOM_NAV.map((item) => {
            const active = view === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setView(item.key)}
                aria-current={active ? "page" : undefined}
                className={`flex min-h-[56px] flex-col items-center justify-center gap-0.5 px-1 pt-1.5 pb-1 text-[10px] font-medium transition-colors ${
                  active ? "text-emerald-700" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <span className={`relative flex h-7 w-7 items-center justify-center rounded-full ${active ? "bg-emerald-100" : ""}`}>
                  {item.icon}
                </span>
                {t(item.label)}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Footer — sticks to bottom via flex, respects safe areas */}
      <footer className="panel-deep mt-auto text-emerald-50">
        <div className="mx-auto max-w-6xl px-4 pb-[calc(env(safe-area-inset-bottom)+40px)] pt-8 lg:pb-[env(safe-area-inset-bottom)]">
          <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
            <div className="max-w-sm">
              <p className="flex items-center gap-2 text-base font-bold">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 ring-1 ring-emerald-300/30">
                  <HeartPulse className="h-4 w-4" />
                </span>
                Oshudh<span className="text-emerald-300">Scan</span> 2.0
              </p>
              <p className="mt-2 text-xs leading-relaxed text-emerald-100/70">{t("app.tagline")} · SDG 3.8 / 3.b</p>
            </div>
            <div className="flex items-start gap-1.5 text-xs leading-relaxed text-emerald-100/60 md:max-w-md">
              <LayoutGrid className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-300/70" />
              <p>{t("common.privacyNote")}</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
