import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { hashPassword, verifyPassword, createSession, sessionCookieOptions, SESSION_COOKIE, ApiError } from "@/lib/auth";
import { withApi, parseJson, rateLimit, clientIp, audit, ok } from "@/lib/api";

const registerSchema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email().max(120),
  password: z.string().min(8).max(100),
  phone: z.string().max(20).optional(),
  locale: z.enum(["bn", "en"]).optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

function userPayload(user: { id: string; email: string; name: string; role: string; locale: string; largeText: boolean; phone: string | null }) {
  return { id: user.id, email: user.email, name: user.name, role: user.role, locale: user.locale, largeText: user.largeText, phone: user.phone };
}

export const POST = withApi(async ({ req }) => {
  const url = new URL(req.url);
  const action = url.searchParams.get("action") ?? "login";
  const ip = clientIp(req);

  if (action === "register") {
    rateLimit(`register:${ip}`, 5, 60 * 60 * 1000);
    const body = await parseJson(req, registerSchema);
    const email = body.email.toLowerCase().trim();
    const existing = await db.user.findUnique({ where: { email } });
    if (existing) throw new ApiError(409, "EMAIL_TAKEN", "An account with this email already exists");
    const passwordHash = await hashPassword(body.password);
    const user = await db.user.create({
      data: {
        email,
        name: body.name.trim(),
        passwordHash,
        phone: body.phone ?? null,
        locale: body.locale ?? "bn",
        role: "PATIENT",
        patientProfile: { create: {} },
        consents: { create: { consentType: "DATA_PROCESSING", granted: true, version: "1.0" } },
      },
    });
    const session = await createSession(user.id, { ip, userAgent: req.headers.get("user-agent") ?? undefined });
    await audit(req, { userId: user.id, action: "AUTH_REGISTER", entity: "user", entityId: user.id });
    const res = ok({ user: userPayload(user) });
    res.cookies.set(SESSION_COOKIE, session.token, sessionCookieOptions(session.expiresAt));
    return res;
  }

  // login
  rateLimit(`login:${ip}`, 10, 15 * 60 * 1000);
  const body = await parseJson(req, loginSchema);
  const email = body.email.toLowerCase().trim();
  const user = await db.user.findUnique({ where: { email } });
  if (!user || user.deletedAt) throw new ApiError(401, "INVALID_CREDENTIALS", "Wrong email or password");
  const valid = await verifyPassword(body.password, user.passwordHash);
  if (!valid) throw new ApiError(401, "INVALID_CREDENTIALS", "Wrong email or password");
  const session = await createSession(user.id, { ip, userAgent: req.headers.get("user-agent") ?? undefined });
  await audit(req, { userId: user.id, action: "AUTH_LOGIN", entity: "user", entityId: user.id });
  const res = ok({ user: userPayload(user) });
  res.cookies.set(SESSION_COOKIE, session.token, sessionCookieOptions(session.expiresAt));
  return res;
});
