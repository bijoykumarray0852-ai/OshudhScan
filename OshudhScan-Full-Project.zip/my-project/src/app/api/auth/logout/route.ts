import { NextResponse } from "next/server";
import { destroySession } from "@/lib/auth";
import { withApi, ok } from "@/lib/api";

export const POST = withApi(async () => {
  await destroySession();
  return ok({ signedOut: true });
});
