import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { withApi, ok } from "@/lib/api";

export const GET = withApi(async ({ req }: { req: NextRequest }) => {
  const user = await getSessionUser();
  if (!user) return ok({ user: null });
  // attach pharmacy context for pharmacy owners/staff
  const staff = await db.pharmacyStaff.findMany({
    where: { userId: user.id },
    include: { pharmacy: { select: { id: true, name: true, status: true, isVerified: true, isDemo: true } } },
  });
  return ok({ user, pharmacies: staff.map((s) => ({ ...s.pharmacy, staffRole: s.role })) });
}, { rate: { limit: 60, windowMs: 60_000 } });
