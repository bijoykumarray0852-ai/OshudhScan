import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, fail, parseJson, searchParams, pageArgs, audit } from "@/lib/api";
import { getSessionUser } from "@/lib/auth";
import { REPORT_TYPES } from "@/lib/directory";

const reportSchema = z.object({
  entityType: z.enum(["FACILITY", "PHARMACY", "LOCATION"]),
  entityId: z.string().min(1),
  reportType: z.enum(REPORT_TYPES as unknown as [string, ...string[]]),
  message: z.string().min(5).max(1000),
  suggestedValue: z.string().max(300).optional(),
  reporterName: z.string().max(120).optional(),
  reporterContact: z.string().max(120).optional(),
});

// POST /api/reports — anyone can report a wrong phone/address/closed listing
// etc. Reports go to the admin verification queue and are never auto-applied.
export const POST = withApi(async ({ req }) => {
  const user = await getSessionUser();
  const body = await parseJson(req, reportSchema);

  // validate target existence (no opaque FK errors)
  if (body.entityType === "FACILITY") {
    const f = await db.healthcareFacility.findUnique({ where: { id: body.entityId } });
    if (!f) return fail(400, "VALIDATION", "Unknown facilityId");
  } else if (body.entityType === "PHARMACY") {
    const p = await db.pharmacy.findUnique({ where: { id: body.entityId } });
    if (!p) return fail(400, "VALIDATION", "Unknown pharmacyId");
  }

  const report = await db.facilityReport.create({
    data: {
      entityType: body.entityType,
      entityId: body.entityId,
      reportType: body.reportType,
      message: body.message,
      suggestedValue: body.suggestedValue,
      reporterName: body.reporterName ?? user?.name,
      reporterContact: body.reporterContact,
      userId: user?.id,
    },
  });
  await audit(req, { userId: user?.id, action: "DIRECTORY_REPORT_CREATE", entity: "facility_report", entityId: report.id, detail: { reportType: body.reportType, entityType: body.entityType } });
  return ok({ report: { id: report.id, status: report.status }, message: "Thank you — your report was submitted for admin review." }, { status: 201 });
}, { rate: { limit: 10, windowMs: 60 * 60_000 } });

// GET /api/reports — admin review queue.
export const GET = withApi(async ({ req }) => {
  const { skip, take, page, pageSize } = pageArgs(searchParams(req), 30);
  const status = searchParams(req).get("status") ?? undefined;
  const where = status && status !== "ALL" ? { status } : {};
  const [reports, total] = await Promise.all([
    db.facilityReport.findMany({ where, orderBy: { createdAt: "desc" }, skip, take }),
    db.facilityReport.count({ where }),
  ]);
  return ok({ page, pageSize, total, reports });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
