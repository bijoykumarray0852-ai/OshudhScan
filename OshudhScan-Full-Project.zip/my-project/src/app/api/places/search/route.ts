import { withApi, ok, searchParams } from "@/lib/api";
import { googlePlacesTextSearch, placesConfigured, cachePlaceResults } from "@/lib/directory-server";

// GET /api/places/search?q=&lat=&lng= — Google Places Text Search proxy.
// Requires GOOGLE_MAPS_API_KEY; without it we return configured:false and the
// UI falls back to registry data + plain Google Maps search links. The API
// key never leaves the server.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const q = sp.get("q")?.trim() ?? "";
  if (!q) return ok({ configured: placesConfigured(), results: [], message: "q parameter required" });
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  const res = await googlePlacesTextSearch(q, {
    lat: !Number.isNaN(lat) ? lat : undefined,
    lng: !Number.isNaN(lng) ? lng : undefined,
  });
  if (res.configured && res.results.length) await cachePlaceResults(res.results).catch(() => undefined);
  return ok({
    configured: res.configured,
    results: res.results,
    error: res.error,
    message: res.configured ? undefined : "Google Maps Platform key not configured — showing registry data with Google Maps search links instead.",
  });
}, { rate: { limit: 30, windowMs: 60_000 } });
