import { db } from "@/lib/db";
import { withApi, ok, fail, searchParams } from "@/lib/api";
import { placesConfigured } from "@/lib/directory-server";

// GET /api/places/details?placeId= — returns the CACHED place record when
// available. Live Place Details calls require GOOGLE_MAPS_API_KEY and are
// added at deployment time; caching respects Google's retention terms.
export const GET = withApi(async ({ req }) => {
  const placeId = searchParams(req).get("placeId")?.trim();
  if (!placeId) return fail(400, "VALIDATION", "placeId required");
  const record = await db.googlePlaceRecord.findUnique({ where: { placeId } });
  return ok({
    configured: placesConfigured(),
    place: record
      ? {
          placeId: record.placeId, name: record.name, formattedAddress: record.formattedAddress,
          phone: record.phone, lat: record.lat, lng: record.lng, rating: record.rating,
          types: record.types ? JSON.parse(record.types) : [], fetchedAt: record.fetchedAt,
        }
      : null,
    message: record ? undefined : "No cached place record — live details require a configured Google Maps Platform key.",
  });
}, { rate: { limit: 60, windowMs: 60_000 } });
