import { withApi, ok, fail, searchParams } from "@/lib/api";
import { googlePlacesTextSearch, placesConfigured, cachePlaceResults } from "@/lib/directory-server";

// GET /api/places/nearby?lat=&lng=&radius=&type= — Google Places Nearby via
// text search with location bias. Graceful when no API key is configured.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  if (Number.isNaN(lat) || Number.isNaN(lng)) return fail(400, "VALIDATION", "lat and lng are required");
  const type = sp.get("type") ?? "pharmacy";
  const res = await googlePlacesTextSearch(type, { lat, lng, radius: 20000 });
  if (res.configured && res.results.length) await cachePlaceResults(res.results).catch(() => undefined);
  return ok({
    configured: res.configured,
    results: res.results,
    error: res.error,
    message: res.configured ? undefined : "Google Maps Platform key not configured — showing registry data with Google Maps search links instead.",
  });
}, { rate: { limit: 30, windowMs: 60_000 } });
