import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, searchParams, pageArgs, audit } from "@/lib/api";
import { requireUser } from "@/lib/auth";

const saveSchema = z.object({
  doctorName: z.string().max(120).optional(),
  doctorDegrees: z.string().max(160).optional(),
  facility: z.string().max(160).optional(),
  patientName: z.string().max(120).optional(),
  prescribedAt: z.string().optional(),
  familyMemberId: z.string().optional(),
  sampleId: z.string().max(40).optional(),
  ocrConfidence: z.number().min(0).max(1).optional(),
  medicines: z.array(z.object({
    medicineId: z.string().optional(),
    rawLine: z.string().max(200).optional(),
    brandRaw: z.string().max(120).optional(),
    matchedBrand: z.string().max(80).optional(),
    generic: z.string().max(160).optional(),
    strength: z.string().max(40).optional(),
    doseText: z.string().max(20).optional(),
    perDay: z.number().int().optional(),
    slots: z.array(z.enum(["MORNING", "AFTERNOON", "NIGHT"])).optional(),
    durationDays: z.number().int().optional(),
    meal: z.string().max(12).optional(),
    matchMethod: z.string().max(20).optional(),
    confidence: z.number().min(0).max(1).optional(),
    priceBdt: z.number().optional(),
    genericPriceBdt: z.number().optional(),
  })).min(1).max(30),
  findings: z.array(z.record(z.string(), z.unknown())).max(40).optional(),
  totals: z.record(z.string(), z.unknown()).optional(),
  imageBase64: z.string().max(3_000_000).optional(),
});

// GET /api/prescriptions — the patient's saved prescriptions.
export const GET = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const sp = searchParams(req);
  const { skip, take, page, pageSize } = pageArgs(sp, 10);
  const [rows, total] = await Promise.all([
    db.prescription.findMany({
      where: { patientUserId: u.id, deletedAt: null },
      orderBy: { createdAt: "desc" },
      skip,
      take,
      include: {
        items: { orderBy: { position: "asc" } },
        familyMember: { select: { name: true, relation: true } },
        images: { select: { id: true, fileName: true, createdAt: true } },
      },
    }),
    db.prescription.count({ where: { patientUserId: u.id, deletedAt: null } }),
  ]);
  return ok({
    page,
    pageSize,
    total,
    prescriptions: rows.map((r) => ({
      id: r.id,
      doctorName: r.doctorName,
      facility: r.facility,
      patientName: r.patientName,
      familyMember: r.familyMember,
      prescribedAt: r.prescribedAt,
      source: r.source,
      createdAt: r.createdAt,
      items: r.items.map((it) => ({ id: it.id, brand: it.matchedBrand ?? it.brandRaw, generic: it.generic, strength: it.strength, dose: it.doseText, perDay: it.perDay, durationDays: it.durationDays, medicineId: it.medicineId })),
      findings: r.findings ? JSON.parse(r.findings) : [],
      totals: r.totals ? JSON.parse(r.totals) : null,
      hasImage: r.images.length > 0,
    })),
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// POST /api/prescriptions — persist a decoded prescription (from ScanView).
export const POST = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, saveSchema);

  const prescribedAt = body.prescribedAt ? new Date(body.prescribedAt) : null;
  let imageRef: { fileName: string; mimeType: string; sizeBytes: number; storagePath: string } | null = null;
  if (body.imageBase64) {
    imageRef = await savePrivateFile(u.id, body.imageBase64);
  }

  const created = await db.prescription.create({
    data: {
      patientUserId: u.id,
      familyMemberId: body.familyMemberId ?? null,
      source: "SCAN",
      sampleId: body.sampleId,
      doctorName: body.doctorName,
      doctorDegrees: body.doctorDegrees,
      facility: body.facility,
      patientName: body.patientName,
      prescribedAt,
      ocrConfidence: body.ocrConfidence,
      findings: body.findings ? JSON.stringify(body.findings) : null,
      totals: body.totals ? JSON.stringify(body.totals) : null,
      items: {
        create: body.medicines.map((m, i) => ({
          medicineId: m.medicineId ?? null,
          rawLine: m.rawLine,
          brandRaw: m.brandRaw,
          matchedBrand: m.matchedBrand,
          generic: m.generic,
          strength: m.strength,
          doseText: m.doseText,
          perDay: m.perDay,
          slots: m.slots ? JSON.stringify(m.slots) : null,
          durationDays: m.durationDays,
          meal: m.meal,
          matchMethod: m.matchMethod,
          confidence: m.confidence,
          priceBdt: m.priceBdt,
          genericPriceBdt: m.genericPriceBdt,
          position: i,
        })),
      },
      ...(imageRef ? { images: { create: imageRef } } : {}),
    },
    include: { items: true },
  });
  await audit(req, { userId: u.id, action: "PRESCRIPTION_SAVE", entity: "prescription", entityId: created.id, detail: { items: created.items.length } });
  return ok({ prescription: { id: created.id, items: created.items.length } }, { status: 201 });
}, { auth: true, rate: { limit: 15, windowMs: 60 * 60_000 } });

// DELETE /api/prescriptions?id= — soft delete.
export const DELETE = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const id = searchParams(req).get("id");
  if (!id) return fail(400, "VALIDATION", "id required");
  const rx = await db.prescription.findFirst({ where: { id, patientUserId: u.id, deletedAt: null } });
  if (!rx) return fail(404, "NOT_FOUND", "Prescription not found");
  await db.prescription.update({ where: { id: rx.id }, data: { deletedAt: new Date() } });
  await audit(req, { userId: u.id, action: "PRESCRIPTION_DELETE", entity: "prescription", entityId: rx.id });
  return ok({ deleted: true });
}, { auth: true, rate: { limit: 20, windowMs: 60_000 } });

import { mkdir, writeFile } from "fs/promises";
import path from "path";

// Writes a private document under db/documents/<userId>/ (never web-served).
export async function savePrivateFile(userId: string, base64: string, fileName = "prescription.jpg", mimeType = "image/jpeg") {
  const dir = path.join(process.cwd(), "db", "documents", userId);
  await mkdir(dir, { recursive: true });
  const name = `${Date.now()}-${Math.floor(Math.random() * 100000)}.${mimeType === "application/pdf" ? "pdf" : "jpg"}`;
  const abs = path.join(dir, name);
  await writeFile(abs, Buffer.from(base64, "base64"));
  return { fileName, mimeType, sizeBytes: Math.round((base64.length * 3) / 4), storagePath: abs };
}
