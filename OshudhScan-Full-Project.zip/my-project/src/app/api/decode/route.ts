import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { SAMPLE_BY_ID } from "@/lib/samples";
import { matchBrand, parseDose, parseDuration } from "@/lib/match";
import { runSafetyEngine } from "@/lib/interactions";
import type { DecodeResponse, MatchedMedicine, OcrResult } from "@/lib/types";
import { db } from "@/lib/db";

// Governance: rules retired in the clinical_rules registry stop firing.
async function disabledRuleIds(): Promise<string[]> {
  try {
    const rows = await db.clinicalRule.findMany({ where: { enabled: false }, select: { ruleId: true } });
    return rows.map((r) => r.ruleId);
  } catch {
    return []; // registry unavailable → engine runs with its full curated matrix
  }
}

const VISION_SYSTEM = `You are an OCR engine specialized in Bangladeshi medical prescriptions (handwritten Bangla/English mixed).
Read the image and return STRICT JSON only — no markdown fences, no commentary — with this exact shape:
{"doctor": string|null, "date": string|null, "medicines": [{"brand_raw": string, "strength": string|null, "dose": string|null, "duration": string|null}]}
Notes:
- brand_raw is the medicine brand name exactly as written (Bangladeshi brand, e.g. Napa, Seclo, Monas, Zimax, Flexi).
- dose uses Bangladesh notation like "1+1+1" (morning+noon+night) when present; null if missing.
- duration examples: "5 days", "30 days", "1 month"; null if missing.
- If a line is unreadable, set fields to null rather than guessing.`;

function stripFences(text: string): string {
  return text
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/```\s*$/i, "")
    .trim();
}

async function visionOcr(imageBase64: string): Promise<OcrResult> {
  const zai = await ZAI.create();
  const completion = await Promise.race([
    zai.chat.completions.createVision({
      model: "glm-4.5v",
      messages: [
        { role: "assistant", content: VISION_SYSTEM },
        {
          role: "user",
          content: [
            { type: "text", text: "Extract all medicines from this prescription photo. Return strict JSON only." },
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } },
          ],
        },
      ],
      thinking: { type: "disabled" },
    }),
    new Promise<never>((_, reject) => setTimeout(() => reject(new Error("OCR timeout (25s)")), 25000)),
  ]);
  const content: string = completion?.choices?.[0]?.message?.content ?? "";
  const parsed = JSON.parse(stripFences(content));
  if (!parsed || !Array.isArray(parsed.medicines)) throw new Error("Malformed OCR response");
  return {
    doctor: parsed.doctor ?? null,
    date: parsed.date ?? null,
    medicines: parsed.medicines
      .map((m: Record<string, unknown>) => ({
        brand_raw: String(m.brand_raw ?? "").trim(),
        strength: m.strength ? String(m.strength) : null,
        dose: m.dose ? String(m.dose) : null,
        duration: m.duration ? String(m.duration) : null,
      }))
      .filter((m: { brand_raw: string }) => m.brand_raw.length > 0),
  };
}

function normalizeStrength(raw: string | null, known: string[]): string | null {
  if (!raw) return null;
  const s = raw.toLowerCase().replace(/\s+/g, "");
  const exact = known.find((k) => k.toLowerCase() === s);
  if (exact) return exact;
  const num = s.match(/(\d+(?:\.\d+)?)/);
  if (num) {
    const byNum = known.find((k) => k.toLowerCase().startsWith(num[1]));
    if (byNum) return byNum;
  }
  return raw;
}

function buildMedicines(ocr: OcrResult): MatchedMedicine[] {
  return ocr.medicines.map((line) => {
    const match = matchBrand(line.brand_raw);
    const dose = parseDose(line.dose);
    const days = parseDuration(line.duration);

    if (!match) {
      return {
        brandRaw: line.brand_raw,
        brand: null,
        manufacturer: null,
        generic: null,
        genericBangla: null,
        strength: line.strength,
        form: null,
        therapeuticClass: null,
        dose: line.dose,
        duration: line.duration,
        meal: null,
        unitPriceBdt: null,
        genericUnitPriceBdt: null,
        matchMethod: "unmatched" as const,
        confidence: 0.3,
        perDay: dose?.perDay ?? null,
        days,
        qty: dose && days ? dose.perDay * days : null,
        lineTotalBdt: null,
        genericLineTotalBdt: null,
      };
    }

    const drug = match.drug;
    const strength = normalizeStrength(line.strength, drug.strengths);
    const qty = dose && days ? dose.perDay * days : null;
    const lineTotal = qty !== null ? qty * drug.unitPriceBdt : null;
    const genericTotal = qty !== null ? qty * drug.genericUnitPriceBdt : null;

    return {
      brandRaw: line.brand_raw,
      brand: drug.brand,
      manufacturer: drug.manufacturer,
      generic: drug.generic,
      genericBangla: drug.genericBangla,
      strength,
      form: drug.form,
      therapeuticClass: drug.therapeuticClass,
      dose: line.dose,
      duration: line.duration,
      meal: drug.meal,
      unitPriceBdt: drug.unitPriceBdt,
      genericUnitPriceBdt: drug.genericUnitPriceBdt,
      matchMethod: match.method,
      confidence: match.confidence,
      perDay: dose?.perDay ?? null,
      days,
      qty,
      lineTotalBdt: lineTotal,
      genericLineTotalBdt: genericTotal,
    };
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { imageBase64?: string; sampleId?: string };
    let ocr: OcrResult;
    let source: "upload" | "sample";
    const degraded = false;
    let engine = "glm-4.5v vision OCR";

    if (body.sampleId) {
      const sample = SAMPLE_BY_ID[body.sampleId];
      if (!sample) {
        return NextResponse.json({ ok: false, error: "Unknown sample id" }, { status: 400 });
      }
      ocr = sample.ocr;
      source = "sample";
      engine = "curated sample (OCR bypassed) + rules engine";
    } else if (body.imageBase64) {
      try {
        ocr = await visionOcr(body.imageBase64);
        source = "upload";
      } catch (err) {
        return NextResponse.json(
          {
            ok: false,
            degraded: true,
            medicines: [],
            findings: [],
            totals: { itemsRecognized: 0, itemsTotal: 0 },
            error: err instanceof Error ? err.message : "Vision OCR failed",
          } as unknown as DecodeResponse,
          { status: 200 }
        );
      }
    } else {
      return NextResponse.json({ ok: false, error: "Provide imageBase64 or sampleId" }, { status: 400 });
    }

    const medicines = buildMedicines(ocr);
    const findings = runSafetyEngine(medicines, await disabledRuleIds());

    const brandBdt = medicines.reduce((acc, m) => acc + (m.lineTotalBdt ?? 0), 0);
    const genericBdt = medicines.reduce((acc, m) => acc + (m.genericLineTotalBdt ?? 0), 0);
    const recognized = medicines.filter((m) => m.brand).length;

    const totals = {
      brandBdt: brandBdt > 0 ? Math.round(brandBdt * 100) / 100 : null,
      genericBdt: genericBdt > 0 ? Math.round(genericBdt * 100) / 100 : null,
      savingsBdt: brandBdt > 0 ? Math.round((brandBdt - genericBdt) * 100) / 100 : null,
      savingsPct: brandBdt > 0 ? Math.round(((brandBdt - genericBdt) / brandBdt) * 100) : null,
      paracetamolMgPerDay:
        medicines.reduce((acc, m) => {
          if (!m.generic || !m.perDay) return acc;
          const pc = m.generic.match(/Paracetamol\s*(\d+)/i);
          return pc ? acc + parseInt(pc[1], 10) * m.perDay : acc;
        }, 0) || null,
      itemsRecognized: recognized,
      itemsTotal: medicines.length,
    };

    const res: DecodeResponse = {
      ok: true,
      engine,
      degraded,
      source,
      ocr,
      medicines,
      findings,
      totals,
    };
    return NextResponse.json(res);
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "Decode failed" },
      { status: 500 }
    );
  }
}
