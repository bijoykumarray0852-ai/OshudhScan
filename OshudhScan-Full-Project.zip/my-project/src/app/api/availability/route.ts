import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { withApi, ok, fail, searchParams } from "@/lib/api";
import { haversineKm, stockStatus, isExpiredBatch, STALE_AFTER_HOURS } from "@/lib/geo";

// GET /api/availability?medicineId= | q=  (&lat=&lng=&district=&distance=)
// LIVE AVAILABILITY SEARCH — reports ONLY what pharmacies actually reported.
// Freshness rules: stock older than STALE_AFTER_HOURS is shown as STALE and
// must be confirmed by phone. No availability is guaranteed until confirmed.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const medicineId = sp.get("medicineId");
  const q = sp.get("q")?.trim();
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  const division = sp.get("division");
  const district = sp.get("district");
  const upazila = sp.get("upazila");
  const distance = Math.min(50, Math.max(0.5, parseFloat(sp.get("distance") ?? "") || 10));

  if (!medicineId && !q) return fail(400, "VALIDATION", "Provide medicineId or q");

  const medicineWhere: Record<string, unknown> = { isActive: true };
  if (medicineId) medicineWhere.id = medicineId;
  else if (q) medicineWhere.OR = [{ brand: { contains: q } }, { generic: { contains: q } }];

  const medicines = await db.medicine.findMany({ where: medicineWhere, take: 5 });
  if (medicines.length === 0) return ok({ medicines: [], results: [], note: "No registered medicine matches — the knowledge base grows with verified records." });

  const medIds = medicines.map((m) => m.id);
  const now = new Date();

  const pharmacies = await db.pharmacy.findMany({
    where: {
      deletedAt: null,
      ...(division ? { division } : {}),
      ...(district ? { district } : {}),
      ...(upazila ? { upazila } : {}),
      inventory: { some: { medicineId: { in: medIds }, status: "ACTIVE" } },
    },
    include: {
      inventory: { where: { medicineId: { in: medIds }, status: "ACTIVE" }, select: { medicineId: true, quantity: true, sellingPrice: true, updatedAt: true, expiryDate: true } },
    },
    take: division || district || upazila ? 500 : 300,
  });

  const hasGeo = !Number.isNaN(lat) && !Number.isNaN(lng);
  const results = pharmacies
    .map((p) => {
      const batches = p.inventory.filter((inv) => !isExpiredBatch(inv.expiryDate, now));
      if (batches.length === 0) return null;
      const qty = batches.reduce((acc, inv) => acc + inv.quantity, 0);
      const lastUpdate = batches.reduce((acc, inv) => (inv.updatedAt > acc ? inv.updatedAt : acc), batches[0].updatedAt);
      const price = batches.reduce((acc, inv) => (inv.sellingPrice !== null && inv.sellingPrice < acc ? inv.sellingPrice : acc), Infinity);
      const distanceKm = hasGeo && p.lat != null && p.lng != null ? haversineKm({ lat, lng }, { lat: p.lat, lng: p.lng }) : null;
      return {
        pharmacyId: p.id,
        pharmacyName: p.name,
        addressLine: p.addressLine,
        division: p.division,
        district: p.district,
        area: p.area,
        contactPhone: p.contactPhone,
        lat: p.lat,
        lng: p.lng,
        isVerified: p.isVerified,
        isDemo: p.isDemo,
        rating: p.rating,
        distanceKm,
        stockStatus: stockStatus(qty, lastUpdate, now),
        quantity: qty,
        indicativePrice: Number.isFinite(price) ? price : null,
        lastStockUpdate: lastUpdate,
        staleHours: STALE_AFTER_HOURS,
        medicine: medicines.find((m) => batches.some((b) => b.medicineId === m.id))
          ? { id: medicines[0].id, brand: medicines[0].brand, strength: medicines[0].strength, form: medicines[0].form }
          : null,
      };
    })
    .filter((r): r is NonNullable<typeof r> => r !== null)
    .filter((r) => (hasGeo ? r.distanceKm === null || r.distanceKm <= distance : true))
    .sort((a, b) => {
      const order = { IN_STOCK: 0, LOW_STOCK: 1, UNKNOWN: 2, STALE: 3, OUT_OF_STOCK: 4 } as Record<string, number>;
      if (order[a.stockStatus] !== order[b.stockStatus]) return order[a.stockStatus] - order[b.stockStatus];
      if (a.distanceKm !== null && b.distanceKm !== null) return a.distanceKm - b.distanceKm;
      return 0;
    })
    .slice(0, 50);

  return ok({
    medicines: medicines.map((m) => ({ id: m.id, brand: m.brand, generic: m.generic, genericBangla: m.genericBangla, strength: m.strength, form: m.form, unitPriceBdt: m.unitPriceBdt })),
    results,
    note: "Stock reflects what pharmacies reported. Old records are marked stale — call the pharmacy to confirm before travelling.",
  });
}, { rate: { limit: 90, windowMs: 60_000 } });
