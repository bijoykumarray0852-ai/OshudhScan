import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, searchParams, audit } from "@/lib/api";
import { requireUser } from "@/lib/auth";

// GET /api/family — family member profiles.
export const GET = withApi(async ({ user }) => {
  const u = await requireUser();
  const members = await db.familyMember.findMany({ where: { ownerUserId: u.id, deletedAt: null }, orderBy: { createdAt: "asc" } });
  return ok({
    members: members.map((m) => ({
      id: m.id,
      name: m.name,
      relation: m.relation,
      ageYears: m.ageYears,
      gender: m.gender,
      allergies: m.allergies ? JSON.parse(m.allergies) : [],
      chronicConditions: m.chronicConditions ? JSON.parse(m.chronicConditions) : [],
      notes: m.notes,
    })),
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

const upsertSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1).max(80),
  relation: z.enum(["SELF", "SPOUSE", "FATHER", "MOTHER", "SON", "DAUGHTER", "OTHER"]),
  ageYears: z.number().int().min(0).max(120).optional(),
  gender: z.enum(["MALE", "FEMALE", "OTHER"]).optional(),
  allergies: z.array(z.string().max(60)).max(10).optional(),
  chronicConditions: z.array(z.string().max(80)).max(10).optional(),
  notes: z.string().max(300).optional(),
});

// POST /api/family — add or update a family member.
export const POST = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, upsertSchema);
  if (body.id) {
    const existing = await db.familyMember.findFirst({ where: { id: body.id, ownerUserId: u.id, deletedAt: null } });
    if (!existing) return fail(404, "NOT_FOUND", "Family member not found");
    await db.familyMember.update({
      where: { id: existing.id },
      data: {
        name: body.name, relation: body.relation, ageYears: body.ageYears, gender: body.gender,
        allergies: body.allergies ? JSON.stringify(body.allergies) : existing.allergies,
        chronicConditions: body.chronicConditions ? JSON.stringify(body.chronicConditions) : existing.chronicConditions,
        notes: body.notes,
      },
    });
    return ok({ updated: true });
  }
  const member = await db.familyMember.create({
    data: {
      ownerUserId: u.id,
      name: body.name,
      relation: body.relation,
      ageYears: body.ageYears,
      gender: body.gender,
      allergies: body.allergies ? JSON.stringify(body.allergies) : null,
      chronicConditions: body.chronicConditions ? JSON.stringify(body.chronicConditions) : null,
      notes: body.notes,
    },
  });
  return ok({ member: { id: member.id, name: member.name } }, { status: 201 });
}, { auth: true, rate: { limit: 30, windowMs: 60_000 } });

// DELETE /api/family?id=
export const DELETE = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const id = searchParams(req).get("id");
  if (!id) return fail(400, "VALIDATION", "id required");
  const member = await db.familyMember.findFirst({ where: { id, ownerUserId: u.id, deletedAt: null } });
  if (!member) return fail(404, "NOT_FOUND", "Family member not found");
  await db.familyMember.update({ where: { id: member.id }, data: { deletedAt: new Date() } });
  await audit(req, { userId: u.id, action: "FAMILY_DELETE", entity: "family_member", entityId: member.id });
  return ok({ deleted: true });
}, { auth: true, rate: { limit: 30, windowMs: 60_000 } });
