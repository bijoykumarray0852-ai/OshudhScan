import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, withAuthApi, ok, parseJson, fail, audit } from "@/lib/api";

// GET /api/admin/rules — the clinical rule registry (governance layer over the
// deterministic engine). Publication requires an authorized review trail.
export const GET = withAuthApi(async () => {
  const rules = await db.clinicalRule.findMany({
    orderBy: { ruleId: "asc" },
    include: { reviewer: { select: { name: true } } },
  });
  return ok({
    rules: rules.map((r) => ({
      id: r.id,
      ruleId: r.ruleId,
      title: r.title,
      severity: r.severity,
      triggerDescription: r.triggerDescription,
      clinicalExplanation: r.clinicalExplanation,
      recommendedAction: r.recommendedAction,
      evidenceSource: r.evidenceSource,
      evidenceLevel: r.evidenceLevel,
      lastReviewedAt: r.lastReviewedAt,
      reviewer: r.reviewer?.name ?? null,
      status: r.status,
      enabled: r.enabled,
    })),
    engineNote: "The deterministic engine (src/lib/interactions.ts) reads this registry's enabled/status flags at decode time. Retiring a rule here stops it firing.",
  });
}, { roles: ["ADMIN"], rate: { limit: 60, windowMs: 60_000 } });

// PATCH /api/admin/rules — retire / re-enable a rule (audited decision).
export const PATCH = withAuthApi(async ({ req, user: admin }) => {
  const body = await parseJson(req, z.object({
    ruleId: z.string(),
    action: z.enum(["RETIRE", "ENABLE", "REVIEW"]),
  }));
  const rule = await db.clinicalRule.findUnique({ where: { ruleId: body.ruleId } });
  if (!rule) return fail(404, "NOT_FOUND", "Rule not found");

  const data: Record<string, unknown> = {};
  if (body.action === "RETIRE") { data.status = "RETIRED"; data.enabled = false; }
  if (body.action === "ENABLE") { data.status = "PUBLISHED"; data.enabled = true; }
  if (body.action === "REVIEW") { data.lastReviewedAt = new Date(); }
  data.reviewedById = admin.id;

  await db.clinicalRule.update({ where: { ruleId: rule.ruleId }, data });
  await audit(req, { userId: admin.id, action: `RULE_${body.action}`, entity: "clinical_rule", entityId: rule.ruleId });
  return ok({ rule: { ruleId: rule.ruleId, status: data.status ?? rule.status, enabled: data.enabled ?? rule.enabled } });
}, { roles: ["ADMIN"], rate: { limit: 20, windowMs: 60_000 } });
