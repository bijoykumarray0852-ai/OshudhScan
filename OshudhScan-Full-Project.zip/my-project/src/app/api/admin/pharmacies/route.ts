import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, withAuthApi, ok, parseJson, fail, audit, searchParams } from "@/lib/api";

// GET /api/admin/pharmacies?status=PENDING — verification queue + registry.
export const GET = withAuthApi(async ({ req }) => {
  const status = searchParams(req).get("status");
  const where: Record<string, unknown> = { deletedAt: null };
  if (status && status !== "ALL") where.status = status;
  const pharmacies = await db.pharmacy.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      verifications: { orderBy: { submittedAt: "desc" }, take: 1 },
      owner: { select: { name: true, email: true } },
      _count: { select: { inventory: true } },
    },
  });
  return ok({
    pharmacies: pharmacies.map((p) => ({
      id: p.id,
      name: p.name,
      district: p.district,
      upazila: p.upazila,
      addressLine: p.addressLine,
      contactPhone: p.contactPhone,
      licenseNumber: p.licenseNumber,
      status: p.status,
      isVerified: p.isVerified,
      isDemo: p.isDemo,
      createdAt: p.createdAt,
      owner: p.owner,
      inventoryCount: p._count.inventory,
      latestVerification: p.verifications[0]
        ? { id: p.verifications[0].id, licenseType: p.verifications[0].licenseType, pharmacistName: p.verifications[0].pharmacistName, pharmacistReg: p.verifications[0].pharmacistReg, submittedAt: p.verifications[0].submittedAt, status: p.verifications[0].status }
        : null,
    })),
  });
}, { roles: ["ADMIN"], rate: { limit: 60, windowMs: 60_000 } });

// PATCH /api/admin/pharmacies — approve/reject verification (admin decision).
// Verified status is granted ONLY here — never automatically.
export const PATCH = withAuthApi(async ({ req, user }) => {
  const admin = user;
  const body = await parseJson(req, z.object({
    pharmacyId: z.string(),
    decision: z.enum(["APPROVE", "REJECT", "SUSPEND"]),
    reviewNote: z.string().max(300).optional(),
  }));

  const pharmacy = await db.pharmacy.findUnique({ where: { id: body.pharmacyId } });
  if (!pharmacy) return fail(404, "NOT_FOUND", "Pharmacy not found");
  const pending = await db.pharmacyVerification.findFirst({ where: { pharmacyId: pharmacy.id, status: "PENDING" }, orderBy: { submittedAt: "desc" } });

  if (body.decision === "APPROVE") {
    if (!pending && !pharmacy.isDemo) {
      return fail(422, "VALIDATION", "No verification request on record — verified status requires an actual submission");
    }
    await db.pharmacy.update({ where: { id: pharmacy.id }, data: { status: "VERIFIED", isVerified: true } });
    if (pending) {
      await db.pharmacyVerification.update({ where: { id: pending.id }, data: { status: "APPROVED", reviewedById: admin.id, reviewNote: body.reviewNote, reviewedAt: new Date() } });
    }
    if (pharmacy.ownerUserId) {
      await db.notification.create({ data: { userId: pharmacy.ownerUserId, type: "VERIFICATION", title: "Pharmacy verified", body: `${pharmacy.name} passed admin verification — the Verified badge is now live.`, data: JSON.stringify({ pharmacyId: pharmacy.id }) } });
    }
  } else if (body.decision === "REJECT") {
    await db.pharmacy.update({ where: { id: pharmacy.id }, data: { status: "REJECTED", isVerified: false } });
    if (pending) {
      await db.pharmacyVerification.update({ where: { id: pending.id }, data: { status: "REJECTED", reviewedById: admin.id, reviewNote: body.reviewNote, reviewedAt: new Date() } });
    }
    if (pharmacy.ownerUserId) {
      await db.notification.create({ data: { userId: pharmacy.ownerUserId, type: "VERIFICATION", title: "Verification rejected", body: `${pharmacy.name}: ${body.reviewNote ?? "please review the submission requirements and resubmit."}`, data: JSON.stringify({ pharmacyId: pharmacy.id }) } });
    }
  } else {
    await db.pharmacy.update({ where: { id: pharmacy.id }, data: { status: "SUSPENDED", isVerified: false } });
  }
  await audit(req, { userId: admin.id, action: `PHARMACY_${body.decision}`, entity: "pharmacy", entityId: pharmacy.id, detail: { note: body.reviewNote } });
  return ok({ pharmacy: { id: pharmacy.id, status: body.decision === "APPROVE" ? "VERIFIED" : body.decision === "REJECT" ? "REJECTED" : "SUSPENDED" } });
}, { roles: ["ADMIN"], rate: { limit: 30, windowMs: 60_000 } });

// DELETE /api/admin/pharmacies?id= — soft-delete a directory record (removes it
// from all public searches). Relation rows are cleared first (SQLite FKs).
export const DELETE = withAuthApi(async ({ req, user }) => {
  const admin = user;
  const id = searchParams(req).get("id") ?? "";
  const pharmacy = await db.pharmacy.findUnique({ where: { id } });
  if (!pharmacy) return fail(404, "NOT_FOUND", "Pharmacy not found");

  const invIds = (await db.pharmacyInventory.findMany({ where: { pharmacyId: id }, select: { id: true } })).map((r) => r.id);
  await db.inventoryMovement.deleteMany({ where: { OR: [{ fromPharmacyId: id }, { toPharmacyId: id }, { inventoryId: { in: invIds.length ? invIds : ["__none__"] } }] } });
  await db.pharmacyInventory.deleteMany({ where: { pharmacyId: id } });
  await db.payment.deleteMany({ where: { subscription: { pharmacyId: id } } });
  await db.subscription.deleteMany({ where: { pharmacyId: id } });
  await db.pharmacyVerification.deleteMany({ where: { pharmacyId: id } });
  await db.lead.deleteMany({ where: { pharmacyId: id } });
  await db.medicineReservation.deleteMany({ where: { pharmacyId: id } });
  await db.pharmacyStaff.deleteMany({ where: { pharmacyId: id } });
  await db.pharmacyBranch.deleteMany({ where: { pharmacyId: id } });
  await db.supplier.deleteMany({ where: { pharmacyId: id } });
  await db.pharmacy.delete({ where: { id } });
  await audit(req, { userId: admin.id, action: "PHARMACY_DELETE", entity: "pharmacy", entityId: id });
  return ok({ deleted: id });
}, { roles: ["ADMIN"], rate: { limit: 30, windowMs: 60_000 } });
