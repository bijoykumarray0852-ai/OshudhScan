import { db } from "@/lib/db";
import { withApi, withAuthApi, ok, searchParams, pageArgs } from "@/lib/api";

// GET /api/admin/audit — audit trail (no clinical content is ever logged).
export const GET = withAuthApi(async ({ req }) => {
  const { skip, take, page, pageSize } = pageArgs(searchParams(req), 50);
  const action = searchParams(req).get("action");
  const where: Record<string, unknown> = {};
  if (action) where.action = { contains: action };
  const [rows, total] = await Promise.all([
    db.auditLog.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip,
      take,
      include: { user: { select: { name: true, role: true } } },
    }),
    db.auditLog.count({ where }),
  ]);
  return ok({
    page,
    pageSize,
    total,
    logs: rows.map((l) => ({
      id: l.id,
      action: l.action,
      entity: l.entity,
      entityId: l.entityId,
      detail: l.detail ? JSON.parse(l.detail) : null,
      user: l.user,
      ip: l.ip,
      createdAt: l.createdAt,
    })),
  });
}, { roles: ["ADMIN"], rate: { limit: 60, windowMs: 60_000 } });
