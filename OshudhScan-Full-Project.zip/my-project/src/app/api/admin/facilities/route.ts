import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, withAuthApi, ok, parseJson, fail, audit, searchParams, pageArgs } from "@/lib/api";

// GET /api/admin/facilities — facility registry.
export const GET = withAuthApi(async ({ req }) => {
  const { skip, take } = pageArgs(searchParams(req), 50);
  const rows = await db.healthcareFacility.findMany({
    where: { deletedAt: null },
    orderBy: { createdAt: "desc" },
    skip,
    take,
  });
  const doctors = await db.doctor.findMany({ where: { deletedAt: null }, include: { facility: { select: { name: true } } }, take: 100 });
  return ok({
    facilities: rows.map((f) => ({
      id: f.id, name: f.name, type: f.type, ownership: f.ownership, district: f.district, division: f.division,
      addressLine: f.addressLine, phone: f.phone, isPhoneVerified: f.isPhoneVerified, emergency: f.emergency,
      source: f.source, verifiedAt: f.verifiedAt,
    })),
    doctors: doctors.map((d) => ({ id: d.id, name: d.name, specialty: d.specialty, degrees: d.degrees, facility: d.facility?.name, isVerified: d.isVerified, source: d.source })),
  });
}, { roles: ["ADMIN"], rate: { limit: 60, windowMs: 60_000 } });

// POST /api/admin/facilities — add facility/doctor ONLY with a cited source.
// Records without a source are rejected — no invented entries.
export const POST = withAuthApi(async ({ req, user: admin }) => {
  const body = await parseJson(req, z.object({
    kind: z.enum(["FACILITY", "DOCTOR"]),
    name: z.string().min(2).max(120),
    nameBangla: z.string().max(120).optional(),
    type: z.enum(["HOSPITAL", "CLINIC", "DIAGNOSTIC", "BLOOD_BANK", "AMBULANCE_SERVICE"]).optional(),
    ownership: z.enum(["PUBLIC", "PRIVATE", "NGO"]).optional(),
    division: z.string().optional(),
    district: z.string().optional(),
    area: z.string().optional(),
    addressLine: z.string().min(5).max(200).optional(),
    lat: z.number().optional(),
    lng: z.number().optional(),
    phone: z.string().max(20).optional(),
    emergency: z.boolean().optional(),
    specialties: z.array(z.string().max(40)).optional(),
    // doctor fields
    doctorSpecialty: z.string().max(60).optional(),
    degrees: z.string().max(120).optional(),
    designation: z.string().max(120).optional(),
    facilityId: z.string().optional(),
    // source is mandatory for every record
    source: z.string().min(4).max(200),
    phoneVerified: z.boolean().optional(),
  }));

  if (!body.source || body.source.trim().length < 4) {
    return fail(422, "VALIDATION", "A source reference is mandatory — records without a source are not accepted");
  }

  if (body.kind === "FACILITY") {
    if (!body.type || !body.addressLine || !body.district) return fail(422, "VALIDATION", "type, addressLine and district are required for facilities");
    const facility = await db.healthcareFacility.create({
      data: {
        name: body.name, nameBangla: body.nameBangla, type: body.type, ownership: body.ownership ?? "PUBLIC",
        division: body.division, district: body.district, area: body.area, addressLine: body.addressLine,
        lat: body.lat, lng: body.lng, phone: body.phone ?? null,
        isPhoneVerified: body.phoneVerified ?? false, emergency: body.emergency ?? false,
        specialties: body.specialties ? JSON.stringify(body.specialties) : null,
        source: body.source, verifiedAt: new Date(),
      },
    });
    await audit(req, { userId: admin.id, action: "FACILITY_ADD", entity: "healthcare_facility", entityId: facility.id, detail: { source: body.source } });
    return ok({ facility: { id: facility.id } }, { status: 201 });
  }

  // DOCTOR — verified at entry because an admin with a cited source created it
  if (!body.doctorSpecialty) return fail(422, "VALIDATION", "doctorSpecialty required");
  const doctor = await db.doctor.create({
    data: {
      name: body.name, specialty: body.doctorSpecialty, degrees: body.degrees,
      designation: body.designation, facilityId: body.facilityId ?? null, phone: body.phone ?? null,
      isVerified: true, source: body.source,
    },
  });
  await audit(req, { userId: admin.id, action: "DOCTOR_ADD", entity: "doctor", entityId: doctor.id, detail: { source: body.source } });
  return ok({ doctor: { id: doctor.id } }, { status: 201 });
}, { roles: ["ADMIN"], rate: { limit: 30, windowMs: 60_000 } });

// PATCH /api/admin/facilities — attach a REGISTERED barcode to a medicine.
export const PATCH = withAuthApi(async ({ req, user: admin }) => {
  const body = await parseJson(req, z.object({
    medicineId: z.string(),
    barcode: z.string().regex(/^[0-9A-Za-z\-]{6,40}$/),
  }));
  const clash = await db.medicine.findUnique({ where: { barcode: body.barcode } });
  if (clash) return fail(409, "CONFLICT", "This barcode is already registered to another medicine");
  const med = await db.medicine.findUnique({ where: { id: body.medicineId } });
  if (!med) return fail(404, "NOT_FOUND", "Medicine not found");
  await db.medicine.update({ where: { id: med.id }, data: { barcode: body.barcode } });
  await audit(req, { userId: admin.id, action: "BARCODE_REGISTER", entity: "medicine", entityId: med.id, detail: { barcode: body.barcode } });
  return ok({ medicine: { id: med.id, barcode: body.barcode } });
}, { roles: ["ADMIN"], rate: { limit: 30, windowMs: 60_000 } });
