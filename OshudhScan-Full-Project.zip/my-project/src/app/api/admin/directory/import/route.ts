import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, fail, parseJson, searchParams, audit } from "@/lib/api";
import { requireRole, ApiError } from "@/lib/auth";
import { recordKey, normalizePhoneBd, parseCsv, qualityScore, facilityQualityFields } from "@/lib/directory";

const importSchema = z.object({
  entityType: z.enum(["FACILITY", "PHARMACY"]),
  sourceType: z.enum(["DGHS", "GOOGLE_PLACES", "CSV", "EXCEL", "JSON", "MANUAL"]),
  fileName: z.string().max(200).optional(),
  content: z.string().min(1).max(2_000_000),
  format: z.enum(["CSV", "JSON"]).default("CSV"),
  // by default imported rows are UNVERIFIED; admins may set OFFICIALLY_LISTED
  // only when the import genuinely came from an official source
  markOfficiallyListed: z.boolean().optional(),
});

function pick(row: Record<string, string>, keys: string[]): string | undefined {
  for (const k of keys) {
    const v = row[k] ?? row[k.toLowerCase()] ?? row[k.toUpperCase()];
    if (v !== undefined && v !== "") return v;
  }
  return undefined;
}

// POST /api/admin/directory/import — ingestion pipeline (CSV / JSON rows).
// Dedup: normalized-name+district key, phone match, placeId. New rows land
// UNVERIFIED with a computed quality score; duplicates are skipped and
// reported. Every job + error row is stored for the admin dashboard.
export const POST = withApi(async ({ req }) => {
  const admin = await requireRole("ADMIN");
  const body = await parseJson(req, importSchema);

  let rows: Record<string, string>[] = [];
  try {
    if (body.format === "JSON") {
      const parsed = JSON.parse(body.content) as unknown;
      rows = (Array.isArray(parsed) ? parsed : [parsed]) as Record<string, string>[];
    } else {
      const parsed = parseCsv(body.content);
      if (parsed.length < 2) return fail(400, "VALIDATION", "CSV needs a header row and at least one data row");
      const headers = parsed[0].map((h) => h.trim());
      rows = parsed.slice(1).map((cells) => Object.fromEntries(headers.map((h, i) => [h, (cells[i] ?? "").trim()])));
    }
  } catch (err) {
    return fail(400, "VALIDATION", err instanceof Error ? `Parse error: ${err.message}` : "Could not parse content");
  }
  if (!rows.length) return fail(400, "VALIDATION", "No data rows found");

  const job = await db.directoryImportJob.create({
    data: {
      sourceType: body.sourceType, entityType: body.entityType, fileName: body.fileName,
      status: "RUNNING", totalRows: rows.length, startedById: admin.id,
    },
  });

  let imported = 0, duplicates = 0, errors = 0;
  const errorLog: { rowNumber: number; field?: string; message: string; raw?: string }[] = [];

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    try {
      const name = pick(row, ["name", "facilityName", "pharmacyName", "Name"]);
      const district = pick(row, ["district", "District"]);
      if (!name || !district) throw new Error("name and district are required fields");
      const upazila = pick(row, ["upazila", "Upazila"]) ?? null;
      const latStr = pick(row, ["lat", "latitude", "Lat"]);
      const lngStr = pick(row, ["lng", "lng", "longitude", "Lng"]);
      const lat = latStr ? parseFloat(latStr) : null;
      const lng = lngStr ? parseFloat(lngStr) : null;
      if ((latStr && lat === null) || (lngStr && lng === null)) throw new Error("invalid lat/lng value");
      const phoneRaw = pick(row, ["phone", "contactPhone", "phoneNumber", "Phone"]);
      const phone = phoneRaw ? normalizePhoneBd(phoneRaw) : null;
      if (phoneRaw && !phone) throw new Error(`invalid phone number: ${phoneRaw}`);

      // duplicate detection: normalized name+district key across ALL records in
      // the district, plus phone match. Names compared via recordKey so that
      // "X Hospital" vs "X" vs "X Ltd" collapse to the same identity.
      const key = recordKey(name, district, upazila);
      if (body.entityType === "FACILITY") {
        const candidates = await db.healthcareFacility.findMany({ where: { district, deletedAt: null }, select: { id: true, name: true, upazila: true, phone: true } });
        const existing =
          candidates.find((c) => recordKey(c.name, district, c.upazila) === key) ??
          (phone ? candidates.find((c) => c.phone === phone) : undefined) ??
          (phone ? await db.healthcareFacility.findFirst({ where: { phone, deletedAt: null }, select: { id: true, name: true, upazila: true, phone: true } }) : null);
        if (existing) { duplicates++; continue; }
        const fields = {
          name, nameBangla: pick(row, ["nameBangla", "nameBn"]) ?? null, type: pick(row, ["type"]) ?? "HOSPITAL",
          ownership: pick(row, ["ownership"]) ?? null, division: pick(row, ["division"]) ?? null,
          district, upazila, addressLine: pick(row, ["address", "addressLine"]) ?? district,
          lat, lng, phone, services: pick(row, ["services"]) ?? null, source: `${body.sourceType} import (job ${job.id})`,
          verificationStatus: body.markOfficiallyListed && body.sourceType === "DGHS" ? "OFFICIALLY_LISTED" : "UNVERIFIED",
        };
        await db.healthcareFacility.create({
          // facilityQualityFields derives `verified` from verificationStatus itself
          data: { ...fields, qualityScore: qualityScore(facilityQualityFields(fields)), verifiedAt: fields.verificationStatus !== "UNVERIFIED" ? new Date() : null, sourceType: body.sourceType },
        });
        imported++;
      } else {
        const candidates = await db.pharmacy.findMany({ where: { district, deletedAt: null }, select: { id: true, name: true, upazila: true, contactPhone: true } });
        const existing =
          candidates.find((c) => recordKey(c.name, district, c.upazila) === key) ??
          (phone ? candidates.find((c) => c.contactPhone.replace(/\D/g, "").endsWith(phone.slice(2))) : undefined) ??
          (phone ? await db.pharmacy.findFirst({ where: { contactPhone: { contains: phone.slice(2) }, deletedAt: null }, select: { id: true, name: true, upazila: true, contactPhone: true } }) : null);
        if (existing) { duplicates++; continue; }
        const license = pick(row, ["licenseNumber", "drugLicense", "license"]) ?? null;
        // Pharmacy.division is a required column — resolve it from the
        // administrative hierarchy when the CSV row does not carry it.
        const districtRow = await db.administrativeLocation.findFirst({
          where: { level: "DISTRICT", name: district },
          select: { division: true },
        });
        const division = pick(row, ["division"]) ?? districtRow?.division ?? "";
        const fields = {
          name, nameBangla: pick(row, ["nameBangla", "nameBn"]) ?? null, contactPhone: phone ?? "",
          addressLine: pick(row, ["address", "addressLine"]) ?? district, division,
          district, upazila, lat, lng, licenseNumber: license,
          sourceName: `${body.sourceType} import (job ${job.id})`, sourceType: body.sourceType,
          verificationStatus: body.markOfficiallyListed && body.sourceType === "DGHS" ? "OFFICIALLY_LISTED" : "UNVERIFIED",
        };
        await db.pharmacy.create({
          data: { ...fields, qualityScore: qualityScore({ name: true, nameBangla: Boolean(fields.nameBangla), type: true, ownership: true, division: Boolean(fields.division), district: true, upazila: Boolean(fields.upazila), address: true, latLng: lat != null && lng != null, phone: Boolean(phone), services: false, source: true, verified: fields.verificationStatus !== "UNVERIFIED" }), lastVerifiedAt: fields.verificationStatus !== "UNVERIFIED" ? new Date() : null },
        });
        imported++;
      }
    } catch (err) {
      errors++;
      errorLog.push({ rowNumber: i + 1, message: err instanceof Error ? err.message : "unknown error", raw: JSON.stringify(row).slice(0, 500) });
    }
  }

  const finished = await db.directoryImportJob.update({
    where: { id: job.id },
    data: {
      status: errors === 0 ? "COMPLETED" : imported > 0 ? "PARTIAL" : "FAILED",
      importedRows: imported, duplicateRows: duplicates, errorRows: errors,
      summary: JSON.stringify({ imported, duplicates, errors }),
      finishedAt: new Date(),
    },
  });
  if (errorLog.length) {
    await db.directoryImportError.createMany({ data: errorLog.slice(0, 100).map((e) => ({ jobId: job.id, rowNumber: e.rowNumber, message: e.message, raw: e.raw })) });
  }
  await audit(req, { userId: admin.id, action: "DIRECTORY_IMPORT", entity: "directory_import_job", entityId: job.id, detail: { imported, duplicates, errors } });
  return ok({ job: { id: finished.id, status: finished.status, totalRows: finished.totalRows, importedRows: imported, duplicateRows: duplicates, errorRows: errors } });
}, { auth: true, rate: { limit: 10, windowMs: 60 * 60_000 } });

// GET /api/admin/directory/import — list recent jobs with error counts.
export const GET = withApi(async () => {
  const jobs = await db.directoryImportJob.findMany({
    orderBy: { createdAt: "desc" },
    take: 20,
    include: { errors: { take: 5, orderBy: { rowNumber: "asc" } }, startedBy: { select: { name: true } } },
  });
  return ok({ jobs });
});
