import { db } from "@/lib/db";
import { withApi, ok } from "@/lib/api";

// GET /api/admin/directory/coverage — national coverage statistics computed
// from actual database records (never claimed beyond what is measured).
export const GET = withApi(async () => {
  const [totalFacilities, totalPharmacies, totalLocations] = await Promise.all([
    db.healthcareFacility.count({ where: { deletedAt: null } }),
    db.pharmacy.count({ where: { deletedAt: null } }),
    db.administrativeLocation.count(),
  ]);

  const byType = await db.healthcareFacility.groupBy({ by: ["type"], _count: true, where: { deletedAt: null } });
  const byCategory = await db.healthcareFacility.groupBy({ by: ["hospitalCategory"], _count: true, where: { deletedAt: null, type: "HOSPITAL" } });
  const byDivisionF = await db.healthcareFacility.groupBy({ by: ["division"], _count: true, where: { deletedAt: null } });
  const byDivisionP = await db.pharmacy.groupBy({ by: ["division"], _count: true, where: { deletedAt: null } });
  const byDistrict = await db.healthcareFacility.groupBy({ by: ["district"], _count: true, where: { deletedAt: null } });
  const byVerification = await db.healthcareFacility.groupBy({ by: ["verificationStatus"], _count: true, where: { deletedAt: null } });
  const pharmacyVerification = await db.pharmacy.groupBy({ by: ["verificationStatus"], _count: true, where: { deletedAt: null } });

  const missingPhone = await db.healthcareFacility.count({ where: { deletedAt: null, phone: null } });
  const missingCoords = await db.healthcareFacility.count({ where: { deletedAt: null, OR: [{ lat: null }, { lng: null }] } });
  const pharmMissingPhone = await db.pharmacy.count({ where: { deletedAt: null, contactPhone: "" } });

  const districts = await db.administrativeLocation.findMany({ where: { level: "DISTRICT" }, select: { name: true, division: true } });
  const districtFacilityCounts = new Map(byDistrict.map((d) => [d.district ?? "", d._count]));
  const districtsCovered = districts.filter((d) => (districtFacilityCounts.get(d.name) ?? 0) > 0).length;

  return ok({
    totals: {
      facilities: totalFacilities,
      pharmacies: totalPharmacies,
      locations: totalLocations,
      divisions: 8,
      districts: 64,
      districtsCovered,
      upazilas: await db.administrativeLocation.count({ where: { level: "UPAZILA" } }),
      coverageNote: `${districtsCovered} of 64 districts have at least one facility record — national coverage grows via imports.`,
    },
    facilitiesByType: byType.map((t) => ({ type: t.type, count: t._count })),
    hospitalsByCategory: byCategory.filter((c) => c.hospitalCategory).map((c) => ({ category: c.hospitalCategory, count: c._count })),
    facilitiesByDivision: byDivisionF.map((d) => ({ division: d.division, count: d._count })).sort((a, b) => (a.division ?? "").localeCompare(b.division ?? "")),
    pharmaciesByDivision: byDivisionP.map((d) => ({ division: d.division, count: d._count })).sort((a, b) => (a.division ?? "").localeCompare(b.division ?? "")),
    facilitiesByVerification: byVerification.map((v) => ({ status: v.verificationStatus, count: v._count })),
    pharmaciesByVerification: pharmacyVerification.map((v) => ({ status: v.verificationStatus, count: v._count })),
    dataGaps: { facilitiesMissingPhone: missingPhone, facilitiesMissingCoordinates: missingCoords, pharmaciesMissingPhone: pharmMissingPhone },
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
