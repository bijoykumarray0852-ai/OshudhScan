import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, fail, parseJson, audit } from "@/lib/api";
import { requireRole } from "@/lib/auth";

const actionSchema = z.object({
  reportId: z.string().min(1),
  action: z.enum(["REVIEWING", "RESOLVED", "REJECTED"]),
  resolutionNote: z.string().max(500).optional(),
  // when resolving with a correction, admin can apply suggested values
  applyCorrection: z.boolean().optional(),
});

// POST /api/admin/directory/reports — review user-submitted reports.
// Corrections are applied only when an admin explicitly confirms.
export const POST = withApi(async ({ req }) => {
  const admin = await requireRole("ADMIN");
  const body = await parseJson(req, actionSchema);
  const report = await db.facilityReport.findUnique({ where: { id: body.reportId } });
  if (!report) return fail(404, "NOT_FOUND", "Report not found");

  if (body.action === "RESOLVED" && body.applyCorrection && report.suggestedValue) {
    const isPhone = report.reportType === "WRONG_PHONE";
    if (report.entityType === "FACILITY") {
      const f = await db.healthcareFacility.findUnique({ where: { id: report.entityId } });
      if (f) {
        await db.healthcareFacility.update({
          where: { id: f.id },
          data: isPhone ? { phone: report.suggestedValue, isPhoneVerified: false, verificationStatus: "UNVERIFIED", lastVerifiedAt: null } : { addressLine: report.suggestedValue },
        });
      }
    } else if (report.entityType === "PHARMACY") {
      const p = await db.pharmacy.findUnique({ where: { id: report.entityId } });
      if (p) {
        await db.pharmacy.update({
          where: { id: p.id },
          data: isPhone ? { contactPhone: report.suggestedValue, isVerified: false, verificationStatus: "UNVERIFIED", lastVerifiedAt: null } : { addressLine: report.suggestedValue },
        });
      }
    }
  }

  const updated = await db.facilityReport.update({
    where: { id: report.id },
    data: {
      status: body.action,
      resolutionNote: body.resolutionNote,
      reviewedById: admin.id,
      reviewedAt: new Date(),
    },
  });
  await audit(req, { userId: admin.id, action: `DIRECTORY_REPORT_${body.action}`, entity: "facility_report", entityId: report.id, detail: { applyCorrection: Boolean(body.applyCorrection) } });
  return ok({ report: { id: updated.id, status: updated.status } });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
