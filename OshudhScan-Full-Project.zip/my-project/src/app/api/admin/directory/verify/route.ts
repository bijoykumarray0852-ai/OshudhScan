import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, fail, parseJson, audit } from "@/lib/api";
import { requireRole } from "@/lib/auth";
import { isVerificationStatus } from "@/lib/directory";

const schema = z.object({
  entityType: z.enum(["FACILITY", "PHARMACY"]),
  entityId: z.string().min(1),
  toStatus: z.string().min(1),
  method: z.string().min(2).max(200),
  evidenceUrl: z.string().url().max(500).optional(),
  note: z.string().max(500).optional(),
});

// POST /api/admin/directory/verify — move a record along the verification
// ladder. Every change writes an immutable VerificationEvent (provenance).
export const POST = withApi(async ({ req }) => {
  const admin = await requireRole("ADMIN");
  const body = await parseJson(req, schema);
  if (!isVerificationStatus(body.toStatus)) return fail(400, "VALIDATION", `Invalid verification status: ${body.toStatus}`);

  if (body.entityType === "FACILITY") {
    const f = await db.healthcareFacility.findUnique({ where: { id: body.entityId } });
    if (!f) return fail(404, "NOT_FOUND", "Facility not found");
    const updated = await db.healthcareFacility.update({
      where: { id: body.entityId },
      data: {
        verificationStatus: body.toStatus,
        lastVerifiedAt: new Date(),
        verifiedAt: f.verifiedAt ?? new Date(),
        isPhoneVerified: body.toStatus === "CONTACT_VERIFIED" ? true : f.isPhoneVerified,
        qualityScore: f.qualityScore,
      },
    });
    await db.verificationEvent.create({
      data: { entityType: "FACILITY", entityId: f.id, fromStatus: f.verificationStatus, toStatus: body.toStatus, method: body.method, evidenceUrl: body.evidenceUrl, note: body.note, actorId: admin.id },
    });
    await audit(req, { userId: admin.id, action: "DIRECTORY_VERIFY", entity: "healthcare_facility", entityId: f.id, detail: { toStatus: body.toStatus, method: body.method } });
    return ok({ facility: { id: updated.id, verificationStatus: updated.verificationStatus, lastVerifiedAt: updated.lastVerifiedAt } });
  }

  const p = await db.pharmacy.findUnique({ where: { id: body.entityId } });
  if (!p) return fail(404, "NOT_FOUND", "Pharmacy not found");
  const updated = await db.pharmacy.update({
    where: { id: body.entityId },
    data: {
      verificationStatus: body.toStatus,
      lastVerifiedAt: new Date(),
      isVerified: ["CONTACT_VERIFIED", "LICENSE_VERIFIED", "ADMIN_VERIFIED", "OFFICIALLY_LISTED"].includes(body.toStatus) ? true : p.isVerified,
      status: body.toStatus === "TEMPORARILY_CLOSED" || body.toStatus === "PERMANENTLY_CLOSED" ? "SUSPENDED" : p.status,
    },
  });
  await db.verificationEvent.create({
    data: { entityType: "PHARMACY", entityId: p.id, fromStatus: p.verificationStatus, toStatus: body.toStatus, method: body.method, evidenceUrl: body.evidenceUrl, note: body.note, actorId: admin.id },
  });
  await audit(req, { userId: admin.id, action: "DIRECTORY_VERIFY", entity: "pharmacy", entityId: p.id, detail: { toStatus: body.toStatus, method: body.method } });
  return ok({ pharmacy: { id: updated.id, verificationStatus: updated.verificationStatus, lastVerifiedAt: updated.lastVerifiedAt } });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
