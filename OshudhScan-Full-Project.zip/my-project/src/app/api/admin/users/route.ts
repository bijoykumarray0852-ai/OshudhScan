import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, withAuthApi, ok, parseJson, fail, searchParams, pageArgs, audit } from "@/lib/api";

// GET /api/admin/users — user registry (de-identified to admins' need-to-know).
export const GET = withAuthApi(async ({ req }) => {
  const { skip, take, page, pageSize } = pageArgs(searchParams(req), 25);
  const q = searchParams(req).get("q")?.trim();
  const where: Record<string, unknown> = { deletedAt: null };
  if (q) where.OR = [{ name: { contains: q } }, { email: { contains: q } }];
  const [rows, total] = await Promise.all([
    db.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip,
      take,
      select: { id: true, name: true, email: true, role: true, locale: true, createdAt: true, updatedAt: true },
    }),
    db.user.count({ where }),
  ]);
  return ok({ page, pageSize, total, users: rows });
}, { roles: ["ADMIN"], rate: { limit: 60, windowMs: 60_000 } });

// PATCH /api/admin/users — role change (admin only, audited).
export const PATCH = withAuthApi(async ({ req, user: admin }) => {
  const body = await parseJson(req, z.object({
    userId: z.string(),
    role: z.enum(["PATIENT", "PHARMACY_OWNER", "PHARMACY_STAFF", "PHARMACIST", "ADMIN"]),
  }));
  const target = await db.user.findUnique({ where: { id: body.userId } });
  if (!target || target.deletedAt) return fail(404, "NOT_FOUND", "User not found");
  await db.user.update({ where: { id: target.id }, data: { role: body.role } });
  await audit(req, { userId: admin.id, action: "USER_ROLE_CHANGE", entity: "user", entityId: target.id, detail: { role: body.role } });
  return ok({ user: { id: target.id, role: body.role } });
}, { roles: ["ADMIN"], rate: { limit: 20, windowMs: 60_000 } });

// DELETE /api/admin/users?id= — soft delete (admin).
export const DELETE = withAuthApi(async ({ req, user: admin }) => {
  const id = searchParams(req).get("id");
  if (!id) return fail(400, "VALIDATION", "id required");
  if (id === admin.id) return fail(422, "VALIDATION", "You cannot delete your own admin account here");
  const target = await db.user.findUnique({ where: { id } });
  if (!target || target.deletedAt) return fail(404, "NOT_FOUND", "User not found");
  await db.$transaction([
    db.user.update({ where: { id }, data: { deletedAt: new Date(), email: `deleted+${id}@oshudhscan.invalid`, name: "Deleted user", phone: null } }),
    db.session.deleteMany({ where: { userId: id } }),
  ]);
  await audit(req, { userId: admin.id, action: "USER_DELETE", entity: "user", entityId: id });
  return ok({ deleted: true });
}, { roles: ["ADMIN"], rate: { limit: 20, windowMs: 60_000 } });
