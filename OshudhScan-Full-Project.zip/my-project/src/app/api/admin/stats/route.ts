import { db } from "@/lib/db";
import { withApi, withAuthApi, ok } from "@/lib/api";

// GET /api/admin/stats — platform statistics (admin only).
export const GET = withAuthApi(async () => {
  const [patients, pharmacies, verifiedPharmacies, pendingVerifications, scans, medicines, rules, facilities, demoFacilities] = await Promise.all([
    db.user.count({ where: { role: "PATIENT", deletedAt: null } }),
    db.pharmacy.count({ where: { deletedAt: null } }),
    db.pharmacy.count({ where: { isVerified: true, deletedAt: null } }),
    db.pharmacyVerification.count({ where: { status: "PENDING" } }),
    db.prescription.count(),
    db.medicine.count({ where: { isActive: true } }),
    db.clinicalRule.count(),
    db.healthcareFacility.count({ where: { deletedAt: null } }),
    db.healthcareFacility.count({ where: { isPhoneVerified: true, deletedAt: null } }),
  ]);

  // scans per day, last 14 days
  const since = new Date(Date.now() - 14 * 24 * 3600 * 1000);
  const recent = await db.prescription.findMany({ where: { createdAt: { gte: since } }, select: { createdAt: true } });
  const byDay: Record<string, number> = {};
  for (let i = 13; i >= 0; i--) {
    const d = new Date(Date.now() - i * 24 * 3600 * 1000);
    byDay[d.toISOString().slice(0, 10)] = 0;
  }
  for (const r of recent) {
    const key = r.createdAt.toISOString().slice(0, 10);
    if (key in byDay) byDay[key]++;
  }

  // top decoded medicines (by matched brand name)
  const items = await db.prescriptionItem.findMany({ where: { matchedBrand: { not: null } }, select: { matchedBrand: true } });
  const counts = new Map<string, number>();
  for (const it of items) counts.set(it.matchedBrand as string, (counts.get(it.matchedBrand as string) ?? 0) + 1);
  const topMedicines = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([brand, count]) => ({ brand, count }));

  // pharmacy coverage by district
  const districts = await db.pharmacy.groupBy({ by: ["district"], where: { deletedAt: null }, _count: true });
  const coverage = districts.map((d) => ({ district: d.district, pharmacies: d._count })).sort((a, b) => b.pharmacies - a.pharmacies);

  return ok({
    stats: { patients, pharmacies, verifiedPharmacies, pendingVerifications, scans, medicines, rules, facilities, verifiedPhones: demoFacilities },
    scansByDay: Object.entries(byDay).map(([date, count]) => ({ date, count })),
    topMedicines,
    coverage,
  });
}, { roles: ["ADMIN"], rate: { limit: 60, windowMs: 60_000 } });
