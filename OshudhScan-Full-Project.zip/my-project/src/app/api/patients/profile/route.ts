import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, audit } from "@/lib/api";
import { requireUser, verifyPassword, destroySession, hashPassword } from "@/lib/auth";

// GET /api/patients/profile — profile + consents + completion %.
export const GET = withApi(async ({ user }) => {
  const u = await requireUser();
  const profile = await db.patientProfile.findUnique({ where: { userId: u.id } });
  const consents = await db.userConsent.findMany({ where: { userId: u.id }, orderBy: { createdAt: "desc" } });
  const family = await db.familyMember.count({ where: { ownerUserId: u.id, deletedAt: null } });

  const fields = [
    Boolean(u.phone), Boolean(profile?.dateOfBirth), Boolean(profile?.bloodGroup),
    Boolean(profile?.heightCm), Boolean(profile?.weightKg),
    Boolean(profile?.allergies), Boolean(profile?.chronicConditions),
    Boolean(profile?.district), Boolean(profile?.emergencyContact),
  ];
  const completion = Math.round((fields.filter(Boolean).length / fields.length) * 100);

  return ok({
    user: { id: u.id, email: u.email, name: u.name, phone: u.phone, role: u.role, locale: u.locale, largeText: u.largeText },
    profile: profile
      ? {
          dateOfBirth: profile.dateOfBirth,
          gender: profile.gender,
          bloodGroup: profile.bloodGroup,
          heightCm: profile.heightCm,
          weightKg: profile.weightKg,
          allergies: profile.allergies ? JSON.parse(profile.allergies) : [],
          chronicConditions: profile.chronicConditions ? JSON.parse(profile.chronicConditions) : [],
          emergencyContact: profile.emergencyContact ? JSON.parse(profile.emergencyContact) : null,
          addressLine: profile.addressLine,
          division: profile.division,
          district: profile.district,
          upazila: profile.upazila,
          area: profile.area,
        }
      : null,
    consents: consents.map((c) => ({ type: c.consentType, granted: c.granted, version: c.version, at: c.createdAt })),
    familyMembers: family,
    completion,
  });
}, { auth: true, rate: { limit: 90, windowMs: 60_000 } });

const patchSchema = z.object({
  name: z.string().min(2).max(80).optional(),
  phone: z.string().max(20).nullable().optional(),
  locale: z.enum(["bn", "en"]).optional(),
  largeText: z.boolean().optional(),
  dateOfBirth: z.string().nullable().optional(),
  gender: z.enum(["MALE", "FEMALE", "OTHER"]).nullable().optional(),
  bloodGroup: z.enum(["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"]).nullable().optional(),
  heightCm: z.number().int().min(30).max(250).nullable().optional(),
  weightKg: z.number().int().min(2).max(400).nullable().optional(),
  allergies: z.array(z.string().max(60)).max(10).optional(),
  chronicConditions: z.array(z.string().max(80)).max(10).optional(),
  emergencyContact: z.object({ name: z.string().max(80), phone: z.string().max(20) }).nullable().optional(),
  addressLine: z.string().max(200).nullable().optional(),
  division: z.string().nullable().optional(),
  district: z.string().nullable().optional(),
  upazila: z.string().nullable().optional(),
  area: z.string().nullable().optional(),
  consents: z.array(z.object({ type: z.enum(["DATA_PROCESSING", "MARKETING", "GPS"]), granted: z.boolean() })).optional(),
});

// PATCH /api/patients/profile — profile + consent updates.
export const PATCH = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, patchSchema);

  await db.user.update({
    where: { id: u.id },
    data: {
      ...(body.name ? { name: body.name } : {}),
      ...(body.phone !== undefined ? { phone: body.phone } : {}),
      ...(body.locale ? { locale: body.locale } : {}),
      ...(body.largeText !== undefined ? { largeText: body.largeText } : {}),
    },
  });

  const profileData: Record<string, unknown> = {};
  if (body.dateOfBirth !== undefined) profileData.dateOfBirth = body.dateOfBirth ? new Date(body.dateOfBirth) : null;
  if (body.gender !== undefined) profileData.gender = body.gender;
  if (body.bloodGroup !== undefined) profileData.bloodGroup = body.bloodGroup;
  if (body.heightCm !== undefined) profileData.heightCm = body.heightCm;
  if (body.weightKg !== undefined) profileData.weightKg = body.weightKg;
  if (body.allergies !== undefined) profileData.allergies = JSON.stringify(body.allergies);
  if (body.chronicConditions !== undefined) profileData.chronicConditions = JSON.stringify(body.chronicConditions);
  if (body.emergencyContact !== undefined) profileData.emergencyContact = body.emergencyContact ? JSON.stringify(body.emergencyContact) : null;
  if (body.addressLine !== undefined) profileData.addressLine = body.addressLine;
  if (body.division !== undefined) profileData.division = body.division;
  if (body.district !== undefined) profileData.district = body.district;
  if (body.upazila !== undefined) profileData.upazila = body.upazila;
  if (body.area !== undefined) profileData.area = body.area;
  if (Object.keys(profileData).length > 0) {
    await db.patientProfile.upsert({
      where: { userId: u.id },
      create: { userId: u.id, ...profileData },
      update: profileData,
    });
  }

  if (body.consents) {
    for (const c of body.consents) {
      await db.userConsent.create({ data: { userId: u.id, consentType: c.type, granted: c.granted, version: "1.0" } });
    }
  }
  await audit(req, { userId: u.id, action: "PROFILE_UPDATE", entity: "user", entityId: u.id });
  return ok({ updated: true });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// POST /api/patients/profile — data export (own data only) or account deletion.
export const POST = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, z.object({ action: z.enum(["EXPORT", "DELETE"]), password: z.string().min(1) }));

  const full = await db.user.findUnique({ where: { id: u.id } });
  if (!full || !(await verifyPassword(body.password, full.passwordHash))) {
    return fail(401, "INVALID_CREDENTIALS", "Wrong password");
  }

  if (body.action === "EXPORT") {
    const [profile, prescriptions, schedules, documents, reservations, consents, family] = await Promise.all([
      db.patientProfile.findUnique({ where: { userId: u.id } }),
      db.prescription.findMany({ where: { patientUserId: u.id, deletedAt: null }, include: { items: true } }),
      db.dosageSchedule.findMany({ where: { patientUserId: u.id }, include: { reminders: true } }),
      db.medicalDocument.findMany({ where: { userId: u.id, deletedAt: null }, select: { id: true, title: true, category: true, createdAt: true } }),
      db.medicineReservation.findMany({ where: { requestedByUserId: u.id } }),
      db.userConsent.findMany({ where: { userId: u.id } }),
      db.familyMember.findMany({ where: { ownerUserId: u.id, deletedAt: null } }),
    ]);
    await audit(req, { userId: u.id, action: "DATA_EXPORT", entity: "user", entityId: u.id });
    return ok({
      export: {
        exportedAt: new Date().toISOString(),
        user: { id: u.id, email: u.email, name: u.name, phone: u.phone, locale: u.locale },
        profile, prescriptions, schedules, documentsMeta: documents, reservations, consents, familyMembers: family,
      },
      note: "This export contains your personal health data. Store it securely.",
    });
  }

  // DELETE — soft delete user + cascade soft deletes; revoke sessions.
  await db.$transaction([
    db.user.update({ where: { id: u.id }, data: { deletedAt: new Date(), email: `deleted+${u.id}@oshudhscan.invalid`, name: "Deleted user", phone: null } }),
    db.session.deleteMany({ where: { userId: u.id } }),
    db.dosageSchedule.updateMany({ where: { patientUserId: u.id }, data: { status: "CANCELLED" } }),
    db.medicalDocument.updateMany({ where: { userId: u.id }, data: { deletedAt: new Date() } }),
    db.prescription.updateMany({ where: { patientUserId: u.id }, data: { deletedAt: new Date() } }),
    db.familyMember.updateMany({ where: { ownerUserId: u.id }, data: { deletedAt: new Date() } }),
  ]);
  await destroySession();
  await audit(req, { userId: u.id, action: "ACCOUNT_DELETE", entity: "user", entityId: u.id });
  return ok({ deleted: true });
}, { auth: true, rate: { limit: 5, windowMs: 60 * 60_000 } });
