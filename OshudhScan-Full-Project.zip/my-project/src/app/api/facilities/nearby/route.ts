import { withApi, ok, fail, searchParams } from "@/lib/api";
import { queryFacilities } from "@/lib/directory-server";

// GET /api/facilities/nearby?lat=&lng=&radius=&type=&emergency=1 — GPS nearby search.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  if (Number.isNaN(lat) || Number.isNaN(lng)) return fail(400, "VALIDATION", "lat and lng are required");
  const radius = Math.min(50, Math.max(0.5, parseFloat(sp.get("radius") ?? "") || 10));
  const type = sp.get("type") && sp.get("type") !== "ALL" ? sp.get("type") : null;
  const { rows, total } = await queryFacilities({
    type,
    origin: { lat, lng },
    distanceKm: radius,
    emergencyOnly: sp.get("emergency") === "1",
    take: 2000,
  });
  const nearby = rows
    .filter((r) => r.distanceKm !== null && r.distanceKm <= radius)
    .sort((a, b) => (a.distanceKm ?? 0) - (b.distanceKm ?? 0))
    .slice(0, 50);
  return ok({ facilities: nearby, total: nearby.length, center: { lat, lng }, radius });
}, { rate: { limit: 60, windowMs: 60_000 } });
