import { db } from "@/lib/db";
import { withApi, ok, fail } from "@/lib/api";
import { toFacilityRow } from "@/lib/directory-server";

// GET /api/facilities/:id — facility details incl. verification trail.
export const GET = withApi(async ({ params }) => {
  const f = await db.healthcareFacility.findFirst({
    where: { id: params.id, deletedAt: null },
  });
  if (!f) return fail(404, "NOT_FOUND", "Facility not found");
  const events = await db.verificationEvent.findMany({
    where: { entityType: "FACILITY", entityId: f.id },
    orderBy: { createdAt: "desc" },
    take: 10,
    select: { toStatus: true, method: true, note: true, createdAt: true },
  });
  return ok({ facility: toFacilityRow(f), verificationEvents: events });
}, { rate: { limit: 90, windowMs: 60_000 } });
