import { db } from "@/lib/db";
import { withApi, ok, fail, searchParams } from "@/lib/api";
import { assertPharmacyAccess } from "@/lib/pharmacy-access";
import { requireUser } from "@/lib/auth";

// GET /api/analytics/pharmacy?pharmacyId= — sales/inventory/lead analytics for MY pharmacy.
export const GET = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const id = searchParams(req).get("pharmacyId") ?? "";
  if (!id) return fail(400, "VALIDATION", "pharmacyId required");
  await assertPharmacyAccess(u, id);

  const now = new Date();
  const dayStart = new Date(now); dayStart.setHours(0, 0, 0, 0);
  const monthStart = new Date(now); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);

  const [salesDaily, salesMonthly, leadStats, inventoryStats, expiryRisk] = await Promise.all([
    db.pharmacySale.findMany({ where: { pharmacyId: id, soldAt: { gte: new Date(now.getTime() - 14 * 24 * 3600 * 1000) } }, orderBy: { soldAt: "asc" } }),
    db.pharmacySale.aggregate({ where: { pharmacyId: id, soldAt: { gte: monthStart } }, _sum: { totalBdt: true }, _count: true }),
    db.lead.findMany({ where: { pharmacyId: id } }),
    db.pharmacyInventory.findMany({ where: { pharmacyId: id, status: "ACTIVE" }, include: { medicine: { select: { brand: true, strength: true } } } }),
    db.pharmacyInventory.findMany({ where: { pharmacyId: id, status: "ACTIVE", expiryDate: { lte: new Date(now.getTime() + 90 * 24 * 3600 * 1000) } }, include: { medicine: { select: { brand: true, strength: true } } } }),
  ]);

  const byDay: Record<string, { revenue: number; count: number }> = {};
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 3600 * 1000);
    const key = d.toISOString().slice(0, 10);
    byDay[key] = { revenue: 0, count: 0 };
  }
  for (const s of salesDaily) {
    const key = s.soldAt.toISOString().slice(0, 10);
    if (byDay[key]) { byDay[key].revenue += s.totalBdt; byDay[key].count += 1; }
  }

  const accepted = leadStats.filter((l) => l.status !== "NEW").length;
  const lowStock = inventoryStats.filter((i) => i.quantity <= i.lowStockThreshold && i.quantity > 0);
  const outOfStock = inventoryStats.filter((i) => i.quantity === 0);
  const expired = inventoryStats.filter((i) => i.expiryDate && i.expiryDate < now);

  return ok({
    daily: Object.entries(byDay).map(([date, v]) => ({ date, ...v })),
    month: { revenue: salesMonthly._sum.totalBdt ?? 0, count: salesMonthly._count },
    leads: {
      total: leadStats.length,
      newCount: leadStats.length - accepted,
      accepted,
      converted: leadStats.filter((l) => l.status === "CONVERTED").length,
      acceptRate: leadStats.length ? Math.round((accepted / leadStats.length) * 100) : 0,
    },
    inventory: {
      stocked: inventoryStats.length,
      lowStock: lowStock.map((i) => ({ brand: i.medicine.brand, strength: i.medicine.strength, quantity: i.quantity, threshold: i.lowStockThreshold })),
      outOfStock: outOfStock.map((i) => ({ brand: i.medicine.brand, strength: i.medicine.strength })),
      expiringSoon: expiryRisk.filter((i) => i.expiryDate && i.expiryDate >= now).map((i) => ({ brand: i.medicine.brand, strength: i.medicine.strength, expiryDate: i.expiryDate, batch: i.batchNumber, quantity: i.quantity })),
      expired: expired.map((i) => ({ brand: i.medicine.brand, strength: i.medicine.strength, expiryDate: i.expiryDate, batch: i.batchNumber })),
    },
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
