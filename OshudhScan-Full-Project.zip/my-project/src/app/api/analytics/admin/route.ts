import { db } from "@/lib/db";
import { withApi, withAuthApi, ok } from "@/lib/api";

// GET /api/analytics/admin — aggregated, DE-IDENTIFIED platform analytics.
// Never exposes identifiable patient medical data: all outputs are counts,
// averages and per-district rollups.
export const GET = withAuthApi(async () => {
  const now = new Date();
  const since14 = new Date(now.getTime() - 14 * 24 * 3600 * 1000);

  const [totalScans, scans14, avgItemsPerRx, recognition, degradedProxies, pharmaciesByDistrict, reservationsByStatus, leadsByStatus] = await Promise.all([
    db.prescription.count(),
    db.prescription.count({ where: { createdAt: { gte: since14 } } }),
    db.prescriptionItem.groupBy({ by: ["prescriptionId"], _count: true }),
    db.prescriptionItem.findMany({ where: { medicineId: { not: null } }, select: { confidence: true, matchMethod: true } }),
    db.prescriptionItem.findMany({ where: { medicineId: null, matchedBrand: null }, select: { id: true } }),
    db.pharmacy.groupBy({ by: ["district"], where: { deletedAt: null }, _count: true }),
    db.medicineReservation.groupBy({ by: ["status"], _count: true }),
    db.lead.groupBy({ by: ["status"], _count: true }),
  ]);

  const avgItems = avgItemsPerRx.length
    ? Math.round((avgItemsPerRx.reduce((acc, r) => acc + r._count, 0) / avgItemsPerRx.length) * 10) / 10
    : 0;
  const totalItems = await db.prescriptionItem.count();
  const recognizedItems = recognition.length + degradedProxies.length; // matched + unmatched lines
  const matchedItems = recognition.length;
  const matchRate = totalItems ? Math.round((matchedItems / totalItems) * 100) : null;
  const avgConfidence = recognition.length
    ? Math.round((recognition.reduce((acc, r) => acc + (r.confidence ?? 0), 0) / recognition.length) * 100)
    : null;

  // scan volume by day (14d)
  const recent = await db.prescription.findMany({ where: { createdAt: { gte: since14 } }, select: { createdAt: true } });
  const byDay: Record<string, number> = {};
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 3600 * 1000);
    byDay[d.toISOString().slice(0, 10)] = 0;
  }
  for (const r of recent) {
    const key = r.createdAt.toISOString().slice(0, 10);
    if (key in byDay) byDay[key]++;
  }

  return ok({
    scans: { total: totalScans, last14Days: scans14, avgItemsPerRx, matchRate, avgConfidence, unmatchedItems: degradedProxies.length },
    scansByDay: Object.entries(byDay).map(([date, count]) => ({ date, count })),
    pharmacyCoverage: pharmaciesByDistrict.map((d) => ({ district: d.district, pharmacies: d._count })).sort((a, b) => b.pharmacies - a.pharmacies),
    reservationsByStatus: reservationsByStatus.map((r) => ({ status: r.status, count: r._count })),
    leadsByStatus: leadsByStatus.map((l) => ({ status: l.status, count: l._count })),
    privacyNote: "All figures are aggregated and de-identified. No patient-level medical data is exposed through this endpoint.",
  });
}, { roles: ["ADMIN"], rate: { limit: 60, windowMs: 60_000 } });
