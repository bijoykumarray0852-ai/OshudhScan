import { db } from "@/lib/db";
import { withApi, ok, fail, audit } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { unlink } from "fs/promises";
import { createReadStream, existsSync } from "fs";
import path from "path";

// GET /api/documents/[id]?download=1 — stream the PRIVATE file after an
// ownership check. Never a public URL. preview=1 returns inline; download
// forces Content-Disposition.
export const GET = async (req: Request, context?: { params: Promise<{ id: string }> }) => {
  try {
    const { id } = (context?.params ? await context.params : { id: "" }) as { id: string };
    const user = await requireUser();
    const doc = await db.medicalDocument.findFirst({ where: { id, userId: user.id, deletedAt: null } });
    if (!doc) {
      // also allow prescription images owned by the same user
      const img = await db.prescriptionImage.findFirst({ where: { id, prescription: { patientUserId: user.id } } });
      if (!img) {
        return Response.json({ ok: false, code: "NOT_FOUND", error: "Document not found" }, { status: 404 });
      }
      return streamFile(img.storagePath, img.mimeType, img.fileName, req);
    }
    if (!existsSync(doc.storagePath)) {
      return Response.json({ ok: false, code: "GONE", error: "File missing from storage" }, { status: 410 });
    }
    const url = new URL(req.url);
    if (url.searchParams.get("audit") === "1") {
      await audit(req as unknown as import("next/server").NextRequest, { userId: user.id, action: "DOC_DOWNLOAD", entity: "medical_document", entityId: doc.id });
    }
    return streamFile(doc.storagePath, doc.mimeType, doc.fileName, req);
  } catch {
    return Response.json({ ok: false, code: "AUTH_REQUIRED", error: "Sign in required" }, { status: 401 });
  }
};

function streamFile(storagePath: string, mimeType: string, fileName: string, req: Request) {
  const url = new URL(req.url);
  const forceDownload = url.searchParams.get("download") === "1";
  const stream = createReadStream(storagePath) as unknown as ReadableStream;
  return new Response(stream, {
    headers: {
      "Content-Type": mimeType,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "Content-Disposition": `${forceDownload ? "attachment" : "inline"}; filename="${path.basename(fileName).replace(/"/g, "")}"`,
    },
  });
}

// DELETE /api/documents/[id] — soft delete + remove file.
export const DELETE = async (_req: Request, context?: { params: Promise<{ id: string }> }) => {
  try {
    const { id } = (context?.params ? await context.params : { id: "" }) as { id: string };
    const user = await requireUser();
    const doc = await db.medicalDocument.findFirst({ where: { id, userId: user.id, deletedAt: null } });
    if (!doc) return Response.json({ ok: false, code: "NOT_FOUND", error: "Document not found" }, { status: 404 });
    await db.medicalDocument.update({ where: { id: doc.id }, data: { deletedAt: new Date() } });
    await unlink(doc.storagePath).catch(() => undefined);
    return Response.json({ ok: true, deleted: true });
  } catch {
    return Response.json({ ok: false, code: "AUTH_REQUIRED", error: "Sign in required" }, { status: 401 });
  }
};

// keep bundler-happy: path is used for filename safety below
void path;
