import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, searchParams, pageArgs, audit } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { savePrivateFile } from "@/app/api/prescriptions/route";
import { mkdir } from "fs/promises";
import path from "path";

const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp", "application/pdf"];
const MAX_SIZE = 10 * 1024 * 1024;

// GET /api/documents?category=&q=&page=
export const GET = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const sp = searchParams(req);
  const { skip, take, page, pageSize } = pageArgs(sp, 20);
  const where: Record<string, unknown> = { userId: u.id, deletedAt: null };
  if (sp.get("category")) where.category = sp.get("category");
  if (sp.get("q")) where.title = { contains: sp.get("q") };
  if (sp.get("familyMemberId")) where.familyMemberId = sp.get("familyMemberId");
  const [rows, total] = await Promise.all([
    db.medicalDocument.findMany({ where, orderBy: { createdAt: "desc" }, skip, take }),
    db.medicalDocument.count({ where }),
  ]);
  return ok({
    page,
    pageSize,
    total,
    documents: rows.map((d) => ({
      id: d.id,
      title: d.title,
      category: d.category,
      fileName: d.fileName,
      mimeType: d.mimeType,
      sizeBytes: d.sizeBytes,
      docDate: d.docDate,
      createdAt: d.createdAt,
      familyMemberId: d.familyMemberId,
    })),
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// POST /api/documents — upload (multipart) to PRIVATE storage.
export const POST = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const form = await req.formData().catch(() => null);
  if (!form) return fail(400, "VALIDATION", "multipart/form-data required");
  const file = form.get("file") as File | null;
  if (!file) return fail(400, "VALIDATION", "file field required");
  if (!ALLOWED_MIME.includes(file.type)) return fail(415, "VALIDATION", "Only JPG, PNG, WebP or PDF allowed");
  if (file.size > MAX_SIZE) return fail(413, "VALIDATION", "File must be under 10 MB");

  const title = String(form.get("title") ?? file.name).slice(0, 120) || file.name;
  const category = ["PRESCRIPTION", "LAB_REPORT", "DIAGNOSTIC", "OTHER"].includes(String(form.get("category"))) ? String(form.get("category")) : "OTHER";
  const docDateRaw = String(form.get("docDate") ?? "");
  const notes = String(form.get("notes") ?? "").slice(0, 300);
  const familyMemberId = String(form.get("familyMemberId") ?? "") || null;

  const buffer = Buffer.from(await file.arrayBuffer());
  const dir = path.join(process.cwd(), "db", "documents", u.id);
  await mkdir(dir, { recursive: true });
  const ext = file.type === "application/pdf" ? "pdf" : file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
  const name = `${Date.now()}-${Math.floor(Math.random() * 100000)}.${ext}`;
  const abs = path.join(dir, name);
  await (await import("fs/promises")).writeFile(abs, buffer);

  const doc = await db.medicalDocument.create({
    data: {
      userId: u.id,
      familyMemberId,
      title,
      category,
      fileName: file.name,
      mimeType: file.type,
      sizeBytes: buffer.length,
      storagePath: abs,
      docDate: docDateRaw ? new Date(docDateRaw) : null,
      notes: notes || null,
    },
  });
  await audit(req, { userId: u.id, action: "DOC_UPLOAD", entity: "medical_document", entityId: doc.id, detail: { category, size: buffer.length } });
  return ok({ document: { id: doc.id, title: doc.title, category: doc.category } }, { status: 201 });
}, { auth: true, rate: { limit: 20, windowMs: 60 * 60_000 } });
