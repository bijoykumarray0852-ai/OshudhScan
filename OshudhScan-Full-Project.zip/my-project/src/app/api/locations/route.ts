import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { withApi, ok, searchParams } from "@/lib/api";

// GET /api/locations?level=DIVISION|DISTRICT|UPAZILA&division=&district=
// Administrative geography for the location picker. Seeded from BBS data.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const level = sp.get("level") ?? "DIVISION";
  const division = sp.get("division") ?? undefined;
  const district = sp.get("district") ?? undefined;
  const q = sp.get("q")?.trim();

  const where: Record<string, unknown> = { level };
  if (level === "DISTRICT" && division) where.division = division;
  if (level === "UPAZILA" && district) where.district = district;
  if (q) where.name = { contains: q };

  const rows = await db.administrativeLocation.findMany({
    where,
    orderBy: { name: "asc" },
    take: 200,
    select: { id: true, code: true, level: true, name: true, nameBangla: true, division: true, district: true, lat: true, lng: true, source: true },
  });
  return ok({ locations: rows, total: rows.length, source: "BBS administrative areas (public)" });
}, { rate: { limit: 120, windowMs: 60_000 } });
