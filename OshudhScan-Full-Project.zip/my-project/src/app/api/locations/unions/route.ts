import { db } from "@/lib/db";
import { withApi, ok, searchParams } from "@/lib/api";

// GET /api/locations/unions?upazila=Savar — union/area level when reliable
// administrative data is available. Coverage grows with verified imports;
// an empty list is an honest empty result, never fabricated rows.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const upazila = sp.get("upazila")?.trim();
  // Resolve the upazila row first, then match UNION/AREA children by
  // parentCode — the denormalised `district` column holds the DISTRICT name,
  // not the upazila, so filtering on it was always wrong.
  const upazilaRow = upazila
    ? await db.administrativeLocation.findFirst({
        where: { level: "UPAZILA", name: upazila },
        select: { code: true },
      })
    : null;
  const rows =
    upazila && upazilaRow
      ? await db.administrativeLocation.findMany({
          where: { level: { in: ["UNION", "AREA"] }, parentCode: upazilaRow.code },
          orderBy: { name: "asc" },
          select: { id: true, code: true, level: true, name: true, nameBangla: true, parentCode: true },
        })
      : [];
  return ok({
    unions: rows,
    total: rows.length,
    note: rows.length ? undefined : "Union/area level data is not yet available for this upazila — coverage grows with verified imports.",
  });
}, { rate: { limit: 120, windowMs: 60_000 } });
