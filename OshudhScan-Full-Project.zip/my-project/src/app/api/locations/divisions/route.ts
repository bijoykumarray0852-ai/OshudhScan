import { db } from "@/lib/db";
import { withApi, ok } from "@/lib/api";

// GET /api/locations/divisions — 8 divisions of Bangladesh (BBS data).
export const GET = withApi(async () => {
  const rows = await db.administrativeLocation.findMany({
    where: { level: "DIVISION" },
    orderBy: { name: "asc" },
    select: { id: true, code: true, name: true, nameBangla: true, lat: true, lng: true },
  });
  return ok({ divisions: rows, total: rows.length });
}, { rate: { limit: 120, windowMs: 60_000 } });
