import { db } from "@/lib/db";
import { withApi, ok, fail, searchParams } from "@/lib/api";

// GET /api/locations/upazilas?district=Dhaka — upazilas of a district (full BBS list).
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const district = sp.get("district")?.trim();
  const q = sp.get("q")?.trim();
  if (!district && !q) return fail(400, "VALIDATION", "district (or q) query parameter is required");
  const where: Record<string, unknown> = { level: "UPAZILA" };
  if (district) where.district = district;
  if (q) where.name = { contains: q };
  const rows = await db.administrativeLocation.findMany({
    where,
    orderBy: { name: "asc" },
    take: 600,
    select: { id: true, code: true, name: true, nameBangla: true, division: true, district: true, parentCode: true },
  });
  return ok({ upazilas: rows, total: rows.length });
}, { rate: { limit: 120, windowMs: 60_000 } });
