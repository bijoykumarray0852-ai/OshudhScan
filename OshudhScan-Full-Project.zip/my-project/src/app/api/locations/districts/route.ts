import { db } from "@/lib/db";
import { withApi, ok, fail, searchParams } from "@/lib/api";

// GET /api/locations/districts?division=Dhaka — districts of a division.
export const GET = withApi(async ({ req }) => {
  const division = searchParams(req).get("division")?.trim();
  if (!division) return fail(400, "VALIDATION", "division query parameter is required");
  const rows = await db.administrativeLocation.findMany({
    where: { level: "DISTRICT", division },
    orderBy: { name: "asc" },
    select: { id: true, code: true, name: true, nameBangla: true, lat: true, lng: true, parentCode: true },
  });
  return ok({ districts: rows, total: rows.length });
}, { rate: { limit: 120, windowMs: 60_000 } });
