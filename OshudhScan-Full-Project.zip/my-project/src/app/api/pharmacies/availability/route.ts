import { NextRequest, NextResponse } from "next/server";

// GET /api/pharmacies/availability — stable alias of /api/availability
// (same handler, canonical URL for the national directory).
export const GET = (req: NextRequest) => {
  const url = new URL(req.url);
  url.pathname = "/api/availability";
  return NextResponse.rewrite(url);
};

export const POST = (req: NextRequest) => {
  const url = new URL(req.url);
  url.pathname = "/api/availability";
  return NextResponse.rewrite(url);
};
