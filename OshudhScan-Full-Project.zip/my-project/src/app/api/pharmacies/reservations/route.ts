import { NextRequest, NextResponse } from "next/server";

// /api/pharmacies/reservations — stable alias of /api/reservations.
export const GET = (req: NextRequest) => {
  const url = new URL(req.url);
  url.pathname = "/api/reservations";
  return NextResponse.rewrite(url);
};

export const POST = (req: NextRequest) => {
  const url = new URL(req.url);
  url.pathname = "/api/reservations";
  return NextResponse.rewrite(url);
};
