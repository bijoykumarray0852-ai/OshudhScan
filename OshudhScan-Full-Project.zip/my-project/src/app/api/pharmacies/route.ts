import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, searchParams, parseJson, pageArgs, audit } from "@/lib/api";
import { haversineKm, stockStatus, isExpiredBatch } from "@/lib/geo";
import { isOpenNow } from "@/lib/hours";
import { requireUser, ApiError } from "@/lib/auth";

// GET /api/pharmacies — finder query with geo distance, filters, medicine stock.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const q = sp.get("q")?.trim();
  const medicineId = sp.get("medicineId");
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  const division = sp.get("division");
  const district = sp.get("district");
  const upazila = sp.get("upazila");
  const distance = Math.min(50, Math.max(0.5, parseFloat(sp.get("distance") ?? "") || 10));
  const openNow = sp.get("openNow") === "1";
  const verifiedOnly = sp.get("verified") === "1";
  const { skip, take, page, pageSize } = pageArgs(sp, 20);

  const where: Record<string, unknown> = { deletedAt: null };
  // name search covers Bangla names and areas too, matching the directory
  // search semantics (SQLite LIKE is case-insensitive for ASCII)
  if (q) where.OR = [{ name: { contains: q } }, { nameBangla: { contains: q } }, { area: { contains: q } }];
  if (division) where.division = division;
  if (district) where.district = district;
  if (upazila) where.upazila = upazila;
  if (verifiedOnly) where.isVerified = true;
  // Spatial prefilter: bounding box ⊇ radius circle (PostGIS moves this into
  // SQL — see docs/DATABASE.md). Keeps the distance ranking correct at
  // national pharmacy counts instead of the alphabetical first N rows.
  const hasGeo = !Number.isNaN(lat) && !Number.isNaN(lng);
  if (hasGeo) {
    const dLat = distance / 111;
    const dLng = distance / (111 * Math.max(0.2, Math.cos((lat * Math.PI) / 180)));
    where.lat = { gte: lat - dLat, lte: lat + dLat };
    where.lng = { gte: lng - dLng, lte: lng + dLng };
  }

  // Cap for in-app distance ranking. A generous cap whenever the query is
  // narrowed by filters (division/district/upazila/name) or geo — so every
  // division/district really surfaces its own records instead of the first
  // 400 rows of the national table. Unfiltered national lists keep the cap.
  const narrowed = Boolean(division || district || upazila || q || medicineId);
  let pharmacies = await db.pharmacy.findMany({
    where,
    include: {
      inventory: {
        where: { status: "ACTIVE", ...(medicineId ? { medicineId } : {}) },
        include: { medicine: { select: { id: true, brand: true, strength: true, form: true } } },
      },
    },
    take: hasGeo || narrowed ? 2000 : 400,
  });

  const now = new Date();

  type Row = (typeof pharmacies)[number];
  let rows: Array<Row & { distanceKm: number | null; openNow: boolean }> = pharmacies.map((p) => ({
    ...p,
    distanceKm: hasGeo && p.lat != null && p.lng != null ? haversineKm({ lat, lng }, { lat: p.lat, lng: p.lng }) : null,
    openNow: isOpenNow(p.openingHours, (p.services ?? "").includes("24_hours"), now),
  }));

  // with geo → drop rows outside the requested radius; without geo the
  // distance selector is inert and `distanceFilterApplied` reports that honestly
  if (hasGeo) rows = rows.filter((r) => r.distanceKm === null || r.distanceKm <= distance);
  if (openNow) rows = rows.filter((r) => r.openNow);

  // order: with geo → by distance; without → real records first (demo flagged
  // records are shown, but never crowd out real directory rows), then
  // verified, then rating
  rows.sort((a, b) => {
    if (a.distanceKm !== null && b.distanceKm !== null) return a.distanceKm - b.distanceKm;
    if (a.distanceKm !== null) return -1;
    if (b.distanceKm !== null) return 1;
    if (a.isDemo !== b.isDemo) return a.isDemo ? 1 : -1;
    if (a.isVerified !== b.isVerified) return a.isVerified ? -1 : 1;
    return b.rating - a.rating;
  });

  const total = rows.length;
  const pageRows = rows.slice(skip, skip + take);

  return ok({
    page,
    pageSize,
    total,
    geoApplied: hasGeo,
    distanceFilterApplied: hasGeo,
    pharmacies: pageRows.map((p) => {
      const activeBatches = p.inventory.filter((inv) => !isExpiredBatch(inv.expiryDate, now));
      let stock = null as null | { status: string; quantity: number; updatedAt: Date; sellingPrice: number | null; medicineLabel: string };
      if (medicineId && p.inventory.length > 0) {
        const best = activeBatches.reduce((acc, inv) => (acc && acc.quantity >= inv.quantity ? acc : inv), activeBatches[0]);
        if (best) {
          const qty = activeBatches.reduce((acc, inv) => acc + inv.quantity, 0);
          const lastUpdate = activeBatches.reduce((acc, inv) => (inv.updatedAt > acc ? inv.updatedAt : acc), activeBatches[0].updatedAt);
          stock = {
            status: stockStatus(qty, lastUpdate, now),
            quantity: qty,
            updatedAt: lastUpdate,
            sellingPrice: best.sellingPrice,
            medicineLabel: `${best.medicine.brand} ${best.medicine.strength ?? ""}`.trim(),
          };
        } else {
          stock = { status: "OUT_OF_STOCK", quantity: 0, updatedAt: now, sellingPrice: null, medicineLabel: "" };
        }
      }
      return {
        id: p.id,
        name: p.name,
        nameBangla: p.nameBangla,
        contactPhone: p.contactPhone,
        addressLine: p.addressLine,
        division: p.division,
        district: p.district,
        upazila: p.upazila,
        area: p.area,
        lat: p.lat,
        lng: p.lng,
        rating: p.rating,
        status: p.status,
        isVerified: p.isVerified,
        isDemo: p.isDemo,
        services: p.services,
        openingHours: p.openingHours,
        openNow: p.openNow,
        distanceKm: p.distanceKm,
        stockedCount: activeBatches.length,
        stock,
      };
    }),
  });
}, { rate: { limit: 90, windowMs: 60_000 } });

const registerSchema = z.object({
  name: z.string().min(2).max(120),
  contactPhone: z.string().min(6).max(20),
  email: z.string().email().optional(),
  addressLine: z.string().min(5).max(200),
  division: z.string().min(2),
  district: z.string().min(2),
  upazila: z.string().optional(),
  area: z.string().optional(),
  postalCode: z.string().max(10).optional(),
  lat: z.number().min(-90).max(90).optional(),
  lng: z.number().min(-180).max(180).optional(),
  openingHours: z.object({ open: z.string().regex(/^\d{2}:\d{2}$/), close: z.string().regex(/^\d{2}:\d{2}$/) }).optional(),
  licenseNumber: z.string().min(3).max(60),
  licenseType: z.enum(["RETAIL", "WHOLESALE", "RETAIL_WHOLESALE"]),
  pharmacistName: z.string().max(100).optional(),
  pharmacistReg: z.string().max(40).optional(),
});

// POST /api/pharmacies — registration (auth). Creates PENDING pharmacy +
// verification request. Verified status is granted ONLY by admin review.
export const POST = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, registerSchema);
  const pharmacy = await db.pharmacy.create({
    data: {
      name: body.name.trim(),
      ownerUserId: u.id,
      contactPhone: body.contactPhone,
      email: body.email ?? null,
      addressLine: body.addressLine.trim(),
      division: body.division,
      district: body.district,
      upazila: body.upazila,
      area: body.area,
      postalCode: body.postalCode,
      lat: body.lat,
      lng: body.lng,
      openingHours: body.openingHours ? JSON.stringify(body.openingHours) : null,
      licenseNumber: body.licenseNumber,
      status: "PENDING",
      isVerified: false,
      isDemo: false,
      services: JSON.stringify(["home_delivery"]),
      verifications: {
        create: {
          licenseNumber: body.licenseNumber,
          licenseType: body.licenseType,
          pharmacistName: body.pharmacistName,
          pharmacistReg: body.pharmacistReg,
          status: "PENDING",
        },
      },
      staff: { create: { userId: u.id, role: "OWNER" } },
      subscription: { create: { plan: "FREE", status: "ACTIVE" } },
    },
    include: { verifications: true },
  });
  await audit(req, { userId: u.id, action: "PHARMACY_REGISTER", entity: "pharmacy", entityId: pharmacy.id, detail: { name: pharmacy.name, district: pharmacy.district } });
  return ok({ pharmacy: { id: pharmacy.id, name: pharmacy.name, status: pharmacy.status } }, { status: 201 });
}, { rate: { limit: 5, windowMs: 60 * 60_000 } });
