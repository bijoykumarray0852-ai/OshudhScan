import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, searchParams, audit } from "@/lib/api";
import { getSessionUser, requireUser, ApiError } from "@/lib/auth";
import { assertPharmacyAccess } from "@/lib/pharmacy-access";

// GET /api/pharmacies/[id]/leads — inbox for this pharmacy.
export const GET = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const { skip, take } = pageParams(searchParams(req));
  const [leads, total, newCount] = await Promise.all([
    db.lead.findMany({ where: { pharmacyId: id }, orderBy: { createdAt: "desc" }, skip, take }),
    db.lead.count({ where: { pharmacyId: id } }),
    db.lead.count({ where: { pharmacyId: id, status: "NEW" } }),
  ]);
  return ok({
    leads: leads.map((l) => ({
      id: l.id,
      patientName: l.patientName,
      patientPhone: l.patientPhone,
      medicines: JSON.parse(l.medicines),
      coveragePct: l.coveragePct,
      estimatedValueBdt: l.estimatedValueBdt,
      status: l.status,
      createdAt: l.createdAt,
    })),
    total,
    newCount,
  });
}, { auth: true, rate: { limit: 90, windowMs: 60_000 } });

function pageParams(sp: URLSearchParams) {
  const page = Math.max(1, Number(sp.get("page") ?? 1) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(sp.get("pageSize") ?? 30) || 30));
  return { skip: (page - 1) * pageSize, take: pageSize };
}

const leadSchema = z.object({
  patientName: z.string().min(2).max(80),
  patientPhone: z.string().min(6).max(20),
  medicines: z.array(z.object({ id: z.string().max(40).optional(), brand: z.string().max(80), stocked: z.boolean().optional() })).min(1).max(30),
  coveragePct: z.number().min(0).max(100).optional(),
  estimatedValueBdt: z.number().min(0).optional(),
});

// POST /api/pharmacies/[id]/leads — push a decoded-prescription lead.
// Commercial pipeline data ONLY: the payload carries decoded brand names and a
// patient reference, never clinical findings or document data.
export const POST = withApi(async ({ req, params }) => {
  const { id } = params as { id: string };
  const body = await parseJson(req, leadSchema);
  const ph = await db.pharmacy.findUnique({ where: { id } });
  if (!ph || ph.deletedAt) return fail(404, "NOT_FOUND", "Pharmacy not found");
  const user = await getSessionUser();
  const lead = await db.lead.create({
    data: {
      pharmacyId: id,
      patientName: body.patientName,
      patientPhone: body.patientPhone,
      medicines: JSON.stringify(body.medicines),
      coveragePct: body.coveragePct,
      estimatedValueBdt: body.estimatedValueBdt ?? 0,
      status: "NEW",
    },
  });
  await audit(req, { userId: user?.id ?? null, action: "LEAD_CREATED", entity: "lead", entityId: lead.id, detail: { pharmacyId: id } });
  return ok({ lead: { id: lead.id, status: lead.status } }, { status: 201 });
}, { rate: { limit: 20, windowMs: 60_000 } });

// PATCH /api/pharmacies/[id]/leads — accept/decline/convert a lead.
export const PATCH = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const body = await parseJson(req, z.object({
    leadId: z.string(),
    status: z.enum(["ACCEPTED", "DECLINED", "CONVERTED"]),
  }));
  const lead = await db.lead.findFirst({ where: { id: body.leadId, pharmacyId: id } });
  if (!lead) return fail(404, "NOT_FOUND", "Lead not found");
  await db.lead.update({
    where: { id: lead.id },
    data: { status: body.status, acceptedAt: body.status === "ACCEPTED" ? new Date() : lead.acceptedAt },
  });
  await audit(req, { userId: u.id, action: "LEAD_STATUS", entity: "lead", entityId: lead.id, detail: { status: body.status } });
  return ok({ lead: { id: lead.id, status: body.status } });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
