import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, audit } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { assertPharmacyAccess } from "@/lib/pharmacy-access";

// GET /api/pharmacies/[id]/suppliers
export const GET = withApi(async ({ params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const suppliers = await db.supplier.findMany({ where: { pharmacyId: id, deletedAt: null }, orderBy: { createdAt: "desc" } });
  return ok({ suppliers });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// POST /api/pharmacies/[id]/suppliers
export const POST = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const body = await parseJson(req, z.object({
    name: z.string().min(2).max(120),
    contactPerson: z.string().max(100).optional(),
    phone: z.string().max(20).optional(),
    email: z.string().email().optional(),
    address: z.string().max(200).optional(),
    notes: z.string().max(300).optional(),
  }));
  const supplier = await db.supplier.create({ data: { pharmacyId: id, ...body } });
  await audit(req, { userId: u.id, action: "SUPPLIER_ADD", entity: "supplier", entityId: supplier.id });
  return ok({ supplier: { id: supplier.id } }, { status: 201 });
}, { auth: true, rate: { limit: 30, windowMs: 60_000 } });

// DELETE /api/pharmacies/[id]/suppliers?supplierId=
export const DELETE = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const supplierId = new URL(req.url).searchParams.get("supplierId");
  if (!supplierId) return fail(400, "VALIDATION", "supplierId required");
  const row = await db.supplier.findFirst({ where: { id: supplierId, pharmacyId: id } });
  if (!row) return fail(404, "NOT_FOUND", "Supplier not found");
  await db.supplier.update({ where: { id: row.id }, data: { deletedAt: new Date() } });
  await audit(req, { userId: u.id, action: "SUPPLIER_ARCHIVE", entity: "supplier", entityId: row.id });
  return ok({ archived: true });
}, { auth: true, rate: { limit: 30, windowMs: 60_000 } });
