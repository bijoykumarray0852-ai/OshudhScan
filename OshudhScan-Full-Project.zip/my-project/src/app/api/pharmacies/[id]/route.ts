import { db } from "@/lib/db";
import { withApi, ok, fail, searchParams } from "@/lib/api";
import { haversineKm, stockStatus, isExpiredBatch } from "@/lib/geo";
import { isOpenNow } from "@/lib/hours";

// GET /api/pharmacies/[id]?lat=&lng= — pharmacy details + stocked medicines.
export const GET = withApi(async ({ req, params }) => {
  const { id } = params as { id: string };
  const sp = searchParams(req);
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  const pharmacy = await db.pharmacy.findUnique({
    where: { id },
    include: {
      inventory: {
        where: { status: "ACTIVE" },
        include: { medicine: { select: { id: true, brand: true, generic: true, genericBangla: true, strength: true, form: true, unitPriceBdt: true } } },
        orderBy: { updatedAt: "desc" },
        take: 100,
      },
      branches: { where: { deletedAt: null } },
      verifications: { orderBy: { submittedAt: "desc" }, take: 1 },
    },
  });
  if (!pharmacy || pharmacy.deletedAt) return fail(404, "NOT_FOUND", "Pharmacy not found");

  const now = new Date();
  const distanceKm = !Number.isNaN(lat) && !Number.isNaN(lng) && pharmacy.lat != null && pharmacy.lng != null
    ? Math.round(haversineKm({ lat, lng }, { lat: pharmacy.lat, lng: pharmacy.lng }) * 10) / 10
    : null;

  const medicines = pharmacy.inventory
    .filter((inv) => !isExpiredBatch(inv.expiryDate, now))
    .map((inv) => {
      const status = stockStatus(inv.quantity, inv.updatedAt, now);
      return {
        inventoryId: inv.id,
        medicineId: inv.medicine.id,
        brand: inv.medicine.brand,
        generic: inv.medicine.generic,
        genericBangla: inv.medicine.genericBangla,
        strength: inv.medicine.strength,
        form: inv.medicine.form,
        quantity: inv.quantity,
        status,
        sellingPrice: inv.sellingPrice ?? inv.medicine.unitPriceBdt,
        updatedAt: inv.updatedAt,
      };
    });

  return ok({
    pharmacy: {
      id: pharmacy.id,
      name: pharmacy.name,
      nameBangla: pharmacy.nameBangla,
      contactPhone: pharmacy.contactPhone,
      addressLine: pharmacy.addressLine,
      division: pharmacy.division,
      district: pharmacy.district,
      upazila: pharmacy.upazila,
      area: pharmacy.area,
      postalCode: pharmacy.postalCode,
      lat: pharmacy.lat,
      lng: pharmacy.lng,
      rating: pharmacy.rating,
      status: pharmacy.status,
      isVerified: pharmacy.isVerified,
      isDemo: pharmacy.isDemo,
      services: pharmacy.services,
      openingHours: pharmacy.openingHours,
      openNow: isOpenNow(pharmacy.openingHours, (pharmacy.services ?? "").includes("24_hours"), now),
      distanceKm,
      licenseNumber: pharmacy.licenseNumber,
    },
    branches: pharmacy.branches.map((b) => ({ id: b.id, name: b.name, addressLine: b.addressLine, district: b.district, phone: b.phone, isMain: b.isMain })),
    verification: pharmacy.verifications[0]
      ? { status: pharmacy.verifications[0].status, licenseType: pharmacy.verifications[0].licenseType, reviewedAt: pharmacy.verifications[0].reviewedAt }
      : null,
    medicines,
    note: "Stock information is reported by the pharmacy and refreshed as pharmacies update inventory. Availability is guaranteed only after phone confirmation.",
  });
}, { rate: { limit: 90, windowMs: 60_000 } });
