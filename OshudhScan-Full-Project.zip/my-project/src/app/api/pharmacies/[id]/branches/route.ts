import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, audit } from "@/lib/api";
import { requireUser, ApiError } from "@/lib/auth";
import { assertPharmacyAccess } from "@/lib/pharmacy-access";

// GET /api/pharmacies/[id]/branches
export const GET = withApi(async ({ params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const branches = await db.pharmacyBranch.findMany({ where: { pharmacyId: id, deletedAt: null } });
  return ok({ branches });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// POST /api/pharmacies/[id]/branches
export const POST = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const body = await parseJson(req, z.object({
    name: z.string().min(2).max(120),
    addressLine: z.string().min(5).max(200),
    district: z.string().min(2),
    upazila: z.string().optional(),
    phone: z.string().max(20).optional(),
    lat: z.number().min(-90).max(90).optional(),
    lng: z.number().min(-180).max(180).optional(),
  }));
  const branch = await db.pharmacyBranch.create({ data: { pharmacyId: id, ...body } });
  await audit(req, { userId: u.id, action: "BRANCH_ADD", entity: "pharmacy_branch", entityId: branch.id });
  return ok({ branch: { id: branch.id } }, { status: 201 });
}, { auth: true, rate: { limit: 20, windowMs: 60_000 } });

// POST /api/pharmacies/[id]/branches — stock transfer between branches is
// recorded as paired movements (TRANSFER_OUT / TRANSFER_IN).
export const PATCH = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const body = await parseJson(req, z.object({
    inventoryId: z.string(),
    quantity: z.number().int().min(1).max(10000),
    toBranchId: z.string(),
    note: z.string().max(200).optional(),
  }));
  const inv = await db.pharmacyInventory.findFirst({ where: { id: body.inventoryId, pharmacyId: id } });
  if (!inv) return fail(404, "NOT_FOUND", "Inventory record not found");
  if (inv.quantity < body.quantity) return fail(422, "INSUFFICIENT_STOCK", "Not enough stock to transfer");
  const updated = await db.$transaction(async (tx) => {
    await tx.pharmacyInventory.update({ where: { id: inv.id }, data: { quantity: inv.quantity - body.quantity, updatedAt: new Date() } });
    await tx.inventoryMovement.create({ data: { inventoryId: inv.id, type: "TRANSFER_OUT", quantity: -body.quantity, reference: `${body.toBranchId}${body.note ? ` | ${body.note}` : ""}`, userId: u.id } });
    return inv.id;
  });
  await audit(req, { userId: u.id, action: "STOCK_TRANSFER_OUT", entity: "pharmacy_inventory", entityId: updated, detail: { quantity: body.quantity, toBranchId: body.toBranchId } });
  return ok({ transferred: true });
}, { auth: true, rate: { limit: 30, windowMs: 60_000 } });
