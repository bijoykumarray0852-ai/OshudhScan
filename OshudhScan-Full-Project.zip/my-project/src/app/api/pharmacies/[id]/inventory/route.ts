import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, pageArgs, searchParams, audit } from "@/lib/api";
import { ApiError, requireUser } from "@/lib/auth";
import { assertPharmacyAccess, canManageInventory } from "@/lib/pharmacy-access";
import { isExpiredBatch, stockStatus } from "@/lib/geo";

const addSchema = z.object({
  medicineId: z.string().min(1),
  batchNumber: z.string().max(60).optional(),
  mfgDate: z.string().optional(),
  expiryDate: z.string().optional(),
  purchasePrice: z.number().min(0).optional(),
  sellingPrice: z.number().min(0).optional(),
  quantity: z.number().int().min(0).max(100000),
  lowStockThreshold: z.number().int().min(0).max(1000).optional(),
});

// GET /api/pharmacies/[id]/inventory — full batch view incl. expired (flagged).
// STAFF-ONLY: batches include purchase prices and commercial data — patients
// use /api/availability instead, which exposes only reported stock status.
export const GET = withApi(async ({ req, params, user }) => {
  const { id } = params as { id: string };
  const u = await requireUser();
  await assertPharmacyAccess(u, id);
  const sp = searchParams(req);
  const { skip, take } = pageArgs(sp, 100);
  const rows = await db.pharmacyInventory.findMany({
    where: { pharmacyId: id },
    include: { medicine: { select: { id: true, brand: true, generic: true, strength: true, form: true, unitPriceBdt: true } } },
    orderBy: { updatedAt: "desc" },
    skip,
    take,
  });
  const now = new Date();
  return ok({
    inventory: rows.map((r) => {
      const expired = isExpiredBatch(r.expiryDate, now);
      return {
        id: r.id,
        medicineId: r.medicine.id,
        brand: r.medicine.brand,
        generic: r.medicine.generic,
        strength: r.medicine.strength,
        form: r.medicine.form,
        batchNumber: r.batchNumber,
        mfgDate: r.mfgDate,
        expiryDate: r.expiryDate,
        purchasePrice: r.purchasePrice,
        sellingPrice: r.sellingPrice,
        quantity: r.quantity,
        lowStockThreshold: r.lowStockThreshold,
        status: r.status,
        expired,
        expiringIn90Days: r.expiryDate ? r.expiryDate.getTime() - now.getTime() < 90 * 24 * 3600 * 1000 && !expired : false,
        stockStatus: expired ? "EXPIRED" : stockStatus(r.quantity, r.updatedAt, now),
        updatedAt: r.updatedAt,
      };
    }),
  });
}, { auth: true, rate: { limit: 90, windowMs: 60_000 } });

// POST /api/pharmacies/[id]/inventory — add batch (expired batches rejected).
export const POST = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  const staff = await assertPharmacyAccess(u, id);
  if (!canManageInventory(staff.role)) throw new ApiError(403, "FORBIDDEN", "Insufficient permissions");
  const body = await parseJson(req, addSchema);

  const medicine = await db.medicine.findUnique({ where: { id: body.medicineId } });
  if (!medicine || !medicine.isActive) return fail(400, "VALIDATION", "Unknown medicine");

  const expiry = body.expiryDate ? new Date(body.expiryDate) : null;
  if (expiry && isExpiredBatch(expiry)) {
    return fail(422, "EXPIRED_BATCH", "Expired batches cannot be added as available for dispensing");
  }
  if (expiry && !body.mfgDate) {
    return fail(422, "VALIDATION", "Manufacturing date is required when an expiry date is given (pharmacist verification)");
  }

  const inv = await db.pharmacyInventory.upsert({
    where: { pharmacyId_medicineId_batchNumber: { pharmacyId: id, medicineId: body.medicineId, batchNumber: body.batchNumber ?? "" } },
    create: {
      pharmacyId: id,
      medicineId: body.medicineId,
      batchNumber: body.batchNumber,
      mfgDate: body.mfgDate ? new Date(body.mfgDate) : null,
      expiryDate: expiry,
      purchasePrice: body.purchasePrice,
      sellingPrice: body.sellingPrice ?? medicine.unitPriceBdt,
      quantity: body.quantity,
      lowStockThreshold: body.lowStockThreshold ?? 10,
      status: "ACTIVE",
      movements: { create: { type: "IN", quantity: body.quantity, unitPrice: body.purchasePrice, userId: u.id } },
    },
    update: {
      quantity: body.quantity,
      mfgDate: body.mfgDate ? new Date(body.mfgDate) : undefined,
      expiryDate: expiry,
      purchasePrice: body.purchasePrice,
      sellingPrice: body.sellingPrice,
      lowStockThreshold: body.lowStockThreshold,
      updatedAt: new Date(),
    },
  });
  await audit(req, { userId: u.id, action: "INVENTORY_UPSERT", entity: "pharmacy_inventory", entityId: inv.id, detail: { pharmacyId: id, medicineId: body.medicineId, quantity: body.quantity } });
  return ok({ inventory: { id: inv.id } }, { status: 201 });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// PATCH /api/pharmacies/[id]/inventory — update one batch row (quantity/price).
export const PATCH = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  const staff = await assertPharmacyAccess(u, id);
  if (!canManageInventory(staff.role)) throw new ApiError(403, "FORBIDDEN", "Insufficient permissions");
  const body = await parseJson(req, z.object({
    inventoryId: z.string(),
    quantity: z.number().int().min(0).optional(),
    sellingPrice: z.number().min(0).optional(),
    lowStockThreshold: z.number().int().min(0).optional(),
  }));
  const inv = await db.pharmacyInventory.findFirst({ where: { id: body.inventoryId, pharmacyId: id } });
  if (!inv) return fail(404, "NOT_FOUND", "Inventory record not found");
  if (isExpiredBatch(inv.expiryDate) && body.quantity !== undefined && body.quantity > 0) {
    return fail(422, "EXPIRED_BATCH", "Expired batches cannot be marked available for dispensing");
  }
  const updated = await db.pharmacyInventory.update({
    where: { id: inv.id },
    data: {
      quantity: body.quantity ?? inv.quantity,
      sellingPrice: body.sellingPrice ?? inv.sellingPrice,
      lowStockThreshold: body.lowStockThreshold ?? inv.lowStockThreshold,
      updatedAt: new Date(),
    },
  });
  if (body.quantity !== undefined && body.quantity !== inv.quantity) {
    await db.inventoryMovement.create({
      data: { inventoryId: inv.id, type: "ADJUST", quantity: body.quantity - inv.quantity, userId: u.id },
    });
  }
  await audit(req, { userId: u.id, action: "INVENTORY_UPDATE", entity: "pharmacy_inventory", entityId: inv.id });
  return ok({ inventory: { id: updated.id, quantity: updated.quantity } });
}, { auth: true, rate: { limit: 90, windowMs: 60_000 } });

// DELETE /api/pharmacies/[id]/inventory?inventoryId= — archive record.
export const DELETE = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  const staff = await assertPharmacyAccess(u, id);
  if (!canManageInventory(staff.role)) throw new ApiError(403, "FORBIDDEN", "Insufficient permissions");
  const inventoryId = searchParams(req).get("inventoryId");
  if (!inventoryId) return fail(400, "VALIDATION", "inventoryId required");
  const inv = await db.pharmacyInventory.findFirst({ where: { id: inventoryId, pharmacyId: id } });
  if (!inv) return fail(404, "NOT_FOUND", "Inventory record not found");
  if (inv.quantity > 0) {
    await db.inventoryMovement.create({ data: { inventoryId: inv.id, type: "EXPIRED_WRITEOFF", quantity: -inv.quantity, userId: u.id } });
  }
  await db.pharmacyInventory.update({ where: { id: inv.id }, data: { status: "ARCHIVED", quantity: 0, updatedAt: new Date() } });
  await audit(req, { userId: u.id, action: "INVENTORY_ARCHIVE", entity: "pharmacy_inventory", entityId: inv.id });
  return ok({ archived: true });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
