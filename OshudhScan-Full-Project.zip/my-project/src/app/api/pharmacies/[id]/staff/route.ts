import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, audit } from "@/lib/api";
import { requireUser, ApiError } from "@/lib/auth";
import { assertPharmacyAccess, canManageStaff } from "@/lib/pharmacy-access";

// GET /api/pharmacies/[id]/staff
export const GET = withApi(async ({ params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const staff = await db.pharmacyStaff.findMany({
    where: { pharmacyId: id },
    include: { user: { select: { id: true, name: true, email: true, phone: true } } },
  });
  return ok({ staff: staff.map((s) => ({ id: s.id, role: s.role, userId: s.user.id, name: s.user.name, email: s.user.email, phone: s.user.phone })) });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// POST /api/pharmacies/[id]/staff — owner adds a staff member by email.
export const POST = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  const staff = await assertPharmacyAccess(u, id);
  if (!canManageStaff(staff.role)) throw new ApiError(403, "FORBIDDEN", "Only the owner can manage staff");
  const body = await parseJson(req, z.object({
    email: z.string().email(),
    role: z.enum(["PHARMACIST", "MANAGER", "INVENTORY_STAFF"]),
  }));
  const member = await db.user.findUnique({ where: { email: body.email.toLowerCase() } });
  if (!member || member.deletedAt) return fail(404, "NOT_FOUND", "No OshudhScan account with that email — ask them to register first");
  const exists = await db.pharmacyStaff.findUnique({ where: { pharmacyId_userId: { pharmacyId: id, userId: member.id } } });
  if (exists) return fail(409, "CONFLICT", "This person is already staff of the pharmacy");
  const row = await db.pharmacyStaff.create({ data: { pharmacyId: id, userId: member.id, role: body.role } });
  await db.notification.create({
    data: { userId: member.id, type: "SYSTEM", title: "Added to pharmacy team", body: `You were added as ${body.role.replace("_", " ").toLowerCase()} — sign in to see the pharmacy portal.` },
  });
  await audit(req, { userId: u.id, action: "STAFF_ADD", entity: "pharmacy_staff", entityId: row.id, detail: { role: body.role } });
  return ok({ staff: { id: row.id, role: row.role } }, { status: 201 });
}, { auth: true, rate: { limit: 20, windowMs: 60_000 } });

// DELETE /api/pharmacies/[id]/staff?staffId=
export const DELETE = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  const staff = await assertPharmacyAccess(u, id);
  if (!canManageStaff(staff.role)) throw new ApiError(403, "FORBIDDEN", "Only the owner can manage staff");
  const staffId = new URL(req.url).searchParams.get("staffId");
  if (!staffId) return fail(400, "VALIDATION", "staffId required");
  const row = await db.pharmacyStaff.findFirst({ where: { id: staffId, pharmacyId: id } });
  if (!row) return fail(404, "NOT_FOUND", "Staff record not found");
  if (row.role === "OWNER") return fail(422, "FORBIDDEN", "The owner record cannot be removed");
  await db.pharmacyStaff.delete({ where: { id: row.id } });
  await audit(req, { userId: u.id, action: "STAFF_REMOVE", entity: "pharmacy_staff", entityId: row.id });
  return ok({ removed: true });
}, { auth: true, rate: { limit: 20, windowMs: 60_000 } });
