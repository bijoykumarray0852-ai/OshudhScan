import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, audit } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { assertPharmacyAccess } from "@/lib/pharmacy-access";

// GET /api/pharmacies/[id]/verify — verification status for the owner.
export const GET = withApi(async ({ params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const rows = await db.pharmacyVerification.findMany({ where: { pharmacyId: id }, orderBy: { submittedAt: "desc" } });
  const pharmacy = await db.pharmacy.findUnique({ where: { id }, select: { status: true, isVerified: true, licenseNumber: true } });
  return ok({
    status: pharmacy?.status,
    isVerified: pharmacy?.isVerified,
    requests: rows.map((r) => ({ id: r.id, licenseNumber: r.licenseNumber, licenseType: r.licenseType, status: r.status, reviewNote: r.reviewNote, submittedAt: r.submittedAt, reviewedAt: r.reviewedAt })),
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// POST /api/pharmacies/[id]/verify — owner submits / resubmits verification.
export const POST = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  await assertPharmacyAccess(u, id);
  const body = await parseJson(req, z.object({
    licenseNumber: z.string().min(3).max(60),
    licenseType: z.enum(["RETAIL", "WHOLESALE", "RETAIL_WHOLESALE"]),
    pharmacistName: z.string().max(100).optional(),
    pharmacistReg: z.string().max(40).optional(),
    documentsNote: z.string().max(300).optional(),
  }));
  const request = await db.pharmacyVerification.create({
    data: {
      pharmacyId: id,
      licenseNumber: body.licenseNumber,
      licenseType: body.licenseType,
      pharmacistName: body.pharmacistName,
      pharmacistReg: body.pharmacistReg,
      drugLicenseDoc: body.documentsNote ? JSON.stringify({ note: body.documentsNote }) : null,
      status: "PENDING",
    },
  });
  await db.pharmacy.update({ where: { id }, data: { status: "PENDING", isVerified: false, licenseNumber: body.licenseNumber } });
  await audit(req, { userId: u.id, action: "VERIFICATION_SUBMITTED", entity: "pharmacy_verification", entityId: request.id, detail: { pharmacyId: id } });
  return ok({ request: { id: request.id, status: request.status } }, { status: 201 });
}, { auth: true, rate: { limit: 5, windowMs: 60 * 60_000 } });
