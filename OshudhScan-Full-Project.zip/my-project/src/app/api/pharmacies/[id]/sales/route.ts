import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, searchParams, audit, pageArgs } from "@/lib/api";
import { requireUser, ApiError } from "@/lib/auth";
import { assertPharmacyAccess, canRecordSales } from "@/lib/pharmacy-access";

const saleSchema = z.object({
  items: z.array(z.object({
    medicineId: z.string().min(1),
    label: z.string().max(120),
    quantity: z.number().int().min(1).max(1000),
    unitPrice: z.number().min(0),
  })).min(1).max(50),
});

function todayInvoice(): string {
  const d = new Date();
  const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  return `INV-${stamp}-${Math.floor(Math.random() * 9000 + 1000)}`;
}

// GET /api/pharmacies/[id]/sales — history + daily/monthly aggregates.
export const GET = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  const staff = await assertPharmacyAccess(u, id);
  if (!canRecordSales(staff.role)) throw new ApiError(403, "FORBIDDEN", "Insufficient permissions");
  const { skip, take } = pageArgs(searchParams(req), 30);
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  const dayStart = new Date();
  dayStart.setHours(0, 0, 0, 0);

  const [sales, total, todayAgg, monthAgg] = await Promise.all([
    db.pharmacySale.findMany({ where: { pharmacyId: id }, orderBy: { soldAt: "desc" }, skip, take }),
    db.pharmacySale.count({ where: { pharmacyId: id } }),
    db.pharmacySale.aggregate({ where: { pharmacyId: id, soldAt: { gte: dayStart } }, _sum: { totalBdt: true }, _count: true }),
    db.pharmacySale.aggregate({ where: { pharmacyId: id, soldAt: { gte: monthStart } }, _sum: { totalBdt: true }, _count: true }),
  ]);

  return ok({
    sales: sales.map((s) => ({ id: s.id, invoiceNo: s.invoiceNo, items: JSON.parse(s.items), totalBdt: s.totalBdt, soldAt: s.soldAt })),
    total,
    today: { revenue: todayAgg._sum.totalBdt ?? 0, count: todayAgg._count },
    month: { revenue: monthAgg._sum.totalBdt ?? 0, count: monthAgg._count },
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// POST /api/pharmacies/[id]/sales — record a sale; decrements inventory (FIFO
// across active, unexpired batches) inside a transaction.
export const POST = withApi(async ({ req, params, user }) => {
  const u = await requireUser();
  const { id } = params as { id: string };
  const staff = await assertPharmacyAccess(u, id);
  if (!canRecordSales(staff.role)) throw new ApiError(403, "FORBIDDEN", "Insufficient permissions");
  const body = await parseJson(req, saleSchema);
  const now = new Date();

  const result = await db.$transaction(async (tx) => {
    const total = body.items.reduce((acc, i) => acc + i.quantity * i.unitPrice, 0);
    const sale = await tx.pharmacySale.create({
      data: {
        pharmacyId: id,
        invoiceNo: todayInvoice(),
        items: JSON.stringify(body.items),
        totalBdt: Math.round(total * 100) / 100,
        soldById: u.id,
        soldAt: now,
      },
    });
    for (const item of body.items) {
      const batches = await tx.pharmacyInventory.findMany({
        where: { pharmacyId: id, medicineId: item.medicineId, status: "ACTIVE", quantity: { gt: 0 } },
        orderBy: { updatedAt: "asc" },
      });
      let remaining = item.quantity;
      for (const batch of batches) {
        if (remaining <= 0) break;
        if (batch.expiryDate && batch.expiryDate < now) continue; // never sell expired
        const takeQty = Math.min(batch.quantity, remaining);
        await tx.pharmacyInventory.update({ where: { id: batch.id }, data: { quantity: batch.quantity - takeQty, updatedAt: now } });
        await tx.inventoryMovement.create({ data: { inventoryId: batch.id, type: "OUT", quantity: -takeQty, unitPrice: item.unitPrice, reference: sale.id, userId: u.id } });
        remaining -= takeQty;
      }
      if (remaining > 0) {
        throw new ApiError(422, "INSUFFICIENT_STOCK", `Not enough unexpired stock for ${item.label}`);
      }
    }
    return sale;
  });

  await audit(req, { userId: u.id, action: "SALE_RECORDED", entity: "pharmacy_sale", entityId: result.id, detail: { pharmacyId: id, total: result.totalBdt } });
  return ok({ sale: { id: result.id, invoiceNo: result.invoiceNo, totalBdt: result.totalBdt } }, { status: 201 });
}, { auth: true, rate: { limit: 90, windowMs: 60_000 } });
