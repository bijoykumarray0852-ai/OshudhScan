import { withApi, ok, fail, searchParams } from "@/lib/api";
import { queryPharmacies } from "@/lib/directory-server";

// GET /api/pharmacies/nearby?lat=&lng=&distance= — GPS pharmacy finder
// (stable alias of the /api/pharmacies geo search for the national directory).
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  if (Number.isNaN(lat) || Number.isNaN(lng)) return fail(400, "VALIDATION", "lat and lng are required");
  const distance = Math.min(50, Math.max(0.5, parseFloat(sp.get("distance") ?? "") || 10));
  const { rows } = await queryPharmacies({ origin: { lat, lng }, distanceKm: distance, take: 2000 });
  const nearby = rows
    .sort((a, b) => (a.distanceKm ?? 0) - (b.distanceKm ?? 0))
    .slice(0, 50);
  return ok({ pharmacies: nearby, total: nearby.length, center: { lat, lng }, distanceKm: distance });
}, { rate: { limit: 60, windowMs: 60_000 } });
