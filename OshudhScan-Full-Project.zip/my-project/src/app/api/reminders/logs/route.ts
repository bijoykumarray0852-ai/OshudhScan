import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, audit } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { isMissed, MISSED_AFTER_MINUTES } from "@/lib/reminders";

// POST /api/reminders/logs — log a dose (taken/skipped/snoozed) or auto-miss.
// Safety: logging NEVER modifies the prescription or suggests doubling.
export const POST = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, z.object({
    reminderId: z.string(),
    action: z.enum(["TAKEN", "SKIPPED", "SNOOZED", "MISSED"]),
    note: z.string().max(200).optional(),
  }));

  const reminder = await db.medicineReminder.findUnique({ where: { id: body.reminderId }, include: { schedule: true } });
  if (!reminder) return fail(404, "NOT_FOUND", "Reminder not found");
  if (reminder.schedule.patientUserId !== u.id) return fail(403, "FORBIDDEN", "Not your schedule");

  const now = new Date();
  if (body.action === "SNOOZED") {
    const snoozedTo = new Date(now.getTime() + 30 * 60 * 1000);
    await db.medicineReminder.update({ where: { id: reminder.id }, data: { status: "SNOOZED", snoozedTo, loggedAt: now, logNote: body.note } });
    // create the follow-up dose row for the snooze
    await db.medicineReminder.create({ data: { scheduleId: reminder.scheduleId, dueAt: snoozedTo, slot: "CUSTOM", status: "PENDING", logNote: `snoozed from ${reminder.dueAt.toISOString()}` } });
  } else if (body.action === "MISSED") {
    if (!isMissed(reminder.dueAt, reminder.status, now)) return fail(422, "VALIDATION", "This dose is not marked missed yet");
    await db.medicineReminder.update({ where: { id: reminder.id }, data: { status: "MISSED", loggedAt: now } });
    await db.notification.create({
      data: {
        userId: u.id,
        type: "MISSED_DOSE",
        title: "Missed dose",
        body: `You missed ${reminder.schedule.medicineLabel} (${reminder.slot.toLowerCase()}). Do NOT double the next dose — ask your doctor or pharmacist what to do.`,
        data: JSON.stringify({ scheduleId: reminder.scheduleId }),
      },
    });
  } else {
    await db.medicineReminder.update({ where: { id: reminder.id }, data: { status: body.action, loggedAt: now, logNote: body.note } });
    // refill nudges when a taken dose was the 3rd-from-last planned dose
    const remaining = await db.medicineReminder.count({ where: { scheduleId: reminder.scheduleId, status: { in: ["PENDING", "SNOOZED"] } } });
    if (body.action === "TAKEN" && remaining === 0) {
      const all = await db.medicineReminder.count({ where: { scheduleId: reminder.scheduleId } });
      await db.notification.create({
        data: { userId: u.id, type: "COURSE_COMPLETE", title: "Course completed", body: `All ${all} planned doses of ${reminder.schedule.medicineLabel} are logged. Well done — confirm next steps with your doctor or pharmacist.`, data: JSON.stringify({ scheduleId: reminder.scheduleId }) },
      });
    }
  }
  await audit(req, { userId: u.id, action: `DOSE_${body.action}`, entity: "medicine_reminder", entityId: reminder.id });
  return ok({ logged: body.action });
}, { auth: true, rate: { limit: 120, windowMs: 60_000 } });

// GET /api/reminders/logs?scheduleId= — history.
export const GET = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const scheduleId = new URL(req.url).searchParams.get("scheduleId");
  if (!scheduleId) return fail(400, "VALIDATION", "scheduleId required");
  const s = await db.dosageSchedule.findFirst({ where: { id: scheduleId, patientUserId: u.id } });
  if (!s) return fail(404, "NOT_FOUND", "Schedule not found");
  const logs = await db.medicineReminder.findMany({ where: { scheduleId }, orderBy: { dueAt: "desc" }, take: 200 });
  return ok({
    logs: logs.map((l) => ({ id: l.id, dueAt: l.dueAt, slot: l.slot, status: l.status, loggedAt: l.loggedAt, note: l.logNote, snoozedTo: l.snoozedTo })),
    missedThresholdMinutes: MISSED_AFTER_MINUTES,
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
