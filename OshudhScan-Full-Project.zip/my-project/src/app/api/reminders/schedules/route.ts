import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, searchParams, audit } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { expandSchedule, isCourseComplete, adherencePct, refillNeeded, type Slot } from "@/lib/reminders";
import { templateExplain } from "@/lib/bangla";

const createSchema = z.object({
  medicineLabel: z.string().min(1).max(120),
  medicineId: z.string().optional(),
  slots: z.array(z.enum(["MORNING", "AFTERNOON", "NIGHT"])).min(1).max(3),
  customTimes: z.record(z.string(), z.string().regex(/^\d{2}:\d{2}$/)).optional(),
  perDay: z.number().int().min(1).max(12),
  startDate: z.string().optional(),
  durationDays: z.number().int().min(1).max(720).optional(),
  meal: z.enum(["after", "before", "any"]).optional(),
  instructionBangla: z.string().max(300).optional(),
  instructionEnglish: z.string().max(300).optional(),
  prescriptionItemId: z.string().optional(),
  familyMemberId: z.string().optional(),
  confirmed: z.boolean(),
});

// GET /api/reminders/schedules — active + past schedules with today's doses.
export const GET = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const sp = searchParams(req);
  const statusFilter = sp.get("status");
  const where: Record<string, unknown> = { patientUserId: u.id };
  if (statusFilter) where.status = statusFilter;

  const schedules = await db.dosageSchedule.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: {
      reminders: { orderBy: { dueAt: "asc" } },
      familyMember: { select: { name: true, relation: true } },
    },
  });

  const now = new Date();
  const todayStart = new Date(now);
  todayStart.setHours(0, 0, 0, 0);
  const todayEnd = new Date(todayStart);
  todayEnd.setDate(todayEnd.getDate() + 1);

  return ok({
    schedules: schedules.map((s) => {
      const todayDoses = s.reminders.filter((r) => r.dueAt >= todayStart && r.dueAt < todayEnd);
      const endDate = s.endDate;
      const complete = isCourseComplete(s.reminders, endDate, now);
      const daysElapsed = s.startDate ? Math.max(0, Math.floor((now.getTime() - new Date(s.startDate).getTime()) / (24 * 3600 * 1000))) : 0;
      return {
        id: s.id,
        medicineLabel: s.medicineLabel,
        strength: s.strength,
        slots: JSON.parse(s.slots),
        customTimes: s.customTimes ? JSON.parse(s.customTimes) : null,
        perDay: s.perDay,
        startDate: s.startDate,
        endDate: s.endDate,
        durationDays: s.durationDays,
        meal: s.meal,
        instructionBangla: s.instructionBangla,
        instructionEnglish: s.instructionEnglish,
        status: complete && s.status === "ACTIVE" ? "COMPLETED" : s.status,
        confirmedBy: s.confirmedBy,
        familyMember: s.familyMember,
        stockDays: s.stockDays,
        refillNeeded: refillNeeded(s.stockDays, daysElapsed, s.durationDays),
        adherence: adherencePct(s.reminders),
        todayDoses: todayDoses.map((r) => ({ id: r.id, dueAt: r.dueAt, slot: r.slot, status: r.status })),
        totalDoses: s.reminders.length,
        pendingDoses: s.reminders.filter((r) => r.status === "PENDING" || r.status === "SNOOZED").length,
      };
    }),
    disclaimer: "Reminders are memory aids, not medical advice. OshudhScan never changes the prescriber's instructions and never suggests doubling a missed dose.",
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// POST /api/reminders/schedules — create + expand into dose rows.
// Requires explicit confirmation (confirmed=true) — DRAFT otherwise.
export const POST = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, createSchema);

  if (body.perDay !== body.slots.length) {
    return fail(422, "VALIDATION", "Number of times of day must match the daily dose count — never auto-expand an ambiguous dosage");
  }

  const startDate = body.startDate ? new Date(body.startDate) : new Date();
  startDate.setHours(0, 0, 0, 0);
  const endDate = body.durationDays
    ? new Date(startDate.getTime() + (body.durationDays - 1) * 24 * 3600 * 1000)
    : null;

  // default Bangla instruction from the deterministic template layer
  const doseStr = ["MORNING", "AFTERNOON", "NIGHT"]
    .map((s) => (body.slots.includes(s as Slot) ? "1" : "0"))
    .join("+");
  const instructionBn =
    body.instructionBangla ??
    templateExplain([
      {
        id: "rem",
        brand: body.medicineLabel,
        brandRaw: body.medicineLabel,
        genericBangla: null,
        strength: null,
        form: null,
        dose: doseStr,
        duration: body.durationDays ? `${body.durationDays} days` : null,
        meal: body.meal ?? "any",
        therapeuticClass: null,
      },
    ]).items[0]?.bangla ?? null;

  const planned = expandSchedule(
    body.slots,
    startDate,
    body.durationDays ?? null,
    body.customTimes as Partial<Record<Slot, string>> | undefined,
    body.durationDays ? Math.max(31, body.durationDays + 1) : 30
  );

  const created = await db.dosageSchedule.create({
    data: {
      patientUserId: u.id,
      prescriptionItemId: body.prescriptionItemId,
      familyMemberId: body.familyMemberId,
      medicineId: body.medicineId,
      medicineLabel: body.medicineLabel,
      slots: JSON.stringify(body.slots),
      customTimes: body.customTimes ? JSON.stringify(body.customTimes) : null,
      perDay: body.perDay,
      startDate,
      endDate,
      durationDays: body.durationDays,
      meal: body.meal,
      instructionBangla: instructionBn,
      instructionEnglish: body.instructionEnglish,
      status: body.confirmed ? "ACTIVE" : "DRAFT",
      confirmedBy: body.confirmed ? "USER" : null,
      reminders: {
        create: planned.map((p) => ({ dueAt: p.dueAt, slot: p.slot, status: "PENDING" })),
      },
    },
    include: { reminders: true },
  });
  await audit(req, { userId: u.id, action: "SCHEDULE_CREATE", entity: "dosage_schedule", entityId: created.id, detail: { doses: created.reminders.length, confirmed: body.confirmed } });
  return ok({ schedule: { id: created.id, doses: created.reminders.length, status: created.status } }, { status: 201 });
}, { auth: true, rate: { limit: 15, windowMs: 60 * 60_000 } });

// PATCH /api/reminders/schedules?id= — stop/complete a course (never edits doses).
export const PATCH = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, z.object({
    id: z.string(),
    action: z.enum(["STOP", "ACTIVATE", "SET_STOCK"]),
    stockDays: z.number().int().min(0).max(365).optional(),
  }));
  const s = await db.dosageSchedule.findFirst({ where: { id: body.id, patientUserId: u.id } });
  if (!s) return fail(404, "NOT_FOUND", "Schedule not found");
  if (body.action === "STOP") {
    await db.dosageSchedule.update({ where: { id: s.id }, data: { status: "CANCELLED" } });
    await db.medicineReminder.updateMany({ where: { scheduleId: s.id, status: { in: ["PENDING", "SNOOZED"] } }, data: { status: "SKIPPED", logNote: "schedule cancelled by user" } });
    await audit(req, { userId: u.id, action: "SCHEDULE_STOP", entity: "dosage_schedule", entityId: s.id });
    return ok({ status: "CANCELLED" });
  }
  if (body.action === "ACTIVATE") {
    if (s.status !== "DRAFT") return fail(422, "VALIDATION", "Only drafts can be activated");
    await db.dosageSchedule.update({ where: { id: s.id }, data: { status: "ACTIVE", confirmedBy: "USER" } });
    await audit(req, { userId: u.id, action: "SCHEDULE_ACTIVATE", entity: "dosage_schedule", entityId: s.id });
    return ok({ status: "ACTIVE" });
  }
  await db.dosageSchedule.update({ where: { id: s.id }, data: { stockDays: body.stockDays ?? 0 } });
  return ok({ stockDays: body.stockDays });
}, { auth: true, rate: { limit: 30, windowMs: 60_000 } });
