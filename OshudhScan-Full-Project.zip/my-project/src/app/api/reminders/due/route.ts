import { db } from "@/lib/db";
import { withApi, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { isMissed } from "@/lib/reminders";

// GET /api/reminders/due — materialize missed doses (idempotent), then return
// today's upcoming doses + unread notification count for the dashboard.
export const GET = withApi(async ({ user }) => {
  const u = await requireUser();
  const now = new Date();

  // 1. mark overdue PENDING doses as MISSED and notify (once per dose)
  const schedules = await db.dosageSchedule.findMany({
    where: { patientUserId: u.id, status: "ACTIVE" },
    include: { reminders: { where: { status: { in: ["PENDING", "SNOOZED"] } } } },
  });
  let newlyMissed = 0;
  for (const s of schedules) {
    for (const r of s.reminders) {
      const snoozeRef = r.status === "SNOOZED" && r.snoozedTo ? r.snoozedTo : r.dueAt;
      if (isMissed(r.status === "SNOOZED" ? snoozeRef : r.dueAt, r.status, now)) {
        await db.medicineReminder.update({ where: { id: r.id }, data: { status: "MISSED", loggedAt: now } });
        newlyMissed++;
        await db.notification.create({
          data: {
            userId: u.id,
            type: "MISSED_DOSE",
            title: "Missed dose",
            body: `${s.medicineLabel} (${r.slot.toLowerCase()}) was not logged. Do NOT double the next dose — ask your doctor or pharmacist what to do.`,
            data: JSON.stringify({ scheduleId: s.id, reminderId: r.id }),
          },
        });
      }
    }
  }

  // 2. upcoming doses in the next 12 hours + today's list
  const horizon = new Date(now.getTime() + 12 * 3600 * 1000);
  const upcoming = await db.medicineReminder.findMany({
    where: { scheduleId: { in: schedules.map((s) => s.id) }, dueAt: { gte: now, lte: horizon }, status: { in: ["PENDING", "SNOOZED"] } },
    orderBy: { dueAt: "asc" },
    include: { schedule: { select: { id: true, medicineLabel: true, meal: true, instructionBangla: true, instructionEnglish: true, status: true } } },
    take: 10,
  });
  const unread = await db.notification.count({ where: { userId: u.id, readAt: null } });

  return ok({
    upcoming: upcoming.map((r) => ({
      id: r.id,
      scheduleId: r.schedule.id,
      medicineLabel: r.schedule.medicineLabel,
      meal: r.schedule.meal,
      instructionBangla: r.schedule.instructionBangla,
      instructionEnglish: r.schedule.instructionEnglish,
      dueAt: r.dueAt,
      slot: r.slot,
      status: r.status,
    })),
    newlyMissed,
    unreadNotifications: unread,
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
