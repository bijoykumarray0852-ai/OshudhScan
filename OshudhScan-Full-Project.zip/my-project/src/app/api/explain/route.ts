import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { templateExplain } from "@/lib/bangla";

interface ExplainItem {
  id: string;
  brandRaw: string;
  brand: string | null;
  generic: string | null;
  strength: string | null;
  dose: string | null;
  duration: string | null;
  meal: string | null;
  therapeuticClass: string | null;
}

const LLM_SYSTEM = `You are a senior community pharmacist in Bangladesh writing dosage instructions for a patient who reads only simple Bangla.
For EACH medicine write ONE short Bangla sentence telling: when to take it (morning/noon/night), before or after food, how many, and for how many days.
Use everyday Bangla (no English words), Bangla numerals (১, ২, ৩), and add one short practical caution where clinically relevant (e.g. blood thinner → mention INR test; metronidazole → alcohol forbidden; sedative → don't drive; PPI → before food).
Return STRICT JSON only, no markdown fences, shape:
{"items": [{"id": "<same id as input>", "bangla": "<instruction sentence ending with ।>", "note": "<short caution or empty>"}], "summary": "<one reassuring Bangla sentence about finishing the course>"}`;

function stripFences(text: string): string {
  return text
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/```\s*$/i, "")
    .trim();
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { items?: ExplainItem[] };
    const items = body.items ?? [];
    if (items.length === 0) {
      return NextResponse.json({ ok: false, error: "No items" }, { status: 400 });
    }

    // Deterministic template result — always available, also the fallback.
    const tpl = templateExplain(
      items.map((it) => ({
        id: it.id,
        brand: it.brand,
        brandRaw: it.brandRaw,
        genericBangla: null,
        strength: it.strength,
        form: null,
        dose: it.dose,
        duration: it.duration,
        meal: it.meal,
        therapeuticClass: it.therapeuticClass,
      }))
    );

    try {
      const zai = await ZAI.create();
      const completion = await Promise.race([
        zai.chat.completions.create({
          messages: [
            { role: "assistant", content: LLM_SYSTEM },
            {
              role: "user",
              content: JSON.stringify(
                items.map((it) => ({
                  id: it.id,
                  brand: it.brand ?? it.brandRaw,
                  generic: it.generic,
                  strength: it.strength,
                  dose: it.dose,
                  duration: it.duration,
                  meal: it.meal,
                }))
              ),
            },
          ],
          thinking: { type: "disabled" },
        }),
        new Promise<never>((_, reject) => setTimeout(() => reject(new Error("LLM timeout (15s)")), 15000)),
      ]);
      const content: string = completion?.choices?.[0]?.message?.content ?? "";
      const parsed = JSON.parse(stripFences(content));
      if (parsed && Array.isArray(parsed.items) && parsed.items.length > 0) {
        const byId = new Map(tpl.items.map((t) => [t.id, t]));
        const merged = parsed.items.map(
          (li: { id?: string; bangla?: string; note?: string }) => {
            const fallback = byId.get(li.id ?? "") ?? { bangla: "", note: "" };
            return {
              id: li.id ?? "",
              brand: items.find((it) => it.id === li.id)?.brand ?? "",
              bangla: (li.bangla ?? fallback.bangla).toString().slice(0, 300),
              note: (li.note ?? fallback.note).toString().slice(0, 200),
            };
          }
        );
        // Guarantee every input id has an entry (LLM occasionally drops one)
        for (const t of tpl.items) {
          if (!merged.some((m: { id: string }) => m.id === t.id)) {
            merged.push({ id: t.id, brand: t.brand, bangla: t.bangla, note: t.note });
          }
        }
        return NextResponse.json({
          ok: true,
          generatedBy: "llm",
          items: merged,
          summary: String(parsed.summary ?? tpl.summary).slice(0, 400),
        });
      }
      throw new Error("Empty LLM explanation");
    } catch {
      return NextResponse.json({
        ok: true,
        generatedBy: "template",
        items: tpl.items,
        summary: tpl.summary,
      });
    }
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "Explain failed" },
      { status: 500 }
    );
  }
}
