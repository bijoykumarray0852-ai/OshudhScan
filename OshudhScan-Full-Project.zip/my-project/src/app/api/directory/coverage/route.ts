import { withApi, ok } from "@/lib/api";
import { db } from "@/lib/db";
import { DIVISIONS } from "@/lib/data/locations";
import { coverageLevel } from "@/lib/directory";
import type { CoverageLevel } from "@/lib/directory";

export { coverageLevel };
export type { CoverageLevel };

export interface DistrictCoverage {
  district: string;
  districtBangla: string | null;
  division: string | null;
  hospital: number;
  clinic: number;
  diagnostic: number;
  pharmacy: number;
  emergency: number;
  total: number;
  level: CoverageLevel;
}

export interface DivisionCoverage {
  division: string;
  divisionBangla: string | null;
  districts: number;
  hospital: number;
  clinic: number;
  diagnostic: number;
  pharmacy: number;
  total: number;
  level: CoverageLevel;
}

// GET /api/directory/coverage — public national dashboard: how many hospitals,
// clinics, diagnostics and pharmacies are listed per district, which divisions
// are well covered and which areas still have little data.
export const GET = withApi(async () => {
  const [facByDistrict, facByDivision, phByDistrict, phByDivision, emergencyFacByDistrict, districtRows] = await Promise.all([
    db.healthcareFacility.groupBy({ by: ["district", "type"], _count: true, where: { deletedAt: null } }),
    db.healthcareFacility.groupBy({ by: ["division", "type"], _count: true, where: { deletedAt: null } }),
    db.pharmacy.groupBy({ by: ["district"], _count: true, where: { deletedAt: null } }),
    db.pharmacy.groupBy({ by: ["division"], _count: true, where: { deletedAt: null } }),
    db.healthcareFacility.groupBy({ by: ["district"], _count: true, where: { deletedAt: null, emergency: true } }),
    db.administrativeLocation.findMany({
      where: { level: "DISTRICT" },
      select: { name: true, nameBangla: true, division: true },
      orderBy: { name: "asc" },
    }),
  ]);

  const facD = new Map(facByDistrict.map((r) => [r.district ?? "", r._count]));
  const facDiv = new Map(facByDivision.map((r) => [r.division ?? "", r._count]));
  const phD = new Map(phByDistrict.map((r) => [r.district ?? "", r._count]));
  const phDiv = new Map(phByDivision.map((r) => [r.division ?? "", r._count]));
  const emergencyD = new Map(emergencyFacByDistrict.map((r) => [r.district ?? "", r._count]));

  const sumType = (rows: Array<{ _count: number; district?: string | null; division?: string | null; type: string }>, key: string, keyName: "district" | "division", type: string) =>
    rows.filter((r) => r[keyName] === key && r.type === type).reduce((s, r) => s + r._count, 0);

  const districts = districtRows.map((d) => {
    const facTotal = facD.get(d.name) ?? 0;
    const pharmacy = phD.get(d.name) ?? 0;
    return {
      district: d.name,
      districtBangla: d.nameBangla,
      division: d.division,
      hospital: sumType(facByDistrict, d.name, "district", "HOSPITAL"),
      clinic: sumType(facByDistrict, d.name, "district", "CLINIC"),
      diagnostic: sumType(facByDistrict, d.name, "district", "DIAGNOSTIC"),
      pharmacy,
      emergency: emergencyD.get(d.name) ?? 0,
      total: facTotal + pharmacy,
    };
  }).map((d) => ({ ...d, level: coverageLevel(d.total) }));

  const divisions = DIVISIONS.map((div) => {
    const divName = div.name;
    const facTotal = facDiv.get(divName) ?? 0;
    const pharmacy = phDiv.get(divName) ?? 0;
    return {
      division: divName,
      divisionBangla: div.nameBangla,
      districts: districtRows.filter((d) => d.division === divName).length,
      hospital: sumType(facByDivision, divName, "division", "HOSPITAL"),
      clinic: sumType(facByDivision, divName, "division", "CLINIC"),
      diagnostic: sumType(facByDivision, divName, "division", "DIAGNOSTIC"),
      pharmacy,
      total: facTotal + pharmacy,
      level: coverageLevel(facTotal + pharmacy),
    };
  });

  const national = {
    hospital: districts.reduce((s, d) => s + d.hospital, 0),
    clinic: districts.reduce((s, d) => s + d.clinic, 0),
    diagnostic: districts.reduce((s, d) => s + d.diagnostic, 0),
    pharmacy: districts.reduce((s, d) => s + d.pharmacy, 0),
    emergency: districts.reduce((s, d) => s + d.emergency, 0),
    total: districts.reduce((s, d) => s + d.total, 0),
    districtsTracked: districts.length,
    districtsWithData: districts.filter((d) => d.total > 0).length,
  };

  // Areas with little data: EMPTY/MINIMAL first, then LOW — weakest at the top.
  const lowCoverage = districts
    .filter((d) => d.level === "EMPTY" || d.level === "MINIMAL" || d.level === "LOW")
    .sort((a, b) => a.total - b.total)
    .slice(0, 12);

  return ok({
    national,
    divisions,
    districts,
    lowCoverage,
    levels: { EMPTY: 0, MINIMAL: 3, LOW: 11, MEDIUM: 39, HIGH: "40+" },
  });
}, { rate: { limit: 60, windowMs: 60_000 } });
