import { withApi, ok, searchParams, pageArgs } from "@/lib/api";
import { queryFacilities } from "@/lib/directory-server";

// GET /api/directory/hospitals — hospital directory with division → district →
// upazila filters, hospital categories (medical college, district, UHC…),
// ownership and optional GPS distance sorting.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const { skip, take, page, pageSize } = pageArgs(sp, 20);
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  const origin = !Number.isNaN(lat) && !Number.isNaN(lng) ? { lat, lng } : null;
  const { rows, total } = await queryFacilities({
    q: sp.get("q")?.trim(),
    type: "HOSPITAL",
    category: sp.get("category"),
    ownership: sp.get("ownership"),
    division: sp.get("division"),
    district: sp.get("district"),
    upazila: sp.get("upazila"),
    emergencyOnly: sp.get("emergency") === "1",
    origin,
    skip,
    take,
  });
  return ok({ page, pageSize, total, hospitals: rows });
}, { rate: { limit: 90, windowMs: 60_000 } });
