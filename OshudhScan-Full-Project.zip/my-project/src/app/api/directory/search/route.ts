import { withApi, ok, searchParams } from "@/lib/api";
import { queryFacilities, queryPharmacies } from "@/lib/directory-server";

// GET /api/directory/search?q=&division=&district=&upazila= — unified search
// across hospitals/clinics/diagnostics and registered pharmacies.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const q = sp.get("q")?.trim();
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  const origin = !Number.isNaN(lat) && !Number.isNaN(lng) ? { lat, lng } : null;
  const filters = {
    q,
    division: sp.get("division"),
    district: sp.get("district"),
    upazila: sp.get("upazila"),
    origin,
  };
  // When the caller supplies coordinates, rank by proximity (25 km default
  // radius so the map/preview shows actually-nearby records, not the
  // alphabetically-first rows of a national dataset).
  const near = origin ? { origin, distanceKm: 25 } : {};
  const [facilities, pharmacies] = await Promise.all([
    queryFacilities({ ...filters, ...near, take: 12 }),
    queryPharmacies({ q, division: filters.division, district: filters.district, upazila: filters.upazila, origin, distanceKm: origin ? 25 : null, take: 8 }),
  ]);
  return ok({ facilities, pharmacies, query: { q, division: filters.division, district: filters.district, upazila: filters.upazila } });
}, { rate: { limit: 90, windowMs: 60_000 } });
