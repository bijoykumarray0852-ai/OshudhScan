import { withApi, ok, searchParams, pageArgs } from "@/lib/api";
import { queryPharmacies } from "@/lib/directory-server";

// GET /api/directory/pharmacies — national pharmacy directory search.
// Supports medicine-name search (matches reported stock) and GPS distance.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const { skip, take, page, pageSize } = pageArgs(sp, 20);
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  const origin = !Number.isNaN(lat) && !Number.isNaN(lng) ? { lat, lng } : null;
  const distanceKm = parseFloat(sp.get("distance") ?? "");
  const { rows, total } = await queryPharmacies({
    q: sp.get("q")?.trim(),
    medicineQ: sp.get("medicine")?.trim(),
    division: sp.get("division"),
    district: sp.get("district"),
    upazila: sp.get("upazila"),
    origin,
    distanceKm: !Number.isNaN(distanceKm) ? distanceKm : null,
    verifiedOnly: sp.get("verified") === "1",
    skip,
    take,
  });
  return ok({ page, pageSize, total, pharmacies: rows });
}, { rate: { limit: 90, windowMs: 60_000 } });
