import { withApi, ok, searchParams, pageArgs } from "@/lib/api";
import { queryFacilities } from "@/lib/directory-server";

// GET /api/directory/diagnostics — diagnostic centre directory.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const { skip, take, page, pageSize } = pageArgs(sp, 20);
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  const origin = !Number.isNaN(lat) && !Number.isNaN(lng) ? { lat, lng } : null;
  const { rows, total } = await queryFacilities({
    q: sp.get("q")?.trim(),
    type: "DIAGNOSTIC",
    ownership: sp.get("ownership"),
    division: sp.get("division"),
    district: sp.get("district"),
    upazila: sp.get("upazila"),
    origin,
    skip,
    take,
  });
  return ok({ page, pageSize, total, diagnostics: rows });
}, { rate: { limit: 90, windowMs: 60_000 } });
