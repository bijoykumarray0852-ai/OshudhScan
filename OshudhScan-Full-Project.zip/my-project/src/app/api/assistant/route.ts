import { z } from "zod";
import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, audit } from "@/lib/api";
import { getSessionUser } from "@/lib/auth";
import { translate, isLocale, type Locale } from "@/lib/i18n";

const schema = z.object({
  conversationId: z.string().optional(),
  message: z.string().min(1).max(1000),
  locale: z.string().optional(),
});

const GUARD_BN = `তুমি "ওষুধস্ক্যান স্বাস্থ্য সহকারী" — একজন বাংলাদেশি স্বাস্থ্য তথ্য সহকারী (বাংলা/ইংরেজি)।
কঠোর নিয়ম:
1. রোগ নির্ণয় (diagnosis) করবে না। 2. প্রেসক্রিপশন বা ওষুধ লিখে দেবে না। 3. কোনো ওষুধের মাত্রা বদলাতে বলবে না।
4. ভিত্তিহীন চিকিৎসা পরামর্শ দেবে না। 5. জরুরি উপসর্গ (বুকে ব্যথা, শ্বাসকষ্ট, অচেতনতা, রক্তক্ষরণ, স্ট্রোকের লক্ষণ) হলে সাথে সাথে ৯৯৯ কল করতে বা কাছের হাসপাতালে যেতে বলবে।
6. প্রতিটি উত্তরের শেষে ছোট এক লাইনে বলবে: এই তথ্য ডাক্তার বা ফার্মাসিস্টের পরামর্শের বিকল্প নয়।
কাজ: ওষুধের সাধারণ তথ্য ব্যাখ্যা, প্রেসক্রিপশনের পরিভাষা বোঝানো, সাধারণ সতর্কতা, সংরক্ষণ নিয়ম, অ্যাপ ব্যবহারে সাহায্য।
ধর্ম/রাজনীতি/অন্য কিছু এড়িয়ে যাও। উত্তর সংক্ষিপ্ত রাখো (সর্বোচ্চ ~১৫০ শব্দ), সহজ ভাষায়।`;

const GUARD_EN = `You are the "OshudhScan Health Assistant" — a Bangladesh health INFORMATION assistant (Bengali/English).
Strict rules:
1. Never diagnose. 2. Never prescribe. 3. Never change or suggest medicine doses. 4. Never give unsupported treatment advice.
5. For urgent symptoms (chest pain, breathing difficulty, unconsciousness, heavy bleeding, stroke signs) tell the user to call 999 immediately or go to the nearest hospital.
6. End every answer with one short line: this is general information, not a substitute for a doctor or pharmacist.
Your job: explain common medicine information, prescription terminology, general precautions, storage, and help navigate the OshudhScan app.
Keep answers short (max ~150 words), plain language.`;

// POST /api/assistant — guarded health information chat.
// Guardrails are enforced by the system prompt AND by post-checking that the
// model never returns a "diagnose this" style commitment (we re-append the
// disclaimer regardless). Urgency keywords short-circuit to emergency advice.
const URGENCY_PATTERNS = [
  /chest pain|বুকে ব্যথা|বুক ধড়ফড়/i, /can'?t breathe|difficulty breathing|শ্বাসকষ্ট|শ্বাস নিতে/i,
  /unconscious|অচেতন/i, /heavy bleeding|আক্ষিপ্ত রক্তক্ষরণ|রক্ত আটকাচ্ছে না/i, /stroke|পক্ষাঘাত|ফেসিড/i,
  /suicide|আত্মহত্যা/i, /convulsion|খিঁচুনি/i,
];

export const POST = withApi(async ({ req, user }) => {
  const body = await parseJson(req, schema);
  const sessionUser = user ?? (await getSessionUser());
  const locale: Locale = isLocale(body.locale) ? body.locale : (sessionUser?.locale as Locale) || "bn";

  let conversationId = body.conversationId;
  if (conversationId) {
    const conv = await db.assistantConversation.findUnique({ where: { id: conversationId } });
    if (!conv || (conv.userId && conv.userId !== sessionUser?.id)) return fail(404, "NOT_FOUND", "Conversation not found");
  } else {
    const conv = await db.assistantConversation.create({
      data: { userId: sessionUser?.id, locale, title: body.message.slice(0, 60) },
    });
    conversationId = conv.id;
  }

  await db.assistantMessage.create({ data: { conversationId, role: "USER", content: body.message } });

  // emergency short-circuit — deterministic, no LLM
  const urgent = URGENCY_PATTERNS.some((p) => p.test(body.message));
  let reply: string;
  let citations: Array<{ ref: string; label: string }> = [];

  if (urgent) {
    reply = locale === "bn"
      ? "আপনার বর্ণনায় জরুরি লক্ষণ আছে। এখনই ৯৯৯ কল করুন বা কাছের হাসপাতালের ইমারজেন্সিতে যান। অপেক্ষা করবেন না।\n\n(এই তথ্য ডাক্তার বা ফার্মাসিস্টের পরামর্শের বিকল্প নয়।)"
      : "Your description includes emergency warning signs. Call 999 NOW or go to the nearest hospital emergency department. Do not wait.\n\n(This is general information, not a substitute for a doctor or pharmacist.)";
    citations.push({ ref: "999", label: "National Emergency Service" });
  } else {
    // include relevant KB entries for grounding
    const kbHits = await db.medicine.findMany({
      where: { isActive: true, OR: body.message.split(/\s+/).filter((w) => w.length > 3).flatMap((w) => [{ brand: { contains: w } }, { generic: { contains: w } }]) },
      take: 3,
      select: { brand: true, generic: true, strength: true, form: true, indications: true, sideEffects: true, storage: true, contraindications: true, manufacturer: true },
    });
    if (kbHits.length > 0) {
      citations = kbHits.map((k) => ({ ref: k.brand, label: `${k.brand} (${k.generic}) — OshudhScan medicine knowledge base` }));
    }

    const zai = await ZAI.create();
    const system = locale === "bn" ? GUARD_BN : GUARD_EN;
    const kbText = kbHits.length
      ? `\n\nVerified knowledge-base entries for context (use only these facts about specific medicines; do not invent):\n${kbHits
          .map((k) => `- ${k.brand}: ${k.generic}, ${k.strength ?? "varies"}, uses: ${k.indications ?? "—"}, side effects: ${k.sideEffects ?? "—"}, storage: ${k.storage ?? "—"}, do-not-use: ${k.contraindications ?? "—"}`)
          .join("\n")}`
      : "";

    const history = await db.assistantMessage.findMany({
      where: { conversationId },
      orderBy: { createdAt: "asc" },
      take: 12,
      select: { role: true, content: true },
    });

    try {
      const completion = await Promise.race([
        zai.chat.completions.create({
          messages: [
            { role: "assistant", content: system + kbText },
            ...history.map((m) => ({ role: m.role === "USER" ? ("user" as const) : ("assistant" as const), content: m.content })),
          ],
          max_tokens: 600,
        }),
        new Promise<never>((_, reject) => setTimeout(() => reject(new Error("assistant timeout (20s)")), 20000)),
      ]);
      reply = completion?.choices?.[0]?.message?.content?.trim() || "";
    } catch {
      reply = "";
    }

    if (!reply) {
      // deterministic fallback — never fail silently
      reply = locale === "bn"
        ? "এখন উত্তর তৈরি করা যাচ্ছে না। অনুগ্রহ করে আবার চেষ্টা করুন। ওষুধের তথ্যের জন্য 'ঔষধ' পাতা দেখুন, জরুরি সহায়তায় ৯৯৯ বা স্বাস্থ্য বাতায়ন ১৬২৬৩ কল করুন।\n\n(এই তথ্য ডাক্তার বা ফার্মাসিস্টের পরামর্শের বিকল্প নয়।)"
        : "I could not generate an answer right now — please try again. For medicine facts use the Medicines page; for urgent help call 999 or the health line 16263.\n\n(This is general information, not a substitute for a doctor or pharmacist.)";
    } else if (!/doctor|pharmacist|ডাক্তার|ফার্মাসিস্ট/i.test(reply.slice(-200))) {
      reply += locale === "bn" ? "\n\n(এই তথ্য ডাক্তার বা ফার্মাসিস্টের পরামর্শের বিকল্প নয়।)" : "\n\n(This is general information, not a substitute for a doctor or pharmacist.)";
    }
  }

  const saved = await db.assistantMessage.create({
    data: { conversationId, role: "ASSISTANT", content: reply, citations: citations.length ? JSON.stringify(citations) : null },
  });
  await db.assistantConversation.update({ where: { id: conversationId }, data: { updatedAt: new Date() } });
  await audit(req, { userId: sessionUser?.id ?? null, action: "ASSISTANT_MESSAGE", entity: "assistant_conversation", entityId: conversationId });

  return ok({
    conversationId,
    reply: saved.content,
    citations,
    disclaimer: translate(locale, "care.assistantDisclaimer"),
  });
}, { rate: { limit: 15, windowMs: 5 * 60_000 } });

// GET /api/assistant — conversation history for the signed-in user.
export const GET = withApi(async ({ req, user }) => {
  const sp = new URL(req.url).searchParams;
  const conversationId = sp.get("conversationId");
  if (conversationId && user) {
    const conv = await db.assistantConversation.findUnique({ where: { id: conversationId } });
    if (!conv || (conv.userId && conv.userId !== user.id)) return fail(404, "NOT_FOUND", "Conversation not found");
    const messages = await db.assistantMessage.findMany({ where: { conversationId }, orderBy: { createdAt: "asc" }, take: 60 });
    return ok({ conversationId, messages: messages.map((m) => ({ id: m.id, role: m.role, content: m.content, citations: m.citations ? JSON.parse(m.citations) : null, createdAt: m.createdAt })) });
  }
  if (!user) return ok({ conversations: [] });
  const convs = await db.assistantConversation.findMany({ where: { userId: user.id }, orderBy: { updatedAt: "desc" }, take: 15 });
  return ok({ conversations: convs.map((c) => ({ id: c.id, title: c.title, locale: c.locale, updatedAt: c.updatedAt })) });
});
