import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

// Text-to-speech for the Bangla dosage card.
// The SDK returns raw PCM (24 kHz, 16-bit, mono); we wrap it in a WAV header
// so the browser can play it directly as audio/wav.
const SAMPLE_RATE = 24000;

function pcmToWav(pcm: Buffer): Buffer {
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM
  header.writeUInt16LE(1, 22); // mono
  header.writeUInt32LE(SAMPLE_RATE, 24);
  header.writeUInt32LE((SAMPLE_RATE * 1 * 16) / 8, 28);
  header.writeUInt16LE(2, 32); // block align
  header.writeUInt16LE(16, 34); // bits per sample
  header.write("data", 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return Promise.race([p, new Promise<never>((_, reject) => setTimeout(() => reject(new Error(`${label} timeout (${ms / 1000}s)`)), ms))]);
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { text?: string };
    const text = (body.text ?? "").trim();
    if (!text) {
      return NextResponse.json({ ok: false, error: "No text" }, { status: 400 });
    }
    if (text.length > 1200) {
      return NextResponse.json({ ok: false, error: "Text too long" }, { status: 400 });
    }

    // The SDK init and the audio call are BOTH wrapped in a timeout with one
    // retry — a cold or flaky SDK connection must never hang the request.
    let response: Response | undefined;
    for (let attempt = 1; attempt <= 2 && !response; attempt++) {
      try {
        const zai = await withTimeout(ZAI.create(), 15000, "TTS SDK init");
        response = await withTimeout(
          zai.audio.tts.create({ input: text, voice: "tongtong", speed: 0.9 }),
          20000,
          "TTS"
        );
      } catch (err) {
        if (attempt === 2) throw err;
      }
    }
    if (!response) {
      return NextResponse.json({ ok: false, error: "TTS unavailable" }, { status: 502 });
    }
    const arrayBuffer = await response.arrayBuffer();
    const pcm = Buffer.from(arrayBuffer);
    if (pcm.length < 1000) {
      return NextResponse.json({ ok: false, error: "TTS returned no audio" }, { status: 502 });
    }

    const wav = pcmToWav(pcm);
    return new NextResponse(new Uint8Array(wav), {
      status: 200,
      headers: {
        "Content-Type": "audio/wav",
        "Content-Length": String(wav.length),
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "TTS failed" },
      { status: 500 }
    );
  }
}
