import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, searchParams, pageArgs } from "@/lib/api";
import { requireUser } from "@/lib/auth";

// GET /api/notifications — notification centre (paginated).
export const GET = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const { skip, take } = pageArgs(searchParams(req), 30);
  const [rows, unread] = await Promise.all([
    db.notification.findMany({ where: { userId: u.id }, orderBy: { createdAt: "desc" }, skip, take }),
    db.notification.count({ where: { userId: u.id, readAt: null } }),
  ]);
  return ok({
    unread,
    notifications: rows.map((n) => ({
      id: n.id,
      type: n.type,
      title: n.title,
      body: n.body,
      data: n.data ? JSON.parse(n.data) : null,
      readAt: n.readAt,
      createdAt: n.createdAt,
    })),
  });
}, { auth: true, rate: { limit: 90, windowMs: 60_000 } });

// PATCH /api/notifications — mark one or all as read.
export const PATCH = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, z.object({ id: z.string().optional(), all: z.boolean().optional() }));
  if (body.all) {
    await db.notification.updateMany({ where: { userId: u.id, readAt: null }, data: { readAt: new Date() } });
    return ok({ unread: 0 });
  }
  if (body.id) {
    await db.notification.updateMany({ where: { id: body.id, userId: u.id, readAt: null }, data: { readAt: new Date() } });
  }
  const unread = await db.notification.count({ where: { userId: u.id, readAt: null } });
  return ok({ unread });
}, { auth: true, rate: { limit: 90, windowMs: 60_000 } });
