import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, audit, searchParams, pageArgs } from "@/lib/api";
import { requireUser, ApiError } from "@/lib/auth";
import { assertPharmacyAccess } from "@/lib/pharmacy-access";

const createSchema = z.object({
  pharmacyId: z.string().min(1),
  medicineId: z.string().min(1),
  quantity: z.number().int().min(1).max(100),
  note: z.string().max(300).optional(),
});

// POST /api/reservations — patient requests a medicine reservation.
// The pharmacy confirms by phone; availability is guaranteed only after
// confirmation. Only contact fields (name/phone) are shared with the pharmacy.
export const POST = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, createSchema);
  const pharmacy = await db.pharmacy.findUnique({ where: { id: body.pharmacyId } });
  if (!pharmacy || pharmacy.deletedAt) return fail(404, "NOT_FOUND", "Pharmacy not found");
  const medicine = await db.medicine.findUnique({ where: { id: body.medicineId } });
  if (!medicine) return fail(404, "NOT_FOUND", "Medicine not found");

  const reservation = await db.medicineReservation.create({
    data: {
      pharmacyId: body.pharmacyId,
      requestedByUserId: u.id,
      requesterName: u.name,
      requesterPhone: u.phone ?? "",
      medicineId: body.medicineId,
      medicineLabel: `${medicine.brand} ${medicine.strength ?? ""}`.trim(),
      quantity: body.quantity,
      note: body.note,
      status: "NEW",
    },
  });
  await db.notification.create({
    data: {
      userId: u.id,
      type: "RESERVATION",
      title: "Reservation requested",
      body: `${reservation.medicineLabel} at ${pharmacy.name} — the pharmacy will confirm by phone.`,
      data: JSON.stringify({ reservationId: reservation.id }),
    },
  });
  await audit(req, { userId: u.id, action: "RESERVATION_CREATE", entity: "medicine_reservation", entityId: reservation.id, detail: { pharmacyId: body.pharmacyId } });
  return ok({ reservation: { id: reservation.id, status: reservation.status } }, { status: 201 });
}, { auth: true, rate: { limit: 10, windowMs: 60 * 60_000 } });

// GET /api/reservations?mine=1 | ?pharmacyId=
export const GET = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const sp = searchParams(req);
  const { skip, take } = pageArgs(sp, 20);
  if (sp.get("pharmacyId")) {
    const rows = await db.medicineReservation.findMany({
      where: { pharmacyId: sp.get("pharmacyId") as string },
      orderBy: { createdAt: "desc" },
      skip,
      take,
      include: { medicine: { select: { brand: true, strength: true } } },
    });
    return ok({ reservations: rows });
  }
  const rows = await db.medicineReservation.findMany({
    where: { requestedByUserId: u.id },
    orderBy: { createdAt: "desc" },
    skip,
    take,
    include: { pharmacy: { select: { id: true, name: true, contactPhone: true } } },
  });
  return ok({
    reservations: rows.map((r) => ({
      id: r.id,
      medicineLabel: r.medicineLabel,
      quantity: r.quantity,
      status: r.status,
      pharmacyNote: r.pharmacyNote,
      createdAt: r.createdAt,
      pharmacy: r.pharmacy,
    })),
  });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });

// PATCH /api/reservations — pharmacy updates status (CONFIRMED/READY/…).
export const PATCH = withApi(async ({ req, user }) => {
  const u = await requireUser();
  const body = await parseJson(req, z.object({
    reservationId: z.string(),
    status: z.enum(["CONFIRMED", "READY", "FULFILLED", "CANCELLED", "DECLINED"]),
    pharmacyNote: z.string().max(300).optional(),
  }));
  const reservation = await db.medicineReservation.findUnique({ where: { id: body.reservationId } });
  if (!reservation) return fail(404, "NOT_FOUND", "Reservation not found");
  const staff = await db.pharmacyStaff.findUnique({ where: { pharmacyId_userId: { pharmacyId: reservation.pharmacyId, userId: u.id } } });
  if (!staff) throw new ApiError(403, "FORBIDDEN", "Only the pharmacy can update reservations");
  await db.medicineReservation.update({
    where: { id: reservation.id },
    data: { status: body.status, pharmacyNote: body.pharmacyNote ?? reservation.pharmacyNote },
  });
  if (reservation.requestedByUserId) {
    await db.notification.create({
      data: {
        userId: reservation.requestedByUserId,
        type: "RESERVATION",
        title: "Reservation update",
        body: `${reservation.medicineLabel} is now ${body.status.toLowerCase()} at the pharmacy.`,
        data: JSON.stringify({ reservationId: reservation.id }),
      },
    });
  }
  await audit(req, { userId: u.id, action: "RESERVATION_STATUS", entity: "medicine_reservation", entityId: reservation.id, detail: { status: body.status } });
  return ok({ reservation: { id: reservation.id, status: body.status } });
}, { auth: true, rate: { limit: 60, windowMs: 60_000 } });
