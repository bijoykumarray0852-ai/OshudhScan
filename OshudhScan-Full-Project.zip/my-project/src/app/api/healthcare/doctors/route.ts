import { db } from "@/lib/db";
import { withApi, ok, searchParams, pageArgs } from "@/lib/api";

// GET /api/healthcare/doctors — verified doctor directory only.
// Starts EMPTY by design: no doctor record is ever shown without
// administrator-approved verification. Seeding happens via the admin API.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const { skip, take, page, pageSize } = pageArgs(sp, 20);
  const specialty = sp.get("specialty");
  const q = sp.get("q")?.trim();
  const facilityId = sp.get("facilityId");

  const where: Record<string, unknown> = { isVerified: true, deletedAt: null };
  if (specialty && specialty !== "ALL") where.specialty = specialty;
  if (facilityId) where.facilityId = facilityId;
  if (q) where.name = { contains: q };

  const [rows, total] = await Promise.all([
    db.doctor.findMany({
      where,
      orderBy: { name: "asc" },
      skip,
      take,
      include: { facility: { select: { name: true, district: true, area: true, addressLine: true } } },
    }),
    db.doctor.count({ where }),
  ]);

  return ok({
    page,
    pageSize,
    total,
    doctors: rows.map((d) => ({
      id: d.id,
      name: d.name,
      specialty: d.specialty,
      degrees: d.degrees,
      designation: d.designation,
      facility: d.facility,
      visitingHours: d.visitingHours,
      phone: d.phone,
      source: d.source,
    })),
    notice: "The verified doctor directory is under construction — only admin-approved records appear here. No unverified information is displayed.",
  });
}, { rate: { limit: 90, windowMs: 60_000 } });
