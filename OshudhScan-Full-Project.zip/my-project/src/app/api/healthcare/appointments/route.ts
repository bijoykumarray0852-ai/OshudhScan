import { z } from "zod";
import { db } from "@/lib/db";
import { withApi, ok, parseJson, fail, audit, searchParams, pageArgs } from "@/lib/api";
import { getSessionUser } from "@/lib/auth";

// POST /api/healthcare/appointments — appointment REQUEST (no availability is
// invented; the facility contacts the patient to confirm).
export const POST = withApi(async ({ req, user }) => {
  const body = await parseJson(req, z.object({
    facilityId: z.string().optional(),
    doctorId: z.string().optional(),
    requesterName: z.string().min(2).max(80),
    requesterPhone: z.string().min(6).max(20),
    preferredAt: z.string().optional(),
    note: z.string().max(300).optional(),
  }));
  if (!body.facilityId && !body.doctorId) return fail(400, "VALIDATION", "facilityId or doctorId required");

  // validate the referenced facility/doctor actually exists — never accept
  // invented ids (a stale FK turns into an opaque 500 otherwise)
  if (body.facilityId) {
    const facility = await db.healthcareFacility.findUnique({ where: { id: body.facilityId } });
    if (!facility) return fail(400, "VALIDATION", "Unknown facilityId");
  }
  if (body.doctorId) {
    const doctor = await db.doctor.findUnique({ where: { id: body.doctorId } });
    if (!doctor) return fail(400, "VALIDATION", "Unknown doctorId");
  }

  const sessionUser = user ?? (await getSessionUser());
  const request = await db.appointmentRequest.create({
    data: {
      facilityId: body.facilityId ?? null,
      doctorId: body.doctorId ?? null,
      requestedByUserId: sessionUser?.id ?? null,
      requesterName: body.requesterName,
      requesterPhone: body.requesterPhone,
      preferredAt: body.preferredAt ? new Date(body.preferredAt) : null,
      note: body.note,
      status: "NEW",
    },
  });
  await audit(req, { userId: sessionUser?.id ?? null, action: "APPOINTMENT_REQUEST", entity: "appointment_request", entityId: request.id });
  return ok({ request: { id: request.id, status: request.status } }, { status: 201 });
}, { rate: { limit: 10, windowMs: 60 * 60_000 } });

// GET /api/healthcare/appointments — the patient's own requests.
export const GET = withApi(async ({ req, user }) => {
  if (!user) return ok({ requests: [] });
  const { skip, take } = pageArgs(searchParams(req), 20);
  const rows = await db.appointmentRequest.findMany({
    where: { requestedByUserId: user.id },
    orderBy: { createdAt: "desc" },
    skip,
    take,
    include: { facility: { select: { name: true, district: true } }, doctor: { select: { name: true, specialty: true } } },
  });
  return ok({
    requests: rows.map((r) => ({
      id: r.id,
      facility: r.facility,
      doctor: r.doctor,
      preferredAt: r.preferredAt,
      status: r.status,
      createdAt: r.createdAt,
    })),
  });
});
