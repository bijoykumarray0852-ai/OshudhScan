import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { withApi, ok, searchParams, pageArgs } from "@/lib/api";
import { haversineKm } from "@/lib/geo";

// GET /api/healthcare/facilities — hospital/clinic/diagnostic directory.
// Only verified/admin-approved records are served; phones show a verification
// flag (isPhoneVerified) so unverified numbers are clearly distinguished.
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const q = sp.get("q")?.trim();
  const type = sp.get("type");
  const district = sp.get("district");
  const emergencyOnly = sp.get("emergency") === "1";
  const lat = parseFloat(sp.get("lat") ?? "");
  const lng = parseFloat(sp.get("lng") ?? "");
  const { skip, take, page, pageSize } = pageArgs(sp, 20);

  const where: Record<string, unknown> = { deletedAt: null };
  if (q) where.name = { contains: q };
  if (type && type !== "ALL") where.type = type;
  if (district) where.district = district;
  if (emergencyOnly) where.emergency = true;

  const [rows, total] = await Promise.all([
    db.healthcareFacility.findMany({ where, orderBy: { name: "asc" }, skip, take }),
    db.healthcareFacility.count({ where }),
  ]);

  const hasGeo = !Number.isNaN(lat) && !Number.isNaN(lng);
  return ok({
    page,
    pageSize,
    total,
    facilities: rows
      .map((f) => ({
        id: f.id,
        name: f.name,
        nameBangla: f.nameBangla,
        type: f.type,
        ownership: f.ownership,
        district: f.district,
        area: f.area,
        addressLine: f.addressLine,
        lat: f.lat,
        lng: f.lng,
        phone: f.phone,
        isPhoneVerified: f.isPhoneVerified,
        emergency: f.emergency,
        specialties: f.specialties ? JSON.parse(f.specialties) : [],
        services: f.services ? JSON.parse(f.services) : [],
        source: f.source,
        distanceKm: hasGeo && f.lat != null && f.lng != null ? Math.round(haversineKm({ lat, lng }, { lat: f.lat, lng: f.lng }) * 10) / 10 : null,
      }))
      .sort((a, b) => {
        if (a.distanceKm !== null && b.distanceKm !== null) return a.distanceKm - b.distanceKm;
        return 0;
      }),
  });
}, { rate: { limit: 90, windowMs: 60_000 } });
