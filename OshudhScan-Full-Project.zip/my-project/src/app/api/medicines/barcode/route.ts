import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { withApi, ok, searchParams, fail } from "@/lib/api";

// GET /api/medicines/barcode?code=8801...
// Barcode lookup against REGISTERED product records only. A match identifies
// the product record — the API response explicitly states that a barcode
// never proves authenticity.
export const GET = withApi(async ({ req }) => {
  const code = searchParams(req).get("code")?.trim();
  if (!code || code.length < 4 || code.length > 40 || !/^[0-9A-Za-z\-]+$/.test(code)) {
    return fail(400, "VALIDATION", "Invalid barcode format");
  }
  const med = await db.medicine.findUnique({ where: { barcode: code } });
  if (!med || !med.isActive) {
    return ok({ found: false, note: "This barcode is not registered in the database. Registration is done by administrators with verified product records." });
  }
  return ok({
    found: true,
    authenticity: "not_proven",
    note: "A barcode identifies the product record only. It never proves the medicine is genuine — check pack integrity, batch and licence.",
    medicine: {
      id: med.id, brand: med.brand, generic: med.generic, genericBangla: med.genericBangla,
      strength: med.strength, form: med.form, therapeuticClass: med.therapeuticClass,
      manufacturer: med.manufacturer, unitPriceBdt: med.unitPriceBdt,
      indications: med.indications, storage: med.storage, source: med.source,
    },
  });
}, { rate: { limit: 30, windowMs: 60_000 } });
