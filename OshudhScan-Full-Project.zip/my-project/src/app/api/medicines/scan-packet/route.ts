import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { z } from "zod";
import { matchBrand } from "@/lib/match";
import { withApi, parseJson, ok, rateLimit } from "@/lib/api";
import { db } from "@/lib/db";

const schema = z.object({
  imageBase64: z.string().min(100),
});

const PACKET_SYSTEM = `You are an OCR engine specialized in Bangladeshi medicine packets and strip labels.
Read the image and return STRICT JSON only — no markdown fences, no commentary — with this exact shape:
{"brand_raw": string|null, "strength": string|null, "batch_number": string|null, "mfg_date": string|null, "expiry_date": string|null, "barcode_digits": string|null}
Notes:
- brand_raw is the brand name exactly as printed (e.g. Napa, Seclo, Ace).
- dates as printed (e.g. "02 2028", "FEB 2028"); null when not visible.
- batch_number is the printed Batch/Lot code; null when not visible.
- barcode_digits: the numeric code under the barcode if clearly visible; null otherwise.
- Never guess: use null for anything not clearly printed.`;

function stripFences(text: string): string {
  return text.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "").trim();
}

interface PacketOcr {
  brand_raw: string | null;
  strength: string | null;
  batch_number: string | null;
  mfg_date: string | null;
  expiry_date: string | null;
  barcode_digits: string | null;
}

// POST /api/medicines/scan-packet — vision extraction of pack metadata.
// Output is a DRAFT: a pharmacist must verify batch/expiry before the record
// can be marked available for dispensing (enforced in the inventory API).
export const POST = withApi(async ({ req, user }) => {
  rateLimit(`packet:${user?.id ?? "anon"}`, 8, 60_000);
  const body = await parseJson(req, schema);

  const zai = await ZAI.create();
  let ocr: PacketOcr;
  try {
    const completion = await Promise.race([
      zai.chat.completions.createVision({
        model: "glm-4.5v",
        messages: [
          { role: "assistant", content: PACKET_SYSTEM },
          {
            role: "user",
            content: [
              { type: "text", text: "Extract the pack details from this medicine packet photo. Return strict JSON only." },
              { type: "image_url", image_url: { url: `data:image/jpeg;base64,${body.imageBase64}` } },
            ],
          },
        ],
        thinking: { type: "disabled" },
      }),
      new Promise<never>((_, reject) => setTimeout(() => reject(new Error("vision timeout (25s)")), 25000)),
    ]);
    const content: string = completion?.choices?.[0]?.message?.content ?? "";
    ocr = JSON.parse(stripFences(content));
    if (!ocr || typeof ocr !== "object") throw new Error("malformed vision response");
  } catch (err) {
    return NextResponse.json(
      { ok: false, degraded: true, error: err instanceof Error ? err.message : "Packet OCR failed" },
      { status: 200 }
    );
  }

  const match = ocr.brand_raw ? matchBrand(ocr.brand_raw) : null;
  let barcodeRegistered: boolean | null = null;
  if (ocr.barcode_digits && /^\d{6,14}$/.test(ocr.barcode_digits)) {
    const found = await db.medicine.findUnique({ where: { barcode: ocr.barcode_digits } });
    barcodeRegistered = Boolean(found);
  }

  return ok({
    extracted: {
      brandRaw: ocr.brand_raw,
      strength: ocr.strength,
      batchNumber: ocr.batch_number,
      mfgDate: ocr.mfg_date,
      expiryDate: ocr.expiry_date,
      barcodeDigits: ocr.barcode_digits,
    },
    matchedBrand: match ? { brand: match.drug.brand, confidence: match.confidence, method: match.method } : null,
    barcodeRegistered,
    requiresPharmacistVerification: true,
    note: "Draft extraction. A pharmacist must verify batch number and expiry dates before this inventory record becomes available for dispensing.",
  });
}, { rate: { limit: 8, windowMs: 60_000 } });
