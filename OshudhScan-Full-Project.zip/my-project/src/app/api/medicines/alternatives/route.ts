import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { withApi, ok, fail, searchParams } from "@/lib/api";

// GET /api/medicines/alternatives?id=... — generic alternatives for the same molecule.
// Informational only: never an automatic substitution. Requires pharmacist /
// prescriber authorisation for any switch.
export const GET = withApi(async ({ req }) => {
  const id = searchParams(req).get("id");
  if (!id) return fail(400, "VALIDATION", "Medicine id required");
  const med = await db.medicine.findUnique({ where: { id } });
  if (!med || !med.isActive) return fail(404, "NOT_FOUND", "Medicine not found");

  const molecule = med.generic.split(/\s?\+/)[0].replace(/\d+(mg|mcg)?$/i, "").trim();
  const sameMolecule = await db.medicine.findMany({
    where: { isActive: true, generic: { contains: molecule }, id: { not: med.id } },
    orderBy: { unitPriceBdt: "asc" },
    take: 10,
  });

  const cheapest = sameMolecule[0]?.unitPriceBdt ?? med.genericUnitPriceBdt;
  const savingsPct = cheapest && med.unitPriceBdt > 0 ? Math.round(((med.unitPriceBdt - cheapest) / med.unitPriceBdt) * 100) : null;

  return ok({
    reference: { id: med.id, brand: med.brand, generic: med.generic, strength: med.strength, form: med.form, unitPriceBdt: med.unitPriceBdt, manufacturer: med.manufacturer, therapeuticClass: med.therapeuticClass },
    alternatives: sameMolecule.map((m) => ({
      id: m.id,
      brand: m.brand,
      generic: m.generic,
      strength: m.strength,
      form: m.form,
      manufacturer: m.manufacturer,
      unitPriceBdt: m.unitPriceBdt,
      savingsPct: med.unitPriceBdt > 0 ? Math.round(((med.unitPriceBdt - m.unitPriceBdt) / med.unitPriceBdt) * 100) : null,
      source: m.source,
      isDemo: m.isDemo,
    })),
    savingsPct,
    disclaimer: "Any brand switch needs your doctor or pharmacist's approval. Release formulation and strength must match. Prices are indicative and updated periodically.",
    source: med.source,
  });
}, { rate: { limit: 60, windowMs: 60_000 } });
