import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { withApi, ok, searchParams, pageArgs } from "@/lib/api";

// GET /api/medicines?q=&class=&form=&page=&pageSize=
export const GET = withApi(async ({ req }) => {
  const sp = searchParams(req);
  const q = sp.get("q")?.trim();
  const cls = sp.get("class");
  const form = sp.get("form");
  const { skip, take, page, pageSize } = pageArgs(sp, 24);

  const where: Record<string, unknown> = { isActive: true };
  if (q) {
    where.OR = [
      { brand: { contains: q } },
      { generic: { contains: q } },
      { legacyId: { contains: q.toLowerCase() } },
    ];
  }
  if (cls) where.therapeuticClass = cls;
  if (form) where.form = form;

  const [total, rows] = await Promise.all([
    db.medicine.count({ where }),
    db.medicine.findMany({ where, orderBy: { brand: "asc" }, skip, take }),
  ]);

  return ok({
    page,
    pageSize,
    total,
    medicines: rows.map((m) => ({
      id: m.id,
      legacyId: m.legacyId,
      brand: m.brand,
      generic: m.generic,
      genericBangla: m.genericBangla,
      strength: m.strength,
      form: m.form,
      therapeuticClass: m.therapeuticClass,
      manufacturer: m.manufacturer,
      unitPriceBdt: m.unitPriceBdt,
      genericUnitPriceBdt: m.genericUnitPriceBdt,
      meal: m.meal,
      indications: m.indications,
      sideEffects: m.sideEffects,
      storage: m.storage,
      contraindications: m.contraindications,
      source: m.source,
      lastReviewedAt: m.lastReviewedAt,
      isDemo: m.isDemo,
      hasBarcode: Boolean(m.barcode),
    })),
  });
}, { rate: { limit: 120, windowMs: 60_000 } });
