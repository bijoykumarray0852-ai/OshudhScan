import { z } from "zod";
import { matchBrand, parseDose } from "@/lib/match";
import { runSafetyEngine } from "@/lib/interactions";
import type { MatchedMedicine, Finding } from "@/lib/types";
import { withApi, parseJson, ok, rateLimit } from "@/lib/api";
import { db } from "@/lib/db";

const checkSchema = z.object({
  items: z.array(z.object({
    name: z.string().min(1).max(80),
    dose: z.string().max(20).optional(),
  })).min(1).max(15),
  allergies: z.array(z.string().max(60)).max(10).optional(),
});

// Curated adult daily ceilings for demo-KB molecules (mg/day) — clearly
// labelled curated rules; not a substitute for package-insert review.
const DOSE_CEILINGS: Record<string, { mg: number; source: string }> = {
  cetirizine: { mg: 10, source: "Curated package-insert ceiling (adult)" },
  fexofenadine: { mg: 180, source: "Curated package-insert ceiling (adult)" },
  montelukast: { mg: 10, source: "Curated package-insert ceiling (adult)" },
  omeprazole: { mg: 40, source: "Curated package-insert ceiling (adult)" },
  esomeprazole: { mg: 40, source: "Curated package-insert ceiling (adult)" },
  pantoprazole: { mg: 40, source: "Curated package-insert ceiling (adult)" },
  amlodipine: { mg: 10, source: "Curated package-insert ceiling (adult)" },
  metformin: { mg: 2550, source: "Curated package-insert ceiling (adult)" },
  cefixime: { mg: 400, source: "Curated package-insert ceiling (adult)" },
  ondansetron: { mg: 16, source: "Curated package-insert ceiling (adult)" },
};

function mgPerUnit(generic: string | null, strength: string | null): number | null {
  const s = strength ?? generic?.match(/(\d+)\s*mg/i)?.[1] ?? null;
  if (!s) return null;
  const m = s.match(/(\d+)\s*mg/i);
  return m ? parseInt(m[1], 10) : null;
}

function moleculeKey(generic: string | null): string | null {
  if (!generic) return null;
  return generic.split(/\s?\+/)[0].replace(/\d+(mg|mcg)?$/i, "").trim().toLowerCase();
}

// Governance parity with /api/decode: retired rules stay retired everywhere.
async function disabledRuleIds(): Promise<string[]> {
  try {
    const rows = await db.clinicalRule.findMany({ where: { enabled: false }, select: { ruleId: true } });
    return rows.map((r) => r.ruleId);
  } catch {
    return [];
  }
}

// POST /api/medicines/check — deterministic combination checker.
// The LLM is never involved; every finding traces to a rule.
export const POST = withApi(async ({ req, user }) => {
  rateLimit(`medcheck:${user?.id ?? "anon"}`, 20, 60_000);
  const body = await parseJson(req, checkSchema);

  const meds: MatchedMedicine[] = body.items.map((item) => {
    const match = matchBrand(item.name);
    const parsed = item.dose ? parseDose(item.dose) : null;
    if (!match) {
      return {
        brandRaw: item.name, brand: null, manufacturer: null, generic: null,
        genericBangla: null, strength: null, form: null, therapeuticClass: null,
        dose: item.dose ?? null, duration: null, meal: null, unitPriceBdt: null,
        genericUnitPriceBdt: null, matchMethod: "unmatched", confidence: 0,
        perDay: parsed?.perDay ?? null, days: null, qty: null,
        lineTotalBdt: null, genericLineTotalBdt: null,
      };
    }
    const d = match.drug;
    return {
      brandRaw: item.name, brand: d.brand, manufacturer: d.manufacturer,
      generic: d.generic, genericBangla: d.genericBangla, strength: d.strengths[0] ?? null,
      form: d.form, therapeuticClass: d.therapeuticClass, dose: item.dose ?? null,
      duration: null, meal: d.meal, unitPriceBdt: d.unitPriceBdt,
      genericUnitPriceBdt: d.genericUnitPriceBdt, matchMethod: match.method,
      confidence: match.confidence, perDay: parsed?.perDay ?? null, days: null,
      qty: null, lineTotalBdt: null, genericLineTotalBdt: null,
    };
  });

  const findings: Finding[] = runSafetyEngine(meds, await disabledRuleIds());

  // dose-ceiling checks (only when a parseable dose was provided)
  for (const m of meds) {
    if (!m.brand || !m.generic || !m.perDay) continue;
    const key = moleculeKey(m.generic);
    const ceiling = key ? DOSE_CEILINGS[key] : undefined;
    if (!ceiling) continue;
    const mg = mgPerUnit(m.generic, m.strength);
    if (!mg) continue;
    const perDayMg = mg * m.perDay;
    if (perDayMg > ceiling.mg) {
      findings.push({
        id: `dose-limit-${m.brand}`,
        severity: "moderate",
        type: "dose",
        title: `MODERATE — ${m.brand} exceeds the usual adult daily dose (~${perDayMg} mg/day)`,
        detail: `Parsed as ${m.perDay} unit(s)/day × ${mg} mg. The curated ceiling for ${key} is ${ceiling.mg} mg/day for adults.`,
        action: "Pharmacist to verify the written dose against the prescriber's instruction before dispensing.",
        drugs: [m.brand as string],
        source: `Rules engine · dose ceiling (${ceiling.source})`,
      });
    }
  }

  // allergy cross-checks (patient-entered; molecule + curated class level)
  const allergies = (body.allergies ?? []).map((a) => a.toLowerCase().trim()).filter(Boolean);
  // auto-include the signed-in patient's recorded allergies
  if (user) {
    const profile = await db.patientProfile.findUnique({ where: { userId: user.id } });
    if (profile?.allergies) {
      try {
        for (const a of JSON.parse(profile.allergies) as string[]) allergies.push(a.toLowerCase());
      } catch { /* ignore malformed */ }
    }
  }
  for (const allergy of [...new Set(allergies)]) {
    for (const m of meds) {
      if (!m.brand || !m.generic) continue;
      const key = moleculeKey(m.generic);
      const hitMolecule = key && (key.includes(allergy) || allergy.includes(key ?? ""));
      const hitClass =
        (allergy.includes("aspirin") || allergy.includes("nsaid")) &&
        (m.therapeuticClass === "nsaid" || m.therapeuticClass === "nsaid-combo");
      if (hitMolecule || hitClass) {
        findings.push({
          id: `allergy-${m.brand}-${allergy}`,
          severity: "major",
          type: "interaction",
          title: `MAJOR — possible allergy match: ${m.brand} vs recorded allergy "${allergy}"`,
          detail: hitClass
            ? `Aspirin/NSAID sensitivity can cross-react across the NSAID class (including aceclofenac). ${m.generic} belongs to this class.`
            : `Recorded allergy "${allergy}" matches the molecule in ${m.brand} (${m.generic}).`,
          action: "Do not dispense without prescriber confirmation. Flag the allergy in the patient record.",
          drugs: [m.brand],
          source: "Rules engine · allergy cross-check (curated cross-sensitivity guidance)",
        });
      }
    }
  }

  const order = { major: 0, moderate: 1, minor: 2, info: 3 } as const;
  findings.sort((x, y) => order[x.severity] - order[y.severity]);

  return ok({
    generatedBy: "rules-engine",
    resolved: meds.map((m) => ({
      input: m.brandRaw,
      brand: m.brand,
      generic: m.generic,
      matchMethod: m.matchMethod,
      confidence: m.confidence,
    })),
    findings,
    note: "Deterministic rule output. Every finding is auditable and reproducible. Confirm with a pharmacist before acting.",
  });
}, { rate: { limit: 20, windowMs: 60_000 } });
