import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import localFont from "next/font/local";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const bangla = localFont({
  src: "../fonts/NotoSansBengali-var.ttf",
  variable: "--font-bangla",
  display: "swap",
});

const handwriting = localFont({
  src: "../fonts/Caveat-Bold.ttf",
  variable: "--font-hand",
  display: "swap",
});

export const metadata: Metadata = {
  title: "OshudhScan — Prescription Decoder & Medicine Safety Net",
  description:
    "Snap a handwritten prescription. AI reads it (vision OCR), maps brands to generics, flags interactions & duplicates, explains dosage in simple Bangla with voice, and routes the order to a stocking pharmacy nearby.",
  keywords: [
    "prescription OCR",
    "Bangladesh pharmacy",
    "drug interactions",
    "generic substitution",
    "SDG 3.8",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${bangla.variable} ${handwriting.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
