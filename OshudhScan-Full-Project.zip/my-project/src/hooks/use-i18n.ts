"use client";
import { useCallback } from "react";
import { useAppStore } from "@/lib/store";
import { translate } from "@/lib/i18n";
import type { DictKey } from "@/lib/i18n/en";

/** Central i18n hook — every UI string goes through t(). */
export function useI18n() {
  const locale = useAppStore((s) => s.locale);
  const t = useCallback(
    (key: DictKey | string, vars?: Record<string, string | number>) => translate(locale, key, vars),
    [locale]
  );
  return { t, locale };
}
