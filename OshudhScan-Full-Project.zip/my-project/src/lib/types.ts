// Shared types for the OshudhScan demo pipeline

export type Severity = "major" | "moderate" | "minor" | "info";
export type Meal = "after" | "before" | "any";

export interface DrugEntry {
  id: string;
  brand: string;
  manufacturer: string;
  generic: string;
  genericBangla: string;
  strengths: string[]; // e.g. ["500mg"]
  form: "tablet" | "capsule" | "suspension" | "inhaler" | "sachet";
  therapeuticClass: string;
  unitPriceBdt: number; // indicative retail price per unit
  genericUnitPriceBdt: number; // indicative cheapest generic equivalent per unit
  meal: Meal;
  aliases?: string[]; // alternative spellings for fuzzy OCR matching
}

export interface OcrMedicine {
  brand_raw: string;
  strength: string | null;
  dose: string | null;
  duration: string | null;
}

export interface OcrResult {
  doctor: string | null;
  date: string | null;
  medicines: OcrMedicine[];
}

export interface MatchedMedicine {
  brandRaw: string;
  brand: string | null;
  manufacturer: string | null;
  generic: string | null;
  genericBangla: string | null;
  strength: string | null;
  form: DrugEntry["form"] | null;
  therapeuticClass: string | null;
  dose: string | null;
  duration: string | null;
  meal: Meal | null;
  unitPriceBdt: number | null;
  genericUnitPriceBdt: number | null;
  matchMethod: "exact" | "alias" | "fuzzy" | "generic" | "unmatched";
  confidence: number;
  perDay: number | null;
  days: number | null;
  qty: number | null;
  lineTotalBdt: number | null;
  genericLineTotalBdt: number | null;
}

export interface Finding {
  id: string;
  severity: Severity;
  type: "interaction" | "duplicate" | "dose" | "lifestyle" | "note";
  title: string;
  detail: string;
  action: string;
  drugs: string[];
  source: string;
}

export interface StageTiming {
  key: string;
  label: string;
  detail: string;
  ms: number;
}

export interface DecodeResponse {
  ok: boolean;
  engine: string;
  degraded: boolean;
  source: "upload" | "sample";
  ocr: OcrResult | null;
  medicines: MatchedMedicine[];
  findings: Finding[];
  totals: {
    brandBdt: number | null;
    genericBdt: number | null;
    savingsBdt: number | null;
    savingsPct: number | null;
    paracetamolMgPerDay: number | null;
    itemsRecognized: number;
    itemsTotal: number;
  };
  error?: string;
}

export interface Lead {
  id: string;
  createdAt: number;
  pharmacyName: string;
  patientRef: string;
  items: string[];
  safetyFlag: Severity | null;
  distanceKm: number;
  estBasketBdt: number;
  status: "new" | "accepted";
}
