// Opening-hours helpers. Times are evaluated in Asia/Dhaka (UTC+6) regardless
// of server timezone — Bangladesh users are the target audience.

const DHAKA_OFFSET_MIN = 6 * 60;

function dhakaNow(now = new Date()): { minutes: number; day: number } {
  const d = new Date(now.getTime() + DHAKA_OFFSET_MIN * 60 * 1000);
  const minutes = d.getUTCHours() * 60 + d.getUTCMinutes();
  const day = d.getUTCDay(); // 0=Sun … 6=Sat
  return { minutes, day };
}

function parseHHMM(s: string): number {
  const [h, m] = s.split(":").map((n) => parseInt(n, 10));
  return (Number.isNaN(h) ? 0 : h) * 60 + (Number.isNaN(m) ? 0 : m);
}

export interface OpeningHours {
  open: string; // "08:00"
  close: string; // "23:00"
}

export function isOpenNow(openingHoursJson: string | null, open24h = false, now = new Date()): boolean {
  if (open24h) return true;
  if (!openingHoursJson) return true; // unknown hours → don't filter out; UI shows "hours not reported"
  try {
    const parsed = JSON.parse(openingHoursJson);
    if (typeof parsed?.open === "string" && typeof parsed?.close === "string") {
      const { minutes } = dhakaNow(now);
      const o = parseHHMM(parsed.open);
      const c = parseHHMM(parsed.close);
      if (c >= o) return minutes >= o && minutes <= c;
      // overnight (e.g. 20:00–02:00)
      return minutes >= o || minutes <= c;
    }
    // per-day schedule {"mon":["08:00","22:00"],...}
    const dayKey = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"][dhakaNow(now).day];
    const today = parsed[dayKey] ?? parsed.today;
    if (Array.isArray(today) && today.length >= 2) {
      const { minutes } = dhakaNow(now);
      return minutes >= parseHHMM(String(today[0])) && minutes <= parseHHMM(String(today[1]));
    }
  } catch {
    // malformed JSON → treat as unknown
  }
  return true;
}
