// Business model + financial sketch (ILLUSTRATIVE — assumptions stated in UI).
// All figures below are computed from explicit assumptions, not invented "facts".

export const PRICING_TIERS = [
  {
    id: "listing",
    name: "Listing",
    priceBdt: 0,
    period: "forever",
    tagline: "Get discovered",
    features: [
      "Stock directory listing — appear in 'nearby pharmacies with stock'",
      "5 patient leads / month",
      "Generic-equivalence card shown with your price",
      "Basic footfall analytics",
    ],
    cta: "Start free",
  },
  {
    id: "pro",
    name: "Lead Engine Pro",
    priceBdt: 1999,
    period: "per month",
    tagline: "Most popular",
    features: [
      "Unlimited patient leads with safety-check context",
      "Priority ranking in the stock matcher",
      "Refill reminders keep patients coming back to YOU",
      "WhatsApp lead cards: decoded Rx + stock needed",
      "Duplicate-medicine & interaction advisory badge (trust builder)",
    ],
    cta: "Subscribe",
  },
  {
    id: "chain",
    name: "Chain",
    priceBdt: 7999,
    period: "per month · up to 5 branches",
    tagline: "For multi-branch pharmacies",
    features: [
      "Consolidated multi-branch lead dashboard",
      "Branch-level stock sync & transfer suggestions",
      "API access: lead webhook into your POS",
      "Co-branded dosage cards at the counter",
    ],
    cta: "Talk to sales",
  },
];

export const DISTRIBUTOR_CARD = {
  title: "Distributor partnership (generic substitution)",
  body: "When the decoder proposes a generic equivalent, the order can route through partner distributors at a lower wholesale price. OshudhScan takes a 6% platform fee on substituted orders — pharmacies keep the margin, distributors get volume, patients pay less.",
  bullets: [
    "6% platform fee on generic-substituted orders",
    "Wholesale price feed synced with stock listing",
    "Zero-cost revenue for the platform, savings for patients",
  ],
};

export interface RoiInputs {
  decodedRxPerDay: number; // decoded prescriptions within ~2 km / day
  capturePct: number; // share this pharmacy captures
  fillPct: number; // leads that convert to a fill
  basketBdt: number; // average basket value
  marginPct: number; // pharmacy gross margin
}

export const ROI_DEFAULTS: RoiInputs = {
  decodedRxPerDay: 45,
  capturePct: 8,
  fillPct: 35,
  basketBdt: 650,
  marginPct: 14,
};

export interface RoiResult {
  leadsPerDay: number;
  ordersPerDay: number;
  monthlyProfitBdt: number;
  netBdt: number;
  roiX: number;
  roiXWithRefill: number;
}

export const PRO_PRICE_BDT = 1999;
export const REFILL_UPLIFT = 0.18; // repeat-purchase uplift from refill reminders

export function computeRoi(i: RoiInputs): RoiResult {
  const leadsPerDay = (i.decodedRxPerDay * i.capturePct) / 100;
  const ordersPerDay = (leadsPerDay * i.fillPct) / 100;
  const dailyProfit = ordersPerDay * i.basketBdt * (i.marginPct / 100);
  const monthlyProfitBdt = dailyProfit * 30;
  const netBdt = monthlyProfitBdt - PRO_PRICE_BDT;
  const roiX = monthlyProfitBdt / PRO_PRICE_BDT;
  const roiXWithRefill = (monthlyProfitBdt * (1 + REFILL_UPLIFT)) / PRO_PRICE_BDT;
  return { leadsPerDay, ordersPerDay, monthlyProfitBdt, netBdt, roiX, roiXWithRefill };
}

// 3-year ARR projection (৳ million) — subscription + partnership/licensing
export const PROJECTION = [
  {
    year: "Year 1",
    subscription: 3.6, // 150 pharmacies × ৳1,999 × 12
    partnership: 0,
    pharmacies: 150,
  },
  {
    year: "Year 2",
    subscription: 17.64, // 700 × ৳2,100 × 12
    partnership: 2.5, // anonymized demand-insight licensing
    pharmacies: 700,
  },
  {
    year: "Year 3",
    subscription: 47.52, // 1,800 × ৳2,200 × 12
    partnership: 19, // 7 data licensing + 12 distributor rev-share
    pharmacies: 1800,
  },
];

export const MARKET_STATS = {
  marketUsdB: 3.39, // domestic pharma market, end of 2024
  marketGrowthPct: 17.7,
  retailPharmacies: "100k+",
  avgBasketBdt: 650,
  leadValueBdt: 90,
};
