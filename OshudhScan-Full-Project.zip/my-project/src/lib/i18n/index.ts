// Centralized translation system.
// - Dictionaries: en.ts (source of truth), bn.ts; architecture accepts ar/hi later.
// - Fallback chain: current locale → English → the key itself.
// - Medicine identity (brand, generic, strength, dose values) is NEVER translated.
import { en, type DictKey, type Dictionary } from "./en";
import { bn } from "./bn";

export type Locale = "bn" | "en";
export const SUPPORTED_LOCALES: Locale[] = ["bn", "en"];
// Future locales land here once dictionaries exist:
// export const FUTURE_LOCALES = ["ar", "hi"];

const DICTS: Record<Locale, Dictionary> = { en, bn };

export function translate(
  locale: Locale,
  key: DictKey | string,
  vars?: Record<string, string | number>
): string {
  const dict = DICTS[locale] ?? en;
  let text = dict[key as DictKey] ?? en[key as DictKey] ?? String(key);
  if (vars) {
    for (const [k, v] of Object.entries(vars)) {
      text = text.replaceAll(`{${k}}`, String(v));
    }
  }
  return text;
}

export function isLocale(value: unknown): value is Locale {
  return value === "bn" || value === "en";
}

export type { DictKey, Dictionary };
export { en, bn };
