// National Healthcare Directory — shared domain logic.
// Data provenance rules: a record's verification status is ALWAYS explicit,
// completeness is NOT legal/clinical verification, and nothing here invents
// data. The deterministic quality score is purely a field-completeness metric.

// ── verification ladder ───────────────────────────────────────────────────────

export const VERIFICATION_STATUSES = [
  "OFFICIALLY_LISTED", // present in a government/official registry (≠ contact verified)
  "MAP_LISTED",        // matched against an authorized Google Maps Platform response
  "CONTACT_VERIFIED",  // phone verified with a timestamp (call/SMS log)
  "LICENSE_VERIFIED",  // drug license verified against an authorized source
  "ADMIN_VERIFIED",    // platform admin reviewed and confirmed
  "UNVERIFIED",        // ingested but not reviewed
  "TEMPORARILY_CLOSED",
  "PERMANENTLY_CLOSED",
  "REPORTED_INCORRECT",
] as const;

export type VerificationStatus = (typeof VERIFICATION_STATUSES)[number];

export function isVerificationStatus(v: string): v is VerificationStatus {
  return (VERIFICATION_STATUSES as readonly string[]).includes(v);
}

/** Statuses that indicate the record is usable right now. */
export const ACTIVE_STATUSES: VerificationStatus[] = [
  "OFFICIALLY_LISTED", "MAP_LISTED", "CONTACT_VERIFIED", "LICENSE_VERIFIED", "ADMIN_VERIFIED", "UNVERIFIED",
];

// ── facility / pharmacy categories ────────────────────────────────────────────

export const HOSPITAL_CATEGORIES = [
  "MEDICAL_COLLEGE",
  "DISTRICT_HOSPITAL",
  "GENERAL_HOSPITAL",
  "UPAZILA_HEALTH_COMPLEX",
  "SPECIALIZED",
  "OTHER",
] as const;

export const FACILITY_TYPES = ["HOSPITAL", "CLINIC", "DIAGNOSTIC", "BLOOD_BANK", "AMBULANCE_SERVICE"] as const;

export const REPORT_TYPES = [
  "WRONG_PHONE", "WRONG_ADDRESS", "TEMPORARILY_CLOSED", "PERMANENTLY_CLOSED",
  "DUPLICATE", "WRONG_CATEGORY", "WRONG_LOCATION", "OTHER",
] as const;

// ── normalization & duplicate detection ───────────────────────────────────────

/** Collapse punctuation/diacritic-free differences for stable matching. */
export function normalizeName(name: string): string {
  return name
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\b(ltd|limited|pvt|private|hospital|general|hmc|cent(er|re))\b/g, " ")
    .replace(/[^a-z0-9\u0980-\u09ff]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

/** Normalize a Bangladeshi phone number to 880 + 10-digit national number. */
export function normalizePhoneBd(raw: string): string | null {
  let digits = raw.replace(/[^\d]/g, "");
  if (digits.length < 10 || digits.length > 14) return null;
  if (digits.startsWith("880")) digits = digits.slice(3);
  else if (digits.startsWith("88")) digits = digits.slice(2);
  if (digits.startsWith("0")) digits = digits.slice(1);
  if (digits.length !== 10) return null;
  return `880${digits}`;
}

/**
 * Duplicate key: normalized name + district (+ upazila when present).
 * Two rows with the same key are treated as duplicates by the importer.
 */
export function recordKey(name: string, district: string | null | undefined, upazila?: string | null): string {
  return [normalizeName(name), (district ?? "").toLowerCase(), (upazila ?? "").toLowerCase()].filter(Boolean).join("|");
}

// ── quality score (field completeness, NOT verification) ──────────────────────

const QUALITY_WEIGHTS = {
  name: 10, nameBangla: 8, type: 6, ownership: 6, division: 4, district: 6,
  upazila: 4, address: 10, latLng: 10, phone: 12, services: 8, source: 6, verified: 10,
} as const;

export type QualityFields = { [K in keyof typeof QUALITY_WEIGHTS]: boolean };

export function qualityScore(fields: Partial<QualityFields>): number {
  const total = Object.values(QUALITY_WEIGHTS).reduce((a, b) => a + b, 0);
  const got = Object.keys(QUALITY_WEIGHTS).reduce(
    (acc, k) => acc + (fields[k as keyof QualityFields] ? QUALITY_WEIGHTS[k as keyof typeof QUALITY_WEIGHTS] : 0),
    0
  );
  return Math.round((got / total) * 100);
}

export function facilityQualityFields(f: {
  name?: string | null; nameBangla?: string | null; type?: string | null; ownership?: string | null;
  division?: string | null; district?: string | null; upazila?: string | null; addressLine?: string | null;
  lat?: number | null; lng?: number | null; phone?: string | null; services?: string | null;
  source?: string | null; verificationStatus?: string | null;
}): QualityFields {
  return {
    name: Boolean(f.name), nameBangla: Boolean(f.nameBangla), type: Boolean(f.type),
    ownership: Boolean(f.ownership), division: Boolean(f.division), district: Boolean(f.district),
    upazila: Boolean(f.upazila), address: Boolean(f.addressLine),
    latLng: f.lat != null && f.lng != null, phone: Boolean(f.phone),
    services: Boolean(f.services && f.services !== "[]"), source: Boolean(f.source),
    verified: Boolean(f.verificationStatus && f.verificationStatus !== "UNVERIFIED"),
  };
}

// ── CSV parsing (RFC 4180-ish, quoted fields supported) ──────────────────────

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { cur += '"'; i++; } else inQuotes = false;
      } else cur += c;
    } else if (c === '"') inQuotes = true;
    else if (c === ",") { row.push(cur); cur = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(cur); cur = "";
      if (row.length > 1 || row[0] !== "") rows.push(row);
      row = [];
    } else cur += c;
  }
  row.push(cur);
  if (row.length > 1 || row[0] !== "") rows.push(row);
  return rows;
}

// ── Google Maps links (no API key required, plain universal links) ────────────

export function googleMapsSearchUrl(name: string, address?: string | null): string {
  const q = encodeURIComponent([name, address].filter(Boolean).join(", "));
  return `https://www.google.com/maps/search/?api=1&query=${q}`;
}

export function googleMapsDirectionsUrl(lat: number, lng: number, origin?: { lat: number; lng: number } | null): string {
  if (origin) {
    return `https://www.google.com/maps/dir/?api=1&origin=${origin.lat},${origin.lng}&destination=${lat},${lng}&travelmode=driving`;
  }
  return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
}

/** OpenStreetMap turn-by-turn directions page between two points (no key). */
export function osmRouteUrl(origin: { lat: number; lng: number }, dest: { lat: number; lng: number }): string {
  return `https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=${origin.lat.toFixed(5)}%2C${origin.lng.toFixed(5)}%2C${dest.lat.toFixed(5)}%2C${dest.lng.toFixed(5)}`;
}

// ── coverage classification (honest, count-based) ────────────────────────────
// EMPTY 0 · MINIMAL 1–3 · LOW 4–11 · MEDIUM 12–39 · HIGH 40+ records.
// Used by /api/directory/coverage to flag districts whose directory data is
// still thin — an honest gap, never padded with invented records.
export type CoverageLevel = "EMPTY" | "MINIMAL" | "LOW" | "MEDIUM" | "HIGH";

export function coverageLevel(total: number): CoverageLevel {
  if (total <= 0) return "EMPTY";
  if (total <= 3) return "MINIMAL";
  if (total <= 11) return "LOW";
  if (total <= 39) return "MEDIUM";
  return "HIGH";
}
