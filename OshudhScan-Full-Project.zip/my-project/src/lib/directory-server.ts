// National Healthcare Directory — server-side query helpers shared by the
// /api/directory/* and /api/facilities/* routes. Keeps the search semantics
// identical across endpoints (honest data: phones flagged, missing = absent,
// distance only when coordinates exist).
import { db } from "@/lib/db";
import { haversineKm } from "@/lib/geo";
import { googleMapsSearchUrl, googleMapsDirectionsUrl, qualityScore, facilityQualityFields } from "@/lib/directory";
import type { Prisma } from "@prisma/client";

export interface FacilityRow {
  id: string;
  name: string;
  nameBangla: string | null;
  type: string;
  hospitalCategory: string | null;
  ownership: string | null;
  division: string | null;
  district: string | null;
  upazila: string | null;
  area: string | null;
  addressLine: string;
  lat: number | null;
  lng: number | null;
  phone: string | null;
  isPhoneVerified: boolean;
  emergencyPhone: string | null;
  email: string | null;
  website: string | null;
  emergency: boolean;
  services: string[];
  specialties: string[];
  openingHours: string | null;
  verificationStatus: string;
  qualityScore: number | null;
  source: string;
  sourceType: string | null;
  sourceUrl: string | null;
  lastVerifiedAt: Date | null;
  distanceKm: number | null;
  mapsSearchUrl: string;
  mapsDirectionsUrl: string | null;
}

const facilitySelect = {
  id: true, name: true, nameBangla: true, type: true, hospitalCategory: true, ownership: true,
  division: true, district: true, upazila: true, area: true, addressLine: true, lat: true, lng: true,
  phone: true, isPhoneVerified: true, emergencyPhone: true, email: true, website: true,
  emergency: true, services: true, specialties: true, openingHours: true,
  verificationStatus: true, qualityScore: true, source: true, sourceType: true, sourceUrl: true,
  lastVerifiedAt: true,
} satisfies Prisma.HealthcareFacilitySelect;

type FacilityModel = Prisma.HealthcareFacilityGetPayload<{ select: typeof facilitySelect }>;

function parseJsonArray(raw: string | null): string[] {
  try { return raw ? (JSON.parse(raw) as string[]) : []; } catch { return []; }
}

export function toFacilityRow(f: FacilityModel, origin?: { lat: number; lng: number }): FacilityRow {
  const distanceKm =
    origin && f.lat != null && f.lng != null
      ? Math.round(haversineKm(origin, { lat: f.lat, lng: f.lng }) * 10) / 10
      : null;
  const mapsDirectionsUrl = f.lat != null && f.lng != null ? googleMapsDirectionsUrl(f.lat, f.lng) : null;
  return {
    ...f,
    services: parseJsonArray(f.services),
    specialties: parseJsonArray(f.specialties),
    qualityScore: f.qualityScore ?? qualityScore(facilityQualityFields(f)),
    distanceKm,
    mapsSearchUrl: googleMapsSearchUrl(f.name, [f.addressLine, f.district].filter(Boolean).join(", ")),
    mapsDirectionsUrl,
  };
}

export interface FacilityQuery {
  q?: string;
  type?: string | null;
  category?: string | null;
  ownership?: string | null;
  division?: string | null;
  district?: string | null;
  upazila?: string | null;
  emergencyOnly?: boolean;
  verification?: string | null;
  origin?: { lat: number; lng: number } | null;
  distanceKm?: number | null;
  skip?: number;
  take?: number;
  nameOnly?: boolean;
}

export async function queryFacilities(query: FacilityQuery): Promise<{ rows: FacilityRow[]; total: number }> {
  const where: Prisma.HealthcareFacilityWhereInput = { deletedAt: null };
  if (query.q) where.OR = [{ name: { contains: query.q } }, { nameBangla: { contains: query.q } }, { area: { contains: query.q } }];
  if (query.type) where.type = query.type;
  // Place-based directory: national hotlines (district = null) live in the
  // emergency directory, not the hospital/clinic/diagnostic listings.
  if (query.type && query.type !== "BLOOD_BANK" && query.type !== "AMBULANCE_SERVICE") {
    where.district = { not: null };
  }
  if (query.category) where.hospitalCategory = query.category;
  if (query.ownership) where.ownership = query.ownership;
  if (query.division) where.division = query.division;
  if (query.district) where.district = query.district;
  if (query.upazila) where.upazila = query.upazila;
  if (query.emergencyOnly) where.emergency = true;
  if (query.verification) where.verificationStatus = query.verification;
  // Spatial prefilter (PostGIS moves this into SQL — see docs/DATABASE.md):
  // a bounding box slightly larger than the radius circle, so the in-memory
  // haversine pass below sees only relevant rows at national scale.
  if (query.origin && query.distanceKm) {
    const dLat = query.distanceKm / 111;
    const dLng = query.distanceKm / (111 * Math.max(0.2, Math.cos((query.origin.lat * Math.PI) / 180)));
    where.lat = { gte: query.origin.lat - dLat, lte: query.origin.lat + dLat };
    where.lng = { gte: query.origin.lng - dLng, lte: query.origin.lng + dLng };
  }

  const hasOrigin = Boolean(query.origin);

  // With a geographic origin we must rank by REAL distance, not alphabetical
  // order — so we pull the bbox candidate set (cap 2000), compute haversine
  // distances, filter to the radius and sort nearest-first in memory before
  // applying skip/take. Without an origin, SQL-side skip/take is correct.
  const [raw, total] = await Promise.all([
    db.healthcareFacility.findMany({
      where,
      select: facilitySelect,
      orderBy: hasOrigin ? [{ name: "asc" }] : [{ district: "asc" }, { name: "asc" }],
      skip: hasOrigin ? undefined : query.skip,
      take: hasOrigin ? 2000 : query.take,
    }),
    db.healthcareFacility.count({ where }),
  ]);
  const mapped = raw.map((f) => toFacilityRow(f, query.origin ?? undefined));
  if (hasOrigin) {
    const radius = query.distanceKm ?? null;
    const inRadius = radius ? mapped.filter((r) => r.distanceKm !== null && r.distanceKm <= radius) : mapped;
    inRadius.sort((a, b) => {
      if (a.distanceKm === null && b.distanceKm === null) return 0;
      if (a.distanceKm === null) return 1;
      if (b.distanceKm === null) return -1;
      return a.distanceKm - b.distanceKm;
    });
    const start = query.skip ?? 0;
    const end = query.take ? start + query.take : undefined;
    return { rows: inRadius.slice(start, end), total: inRadius.length };
  }
  return { rows: mapped, total };
}

// ── pharmacies ────────────────────────────────────────────────────────────────

export interface PharmacyRow {
  id: string;
  name: string;
  nameBangla: string | null;
  contactPhone: string;
  addressLine: string;
  division: string | null;
  district: string | null;
  upazila: string | null;
  area: string | null;
  lat: number | null;
  lng: number | null;
  openingHours: string | null;
  services: string[];
  licenseNumber: string | null;
  status: string;
  isVerified: boolean;
  verificationStatus: string;
  isDemo: boolean;
  qualityScore: number | null;
  sourceName: string | null;
  sourceUrl: string | null;
  distanceKm: number | null;
  mapsSearchUrl: string;
  mapsDirectionsUrl: string | null;
  stockedCount: number;
}

export interface PharmacyQuery {
  q?: string;
  medicineQ?: string;
  division?: string | null;
  district?: string | null;
  upazila?: string | null;
  origin?: { lat: number; lng: number } | null;
  distanceKm?: number | null;
  verifiedOnly?: boolean;
  skip?: number;
  take?: number;
}

export async function queryPharmacies(query: PharmacyQuery): Promise<{ rows: PharmacyRow[]; total: number }> {
  const where: Prisma.PharmacyWhereInput = { deletedAt: null };
  if (query.q) where.OR = [{ name: { contains: query.q } }, { nameBangla: { contains: query.q } }, { area: { contains: query.q } }];
  if (query.medicineQ) {
    where.inventory = {
      some: {
        status: "ACTIVE",
        quantity: { gt: 0 },
        medicine: {
          isActive: true,
          OR: [
            { brand: { contains: query.medicineQ } },
            { generic: { contains: query.medicineQ } },
            { aliases: { contains: query.medicineQ } },
          ],
        },
      },
    };
  }
  if (query.division) where.division = query.division;
  if (query.district) where.district = query.district;
  if (query.upazila) where.upazila = query.upazila;
  if (query.verifiedOnly) where.isVerified = true;
  // Spatial prefilter (see queryFacilities note — bounding box ⊇ radius circle).
  if (query.origin && query.distanceKm) {
    const dLat = query.distanceKm / 111;
    const dLng = query.distanceKm / (111 * Math.max(0.2, Math.cos((query.origin.lat * Math.PI) / 180)));
    where.lat = { gte: query.origin.lat - dLat, lte: query.origin.lat + dLat };
    where.lng = { gte: query.origin.lng - dLng, lte: query.origin.lng + dLng };
  }

  const hasOrigin = Boolean(query.origin);

  const [raw, total] = await Promise.all([
    db.pharmacy.findMany({
      where,
      select: {
        id: true, name: true, nameBangla: true, contactPhone: true, addressLine: true,
        division: true, district: true, upazila: true, area: true, lat: true, lng: true,
        openingHours: true, services: true, licenseNumber: true, status: true,
        isVerified: true, verificationStatus: true, isDemo: true, qualityScore: true,
        sourceName: true, sourceUrl: true,
        _count: { select: { inventory: { where: { status: "ACTIVE", quantity: { gt: 0 } } } } },
      },
      orderBy: hasOrigin ? [{ name: "asc" }] : [{ district: "asc" }, { name: "asc" }],
      skip: hasOrigin ? undefined : query.skip,
      take: hasOrigin ? 2000 : query.take,
    }),
    db.pharmacy.count({ where }),
  ]);

  const rows: PharmacyRow[] = raw.map((p) => {
    const distanceKm =
      query.origin && p.lat != null && p.lng != null
        ? Math.round(haversineKm(query.origin, { lat: p.lat, lng: p.lng }) * 10) / 10
        : null;
    return {
      id: p.id,
      name: p.name,
      nameBangla: p.nameBangla,
      contactPhone: p.contactPhone,
      addressLine: p.addressLine,
      division: p.division,
      district: p.district,
      upazila: p.upazila,
      area: p.area,
      lat: p.lat,
      lng: p.lng,
      openingHours: p.openingHours,
      services: parseJsonArray(p.services),
      licenseNumber: p.licenseNumber,
      status: p.status,
      isVerified: p.isVerified,
      verificationStatus: p.verificationStatus,
      isDemo: p.isDemo,
      qualityScore: p.qualityScore,
      sourceName: p.sourceName,
      sourceUrl: p.sourceUrl,
      distanceKm,
      mapsSearchUrl: googleMapsSearchUrl(p.name, [p.addressLine, p.district].filter(Boolean).join(", ")),
      mapsDirectionsUrl: p.lat != null && p.lng != null ? googleMapsDirectionsUrl(p.lat, p.lng) : null,
      stockedCount: p._count.inventory,
    };
  });

  // apply GPS radius after computing distances, then rank nearest-first and
  // apply skip/take in memory (the SQL prefilter was only a bounding box)
  const filtered = query.origin && query.distanceKm
    ? rows.filter((r) => r.distanceKm !== null && r.distanceKm <= (query.distanceKm as number))
    : rows;
  if (query.origin && query.distanceKm) {
    filtered.sort((a, b) => {
      if (a.distanceKm === null && b.distanceKm === null) return 0;
      if (a.distanceKm === null) return 1;
      if (b.distanceKm === null) return -1;
      return a.distanceKm - b.distanceKm;
    });
    const start = query.skip ?? 0;
    const end = query.take ? start + query.take : undefined;
    return { rows: filtered.slice(start, end), total: filtered.length };
  }
  return { rows: filtered, total };
}

// ── Google Maps Platform (server-side proxy, key never leaves the server) ────

export function placesConfigured(): boolean {
  return Boolean(process.env.GOOGLE_MAPS_API_KEY);
}

export interface PlacesResult {
  placeId: string;
  name: string;
  formattedAddress: string | null;
  phone: string | null;
  lat: number | null;
  lng: number | null;
  rating: number | null;
  types: string[];
  openNow: boolean | null;
}

type GooglePlace = {
  place_id: string; name: string; formatted_address?: string;
  formatted_phone_number?: string; international_phone_number?: string;
  geometry?: { location?: { lat: number; lng: number } };
  rating?: number; types?: string[];
  opening_hours?: { open_now?: boolean };
};

/** Text Search (New API first, legacy fallback). Returns [] when unconfigured. */
export async function googlePlacesTextSearch(
  query: string,
  opts: { lat?: number; lng?: number; radius?: number; type?: string } = {}
): Promise<{ results: PlacesResult[]; configured: boolean; error?: string }> {
  const key = process.env.GOOGLE_MAPS_API_KEY;
  if (!key) return { results: [], configured: false };

  try {
    // Places API (New) — Text Search
    const body: Record<string, unknown> = { textQuery: query, maxResultCount: 12 };
    if (opts.lat != null && opts.lng != null) {
      body.locationBias = {
        circle: { center: { latitude: opts.lat, longitude: opts.lng }, radius: opts.radius ?? 20000 },
      };
    }
    if (opts.type) body.includedType = opts.type;
    const res = await fetch("https://places.googleapis.com/v1/places:searchText", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": key,
        "X-Goog-FieldMask": "places.id,places.displayName,places.formattedAddress,places.internationalPhoneNumber,places.location,places.rating,places.types",
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return { results: [], configured: true, error: `Google Places HTTP ${res.status}` };
    const json = (await res.json()) as { places?: Array<Record<string, unknown>> };
    const results: PlacesResult[] = (json.places ?? []).map((p) => {
      const loc = p.location as { latitude?: number; longitude?: number } | undefined;
      return {
        placeId: String(p.id ?? ""),
        name: String((p.displayName as { text?: string } | undefined)?.text ?? ""),
        formattedAddress: (p.formattedAddress as string | undefined) ?? null,
        phone: (p.internationalPhoneNumber as string | undefined) ?? null,
        lat: loc?.latitude ?? null,
        lng: loc?.longitude ?? null,
        rating: (p.rating as number | undefined) ?? null,
        types: Array.isArray(p.types) ? (p.types as string[]) : [],
        openNow: null,
      };
    });
    return { results, configured: true };
  } catch (err) {
    return { results: [], configured: true, error: err instanceof Error ? err.message : "Places request failed" };
  }
}

/** Keep a minimal audit trail of real API responses (never invented data). */
export async function cachePlaceResults(results: PlacesResult[], facilityId?: string, pharmacyId?: string) {
  for (const r of results.slice(0, 12)) {
    if (!r.placeId) continue;
    await db.googlePlaceRecord.upsert({
      where: { placeId: r.placeId },
      create: {
        placeId: r.placeId, name: r.name, formattedAddress: r.formattedAddress,
        phone: r.phone, lat: r.lat, lng: r.lng, rating: r.rating,
        types: JSON.stringify(r.types), facilityId: facilityId ?? null, pharmacyId: pharmacyId ?? null,
      },
      update: { fetchedAt: new Date() },
    });
  }
}
