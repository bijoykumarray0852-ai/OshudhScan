// Brand-name fuzzy matching against the drug knowledge graph.
// Production note: this resolver would be backed by the full KG (~2,600 BD brands);
// the demo ships a 26-drug curated subset.
import { DRUG_DB } from "./drug-db";
import type { DrugEntry } from "./types";

export function normalizeBrand(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "")
    .trim();
}

function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[] = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= n; j++) {
      const tmp = dp[j];
      dp[j] = Math.min(
        dp[j] + 1,
        dp[j - 1] + 1,
        prev + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
      prev = tmp;
    }
  }
  return dp[n];
}

export interface BrandMatch {
  drug: DrugEntry;
  method: "exact" | "alias" | "fuzzy" | "generic";
  confidence: number;
}

/**
 * Match an OCR-extracted brand string to a knowledge-base entry.
 * Cascade: exact → alias → generic-name → fuzzy (Levenshtein on normalized strings).
 */
export function matchBrand(raw: string): BrandMatch | null {
  const norm = normalizeBrand(raw);
  if (!norm) return null;

  // 1. exact brand match (with strength stripped, e.g. "napa500" → brand "napa")
  for (const drug of DRUG_DB) {
    if (normalizeBrand(drug.brand) === norm) {
      return { drug, method: "exact", confidence: 0.98 };
    }
    const normNoStrength = norm.replace(/\d+(mg|mcg)?$/, "");
    if (normNoStrength && normalizeBrand(drug.brand) === normNoStrength) {
      return { drug, method: "exact", confidence: 0.96 };
    }
  }

  // 2. aliases
  for (const drug of DRUG_DB) {
    for (const alias of drug.aliases ?? []) {
      const na = normalizeBrand(alias);
      if (na === norm) return { drug, method: "alias", confidence: 0.94 };
    }
  }

  // 3. generic-name match — patient/pharmacist wrote the molecule, not the brand
  const genericWords = ["paracetamol", "omeprazole", "esomeprazole", "pantoprazole", "cetirizine", "fexofenadine", "montelukast", "aceclofenac", "tolfenamic", "amlodipine", "losartan", "atorvastatin", "metformin", "azithromycin", "cefixime", "metronidazole", "ondansetron", "clonazepam", "warfarin", "salbutamol"];
  for (const gw of genericWords) {
    if (norm.includes(gw.slice(0, 6))) {
      const drug = DRUG_DB.find((d) => d.generic.toLowerCase().includes(gw));
      if (drug) return { drug, method: "generic", confidence: 0.9 };
    }
  }

  // 4. fuzzy — handwritten OCR noise ("Nopq" → "Napa", "Secio" → "Seclo")
  let best: { drug: DrugEntry; score: number } | null = null;
  for (const drug of DRUG_DB) {
    const candidates = [drug.brand, ...(drug.aliases ?? [])].map(normalizeBrand);
    for (const cand of candidates) {
      const dist = levenshtein(norm, cand);
      const score = 1 - dist / Math.max(norm.length, cand.length);
      if (!best || score > best.score) best = { drug, score };
    }
  }
  if (best && best.score >= 0.72) {
    return { drug: best.drug, method: "fuzzy", confidence: Math.min(0.85, best.score) };
  }
  return null;
}

/** Parse BD dose notation "1+1+1" / "0+0+1" → doses per day and per-slot booleans. */
export function parseDose(dose: string | null): { perDay: number; slots: [boolean, boolean, boolean] } | null {
  if (!dose) return null;
  const parts = dose.split("+").map((p) => parseInt(p.trim(), 10));
  if (parts.length !== 3 || parts.some((p) => Number.isNaN(p))) return null;
  const perDay = parts[0] + parts[1] + parts[2];
  if (perDay === 0) return null;
  return { perDay, slots: [parts[0] > 0, parts[1] > 0, parts[2] > 0] };
}

/** Parse duration "5 days" / "30 days" / "1 month" → days. */
export function parseDuration(duration: string | null): number | null {
  if (!duration) return null;
  const d = duration.toLowerCase();
  const daysMatch = d.match(/(\d+)\s*day/);
  if (daysMatch) return parseInt(daysMatch[1], 10);
  const monthMatch = d.match(/(\d+)\s*month/);
  if (monthMatch) return parseInt(monthMatch[1], 10) * 30;
  const weekMatch = d.match(/(\d+)\s*(week|wk)/);
  if (weekMatch) return parseInt(weekMatch[1], 10) * 7;
  return null;
}
