// Mock pharmacy network (demo). Stock keyed by drug id from the knowledge base.
import { DRUG_DB } from "./drug-db";
import type { DecodeResponse } from "./types";

export interface Pharmacy {
  id: string;
  name: string;
  area: string;
  distanceKm: number;
  rating: number;
  open: boolean;
  stock: string[]; // drug ids stocked
  leadStat: string;
  partner: boolean; // subscribed to lead engine
  // enriched demo-network fields (records are clearly badged "Demo data" in the UI)
  phone: string; // sequential demo numbers — not real businesses
  address: string;
  district: string;
  lat: number;
  lng: number;
  homeDelivery: boolean;
  open24h: boolean;
}

export const PHARMACIES: Pharmacy[] = [
  {
    id: "ph-medinova",
    name: "Medinova Pharmacy",
    area: "Mirpur-10 Roundabout",
    distanceKm: 0.4,
    rating: 4.8,
    open: true,
    stock: ["napa", "seclo", "alatrol", "neurob", "amodis", "emistat", "zimax", "comet", "amdocal", "orsaline", "flexi", "antazol", "fexo", "atova"],
    leadStat: "Answered 92% of leads this month",
    partner: true,
    phone: "+8801800000001",
    address: "Mirpur-10 Roundabout, Mirpur, Dhaka",
    district: "Dhaka",
    lat: 23.8105,
    lng: 90.4105,
    homeDelivery: true,
    open24h: false,
  },
  {
    id: "ph-lazz",
    name: "Lazz Pharma (Mirpur Branch)",
    area: "Mirpur Rd 10/1",
    distanceKm: 1.2,
    rating: 4.6,
    open: true,
    stock: ["napa", "seclo", "alatrol", "neurob", "amodis", "emistat", "zimax", "comet", "amdocal", "orsaline", "flexi", "antazol", "fexo", "atova", "angisartan", "monas", "warf", "maxpro", "losectil", "tufnil", "cef3", "rivotril", "pantonix", "esonix", "aceclo", "ventolin"],
    leadStat: "Full-chain stock — all demo SKUs",
    partner: true,
    phone: "+8801800000002",
    address: "Road 10/1, Mirpur, Dhaka",
    district: "Dhaka",
    lat: 23.8079,
    lng: 90.4122,
    homeDelivery: true,
    open24h: true,
  },
  {
    id: "ph-islamia",
    name: "Islamia Drug House",
    area: "Kazipara Bus Stop",
    distanceKm: 0.9,
    rating: 4.2,
    open: true,
    stock: ["napa", "seclo", "alatrol", "neurob", "amodis", "orsaline", "comet", "flexi", "antazol", "angisartan"],
    leadStat: "Independent — joined via Free listing",
    partner: false,
    phone: "+8801800000003",
    address: "Kazipara Bus Stop, Mirpur, Dhaka",
    district: "Dhaka",
    lat: 23.8149,
    lng: 90.4067,
    homeDelivery: false,
    open24h: false,
  },
  {
    id: "ph-shastho",
    name: "Shastho Seba Point",
    area: "Mirpur-11 Darus Salam Rd",
    distanceKm: 1.8,
    rating: 4.1,
    open: false,
    stock: ["napa", "alatrol", "seclo", "amodis", "emistat", "zimax", "orsaline", "neurob", "monas"],
    leadStat: "Opens 8:00 AM",
    partner: true,
    phone: "+8801800000004",
    address: "Darus Salam Road, Mirpur-11, Dhaka",
    district: "Dhaka",
    lat: 23.8009,
    lng: 90.4035,
    homeDelivery: true,
    open24h: false,
  },
  {
    id: "ph-nurerchaya",
    name: "Nurer Chaya Pharmacy",
    area: "Savar Bazar (rural partner)",
    distanceKm: 14.0,
    rating: 4.0,
    open: true,
    stock: ["napa", "seclo", "alatrol", "amodis", "orsaline", "neurob", "comet", "antazol", "emistat"],
    leadStat: "Rural pilot — union-level stocking hub",
    partner: true,
    phone: "+8801800000005",
    address: "Savar Bazar, Savar, Dhaka",
    district: "Dhaka",
    lat: 23.8583,
    lng: 90.2666,
    homeDelivery: false,
    open24h: false,
  },
];

export const LEAD_VALUE_BDT = 90; // est. gross profit per filled lead (basket ৳650 × 14% margin)

const BRAND_TO_ID = new Map(DRUG_DB.map((d) => [d.brand.toLowerCase(), d.id]));

export interface PharmacyMatch {
  pharmacy: Pharmacy;
  stockedBrands: string[];
  missingBrands: string[];
  coveragePct: number;
}

/** Match a decoded prescription against the pharmacy network's stock. */
export function matchPharmacies(decoded: DecodeResponse): PharmacyMatch[] {
  const neededIds: string[] = [];
  const neededBrands: string[] = [];
  for (const m of decoded.medicines) {
    if (!m.brand) continue;
    const id = BRAND_TO_ID.get(m.brand.toLowerCase());
    if (id) {
      neededIds.push(id);
      neededBrands.push(m.brand);
    }
  }
  return PHARMACIES.map((ph) => {
    const stockedBrands: string[] = [];
    const missingBrands: string[] = [];
    neededBrands.forEach((brand, i) => {
      if (ph.stock.includes(neededIds[i])) stockedBrands.push(brand);
      else missingBrands.push(brand);
    });
    const coveragePct = neededBrands.length
      ? Math.round((stockedBrands.length / neededBrands.length) * 100)
      : 0;
    return { pharmacy: ph, stockedBrands, missingBrands, coveragePct };
  })
    .filter((m) => m.coveragePct > 0)
    .sort((a, b) => b.coveragePct - a.coveragePct || a.pharmacy.distanceKm - b.pharmacy.distanceKm);
}
