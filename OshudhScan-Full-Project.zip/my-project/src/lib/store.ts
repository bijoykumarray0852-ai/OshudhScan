"use client";
import { create } from "zustand";
import type { DecodeResponse, Lead } from "@/lib/types";
import type { Locale } from "@/lib/i18n";
import type { SessionUser } from "@/lib/auth-types";

export type ViewKey =
  | "home"
  | "scan"
  | "medicines"
  | "find"
  | "directory"
  | "emergency"
  | "coverage"
  | "map"
  | "patient"
  | "care"
  | "portal"
  | "pricing"
  | "architecture"
  | "admin"
  | "settings";

interface AppState {
  // navigation
  view: ViewKey;
  setView: (v: ViewKey) => void;

  // i18n
  locale: Locale;
  setLocale: (l: Locale) => void;
  largeText: boolean;
  setLargeText: (on: boolean) => void;

  // Low Internet Mode — text-first results, maps/tiles deferred until asked.
  liteMode: boolean;
  setLiteMode: (on: boolean) => void;

  // auth
  user: SessionUser | null;
  authLoaded: boolean;
  authDialogOpen: boolean;
  authMode: "signin" | "signup";
  setUser: (u: SessionUser | null) => void;
  setAuthLoaded: () => void;
  openAuth: (mode?: "signin" | "signup") => void;
  closeAuth: () => void;

  // decode results
  decoded: DecodeResponse | null;
  decodedSampleTitle: string | null;
  uploadedImagePreview: string | null;
  savedPrescriptionId: string | null;
  setDecoded: (d: DecodeResponse | null, title: string | null, imagePreview: string | null) => void;
  setSavedPrescriptionId: (id: string | null) => void;

  // pharmacy portal leads (client mirror of DB leads for the demo partner)
  leads: Lead[];
  pushLeads: (leads: Lead[]) => void;
  acceptLead: (id: string) => void;
  acceptedLeads: number;

  // favorites (client-persisted convenience list of pharmacy ids)
  favorites: string[];
  toggleFavorite: (id: string) => void;

  // notification badge count
  unreadNotifications: number;
  setUnreadNotifications: (n: number) => void;
}

const FAV_KEY = "oshudh.favorites";

function loadFavorites(): string[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(window.localStorage.getItem(FAV_KEY) ?? "[]") as string[];
  } catch {
    return [];
  }
}

export const useAppStore = create<AppState>((set, get) => ({
  view: "home",
  setView: (v) => set({ view: v }),

  locale: "bn",
  setLocale: (l) => {
    set({ locale: l });
    if (typeof document !== "undefined") {
      document.documentElement.lang = l;
      window.localStorage.setItem("oshudh.locale", l);
    }
    // persist to the user record when signed in
    const user = get().user;
    if (user) {
      fetch("/api/patients/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ locale: l }),
      }).catch(() => undefined);
    }
  },
  largeText: false,
  setLargeText: (on) => {
    set({ largeText: on });
    if (typeof window !== "undefined") window.localStorage.setItem("oshudh.largeText", on ? "1" : "0");
    const user = get().user;
    if (user) {
      fetch("/api/patients/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ largeText: on }),
      }).catch(() => undefined);
    }
  },

  // Low Internet Mode is a device-local accessibility choice — never synced.
  liteMode: false,
  setLiteMode: (on) => {
    set({ liteMode: on });
    if (typeof window !== "undefined") window.localStorage.setItem("oshudh.liteMode", on ? "1" : "0");
  },

  user: null,
  authLoaded: false,
  authDialogOpen: false,
  authMode: "signin",
  setUser: (u) => set({ user: u }),
  setAuthLoaded: () => set({ authLoaded: true }),
  openAuth: (mode = "signin") => set({ authDialogOpen: true, authMode: mode }),
  closeAuth: () => set({ authDialogOpen: false }),

  decoded: null,
  decodedSampleTitle: null,
  uploadedImagePreview: null,
  savedPrescriptionId: null,
  setDecoded: (d, title, imagePreview) =>
    set({ decoded: d, decodedSampleTitle: title, uploadedImagePreview: imagePreview, savedPrescriptionId: null }),
  setSavedPrescriptionId: (id) => set({ savedPrescriptionId: id }),

  leads: [],
  acceptedLeads: 0,
  pushLeads: (incoming) =>
    set((s) => ({ leads: [...incoming, ...s.leads].slice(0, 24) })),
  acceptLead: (id) =>
    set((s) => ({
      acceptedLeads: s.acceptedLeads + 1,
      leads: s.leads.map((l) => (l.id === id ? { ...l, status: "accepted" as const } : l)),
    })),

  favorites: [],
  toggleFavorite: (id) => {
    const cur = get().favorites.length ? get().favorites : loadFavorites();
    const next = cur.includes(id) ? cur.filter((f) => f !== id) : [...cur, id];
    set({ favorites: next });
    if (typeof window !== "undefined") window.localStorage.setItem(FAV_KEY, JSON.stringify(next));
  },

  unreadNotifications: 0,
  setUnreadNotifications: (n) => set({ unreadNotifications: n }),
}));

// hydrate persisted UI prefs on the client (call once from the app root)
export function hydratePrefs() {
  if (typeof window === "undefined") return;
  const locale = window.localStorage.getItem("oshudh.locale");
  if (locale === "bn" || locale === "en") useAppStore.setState({ locale });
  useAppStore.setState({ largeText: window.localStorage.getItem("oshudh.largeText") === "1" });
  useAppStore.setState({ liteMode: window.localStorage.getItem("oshudh.liteMode") === "1" });
  useAppStore.setState({ favorites: loadFavorites() });
  document.documentElement.lang = useAppStore.getState().locale;
}
