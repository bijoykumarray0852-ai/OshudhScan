// Geospatial helpers. SQLite has no PostGIS, so distance is computed in the
// application layer with the haversine formula (see docs/DATABASE.md for the
// PostgreSQL/PostGIS migration path where this moves into SQL).

export interface GeoPoint {
  lat: number;
  lng: number;
}

const EARTH_RADIUS_KM = 6371;

export function haversineKm(a: GeoPoint, b: GeoPoint): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.sqrt(s));
}

export function formatDistance(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`;
  return `${km < 10 ? km.toFixed(1) : Math.round(km)} km`;
}

export const DISTANCE_FILTERS = [1, 3, 5, 10, 20] as const;

/** bbox for an OpenStreetMap embed iframe centred on a point. */
export function osmEmbedUrl(p: GeoPoint, spanKm = 3): string {
  const dLat = spanKm / 111;
  const dLng = spanKm / (111 * Math.max(0.2, Math.cos((p.lat * Math.PI) / 180)));
  const bbox = [p.lng - dLng, p.lat - dLat, p.lng + dLng, p.lat + dLat]
    .map((n) => n.toFixed(5))
    .join(",");
  return `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${p.lat.toFixed(5)},${p.lng.toFixed(5)}`;
}

export function osmDirectionsUrl(p: GeoPoint): string {
  return `https://www.openstreetmap.org/?mlat=${p.lat}&mlon=${p.lng}#map=17/${p.lat}/${p.lng}`;
}

// ── stock freshness (live availability honesty rules) ─────────────────────────

export type StockStatus = "IN_STOCK" | "LOW_STOCK" | "OUT_OF_STOCK" | "UNKNOWN" | "STALE";

/** Hours after which a stock record is treated as stale (not live). */
export const STALE_AFTER_HOURS = 24 * 3; // 3 days

export function stockStatus(qty: number | null, updatedAt: Date | null, now = new Date()): StockStatus {
  if (qty === null || updatedAt === null) return "UNKNOWN";
  const ageH = (now.getTime() - updatedAt.getTime()) / 3600000;
  if (ageH > STALE_AFTER_HOURS) return "STALE";
  if (qty <= 0) return "OUT_OF_STOCK";
  if (qty <= 10) return "LOW_STOCK";
  return "IN_STOCK";
}

export function isExpiredBatch(expiryDate: Date | null | undefined, now = new Date()): boolean {
  if (!expiryDate) return false;
  return expiryDate.getTime() < now.getTime();
}
