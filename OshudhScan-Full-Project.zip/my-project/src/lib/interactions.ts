// Deterministic safety rules engine — the core IP beyond a "GPT wrapper".
// Interactions come from an auditable rule matrix (curated from standard
// clinical references); the LLM never decides safety, it only explains it.
// Governance: the DB registry (clinical_rules) can retire a rule — the decode
// API passes retired/disabled ruleIds here and the engine skips them. Findings
// remain fully deterministic and auditable.
import type { Finding, MatchedMedicine } from "./types";

const NSAID_CLASSES = ["nsaid", "nsaid-combo"];
const PARACETAMOL_GENERIC = /paracetamol/i;

interface ClassRule {
  id: string;
  classA: string;
  classB: string;
  severity: "major" | "moderate";
  title: string;
  detail: string;
  action: string;
  source: string;
}

const CLASS_RULES: ClassRule[] = [
  {
    id: "R1",
    classA: "anticoagulant",
    classB: "nsaid",
    severity: "major",
    title: "MAJOR — Blood thinner + painkiller (bleeding risk)",
    detail:
      "Warfarin plus any NSAID (aceclofenac here) multiplies the risk of serious gastrointestinal bleeding. The NSAID also irritates the stomach lining and displaces warfarin from plasma proteins, pushing INR up unpredictably.",
    action:
      "Do NOT dispense the NSAID without prescriber confirmation. Ask the pharmacy to call the doctor and suggest paracetamol-based pain relief instead.",
    source: "Rules engine · interaction matrix R1",
  },
  {
    id: "R3",
    classA: "nsaid",
    classB: "nsaid",
    severity: "major",
    title: "MAJOR — Two NSAIDs prescribed together",
    detail:
      "Two NSAIDs (or an NSAID + NSAID/paracetamol combo) do not add pain relief — they add stomach ulcer, kidney and bleeding risk. This is one of the most common handwritten-prescription mix-ups.",
    action:
      "Dispense only ONE NSAID. Ask the prescriber which one to keep; offer the generic paracetamol alternative for breakthrough pain.",
    source: "Rules engine · interaction matrix R3",
  },
  {
    id: "R2",
    classA: "anticoagulant",
    classB: "paracetamol-chronic",
    severity: "moderate",
    title: "MODERATE — Regular paracetamol while on warfarin",
    detail:
      "Taking paracetamol regularly (>2g/day for several days) can raise INR in warfarin patients. This prescription includes paracetamol (directly or inside a combo) for multiple days.",
    action:
      "Flag for pharmacist: recommend an INR check mid-course and tell the patient to report unusual bruising or bleeding.",
    source: "Rules engine · interaction matrix R2",
  },
  {
    id: "R4",
    classA: "ppi",
    classB: "ppi",
    severity: "moderate",
    title: "MODERATE — Two brands of the same class (PPI duplicate)",
    detail:
      "Two different proton-pump inhibitor brands (e.g., Seclo + Losectil — both omeprazole) duplicate therapy. Patients often buy both because the names look different, doubling cost with zero benefit.",
    action: "Dispense one brand only. Show the patient the generic match so they never buy two PPIs again.",
    source: "Rules engine · duplicate-class detector R4",
  },
  {
    id: "R5",
    classA: "antihistamine",
    classB: "antihistamine",
    severity: "moderate",
    title: "MODERATE — Duplicate antihistamines",
    detail: "Two antihistamine brands stack sedation and anticholinergic effects without added benefit.",
    action: "Keep one. If one is cetirizine (daytime) and the other was intended for night use, confirm with the prescriber.",
    source: "Rules engine · duplicate-class detector R5",
  },
  {
    id: "R6",
    classA: "macrolide",
    classB: "antiemetic-5ht3",
    severity: "moderate",
    title: "MODERATE — Additive QT-prolongation (azithromycin + ondansetron)",
    detail:
      "Azithromycin and ondansetron both prolong the QT interval. Combined use raises the risk of torsades de pointes, especially with electrolyte disturbance (relevant if the patient has diarrhoea/vomiting).",
    action:
      "Pharmacist note: check if patient is on a heart medication or has low potassium. Advise ECG follow-up if palpitations or fainting occur.",
    source: "Rules engine · interaction matrix R6",
  },
  {
    id: "R7",
    classA: "arb",
    classB: "nsaid",
    severity: "moderate",
    title: "MODERATE — Blood-pressure medicine + NSAID",
    detail:
      "NSAIDs blunt the effect of losartan and can strain kidney function, especially in older patients or with dehydration.",
    action: "Advise the shortest NSAID course possible and monitor BP at home; report swelling or reduced urination.",
    source: "Rules engine · interaction matrix R7",
  },
  {
    id: "R8",
    classA: "nitroimidazole",
    classB: "lifestyle-alcohol",
    severity: "major",
    title: "MAJOR — Metronidazole + alcohol is strictly forbidden",
    detail:
      "Alcohol during metronidazole therapy (and up to 3 days after) causes a disulfiram-like reaction: flushing, severe vomiting, headache, rapid heartbeat.",
    action:
      "Print the Bangla warning card: 'মেট্রোনিডাজল খাওয়ার সময় ও শেষ ডোজের ৩ দিন পর্যন্ত অ্যালকোহল একদম নিষিদ্ধ'।",
    source: "Rules engine · lifestyle guard R8",
  },
];

function paracetamolMgPerDay(meds: MatchedMedicine[]): number | null {
  let total = 0;
  let found = false;
  for (const m of meds) {
    if (!m.generic || !m.perDay) continue;
    if (!PARACETAMOL_GENERIC.test(m.generic)) continue;
    const pcMatch = m.generic.match(/Paracetamol\s*(\d+)/i);
    if (!pcMatch) continue;
    const mgPerUnit = parseInt(pcMatch[1], 10);
    total += mgPerUnit * m.perDay;
    found = true;
  }
  return found ? total : null;
}

export function runSafetyEngine(meds: MatchedMedicine[], disabledRuleIds: string[] = []): Finding[] {
  const disabled = new Set(disabledRuleIds);
  const findings: Finding[] = [];
  const known = meds.filter((m) => m.brand && m.therapeuticClass);

  const classOf = (m: MatchedMedicine) => m.therapeuticClass as string;
  const brandOf = (m: MatchedMedicine) => m.brand as string;

  const hasClass = (c: string) => known.filter((m) => classOf(m) === c);
  const inClass = (c: string) => NSAID_CLASSES.includes(c);

  for (const rule of CLASS_RULES) {
    if (rule.classA === "lifestyle-alcohol") continue; // handled explicitly
    if (rule.id === "R2") continue; // handled explicitly below
    if (disabled.has(rule.id)) continue;

    const a = hasClass(rule.classA === "nsaid" ? "nsaid" : rule.classA);
    const b = hasClass(rule.classB);

    const aAny = inClass(rule.classA)
      ? known.filter((m) => inClass(classOf(m)))
      : a;
    const bAny = inClass(rule.classB)
      ? known.filter((m) => inClass(classOf(m)))
      : b;

    if (rule.id === "R3") {
      // duplicate NSAID: two distinct brand lines that are NSAIDs
      if (aAny.length >= 2) {
        findings.push({
          id: rule.id,
          severity: rule.severity,
          type: "duplicate",
          title: rule.title,
          detail: rule.detail,
          action: rule.action,
          drugs: aAny.slice(0, 2).map(brandOf),
          source: rule.source,
        });
        continue;
      }
    }

    if (aAny.length === 0 || bAny.length === 0) continue;

    // For class-vs-class rules pick first of each side that is a DIFFERENT brand line
    const pair = aAny
      .flatMap((m1) => bAny.filter((m2) => m1 !== m2).map((m2) => [m1, m2] as const))
      .filter(([m1, m2]) => brandOf(m1) !== brandOf(m2))[0];
    if (!pair) continue;

    if (rule.id === "R4" || rule.id === "R5") {
      // duplicate therapy only counts when BOTH sides are the same class
      // and they are different brands of the same/related generic
      findings.push({
        id: rule.id,
        severity: rule.severity,
        type: "duplicate",
        title: rule.title,
        detail: rule.detail,
        action: rule.action,
        drugs: [brandOf(pair[0]), brandOf(pair[1])],
        source: rule.source,
      });
      continue;
    }

    findings.push({
      id: rule.id,
      severity: rule.severity,
      type: "interaction",
      title: rule.title,
      detail: rule.detail,
      action: rule.action,
      drugs: [brandOf(pair[0]), brandOf(pair[1])],
      source: rule.source,
    });
  }

  // R2 — paracetamol with warfarin (chronic use)
  const warf = hasClass("anticoagulant")[0];
  if (warf && !disabled.has("R2")) {
    const para = paracetamolMgPerDay(known);
    if (para !== null && para > 1000) {
      findings.push({
        id: "R2",
        severity: "moderate",
        type: "interaction",
        title: "MODERATE — Regular paracetamol while on warfarin",
        detail: `Estimated paracetamol intake from this prescription is ~${para} mg/day. Regular paracetamol use (especially >2g/day for several days) can raise INR in warfarin patients.`,
        action:
          "Flag for pharmacist: recommend an INR check mid-course and tell the patient to report unusual bruising or bleeding.",
        drugs: [brandOf(warf)],
        source: "Rules engine · interaction matrix R2",
      });
    }
  }

  // R8 — metronidazole lifestyle guard
  const metronidazole = hasClass("nitroimidazole")[0];
  if (metronidazole && !disabled.has("R8")) {
    findings.push({
      id: "R8",
      severity: "major",
      type: "lifestyle",
      title: "MAJOR — Alcohol is strictly forbidden with this medicine",
      detail:
        "Metronidazole + alcohol causes a disulfiram-like reaction: flushing, severe vomiting, headache, rapid heartbeat. Applies until 3 days after the last dose.",
      action:
        "Print the Bangla warning card: 'মেট্রোনিডাজল খাওয়ার সময় ও শেষ ডোজের ৩ দিন পর্যন্ত অ্যালকোহল একদম নিষিদ্ধ'।",
      drugs: [brandOf(metronidazole)],
      source: "Rules engine · lifestyle guard R8",
    });
  }

  // Paracetamol cumulative dose cap
  const para = paracetamolMgPerDay(known);
  if (para !== null && para > 3000 && !disabled.has("P1")) {
      findings.push({
        id: "dose-para",
        severity: "major",
        type: "dose",
        title: `MAJOR — Paracetamol overdose risk (~${para} mg/day)`,
        detail:
          "Total paracetamol across all items exceeds 3g/day (hepatotoxicity threshold in routine use). Patients unknowingly combine Napa with combo painkillers like Flexi — a classic duplicate-medicine error.",
        action:
          "Do not dispense as written. Reduce to a single paracetamol source and keep total under 3g/day (2g/day if elderly or liver issues).",
        drugs: known
          .filter((m) => m.generic && PARACETAMOL_GENERIC.test(m.generic))
          .map(brandOf),
        source: "Rules engine · cumulative dose guard",
      });
  } else if (para !== null && para > 2000 && !disabled.has("P2")) {
      findings.push({
        id: "dose-para-warn",
        severity: "minor",
        type: "dose",
        title: `Paracetamol total ~${para} mg/day — monitor`,
        detail: "Within the usual 4g ceiling but above the 2g/day caution line for long courses, elderly patients or liver disease.",
        action: "Confirm course length with the prescriber; counsel patient not to add any other paracetamol-containing medicine.",
        drugs: known
          .filter((m) => m.generic && PARACETAMOL_GENERIC.test(m.generic))
          .map(brandOf),
        source: "Rules engine · cumulative dose guard",
      });
  }

  // Same-generic, two brands (pharmacy mix-up trap)
  const byGeneric = new Map<string, MatchedMedicine[]>();
  for (const m of known) {
    if (!m.generic) continue;
    const key = m.generic.split(/\s?\+/)[0].replace(/\d+(mg|mcg)?$/i, "").trim().toLowerCase();
    byGeneric.set(key, [...(byGeneric.get(key) ?? []), m]);
  }
  for (const [, group] of byGeneric) {
    const brands = [...new Set(group.map(brandOf))];
    if (brands.length >= 2 && !disabled.has("D1")) {
      findings.push({
        id: `dup-${brands.join("-")}`,
        severity: "moderate",
        type: "duplicate",
        title: `Same generic under two brand names: ${brands.join(" + ")}`,
        detail:
          "Different brand names, identical molecule. This is exactly how patients end up double-dosing and double-paying at the pharmacy counter.",
        action: "Dispense one brand only and show the patient the generic-equivalence card.",
        drugs: brands.slice(0, 2),
        source: "Rules engine · same-molecule detector",
      });
    }
  }

  // Azithromycin regimen sanity check
  const azithro = known.find((m) => m.therapeuticClass === "macrolide" && m.dose);
  if (azithro && azithro.dose && azithro.dose.replace(/[0+]/g, "").length >= 2 && !disabled.has("A1")) {
    findings.push({
      id: "dose-azithro",
      severity: "minor",
      type: "dose",
      title: "Unusual azithromycin regimen — verify",
      detail: `Written as ${azithro.dose}. Common adult course for azithromycin 500mg is once daily for 3 days (1+0+0). Twice-daily dosing suggests either a misread digit or a special indication.`,
      action: "Pharmacist to confirm with prescriber before dispensing more than 3 tablets.",
      drugs: [brandOf(azithro)],
      source: "Rules engine · regimen sanity check",
    });
  }

  // Unrecognized items always surface (unless the reviewer retired U1)
  for (const m of meds) {
    if (!m.brand && !disabled.has("U1")) {
      findings.push({
        id: `unmatched-${m.brandRaw}`,
        severity: "minor",
        type: "note",
        title: `Could not confidently read "${m.brandRaw}"`,
        detail:
          "OCR extracted this line but the brand resolver scored it below the 72% confidence cutoff. It may be a brand outside the current demo knowledge base.",
        action: "Pharmacist review required before dispensing this line.",
        drugs: [m.brandRaw],
        source: "Brand resolver · confidence gate",
      });
    }
  }

  const order = { major: 0, moderate: 1, minor: 2, info: 3 } as const;
  return findings.sort((x, y) => order[x.severity] - order[y.severity]);
}

export function worstSeverity(findings: Finding[]): "major" | "moderate" | "minor" | null {
  if (findings.some((f) => f.severity === "major")) return "major";
  if (findings.some((f) => f.severity === "moderate")) return "moderate";
  if (findings.some((f) => f.severity === "minor")) return "minor";
  return null;
}
