// Bangla text helpers for the patient-facing dosage cards.
// Templates are deterministic (works offline); the LLM layer polishes these
// into natural phrasing and adds context-aware cautions.

const BN_DIGITS = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];

export function toBanglaDigits(input: string | number): string {
  return String(input).replace(/\d/g, (d) => BN_DIGITS[parseInt(d, 10)]);
}

const SLOT_WORDS = ["সকাল", "দুপুর", "রাত"];
const FORM_BN: Record<string, string> = {
  tablet: "ট্যাবলেট",
  capsule: "ক্যাপসুল",
  suspension: "সিরাপ",
  inhaler: "ইনহেলার",
  sachet: "প্যাক",
};

const CLASS_CAUTION_BN: Record<string, string> = {
  anticoagulant: "নিয়মিত রক্ত পরীক্ষা (INR) করান। অস্বাভাবিক রক্তক্ষরণ হলে সাথে সাথে ডাক্তারের কাছে যান।",
  nsaid: "খালি পেটে খাবেন না। গ্যাস্ট্রিকের সমস্যা দেখা দিলে ডাক্তারকে জানান।",
  "nsaid-combo": "খালি পেটে খাবেন না। অন্য কোনো প্যারাসিটামল/ব্যথার ওষুধের সাথে মিলিয়ে খাবেন না।",
  "analgesic-paracetamol": "দিনে ৪ ট্যাবলেটের (২০০০ মিগ্রা) বেশি খাবেন না।",
  ppi: "খাবারের অন্তত ৩০ মিনিট আগে খাবেন।",
  nitroimidazole: "এই ওষুধ খাওয়ার সময় ও শেষ ডোজের ৩ দিন পর্যন্ত অ্যালকোহল একদম নিষিদ্ধ।",
  macrolide: "পুরো কোর্সটা শেষ করুন, মাঝপথে বাদ দেবেন না।",
  benzodiazepine: "ঘুম আসতে পারে — গাড়ি বা মেশিন চালাবেন না।",
  antibiotic: "পুরো কোর্স শেষ করুন।",
  biguanide: "খাবারের পরে খাবেন, খালি পেটে খেলে বমি বমি লাগতে পারে।",
};

function cautionFor(cls: string | null): string {
  if (!cls) return "";
  if (CLASS_CAUTION_BN[cls]) return CLASS_CAUTION_BN[cls];
  if (cls.startsWith("antibiotic") || cls === "cephalosporin") return CLASS_CAUTION_BN.antibiotic;
  return "";
}

export interface TemplateInput {
  brand: string | null;
  brandRaw: string;
  genericBangla: string | null;
  strength: string | null;
  form: string | null;
  dose: string | null;
  duration: string | null;
  meal: string | null;
  therapeuticClass: string | null;
}

export function banglaDoseLine(t: TemplateInput): string {
  const name = t.brand ?? t.brandRaw;
  const strength = t.strength ? ` ${toBanglaDigits(t.strength.replace(/(mg|mcg)$/i, " মিগ্রা"))}` : "";
  const parts: string[] = [];

  const dose = t.dose;
  if (dose) {
    const slots = dose.split("+").map((s) => parseInt(s, 10) > 0);
    if (slots.length === 3 && slots.some(Boolean)) {
      const active = SLOT_WORDS.filter((_, i) => slots[i]).map((w) => `${w}ে`);
      parts.push(active.join(" ও "));
    }
  }

  if (t.meal === "after") parts.push("খাবারের পরে");
  else if (t.meal === "before") parts.push("খাবারের ৩০ মিনিট আগে");

  const form = t.form ? FORM_BN[t.form] ?? "" : "";
  const formText = form ? ` ${form}` : "";

  let line = `${name}${strength} — ${parts.length ? parts.join(", ") + " —" : ""} ১ টি${formText}`;
  if (dose === null) line = `${name} — প্রয়োজনে (কাউকে জিজ্ঞেস করে)`;
  else if (t.form === "sachet") line = `${name} — পানিতে মিশিয়ে খাবেন (প্রয়োজনে)`;
  else if (t.form === "inhaler") line = `${name} — নিয়ম করে পাফ নিন`;

  if (t.duration) {
    const days = t.duration.match(/(\d+)\s*day/);
    if (days) line += ` — ${toBanglaDigits(days[1])} দিন`;
    else line += ` — ${t.duration}`;
  } else if (t.dose) {
    line += " — ডাক্তার বলা পর্যন্ত";
  }

  line += "।";
  return line;
}

export function banglaCautionLine(cls: string | null): string {
  return cautionFor(cls);
}

export function templateExplain(
  items: Array<TemplateInput & { id: string }>
): { items: Array<{ id: string; brand: string; bangla: string; note: string }>; summary: string } {
  const out = items.map((it) => ({
    id: it.id,
    brand: it.brand ?? it.brandRaw,
    bangla: banglaDoseLine(it),
    note: banglaCautionLine(it.therapeuticClass),
  }));
  const summary =
    "প্রতিটি ওষুধের নিয়ম কার্ডে দেওয়া আছে। সব ওষুধ পুরো কোর্স শেষ করুন, আর কোনো অসুবিধা হলে ফার্মেসিতে জিজ্ঞেস করুন বা ডাক্তারকে দেখান।";
  return { items: out, summary };
}
