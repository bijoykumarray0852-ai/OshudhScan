import { createHash, randomBytes, scrypt as _scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

const scrypt = promisify(_scrypt) as (
  password: string,
  salt: string,
  keylen: number
) => Promise<Buffer>;

export const SESSION_COOKIE = "oshudh_session";
const SESSION_DAYS = 14;

import type { Role, SessionUser } from "@/lib/auth-types";
export type { Role, SessionUser };

// ── password hashing: scrypt with per-user random salt ─────────────────────────

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split(":");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  const [, salt, hash] = parts;
  const derived = await scrypt(password, salt, 64);
  const hashBuf = Buffer.from(hash, "hex");
  if (hashBuf.length !== derived.length) return false;
  return timingSafeEqual(hashBuf, derived);
}

// ── sessions ────────────────────────────────────────────────────────────────────

function newToken(): string {
  return randomBytes(32).toString("hex");
}

export async function createSession(
  userId: string,
  meta: { ip?: string; userAgent?: string } = {}
): Promise<{ token: string; expiresAt: Date }> {
  const token = newToken();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 3600 * 1000);
  await db.session.create({
    data: { token: createHash("sha256").update(token).digest("hex"), userId, expiresAt, ip: meta.ip, userAgent: meta.userAgent?.slice(0, 200) },
  });
  return { token, expiresAt };
}

export function sessionCookieOptions(expiresAt: Date) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  };
}

async function userFromToken(token: string | undefined): Promise<SessionUser | null> {
  if (!token) return null;
  const hashed = createHash("sha256").update(token).digest("hex");
  const session = await db.session.findUnique({
    where: { token: hashed },
    include: { user: true },
  });
  if (!session) return null;
  if (session.expiresAt < new Date()) {
    await db.session.delete({ where: { id: session.id } }).catch(() => undefined);
    return null;
  }
  if (session.user.deletedAt) return null;
  return {
    id: session.user.id,
    email: session.user.email,
    name: session.user.name,
    role: session.user.role as Role,
    locale: session.user.locale,
    largeText: session.user.largeText,
    phone: session.user.phone,
  };
}

/** Reads the session cookie and resolves the current user (or null). */
export async function getSessionUser(): Promise<SessionUser | null> {
  try {
    const store = await cookies();
    return await userFromToken(store.get(SESSION_COOKIE)?.value);
  } catch {
    return null;
  }
}

/** Resolves the current user or throws 401 ApiError. */
export async function requireUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) throw new ApiError(401, "AUTH_REQUIRED", "Sign in required");
  return user;
}

/** Resolves the current user and enforces a role allow-list. */
export async function requireRole(...roles: Role[]): Promise<SessionUser> {
  const user = await requireUser();
  if (!roles.includes(user.role)) throw new ApiError(403, "FORBIDDEN", "Insufficient permissions");
  return user;
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    const hashed = createHash("sha256").update(token).digest("hex");
    await db.session.deleteMany({ where: { token: hashed } });
  }
}

// API error with a stable machine-readable code.
export class ApiError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export { userFromToken };
