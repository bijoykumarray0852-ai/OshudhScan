"use client";
// Low Internet Mode (lite) — text-first results for slow connections.
// The user can toggle it manually (Settings / header toggle) and the app
// suggests it automatically when the browser reports a slow connection
// (Network Information API) or Data Saver is on. Never auto-forced.
import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/store";

export type ConnectionSpeed = "unknown" | "slow" | "fast";

function detectSpeed(): ConnectionSpeed {
  if (typeof navigator === "undefined") return "unknown";
  const conn = (navigator as unknown as {
    connection?: { effectiveType?: string; saveData?: boolean };
  }).connection;
  if (!conn) return "unknown";
  if (conn.saveData) return "slow";
  if (conn.effectiveType === "slow-2g" || conn.effectiveType === "2g") return "slow";
  return "fast";
}

/** Reactive lite-mode state + automatic slow-connection suggestion. */
export function useLiteMode() {
  const liteMode = useAppStore((s) => s.liteMode);
  const setLiteMode = useAppStore((s) => s.setLiteMode);
  // lazily read the connection once via an external-system subscription —
  // the initial value is computed in the initializer, not inside the effect
  const [speed, setSpeed] = useState<ConnectionSpeed>(() => detectSpeed());

  useEffect(() => {
    const conn = (navigator as unknown as {
      connection?: EventTarget & { effectiveType?: string };
    }).connection;
    if (!conn) return;
    const onChange = () => setSpeed(detectSpeed());
    conn.addEventListener?.("change", onChange);
    return () => conn.removeEventListener?.("change", onChange);
  }, []);

  const slow = speed === "slow";
  return { liteMode, setLiteMode, slow, suggest: slow && !liteMode, speed };
}
