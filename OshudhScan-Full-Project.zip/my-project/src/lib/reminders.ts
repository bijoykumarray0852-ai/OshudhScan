// Reminder scheduling — pure logic, unit-tested.
//
// SAFETY RULES (enforced here and in the UI):
// - A schedule is never activated without explicit user/pharmacist confirmation.
// - Ambiguous dosages are never auto-expanded: only parsed 1+0+1 style slots.
// - A missed dose is flagged, never "doubled". The engine does not alter
//   prescriber instructions.

export type Slot = "MORNING" | "AFTERNOON" | "NIGHT";

export const DEFAULT_SLOT_TIMES: Record<Slot, string> = {
  MORNING: "08:00",
  AFTERNOON: "14:00",
  NIGHT: "21:00",
};

export const MISSED_AFTER_MINUTES = 180; // 3h overdue → marked missed (in-app only)

export interface PlannedDose {
  dueAt: Date;
  slot: Slot | "CUSTOM";
}

function timeOn(date: Date, hhmm: string): Date {
  const [h, m] = hhmm.split(":").map((n) => parseInt(n, 10));
  const d = new Date(date);
  d.setHours(h, m, 0, 0);
  return d;
}

export function slotList(slots: Slot[]): Slot[] {
  const order: Slot[] = ["MORNING", "AFTERNOON", "NIGHT"];
  return order.filter((s) => slots.includes(s));
}

/**
 * Expand a schedule into concrete dose times.
 * @param slots       which day-slots apply
 * @param startDate   first day of the course
 * @param durationDays course length (null = open-ended/chronic → maxHorizonDays applies)
 * @param customTimes optional per-slot overrides {"MORNING":"07:30"}
 * @param maxHorizonDays materialisation horizon for open-ended schedules
 */
export function expandSchedule(
  slots: Slot[],
  startDate: Date,
  durationDays: number | null,
  customTimes?: Partial<Record<Slot, string>>,
  maxHorizonDays = 30
): PlannedDose[] {
  const activeSlots = slotList(slots);
  if (activeSlots.length === 0) return [];
  const days = Math.min(durationDays ?? maxHorizonDays, maxHorizonDays);
  const out: PlannedDose[] = [];
  for (let day = 0; day < days; day++) {
    const dayDate = new Date(startDate);
    dayDate.setDate(dayDate.getDate() + day);
    for (const slot of activeSlots) {
      const hhmm = customTimes?.[slot] ?? DEFAULT_SLOT_TIMES[slot];
      out.push({ dueAt: timeOn(dayDate, hhmm), slot });
    }
  }
  return out.sort((a, b) => a.dueAt.getTime() - b.dueAt.getTime());
}

/** A reminder is missed when it is PENDING and older than the missed threshold. */
export function isMissed(dueAt: Date, status: string, now = new Date()): boolean {
  if (status !== "PENDING") return false;
  return now.getTime() - dueAt.getTime() > MISSED_AFTER_MINUTES * 60 * 1000;
}

/** Course completion: every dose logged (taken or skipped) and none pending. */
export function isCourseComplete(
  doses: { status: string }[],
  endDate: Date | null,
  now = new Date()
): boolean {
  const pending = doses.some((d) => d.status === "PENDING" || d.status === "SNOOZED");
  if (pending) return false;
  if (endDate && endDate.getTime() > now.getTime()) return false;
  return doses.length > 0;
}

/** Refill warning threshold — warn when fewer than this many days of stock remain. */
export const REFILL_WARN_DAYS = 3;

export function refillNeeded(
  stockDays: number | null,
  daysElapsed: number,
  durationDays: number | null
): boolean {
  if (stockDays === null) return false;
  if (stockDays <= REFILL_WARN_DAYS) return true;
  if (durationDays !== null && durationDays - daysElapsed <= REFILL_WARN_DAYS) return true;
  return false;
}

/** Adherence percentage over logged doses (excludes still-pending). */
export function adherencePct(doses: { status: string }[]): number | null {
  const logged = doses.filter((d) => d.status === "TAKEN" || d.status === "SKIPPED" || d.status === "MISSED");
  if (logged.length === 0) return null;
  const taken = logged.filter((d) => d.status === "TAKEN").length;
  return Math.round((taken / logged.length) * 100);
}
