import { db } from "@/lib/db";
import { ApiError } from "@/lib/auth";
import type { SessionUser } from "@/lib/auth-types";

// Authorisation: owner, pharmacist, manager or inventory staff of THIS pharmacy.
export async function assertPharmacyAccess(user: SessionUser, pharmacyId: string) {
  const staff = await db.pharmacyStaff.findUnique({
    where: { pharmacyId_userId: { pharmacyId, userId: user.id } },
    include: { pharmacy: true },
  });
  if (!staff || staff.pharmacy.deletedAt) {
    throw new ApiError(403, "NOT_STAFF", "You are not authorised for this pharmacy");
  }
  return staff;
}

export function canManageInventory(role: string): boolean {
  return ["OWNER", "PHARMACIST", "MANAGER", "INVENTORY_STAFF"].includes(role);
}
export function canManageStaff(role: string): boolean {
  return role === "OWNER";
}
export function canRecordSales(role: string): boolean {
  return ["OWNER", "PHARMACIST", "MANAGER"].includes(role);
}
