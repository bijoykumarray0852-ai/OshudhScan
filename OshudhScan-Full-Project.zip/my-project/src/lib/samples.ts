// Curated demo prescriptions — these bypass OCR (labeled as such in the UI)
// but run through the exact same brand-matching + safety pipeline.
import type { OcrResult } from "./types";

export interface SampleRx {
  id: string;
  title: string;
  scenario: string;
  doctor: string;
  degrees: string;
  chamber: string;
  reg: string;
  patient: string;
  date: string;
  ocr: OcrResult;
  banglaNote: string; // a Bangla scribble shown on the paper
  expectedHeadline: string;
}

export const SAMPLES: SampleRx[] = [
  {
    id: "sample-a",
    title: "Fever & Gastric",
    scenario: "Common seasonal visit — 4 routine items. Watch the generic savings.",
    doctor: "Dr. Sadia Afrin",
    degrees: "MBBS (DMC), FCPS (Medicine)",
    chamber: "Chamber: Mirpur-10, Dhaka",
    reg: "Reg: A-45812",
    patient: "Mrs. Rahima Begum, 38y, F",
    date: "18-11-2026",
    ocr: {
      doctor: "Dr. Sadia Afrin",
      date: "18-11-2026",
      medicines: [
        { brand_raw: "Napa 500", strength: "500mg", dose: "1+1+1", duration: "5 days" },
        { brand_raw: "Seclo 20", strength: "20mg", dose: "1+0+1", duration: "30 days" },
        { brand_raw: "Alatrol 10", strength: "10mg", dose: "0+0+1", duration: "7 days" },
        { brand_raw: "Neuro-B", strength: null, dose: "1+0+0", duration: "10 days" },
      ],
    },
    banglaNote: "জ্বর কমার পরেও ওষুধ চালিয়ে যান",
    expectedHeadline: "Clean decode · ৳ savings via generics",
  },
  {
    id: "sample-b",
    title: "Infection & Vomiting",
    scenario: "32-year-old with gastritis on antibiotics — two real safety flags.",
    doctor: "Dr. Mahmud Hasan",
    degrees: "MBBS, BCS (Health), MD (Gastro)",
    chamber: "Chamber: Savar New Market",
    reg: "Reg: B-22776",
    patient: "Ms. Tania Akter, 32y, F",
    date: "18-11-2026",
    ocr: {
      doctor: "Dr. Mahmud Hasan",
      date: "18-11-2026",
      medicines: [
        { brand_raw: "Zimax 500", strength: "500mg", dose: "1+0+0", duration: "3 days" },
        { brand_raw: "Amodis 400", strength: "400mg", dose: "1+1+1", duration: "5 days" },
        { brand_raw: "Emistat 8", strength: "8mg", dose: "1+0+1", duration: "2 days" },
        { brand_raw: "Orsaline-N", strength: null, dose: null, duration: null },
      ],
    },
    banglaNote: "ডেন্টাল সংক্রমণ — খাবার স্যালাইন প্রয়োজনে",
    expectedHeadline: "Catches QT interaction + alcohol guard",
  },
  {
    id: "sample-c",
    title: "Chronic Pain (Cardiac Patient)",
    scenario:
      "58-year-old on a blood thinner gets a 15-day NSAID course — the classic near-miss.",
    doctor: "Dr. A. Rahman Chowdhury",
    degrees: "MBBS (DMC), FCPS (Medicine)",
    chamber: "Chamber: Mirpur-10, Dhaka",
    reg: "Reg: A-51234",
    patient: "Md. Kamal Hossain, 58y, M",
    date: "18-11-2026",
    ocr: {
      doctor: "Dr. A. Rahman Chowdhury",
      date: "18-11-2026",
      medicines: [
        { brand_raw: "Warf 5", strength: "5mg", dose: "0+0+1", duration: "30 days" },
        { brand_raw: "Flexi", strength: null, dose: "1+1+1", duration: "15 days" },
        { brand_raw: "Angisartan 50", strength: "50mg", dose: "1+0+1", duration: "30 days" },
        { brand_raw: "Monas 10", strength: "10mg", dose: "0+0+1", duration: "30 days" },
      ],
    },
    banglaNote: "হার্টের রোগী — ইএনও করে আসবেন",
    expectedHeadline: "Blocks a warfarin + NSAID bleed risk",
  },
];

export const SAMPLE_BY_ID: Record<string, SampleRx> = Object.fromEntries(
  SAMPLES.map((s) => [s.id, s])
);
