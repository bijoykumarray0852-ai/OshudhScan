// Client-safe auth types (no server imports — usable from client components).
export type Role = "PATIENT" | "PHARMACY_OWNER" | "PHARMACY_STAFF" | "PHARMACIST" | "ADMIN";

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: Role;
  locale: string;
  largeText: boolean;
  phone: string | null;
}
