import { NextRequest, NextResponse } from "next/server";
import { ZodSchema } from "zod";
import { ApiError } from "@/lib/auth";
import { db } from "@/lib/db";
import { getSessionUser, SessionUser } from "@/lib/auth";

// ── consistent JSON responses ──────────────────────────────────────────────────

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ ok: true, ...(data as object) }, init);
}

export function fail(status: number, code: string, message: string, extra?: Record<string, unknown>) {
  return NextResponse.json({ ok: false, code, error: message, ...extra }, { status });
}

// ── rate limiting (in-memory sliding window; per process) ──────────────────────

const buckets = new Map<string, number[]>();

export function rateLimit(key: string, limit: number, windowMs: number): void {
  const now = Date.now();
  const arr = (buckets.get(key) ?? []).filter((t) => now - t < windowMs);
  if (arr.length >= limit) {
    throw new ApiError(429, "RATE_LIMITED", "Too many requests — please slow down");
  }
  arr.push(now);
  buckets.set(key, arr);
  // opportunistic cleanup
  if (buckets.size > 5000) {
    for (const [k, v] of buckets) if (v.every((t) => now - t > windowMs)) buckets.delete(k);
  }
}

export function clientIp(req: NextRequest): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "local"
  );
}

// ── request parsing / validation ───────────────────────────────────────────────

export async function parseJson<T>(req: NextRequest, schema: ZodSchema<T>): Promise<T> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    throw new ApiError(400, "BAD_JSON", "Request body must be valid JSON");
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    const first = parsed.error.issues[0];
    throw new ApiError(400, "VALIDATION", `${first.path.join(".") || "body"}: ${first.message}`);
  }
  return parsed.data;
}

export function searchParams(req: NextRequest): URLSearchParams {
  return new URL(req.url).searchParams;
}

// ── audit logging (never store clinical content) ───────────────────────────────

export async function audit(
  req: NextRequest,
  opts: { userId?: string | null; action: string; entity: string; entityId?: string; detail?: Record<string, unknown> }
) {
  try {
    await db.auditLog.create({
      data: {
        userId: opts.userId ?? null,
        action: opts.action,
        entity: opts.entity,
        entityId: opts.entityId,
        detail: opts.detail ? JSON.stringify(opts.detail) : undefined,
        ip: clientIp(req),
      },
    });
  } catch {
    // audit logging must never break the request
  }
}

// ── handler wrapper: uniform errors + optional auth/rate limit ─────────────────

type HandlerContext<P, U> = {
  req: NextRequest;
  params: P;
  user: U;
  ip: string;
};

type WithApiOpts = {
  auth?: boolean;
  roles?: SessionUser["role"][];
  rate?: { limit: number; windowMs: number; key?: string };
};

// Optional-auth wrapper: user may be null (route must handle guests).
export function withApi<P = Record<string, string>>(
  handler: (ctx: HandlerContext<P, SessionUser | null>) => Promise<NextResponse> | NextResponse,
  opts: WithApiOpts = {}
) {
  return apiHandler(handler, opts);
}

// Authenticated wrapper: 401 unless signed in; user is guaranteed non-null.
export function withAuthApi<P = Record<string, string>>(
  handler: (ctx: HandlerContext<P, SessionUser>) => Promise<NextResponse> | NextResponse,
  opts: Omit<WithApiOpts, "auth"> & { auth?: true } = {}
) {
  return apiHandler<P, SessionUser>(handler as never, { ...opts, auth: true });
}

function apiHandler<P, U extends SessionUser | null>(
  handler: (ctx: HandlerContext<P, U>) => Promise<NextResponse> | NextResponse,
  opts: WithApiOpts = {}
) {
  return async (req: NextRequest, context?: { params: Promise<P> }) => {
    try {
      const ip = clientIp(req);
      let user: SessionUser | null = null;
      if (opts.auth || opts.roles) {
        user = await getSessionUser();
        if (!user) throw new ApiError(401, "AUTH_REQUIRED", "Sign in required");
        if (opts.roles && !opts.roles.includes(user.role)) {
          throw new ApiError(403, "FORBIDDEN", "Insufficient permissions");
        }
      }
      if (opts.rate) {
        rateLimit(opts.rate.key ?? `${req.method}:${new URL(req.url).pathname}:${ip}`, opts.rate.limit, opts.rate.windowMs);
      }
      const params = (context?.params ? await context.params : ({} as P)) as P;
      return await handler({ req, params, user: user as U, ip });
    } catch (err) {
      if (err instanceof ApiError) {
        return fail(err.status, err.code, err.message);
      }
      console.error("[api]", req.method, new URL(req.url).pathname, err instanceof Error ? err.message : err);
      return fail(500, "INTERNAL", "Something went wrong. Please try again.");
    }
  };
}

// ── pagination helper ──────────────────────────────────────────────────────────

export function pageArgs(sp: URLSearchParams, defaultSize = 20) {
  const page = Math.max(1, Number(sp.get("page") ?? 1) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(sp.get("pageSize") ?? defaultSize) || defaultSize));
  return { skip: (page - 1) * pageSize, take: pageSize, page, pageSize };
}
