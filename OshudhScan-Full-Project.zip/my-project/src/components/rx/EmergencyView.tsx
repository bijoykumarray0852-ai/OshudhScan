"use client";
// Emergency Hospital Finder — a deliberately different interface from the
// general directory search: red critical design, one-tap national hotlines,
// GPS-nearest emergency hospitals with distance, one-tap calling and route
// links. Manual district fallback when GPS is refused. Works offline for
// hotlines (static verified data) — never invents numbers or facilities.
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Siren, Phone, Navigation, MapPin, Map as MapIcon, ListFilter, AlertTriangle,
  Building2, Hospital, Loader2, Clock3,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useI18n } from "@/hooks/use-i18n";
import {
  apiFetch, ApiClientError, EmptyState, LoadingCards, ErrorNote,
  LocationPicker, DistanceLabel, type LocationSel,
} from "@/components/rx/shared";
import {
  MapCanvas, VerificationBadge, FacilityPlaceLabel, ReportDialog, type MapMarker,
} from "@/components/rx/directory-ui";
import { LiteModeSuggestBanner, LiteMapPlaceholder } from "@/components/rx/lite-ui";
import { useLiteMode } from "@/lib/lite";
import { DISTANCE_FILTERS, formatDistance } from "@/lib/geo";
import { googleMapsDirectionsUrl } from "@/lib/directory";
import { EMERGENCY_SERVICES } from "@/lib/data/emergency";
import type { FacilityRow } from "@/lib/directory-server";

export function EmergencyView() {
  const { t, locale } = useI18n();
  const { liteMode } = useLiteMode();
  const [liteMapOpen, setLiteMapOpen] = useState(false);
  const [showMap, setShowMap] = useState(false);

  const [geo, setGeo] = useState<{ lat: number; lng: number } | null>(null);
  const [geoState, setGeoState] = useState<"idle" | "locating" | "ok" | "denied">("idle");
  const [loc, setLoc] = useState<LocationSel>({});
  const [radius, setRadius] = useState(10);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rows, setRows] = useState<FacilityRow[]>([]);
  const [searched, setSearched] = useState(false);

  const [details, setDetails] = useState<FacilityRow | null>(null);
  const [reporting, setReporting] = useState<FacilityRow | null>(null);

  const origin = geo ?? (loc.lat && loc.lng ? { lat: loc.lat, lng: loc.lng } : null);

  const findNearby = useCallback(async () => {
    // division-only pick has no coordinates — tell the user instead of doing
    // nothing silently
    if (!origin) {
      setError(t("emergency.noOrigin"));
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        lat: String(origin.lat),
        lng: String(origin.lng),
        radius: String(radius),
        type: "HOSPITAL",
        emergency: "1",
      });
      const res = await apiFetch<{ facilities: FacilityRow[] }>(`/api/facilities/nearby?${params}`);
      setRows(res.facilities);
      setSearched(true);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setLoading(false);
    }
  }, [origin, radius, t]);

  // auto-search once GPS lands
  useEffect(() => {
    if (geo) void findNearby();
  }, [geo, findNearby]);

  // re-search when radius changes (only if an origin exists)
  useEffect(() => {
    if (origin && searched) void findNearby();
  }, [radius]);

  const locateMe = () => {
    if (!("geolocation" in navigator)) {
      setGeoState("denied");
      return;
    }
    setGeoState("locating");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeo({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGeoState("ok");
        setLoc({});
      },
      () => setGeoState("denied"),
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 120000 }
    );
  };

  const markers: MapMarker[] = useMemo(
    () => rows
      .filter((r) => r.lat != null && r.lng != null)
      .slice(0, 25)
      .map((r) => ({
        id: r.id, lat: r.lat as number, lng: r.lng as number,
        label: locale === "bn" && r.nameBangla ? r.nameBangla : r.name,
        kind: "HOSPITAL", phone: r.phone,
        href: origin ? googleMapsDirectionsUrl(r.lat as number, r.lng as number, origin) : r.mapsSearchUrl,
      })),
    [rows, locale, origin]
  );

  const nearest = rows[0] ?? null;

  return (
    <div className="emergency-view">
      {/* critical header — intentionally louder than normal pages */}
      <div className="mb-6 rounded-2xl border border-red-200 bg-gradient-to-br from-red-50 to-white p-4 md:p-5">
        <div className="flex items-start gap-3">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-red-600 text-white shadow-soft">
            <Siren className="h-6 w-6" />
          </span>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-red-700">{t("emergency.eyebrow")}</p>
            <h1 className="text-xl font-bold tracking-tight text-red-900 md:text-2xl">{t("emergency.title")}</h1>
            <p className="mt-1 max-w-2xl text-sm leading-relaxed text-red-800/80">{t("emergency.subtitle")}</p>
          </div>
        </div>
      </div>

      {/* national hotlines — one-tap call cards, always on top */}
      <section aria-label={t("emergency.hotlines")} className="mb-6">
        <h2 className="mb-2.5 flex items-center gap-2 text-sm font-semibold text-red-900">
          <Phone className="h-4 w-4 text-red-600" /> {t("emergency.hotlines")}
        </h2>
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
          {EMERGENCY_SERVICES.map((s) => (
            <a
              key={s.phone}
              href={`tel:${s.phone}`}
              className="group flex flex-col justify-between gap-1 rounded-xl border border-red-200 bg-white p-3 shadow-soft transition-colors hover:border-red-400 hover:bg-red-50"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-lg font-extrabold tracking-tight text-red-700">{s.phone}</span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-red-600 text-white transition-transform group-hover:scale-105" aria-hidden>
                  <Phone className="h-4 w-4" />
                </span>
              </div>
              <div className="min-w-0">
                <p className="truncate text-xs font-semibold">{locale === "bn" ? s.nameBangla : s.name}</p>
                <p className="truncate text-[11px] leading-snug text-muted-foreground">
                  {locale === "bn" ? s.descriptionBangla : s.description}
                </p>
              </div>
            </a>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">{t("emergency.hotlinesNote")}</p>
      </section>

      {/* nearest finder — one tap */}
      <section aria-label={t("emergency.finder")} className="mb-6">
        <Card className="p-4 shadow-soft">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-sm font-semibold">{t("emergency.finder")}</p>
              <p className="text-xs text-muted-foreground">{t("emergency.finderHint")}</p>
            </div>
            <Button
              size="lg"
              className="min-h-[48px] bg-red-600 text-white hover:bg-red-700"
              onClick={locateMe}
              disabled={geoState === "locating"}
            >
              {geoState === "locating" ? (
                <><Loader2 className="h-5 w-5 animate-spin" /> {t("common.locating")}</>
              ) : (
                <><MapPin className="h-5 w-5" /> {t("emergency.findNearby")}</>
              )}
            </Button>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="text-xs text-muted-foreground">{t("find.radius")}</span>
            {DISTANCE_FILTERS.map((d) => (
              <Button key={d} size="sm" variant={radius === d ? "default" : "outline"} className={`h-8 px-2.5 ${radius === d ? "bg-red-600 hover:bg-red-700" : ""}`} onClick={() => setRadius(d)}>
                {d} {t("common.km")}
              </Button>
            ))}
          </div>

          {/* manual fallback when GPS refused */}
          <div className="mt-3 rounded-lg border border-dashed border-muted-foreground/30 p-3">
            <p className="mb-1.5 text-xs font-medium text-muted-foreground">{t("emergency.manualFallback")}</p>
            <LocationPicker value={loc} onChange={setLoc} />
            {loc.district && (
              <Button size="sm" variant="outline" className="mt-2" onClick={() => void findNearby()}>
                {t("emergency.searchThisArea")}
              </Button>
            )}
          </div>

          {geoState === "denied" && (
            <p className="mt-2 text-xs text-destructive">{t("emergency.gpsDenied")}</p>
          )}
        </Card>
      </section>

      <LiteModeSuggestBanner />

      {error && <ErrorNote message={error} onRetry={() => void findNearby()} />}

      {/* nearest-first results */}
      {loading ? (
        <LoadingCards count={3} />
      ) : rows.length === 0 ? (
        searched ? (
          <EmptyState
            title={t("emergency.noneNear")}
            hint={t("emergency.noneNearHint")}
            action={
              <Button className="bg-red-600 hover:bg-red-700" onClick={() => setRadius(50)}>
                {t("emergency.widenRadius")}
              </Button>
            }
          />
        ) : (
          <EmptyState title={t("emergency.idleTitle")} hint={t("emergency.idleHint")} icon={<Siren className="h-5 w-5" />} />
        )
      ) : (
        <>
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <p className="text-sm text-muted-foreground">
              {t("emergency.results", { n: rows.length })}
              {origin && (
                <span className="ml-1">
                  · {t("emergency.straightLine")}
                </span>
              )}
            </p>
            <Button size="sm" variant="outline" onClick={() => setShowMap((v) => !v)}>
              {showMap ? <><ListFilter className="h-3.5 w-3.5 mr-1" />{t("find.listView")}</> : <><MapIcon className="h-3.5 w-3.5 mr-1" />{t("find.mapView")}</>}
            </Button>
          </div>

          {showMap && (
            liteMode && !liteMapOpen ? (
              <LiteMapPlaceholder onLoad={() => setLiteMapOpen(true)} />
            ) : (
              <MapCanvas
                center={origin ?? { lat: markers[0]?.lat ?? 23.8103, lng: markers[0]?.lng ?? 90.4125 }}
                markers={markers}
                height={380}
                className="mb-4"
              />
            )
          )}

          {/* route strip for the single nearest hospital */}
          {nearest && nearest.lat != null && nearest.lng != null && (
            <Card className="mb-3 flex flex-col gap-2 border-red-200 bg-red-50/60 p-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-2.5">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-600 text-white">
                  <Hospital className="h-4.5 w-4.5" />
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-medium text-red-700">{t("emergency.nearestStrip")}</p>
                  <p className="truncate text-sm font-semibold">
                    {locale === "bn" && nearest.nameBangla ? nearest.nameBangla : nearest.name}
                  </p>
                  {nearest.distanceKm !== null && (
                    <p className="text-xs text-muted-foreground">{formatDistance(nearest.distanceKm)} · {t("emergency.straightLineShort")}</p>
                  )}
                </div>
              </div>
              <div className="flex shrink-0 gap-2">
                {nearest.phone && (
                  <Button asChild className="min-h-[44px] bg-red-600 hover:bg-red-700">
                    <a href={`tel:${nearest.phone}`}><Phone className="h-4 w-4 mr-1" />{t("emergency.callNow")}</a>
                  </Button>
                )}
                <Button asChild variant="outline" className="min-h-[44px]">
                  <a href={googleMapsDirectionsUrl(nearest.lat, nearest.lng, origin)} target="_blank" rel="noreferrer">
                    <Navigation className="h-4 w-4 mr-1" />{t("common.directions")}
                  </a>
                </Button>
              </div>
            </Card>
          )}

          <div className="grid gap-3 md:grid-cols-2">
            {rows.map((f) => (
              <Card key={f.id} className="card-hover p-4 shadow-soft">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold leading-snug">
                      <span className="mr-1.5 inline-flex h-6 w-6 items-center justify-center rounded-lg bg-red-50 text-red-700">
                        <Building2 className="h-4 w-4" />
                      </span>
                      {locale === "bn" && f.nameBangla ? f.nameBangla : f.name}
                    </p>
                    <p className="mt-0.5 text-sm text-muted-foreground">{f.addressLine}</p>
                    <div className="mt-1"><FacilityPlaceLabel division={f.division} district={f.district} upazila={f.upazila} area={f.area} /></div>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1.5">
                    <VerificationBadge status={f.verificationStatus} />
                    {f.distanceKm !== null && <DistanceLabel km={f.distanceKm} />}
                  </div>
                </div>

                <div className="mt-2 flex flex-wrap items-center gap-2">
                  {f.hospitalCategory && <Badge variant="secondary" className="font-medium">{t(`directory.cat.${f.hospitalCategory}`)}</Badge>}
                  {f.ownership && <Badge variant="outline" className="text-xs">{t(`directory.own.${f.ownership}`)}</Badge>}
                  {f.openingHours && (
                    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground"><Clock3 className="h-3 w-3" /> {f.openingHours}</span>
                  )}
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  {f.phone && (
                    <Button size="sm" className="min-h-[40px] bg-red-600 hover:bg-red-700" asChild>
                      <a href={`tel:${f.phone}`}><Phone className="h-4 w-4 mr-1" />{t("emergency.callNow")}</a>
                    </Button>
                  )}
                  {f.emergencyPhone && (
                    <Button size="sm" variant="outline" className="min-h-[40px] border-red-300 text-red-700 hover:bg-red-50" asChild>
                      <a href={`tel:${f.emergencyPhone}`}><Siren className="h-4 w-4 mr-1" />{f.emergencyPhone}</a>
                    </Button>
                  )}
                  {f.lat != null && f.lng != null && (
                    <Button size="sm" variant="outline" className="min-h-[40px]" asChild>
                      <a href={googleMapsDirectionsUrl(f.lat, f.lng, origin)} target="_blank" rel="noreferrer">
                        <Navigation className="h-4 w-4 mr-1" />{t("common.directions")}
                      </a>
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => setDetails(f)}>{t("common.details")}</Button>
                  <Button size="sm" variant="ghost" className="text-amber-700 hover:text-amber-800" onClick={() => setReporting(f)}>
                    <AlertTriangle className="h-3.5 w-3.5 mr-1" />{t("directory.report")}
                  </Button>
                </div>
                {!f.phone && (
                  <p className="mt-2 text-xs text-muted-foreground">{t("directory.phoneUnavailable")} · {t("emergency.noPhoneHint")}</p>
                )}
              </Card>
            ))}
          </div>
        </>
      )}

      {/* details dialog */}
      <Dialog open={Boolean(details)} onOpenChange={(o) => (o ? undefined : setDetails(null))}>
        <DialogContent className="sm:max-w-lg">
          {details && (
            <>
              <DialogHeader>
                <DialogTitle>{locale === "bn" && details.nameBangla ? details.nameBangla : details.name}</DialogTitle>
                <DialogDescription>{details.addressLine}</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 text-sm">
                <div className="flex flex-wrap gap-2">
                  <VerificationBadge status={details.verificationStatus} />
                  {details.hospitalCategory && <Badge variant="secondary">{t(`directory.cat.${details.hospitalCategory}`)}</Badge>}
                  {details.ownership && <Badge variant="outline">{t(`directory.own.${details.ownership}`)}</Badge>}
                  {details.distanceKm !== null && <DistanceLabel km={details.distanceKm} />}
                </div>
                {details.phone && (
                  <Button className="w-full min-h-[46px] bg-red-600 hover:bg-red-700" asChild>
                    <a href={`tel:${details.phone}`}><Phone className="h-4 w-4 mr-2" />{t("emergency.callNow")} · {details.phone}</a>
                  </Button>
                )}
                {details.emergencyPhone && (
                  <Button className="w-full min-h-[46px] border-red-300 text-red-700 hover:bg-red-50" variant="outline" asChild>
                    <a href={`tel:${details.emergencyPhone}`}><Siren className="h-4 w-4 mr-2" />{t("directory.emergencyPhone")}: {details.emergencyPhone}</a>
                  </Button>
                )}
                {details.lat != null && details.lng != null && (
                  <Button className="w-full" variant="outline" asChild>
                    <a href={googleMapsDirectionsUrl(details.lat, details.lng, origin)} target="_blank" rel="noreferrer">
                      <Navigation className="h-4 w-4 mr-2" />{t("common.directions")}
                    </a>
                  </Button>
                )}
                {details.services.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {details.services.map((s) => <Badge key={s} variant="secondary" className="font-normal">{s.replace(/_/g, " ")}</Badge>)}
                  </div>
                )}
                <div className="rounded-lg bg-muted/60 p-3 text-xs leading-relaxed text-muted-foreground">
                  <p><span className="font-medium">{t("common.dataSource")}:</span> {details.source}</p>
                </div>
                <Button size="sm" variant="ghost" className="w-full text-amber-700" onClick={() => { setReporting(details); setDetails(null); }}>
                  <AlertTriangle className="h-3.5 w-3.5 mr-1" />{t("directory.report")}
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <ReportDialog
        entityType="FACILITY"
        entityId={reporting?.id ?? ""}
        entityName={reporting ? (locale === "bn" && reporting.nameBangla ? reporting.nameBangla : reporting.name) : ""}
        open={Boolean(reporting)}
        onOpenChange={(o) => (o ? undefined : setReporting(null))}
      />
    </div>
  );
}
