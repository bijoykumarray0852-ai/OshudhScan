"use client";
// National Healthcare Directory — hospital / clinic / diagnostic finder.
// Division → District → Upazila dependent search, category chips, ownership
// and emergency filters, list + map views, honest phone/verification display,
// Google Maps directions links and a public report dialog.
import { useCallback, useEffect, useState } from "react";
import { Hospital, Search, Phone, Navigation, Map as MapIcon, ListFilter, Building2, Stethoscope, FlaskConical, Siren, Globe, RefreshCcw, AlertTriangle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useI18n } from "@/hooks/use-i18n";
import { apiFetch, ApiClientError, PageHeader, EmptyState, LoadingCards, ErrorNote, fmtDate } from "@/components/rx/shared";
import {
  MapCanvas, MapMarker, VerificationBadge, PhoneLine, ReportDialog,
  DependentLocationSelects, CategoryChips, useDependentLocations, MapsLinkButton, FacilityPlaceLabel,
} from "@/components/rx/directory-ui";
import { LiteModeSuggestBanner } from "@/components/rx/lite-ui";
import type { FacilityRow } from "@/lib/directory-server";

interface DirectoryResp {
  page: number; pageSize: number; total: number;
  hospitals?: FacilityRow[]; clinics?: FacilityRow[]; diagnostics?: FacilityRow[];
  facilities?: FacilityRow[];
}

const CATEGORY_KEYS = ["MEDICAL_COLLEGE", "DISTRICT_HOSPITAL", "GENERAL_HOSPITAL", "UPAZILA_HEALTH_COMPLEX", "SPECIALIZED", "OTHER"] as const;

function kindIcon(kind: string | null) {
  if (kind === "DIAGNOSTIC") return <FlaskConical className="h-4 w-4" />;
  if (kind === "CLINIC") return <Stethoscope className="h-4 w-4" />;
  return <Building2 className="h-4 w-4" />;
}

export function DirectoryView() {
  const { t, locale } = useI18n();
  const loc = useDependentLocations();

  const [tab, setTab] = useState<"HOSPITAL" | "CLINIC" | "DIAGNOSTIC">("HOSPITAL");
  const [q, setQ] = useState("");
  const [category, setCategory] = useState<string | null>(null);
  const [ownership, setOwnership] = useState<string | null>(null);
  const [emergencyOnly, setEmergencyOnly] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [details, setDetails] = useState<FacilityRow | null>(null);
  const [reporting, setReporting] = useState<FacilityRow | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [rows, setRows] = useState<FacilityRow[]>([]);
  const [total, setTotal] = useState(0);

  const search = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (q) params.set("q", q);
      if (loc.sel.division) params.set("division", loc.sel.division);
      if (loc.sel.district) params.set("district", loc.sel.district);
      if (loc.sel.upazila) params.set("upazila", loc.sel.upazila);
      if (tab === "HOSPITAL" && category) params.set("category", category);
      if (ownership) params.set("ownership", ownership);
      if (emergencyOnly) params.set("emergency", "1");
      const path = tab === "HOSPITAL" ? "hospitals" : tab === "CLINIC" ? "clinics" : "diagnostics";
      const res = await apiFetch<DirectoryResp>(`/api/directory/${path}?${params}`);
      const list = res.hospitals ?? res.clinics ?? res.diagnostics ?? res.facilities ?? [];
      setRows(list);
      setTotal(res.total);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setLoading(false);
    }
  }, [q, loc.sel, category, ownership, emergencyOnly, tab, t]);

  useEffect(() => { void search(); }, [tab, loc.sel, category, ownership, emergencyOnly]);

  // place label prefers the Bangla name of the selected location when the
  // UI is in Bangla (selection values are the English BBS names)
  const bnName = (list: Array<{ name: string; nameBangla: string | null }>, name?: string) =>
    locale === "bn" ? list.find((x) => x.name === name)?.nameBangla ?? name : name;
  const searchLabel = [
    bnName(loc.upazilas, loc.sel.upazila),
    bnName(loc.districts, loc.sel.district),
    bnName(loc.divisions, loc.sel.division),
  ].filter(Boolean).join(", ") || t("directory.wholeBangladesh");
  const markers: MapMarker[] = rows
    .filter((r) => r.lat != null && r.lng != null)
    .map((r) => ({ id: r.id, lat: r.lat as number, lng: r.lng as number, label: locale === "bn" && r.nameBangla ? r.nameBangla : r.name, kind: r.type, href: r.mapsSearchUrl }));

  return (
    <>
      <PageHeader
        title={t("directory.title")}
        subtitle={t("directory.subtitle")}
        icon={<Hospital className="h-6 w-6" />}
        eyebrow={t("directory.eyebrow")}
      />

      <LiteModeSuggestBanner />

      {/* search card */}
      <Card className="p-4 mb-5 space-y-3 shadow-soft">
        <div className="flex gap-2">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("directory.searchPlaceholder")}
            aria-label={t("directory.searchPlaceholder")}
            onKeyDown={(e) => e.key === "Enter" && void search()}
          />
          <Button onClick={() => void search()} aria-label={t("common.search")}>
            <Search className="h-4 w-4" />
          </Button>
        </div>

        <DependentLocationSelects
          sel={loc.sel}
          divisions={loc.divisions}
          districts={loc.districts}
          upazilas={loc.upazilas}
          onDivision={(v) => void loc.pickDivision(v)}
          onDistrict={(v) => void loc.pickDistrict(loc.sel.division, v)}
          onUpazila={(v) => loc.pickUpazila(loc.sel.division, loc.sel.district, v)}
        />

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex gap-1.5">
            {(["HOSPITAL", "CLINIC", "DIAGNOSTIC"] as const).map((k) => (
              <Button key={k} size="sm" variant={tab === k ? "default" : "outline"} className="h-8" onClick={() => setTab(k)}>
                {t(`directory.kind.${k}`)}
              </Button>
            ))}
          </div>
          {tab === "HOSPITAL" && (
            <Button size="sm" variant={emergencyOnly ? "default" : "outline"} className={`h-8 ${emergencyOnly ? "bg-red-600 hover:bg-red-700" : ""}`} onClick={() => setEmergencyOnly((v) => !v)}>
              <Siren className="h-3.5 w-3.5 mr-1" /> {t("directory.emergencyOnly")}
            </Button>
          )}
          <Button size="sm" variant="outline" className="h-8" onClick={() => setShowMap((v) => !v)}>
            {showMap ? <><ListFilter className="h-3.5 w-3.5 mr-1" />{t("find.listView")}</> : <><MapIcon className="h-3.5 w-3.5 mr-1" />{t("find.mapView")}</>}
          </Button>
        </div>

        {tab === "HOSPITAL" && (
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-muted-foreground">{t("directory.category")}:</span>
            {CATEGORY_KEYS.map((c) => (
              <button
                key={c}
                onClick={() => setCategory(category === c ? null : c)}
                className={`rounded-full border px-2.5 py-1 text-xs font-medium transition-colors ${
                  category === c ? "border-transparent bg-teal-600 text-white" : "text-muted-foreground hover:border-teal-300 hover:text-teal-800"
                }`}
              >
                {t(`directory.cat.${c}`)}
              </button>
            ))}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">{t("directory.ownership")}:</span>
            {["PUBLIC", "PRIVATE", "NGO"].map((o) => (
              <button
                key={o}
                onClick={() => setOwnership(ownership === o ? null : o)}
                className={`rounded-full border px-2.5 py-1 text-xs font-medium transition-colors ${
                  ownership === o ? "border-transparent bg-emerald-600 text-white" : "text-muted-foreground hover:border-emerald-300 hover:text-emerald-800"
                }`}
              >
                {t(`directory.own.${o}`)}
              </button>
            ))}
          </div>
          <Button size="sm" variant="ghost" className="h-8" onClick={() => void search()}>
            <RefreshCcw className="h-3.5 w-3.5 mr-1" /> {t("common.search")}
          </Button>
        </div>
      </Card>

      {error && <ErrorNote message={error} onRetry={search} />}

      <p className="text-sm text-muted-foreground mb-3">
        {t("directory.showingFor", { place: searchLabel })} · {total} {t("common.results")}
      </p>

      {loading ? (
        <LoadingCards count={4} />
      ) : showMap ? (
        markers.length ? (
          <MapCanvas center={markers.length ? { lat: markers[0].lat, lng: markers[0].lng } : { lat: 23.8103, lng: 90.4125 }} markers={markers} height={460} />
        ) : (
          <EmptyState title={t("common.noResults")} hint={t("directory.noMapData")} icon={<MapIcon className="h-5 w-5" />} />
        )
      ) : rows.length === 0 ? (
        <EmptyState title={t("directory.noResults")} hint={t("directory.noResultsHint")} />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {rows.map((f) => (
            <Card key={f.id} className="card-hover p-4 shadow-soft">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-semibold leading-snug">
                    <span className="mr-1.5 inline-flex h-6 w-6 items-center justify-center rounded-lg bg-teal-50 text-teal-700">{kindIcon(f.type)}</span>
                    {locale === "bn" && f.nameBangla ? f.nameBangla : f.name}
                  </p>
                  <p className="mt-0.5 text-sm text-muted-foreground">{f.addressLine}</p>
                  <div className="mt-1"><FacilityPlaceLabel division={f.division} district={f.district} upazila={f.upazila} area={f.area} /></div>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1.5">
                  <VerificationBadge status={f.verificationStatus} />
                  {f.emergency && (
                    <Badge className="bg-red-600 text-white gap-1"><Siren className="h-3 w-3" /> {t("directory.emergency")}</Badge>
                  )}
                </div>
              </div>

              <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1.5">
                {f.hospitalCategory && tab === "HOSPITAL" && (
                  <Badge variant="secondary" className="font-medium">{t(`directory.cat.${f.hospitalCategory}`)}</Badge>
                )}
                {f.ownership && (
                  <Badge variant="outline" className="text-xs">{t(`directory.own.${f.ownership}`)}</Badge>
                )}
                {f.distanceKm !== null && (
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground"><Navigation className="h-3 w-3" /> {f.distanceKm} {t("common.km")}</span>
                )}
                {f.qualityScore !== null && (
                  <span className="text-xs text-muted-foreground">{t("directory.quality")}: {f.qualityScore}/100</span>
                )}
              </div>

              <div className="mt-2 flex flex-col gap-1.5">
                <PhoneLine phone={f.phone} isPhoneVerified={f.isPhoneVerified} />
                {f.emergencyPhone && (
                  <span className="inline-flex items-center gap-1 text-sm">
                    <Siren className="h-3.5 w-3.5 text-red-600" />
                    <a href={`tel:${f.emergencyPhone}`} className="font-medium text-red-700">{f.emergencyPhone}</a>
                    <span className="text-[11px] text-muted-foreground">({t("directory.emergencyPhone")})</span>
                  </span>
                )}
                {f.website && (
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                    <Globe className="h-3 w-3" />
                    <a href={f.website} target="_blank" rel="noreferrer" className="truncate hover:underline">{f.website.replace(/^https?:\/\//, "")}</a>
                  </span>
                )}
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                {f.phone ? (
                  <Button size="sm" variant="outline" asChild>
                    <a href={`tel:${f.phone}`}><Phone className="h-3.5 w-3.5 mr-1" />{t("common.call")}</a>
                  </Button>
                ) : null}
                <MapsLinkButton href={f.mapsSearchUrl} label={t("common.openInMaps")} />
                {f.mapsDirectionsUrl && <MapsLinkButton href={f.mapsDirectionsUrl} label={t("common.directions")} />}
                <Button size="sm" variant="ghost" onClick={() => setDetails(f)}>{t("common.details")}</Button>
                <Button size="sm" variant="ghost" className="text-amber-700 hover:text-amber-800" onClick={() => setReporting(f)}>
                  <AlertTriangle className="h-3.5 w-3.5 mr-1" />{t("directory.report")}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* details dialog */}
      <Dialog open={Boolean(details)} onOpenChange={(o) => (o ? undefined : setDetails(null))}>
        <DialogContent className="sm:max-w-lg">
          {details && (
            <>
              <DialogHeader>
                <DialogTitle>{locale === "bn" && details.nameBangla ? details.nameBangla : details.name}</DialogTitle>
                <DialogDescription>{details.addressLine}</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 text-sm">
                <div className="flex flex-wrap gap-2">
                  <VerificationBadge status={details.verificationStatus} />
                  {details.hospitalCategory && <Badge variant="secondary">{t(`directory.cat.${details.hospitalCategory}`)}</Badge>}
                  {details.ownership && <Badge variant="outline">{t(`directory.own.${details.ownership}`)}</Badge>}
                  {details.emergency && <Badge className="bg-red-600 text-white gap-1"><Siren className="h-3 w-3" />{t("directory.emergency")}</Badge>}
                </div>
                <PhoneLine phone={details.phone} isPhoneVerified={details.isPhoneVerified} />
                {details.email && <p className="text-sm"><span className="text-muted-foreground">{t("directory.email")}:</span> {details.email}</p>}
                {details.openingHours && (
                  <p className="inline-flex items-center gap-1 text-sm"><Clock className="h-3.5 w-3.5 text-muted-foreground" /> {details.openingHours}</p>
                )}
                {details.services.length > 0 && (
                  <div>
                    <p className="mb-1 text-xs font-medium text-muted-foreground">{t("directory.services")}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {details.services.map((s) => <Badge key={s} variant="secondary" className="font-normal">{s.replace(/_/g, " ")}</Badge>)}
                    </div>
                  </div>
                )}
                {details.specialties.length > 0 && (
                  <div>
                    <p className="mb-1 text-xs font-medium text-muted-foreground">{t("directory.specialties")}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {details.specialties.map((s) => <Badge key={s} variant="outline" className="font-normal">{s}</Badge>)}
                    </div>
                  </div>
                )}
                {details.lat != null && details.lng != null && (
                  <MapCanvas center={{ lat: details.lat, lng: details.lng }} markers={[{ id: details.id, lat: details.lat, lng: details.lng, label: details.name, kind: details.type, href: details.mapsSearchUrl }]} zoom={15} height={220} />
                )}
                <div className="rounded-lg bg-muted/60 p-3 text-xs leading-relaxed text-muted-foreground space-y-1">
                  <p><span className="font-medium">{t("common.dataSource")}:</span> {details.source}</p>
                  {details.sourceUrl && <p><a href={details.sourceUrl} target="_blank" rel="noreferrer" className="text-emerald-700 hover:underline">{details.sourceUrl}</a></p>}
                  <p>{t("directory.lastVerified")}: {fmtDate(details.lastVerifiedAt, locale)}</p>
                  <p>{t("directory.quality")}: {details.qualityScore}/100</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {details.phone && (
                    <Button size="sm" asChild><a href={`tel:${details.phone}`}><Phone className="h-3.5 w-3.5 mr-1" />{t("common.call")}</a></Button>
                  )}
                  <MapsLinkButton href={details.mapsSearchUrl} label={t("common.openInMaps")} />
                  <Button size="sm" variant="ghost" className="ml-auto text-amber-700" onClick={() => { setReporting(details); setDetails(null); }}>
                    <AlertTriangle className="h-3.5 w-3.5 mr-1" />{t("directory.report")}
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* report dialog */}
      <ReportDialog
        entityType="FACILITY"
        entityId={reporting?.id ?? ""}
        entityName={reporting ? (locale === "bn" && reporting.nameBangla ? reporting.nameBangla : reporting.name) : ""}
        open={Boolean(reporting)}
        onOpenChange={(o) => (o ? undefined : setReporting(null))}
      />
    </>
  );
}
