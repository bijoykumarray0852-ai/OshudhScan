"use client";
// National Healthcare Coverage Dashboard — how many hospitals, clinics,
// diagnostics and pharmacies are listed per district, which divisions are well
// covered, and which areas still have little data (honest counts, no padding).
import { useCallback, useEffect, useMemo, useState } from "react";
import { BarChart3, Hospital, Stethoscope, FlaskConical, Pill, Siren, Layers, Search, AlertTriangle, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useI18n } from "@/hooks/use-i18n";
import { apiFetch, ApiClientError, PageHeader, StatCard, EmptyState, LoadingCards, ErrorNote } from "@/components/rx/shared";
import { LiteModeSuggestBanner } from "@/components/rx/lite-ui";

interface DistrictRow {
  district: string;
  districtBangla: string | null;
  division: string | null;
  hospital: number;
  clinic: number;
  diagnostic: number;
  pharmacy: number;
  emergency: number;
  total: number;
  level: "EMPTY" | "MINIMAL" | "LOW" | "MEDIUM" | "HIGH";
}
interface DivisionRow {
  division: string;
  divisionBangla: string | null;
  districts: number;
  hospital: number;
  clinic: number;
  diagnostic: number;
  pharmacy: number;
  total: number;
  level: DistrictRow["level"];
}
interface CoverageResp {
  national: {
    hospital: number; clinic: number; diagnostic: number; pharmacy: number;
    emergency: number; total: number; districtsTracked: number; districtsWithData: number;
  };
  divisions: DivisionRow[];
  districts: DistrictRow[];
  lowCoverage: DistrictRow[];
}

const LEVEL_STYLES: Record<DistrictRow["level"], string> = {
  HIGH: "bg-emerald-600 text-white",
  MEDIUM: "bg-teal-500 text-white",
  LOW: "bg-amber-500 text-white",
  MINIMAL: "bg-orange-500 text-white",
  EMPTY: "bg-red-600 text-white",
};

function LevelPill({ level }: { level: DistrictRow["level"] }) {
  const { t } = useI18n();
  return <Badge className={`font-medium ${LEVEL_STYLES[level]}`}>{t(`coverage.level.${level}`)}</Badge>;
}

function LevelMeter({ total, max }: { total: number; max: number }) {
  const pct = Math.max(4, Math.round((total / Math.max(1, max)) * 100));
  return (
    <div className="h-1.5 w-full min-w-[64px] max-w-[120px] overflow-hidden rounded-full bg-muted" aria-hidden>
      <div className={`h-full rounded-full ${LEVEL_STYLES[total === 0 ? "EMPTY" : total <= 3 ? "MINIMAL" : total <= 11 ? "LOW" : total <= 39 ? "MEDIUM" : "HIGH"].split(" ")[0]}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function CoverageView() {
  const { t, locale } = useI18n();
  const [data, setData] = useState<CoverageResp | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [q, setQ] = useState("");
  const [division, setDivision] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<"district" | "total">("total");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<CoverageResp>("/api/directory/coverage");
      setData(res);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => { void load(); }, [load]);

  const name = (d: { district: string; districtBangla: string | null }) =>
    locale === "bn" && d.districtBangla ? d.districtBangla : d.district;

  const divName = (d: DivisionRow) => (locale === "bn" && d.divisionBangla ? d.divisionBangla : d.division);

  const maxTotal = useMemo(() => Math.max(1, ...(data?.districts.map((d) => d.total) ?? [1])), [data]);

  const filtered = useMemo(() => {
    if (!data) return [];
    let rows = data.districts;
    if (division) rows = rows.filter((d) => d.division === division);
    if (q.trim()) {
      const needle = q.trim().toLowerCase();
      rows = rows.filter((d) =>
        d.district.toLowerCase().includes(needle) ||
        (d.districtBangla ?? "").includes(q.trim())
      );
    }
    return sortBy === "total" ? [...rows].sort((a, b) => b.total - a.total) : [...rows].sort((a, b) => a.district.localeCompare(b.district));
  }, [data, q, division, sortBy]);

  const divOptions = useMemo(() => (data ? Array.from(new Set(data.districts.map((d) => d.division).filter(Boolean) as string[])) : []), [data]);

  return (
    <>
      <PageHeader
        title={t("coverage.title")}
        subtitle={t("coverage.subtitle")}
        eyebrow={t("coverage.eyebrow")}
        icon={<BarChart3 className="h-6 w-6" />}
      />

      <LiteModeSuggestBanner />
      {error && <ErrorNote message={error} onRetry={load} />}
      {loading && <LoadingCards count={6} />}

      {data && !loading && (
        <div className="space-y-6">
          {/* national summary */}
          <section aria-label={t("coverage.national")} className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            <StatCard label={t("directory.kind.HOSPITAL")} value={data.national.hospital.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")} icon={<Hospital className="h-4 w-4" />} tone="brand" />
            <StatCard label={t("directory.kind.CLINIC")} value={data.national.clinic.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")} icon={<Stethoscope className="h-4 w-4" />} />
            <StatCard label={t("directory.kind.DIAGNOSTIC")} value={data.national.diagnostic.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")} icon={<FlaskConical className="h-4 w-4" />} />
            <StatCard label={t("directory.kind.PHARMACY")} value={data.national.pharmacy.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")} icon={<Pill className="h-4 w-4" />} tone="brand" />
            <StatCard label={t("coverage.emergencyReady")} value={data.national.emergency.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")} icon={<Siren className="h-4 w-4" />} tone="danger" />
            <StatCard
              label={t("coverage.districtsWithData")}
              value={`${data.national.districtsWithData}/${data.national.districtsTracked}`}
              icon={<Layers className="h-4 w-4" />}
              hint={t("coverage.districtsHint")}
            />
          </section>

          {/* divisions */}
          <section aria-label={t("coverage.divisions")}>
            <h2 className="mb-3 text-sm font-semibold">{t("coverage.divisions")}</h2>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {data.divisions.map((d) => (
                <Card key={d.division} className="card-hover p-4 shadow-soft">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-semibold">{divName(d)}</p>
                    <LevelPill level={d.level} />
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{d.districts} {t("common.district")}</p>
                  <p className="mt-2 text-2xl font-bold tabular-nums">{d.total.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")}</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
                    {t("directory.kind.HOSPITAL")} {d.hospital.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")} · {t("directory.kind.CLINIC")} {d.clinic.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")} · {t("directory.kind.DIAGNOSTIC")} {d.diagnostic.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")} · {t("directory.kind.PHARMACY")} {d.pharmacy.toLocaleString(locale === "bn" ? "bn-BD" : "en-IN")}
                  </p>
                  <div className="mt-2">
                    <LevelMeter total={d.total} max={maxTotal} />
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* low-coverage areas */}
          {data.lowCoverage.length > 0 && (
            <section aria-label={t("coverage.lowAreas")} className="rounded-2xl border border-amber-300 bg-amber-50/70 p-4">
              <h2 className="mb-1.5 flex items-center gap-2 text-sm font-semibold text-amber-900">
                <AlertTriangle className="h-4 w-4" /> {t("coverage.lowAreas")}
              </h2>
              <p className="mb-3 text-xs leading-relaxed text-amber-800/80">{t("coverage.lowAreasHint")}</p>
              <div className="flex flex-wrap gap-2">
                {data.lowCoverage.map((d) => (
                  <span
                    key={d.district}
                    className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${
                      d.level === "EMPTY" ? "bg-red-600 text-white" : d.level === "MINIMAL" ? "bg-orange-500 text-white" : "bg-amber-400 text-amber-950"
                    }`}
                  >
                    {name(d)}
                    <span className="font-bold tabular-nums">{d.total}</span>
                  </span>
                ))}
              </div>
            </section>
          )}

          {/* district table */}
          <section aria-label={t("coverage.districtTable")}>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <h2 className="text-sm font-semibold">{t("coverage.districtTable")}</h2>
              <div className="ml-auto flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder={t("coverage.searchDistrict")}
                    className="h-8 w-40 pl-8 text-xs sm:w-52"
                    aria-label={t("coverage.searchDistrict")}
                  />
                </div>
                <select
                  aria-label={t("common.division")}
                  className="h-8 rounded-md border bg-background px-2 text-xs"
                  value={division ?? ""}
                  onChange={(e) => setDivision(e.target.value || null)}
                >
                  <option value="">{t("coverage.allDivisions")}</option>
                  {divOptions.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
                <Button size="sm" variant={sortBy === "total" ? "default" : "outline"} className="h-8" onClick={() => setSortBy(sortBy === "total" ? "district" : "total")}>
                  {sortBy === "total" ? t("coverage.sortTotal") : t("coverage.sortName")}
                </Button>
              </div>
            </div>

            {filtered.length === 0 ? (
              <EmptyState title={t("common.noResults")} hint={t("coverage.noDistrictHint")} />
            ) : (
              <Card className="overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[720px] text-sm">
                    <thead>
                      <tr className="border-b bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
                        <th className="px-3 py-2.5 font-medium">{t("common.district")}</th>
                        <th className="px-3 py-2.5 text-right font-medium">{t("directory.kind.HOSPITAL")}</th>
                        <th className="px-3 py-2.5 text-right font-medium">{t("directory.kind.CLINIC")}</th>
                        <th className="px-3 py-2.5 text-right font-medium">{t("directory.kind.DIAGNOSTIC")}</th>
                        <th className="px-3 py-2.5 text-right font-medium">{t("directory.kind.PHARMACY")}</th>
                        <th className="px-3 py-2.5 text-right font-medium"><Siren className="ml-auto h-3.5 w-3.5" /></th>
                        <th className="px-3 py-2.5 text-right font-medium">{t("coverage.total")}</th>
                        <th className="px-3 py-2.5 font-medium">{t("coverage.level")}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map((d) => (
                        <tr key={d.district} className="border-b last:border-0 hover:bg-emerald-50/40">
                          <td className="px-3 py-2.5">
                            <p className="font-medium">{name(d)}</p>
                            <p className="text-[11px] text-muted-foreground">{d.division}</p>
                          </td>
                          <td className="px-3 py-2.5 text-right tabular-nums">{d.hospital || "—"}</td>
                          <td className="px-3 py-2.5 text-right tabular-nums">{d.clinic || "—"}</td>
                          <td className="px-3 py-2.5 text-right tabular-nums">{d.diagnostic || "—"}</td>
                          <td className="px-3 py-2.5 text-right tabular-nums">{d.pharmacy || "—"}</td>
                          <td className="px-3 py-2.5 text-right tabular-nums">{d.emergency || "—"}</td>
                          <td className="px-3 py-2.5 text-right">
                            <p className="font-semibold tabular-nums">{d.total || "—"}</p>
                            <div className="mt-0.5 flex justify-end"><LevelMeter total={d.total} max={maxTotal} /></div>
                          </td>
                          <td className="px-3 py-2.5"><LevelPill level={d.level} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            )}
          </section>

          <p className="flex items-start gap-2 rounded-xl border border-emerald-900/10 bg-emerald-50/50 p-3 text-xs leading-relaxed text-muted-foreground">
            <Database className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700" />
            {t("coverage.dataNote")}
          </p>
        </div>
      )}
    </>
  );
}
