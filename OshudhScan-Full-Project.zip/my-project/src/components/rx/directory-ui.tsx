"use client";
// Shared UI kit for the National Healthcare Directory: interactive map canvas
// (Leaflet + OpenStreetMap tiles, graceful iframe fallback), verification
// badges, honest phone display, and the public report dialog.
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Phone, ShieldCheck, ShieldAlert, Flag, MapPin, ExternalLink, Loader2 } from "lucide-react";
import { apiFetch, ApiClientError } from "@/components/rx/shared";
import { useI18n } from "@/hooks/use-i18n";
import { cn } from "@/lib/utils";
import { useLiteMode } from "@/lib/lite";
import { LiteMapPlaceholder } from "@/components/rx/lite-ui";

// ── Leaflet map canvas (CDN-loaded, iframe fallback) ─────────────────────────

// Leaflet is loaded from CDN at runtime; declare the minimal surface we use.
declare global {
  interface Window {
    L?: any;
  }
}

let leafletPromise: Promise<any> | null = null;
function loadLeaflet(): Promise<any> {
  if (typeof window === "undefined") return Promise.reject(new Error("SSR"));
  if (window.L) return Promise.resolve(window.L);
  if (leafletPromise) return leafletPromise;
  leafletPromise = new Promise((resolve, reject) => {
    const css = document.createElement("link");
    css.rel = "stylesheet";
    css.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
    css.integrity = "sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=";
    css.crossOrigin = "";
    document.head.appendChild(css);
    const script = document.createElement("script");
    script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
    script.integrity = "sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=";
    script.crossOrigin = "";
    script.onload = () => (window.L ? resolve(window.L) : reject(new Error("Leaflet missing")));
    script.onerror = () => reject(new Error("Leaflet CDN unavailable"));
    document.head.appendChild(script);
    setTimeout(() => reject(new Error("Leaflet load timeout")), 10000);
  });
  return leafletPromise;
}

export interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  label: string;
  color?: string;
  kind?: string;
  href?: string;
  phone?: string | null;
}

/** Escape user-facing strings interpolated into Leaflet popup HTML. */
function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c] ?? c));
}

const MARKER_COLORS: Record<string, string> = {
  HOSPITAL: "#0d9488", CLINIC: "#0284c7", DIAGNOSTIC: "#7c3aed",
  PHARMACY: "#16a34a", BLOOD_BANK: "#dc2626", AMBULANCE_SERVICE: "#ea580c", ME: "#e11d48",
};

export function MapCanvas({
  center,
  markers,
  zoom = 12,
  height = 420,
  className,
}: {
  center: { lat: number; lng: number };
  markers: MapMarker[];
  zoom?: number;
  height?: number;
  className?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<{ map: unknown; layer: unknown } | null>(null);
  const [failed, setFailed] = useState(false);
  // Low Internet Mode: defer the Leaflet bundle + OSM tiles until the user
  // explicitly asks for the map — text results stay usable without them.
  const { liteMode } = useLiteMode();
  const [liteOverride, setLiteOverride] = useState(false);
  const { t } = useI18n();

  const renderMarkers = useCallback((L: any, map: any) => {
    const layer = mapRef.current?.layer as any;
    if (layer) layer.clearLayers();
    const group = L.layerGroup();
    for (const m of markers) {
      const color = m.color ?? MARKER_COLORS[m.kind ?? ""] ?? "#0d9488";
      const marker = L.circleMarker([m.lat, m.lng], {
        radius: 9, weight: 2, color: "#ffffff", fillColor: color, fillOpacity: 0.95,
      });
      const callLink = m.phone ? `<br/><a href="tel:${encodeURIComponent(m.phone)}" style="color:#047857;font-weight:600;font-size:13px">&#9742; ${escapeHtml(m.phone)}</a>` : "";
      const href = m.href ?? `https://www.google.com/maps/search/?api=1&query=${m.lat},${m.lng}`;
      marker.bindPopup(
        `<div style="min-width:180px"><strong>${escapeHtml(m.label)}</strong><br/><span style="color:#555;font-size:12px">${m.kind ? escapeHtml(t(`directory.kind.${m.kind}`)) : ""}</span>${callLink}<br/><a href="${escapeHtml(href)}" target="_blank" rel="noreferrer" style="color:#0d9488;font-size:12px">${t("common.openInMaps")}</a></div>`
      );
      group.addLayer(marker);
    }
    group.addTo(map);
    if (mapRef.current) mapRef.current.layer = group;
  }, [markers, t]);

  useEffect(() => {
    let cancelled = false;
    // liteOverride matters: when the user asks for the map in Low Internet
    // Mode, the real container mounts at that moment — the effect must re-run
    // even though center/zoom/markers are unchanged.
    loadLeaflet()
      .then((L: any) => {
        if (cancelled || !containerRef.current) return;
        if (!mapRef.current?.map) {
          const map = L.map(containerRef.current, { scrollWheelZoom: true, zoomControl: true }).setView([center.lat, center.lng], zoom);
          L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 19,
          }).addTo(map);
          mapRef.current = { map, layer: null };
        }
        renderMarkers(L, mapRef.current.map);
      })
      .catch(() => !cancelled && setFailed(true));
    return () => { cancelled = true; };
  }, [center.lat, center.lng, zoom, renderMarkers, liteOverride]);

  // re-render markers when they change (map already initialized)
  useEffect(() => {
    if (mapRef.current?.map) loadLeaflet().then((L: any) => renderMarkers(L, mapRef.current!.map)).catch(() => undefined);
  }, [markers, renderMarkers]);

  if (failed) {
    // Honest fallback: static OSM embed with a single centre marker.
    const dLat = 0.08 / 2;
    const dLng = 0.08 / 2 / Math.max(0.2, Math.cos((center.lat * Math.PI) / 180));
    const bbox = [center.lng - dLng, center.lat - dLat, center.lng + dLng, center.lat + dLat].map((n) => n.toFixed(5)).join(",");
    return (
      <Card className={cn("overflow-hidden", className)}>
        <iframe
          title="OpenStreetMap"
          className="w-full border-0"
          style={{ height }}
          src={`https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${center.lat},${center.lng}`}
          loading="lazy"
        />
        <p className="px-3 py-2 text-xs text-muted-foreground">{t("directory.mapFallback")}</p>
      </Card>
    );
  }

  if (liteMode && !liteOverride) {
    return <LiteMapPlaceholder className={className} onLoad={() => setLiteOverride(true)} />;
  }

  return (
    <Card className={cn("overflow-hidden", className)}>
      <div ref={containerRef} style={{ height }} className="w-full bg-emerald-50/40" />
      <div className="flex flex-wrap items-center gap-3 px-3 py-2 text-[11px] text-muted-foreground">
        {Object.entries(MARKER_COLORS).slice(0, 6).map(([kind, color]) => (
          <span key={kind} className="inline-flex items-center gap-1">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: color }} />
            {t(`directory.kind.${kind}`)}
          </span>
        ))}
      </div>
    </Card>
  );
}

// ── verification badge ───────────────────────────────────────────────────────

const STATUS_META: Record<string, { key: string; cls: string; icon: React.ReactNode }> = {
  OFFICIALLY_LISTED: { key: "directory.st.offic", cls: "bg-teal-600 text-white", icon: <ShieldCheck className="h-3 w-3" /> },
  MAP_LISTED: { key: "directory.st.map", cls: "bg-sky-600 text-white", icon: <ShieldCheck className="h-3 w-3" /> },
  CONTACT_VERIFIED: { key: "directory.st.contact", cls: "bg-emerald-600 text-white", icon: <ShieldCheck className="h-3 w-3" /> },
  LICENSE_VERIFIED: { key: "directory.st.license", cls: "bg-emerald-700 text-white", icon: <ShieldCheck className="h-3 w-3" /> },
  ADMIN_VERIFIED: { key: "directory.st.admin", cls: "bg-emerald-600 text-white", icon: <ShieldCheck className="h-3 w-3" /> },
  UNVERIFIED: { key: "directory.st.unver", cls: "text-muted-foreground", icon: <ShieldAlert className="h-3 w-3" /> },
  TEMPORARILY_CLOSED: { key: "directory.st.temp", cls: "bg-amber-500 text-white", icon: <ShieldAlert className="h-3 w-3" /> },
  PERMANENTLY_CLOSED: { key: "directory.st.perm", cls: "bg-red-600 text-white", icon: <ShieldAlert className="h-3 w-3" /> },
  REPORTED_INCORRECT: { key: "directory.st.reported", cls: "bg-red-700 text-white", icon: <ShieldAlert className="h-3 w-3" /> },
};

export function VerificationBadge({ status }: { status: string | null | undefined }) {
  const { t } = useI18n();
  const meta = STATUS_META[status ?? "UNVERIFIED"] ?? STATUS_META.UNVERIFIED;
  return (
    <Badge variant={status === "UNVERIFIED" ? "outline" : "default"} className={cn("gap-1 font-medium", meta.cls)}>
      {meta.icon} {t(meta.key)}
    </Badge>
  );
}

/** Honest phone line: "Phone number unavailable" when absent. */
export function PhoneLine({ phone, isPhoneVerified }: { phone: string | null; isPhoneVerified?: boolean }) {
  const { t } = useI18n();
  if (!phone) {
    return (
      <span className="inline-flex items-center gap-1 text-sm text-muted-foreground">
        <Phone className="h-3.5 w-3.5" /> {t("directory.phoneUnavailable")}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-sm">
      <Phone className="h-3.5 w-3.5 text-emerald-700" />
      <a href={`tel:${phone}`} className="font-medium text-emerald-800 hover:underline">{phone}</a>
      {isPhoneVerified ? (
        <span className="inline-flex items-center gap-0.5 text-[11px] text-emerald-700">{t("directory.phoneVerified")}</span>
      ) : (
        <span className="text-[11px] text-muted-foreground">({t("directory.phoneUnverified")})</span>
      )}
    </span>
  );
}

// ── public report dialog ─────────────────────────────────────────────────────

const REPORT_TYPE_KEYS: Record<string, string> = {
  WRONG_PHONE: "directory.rt.phone", WRONG_ADDRESS: "directory.rt.address",
  TEMPORARILY_CLOSED: "directory.rt.tempClosed", PERMANENTLY_CLOSED: "directory.rt.permClosed",
  DUPLICATE: "directory.rt.duplicate", WRONG_CATEGORY: "directory.rt.category",
  WRONG_LOCATION: "directory.rt.location", OTHER: "directory.rt.other",
};

export function ReportDialog({
  entityType, entityId, entityName, open, onOpenChange,
}: {
  entityType: "FACILITY" | "PHARMACY";
  entityId: string;
  entityName: string;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const { t } = useI18n();
  const [reportType, setReportType] = useState("WRONG_PHONE");
  const [message, setMessage] = useState("");
  const [suggestedValue, setSuggestedValue] = useState("");
  const [contact, setContact] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  const needsSuggested = reportType === "WRONG_PHONE" || reportType === "WRONG_ADDRESS";

  const submit = async () => {
    setState("sending");
    setError(null);
    try {
      await apiFetch("/api/reports", {
        method: "POST",
        body: JSON.stringify({ entityType, entityId, reportType, message, suggestedValue: needsSuggested && suggestedValue ? suggestedValue : undefined, reporterContact: contact || undefined }),
      });
      setState("sent");
    } catch (err) {
      setState("error");
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    }
  };

  const close = (o: boolean) => {
    if (!o) { setState("idle"); setMessage(""); setSuggestedValue(""); setReportType("WRONG_PHONE"); }
    onOpenChange(o);
  };

  return (
    <Dialog open={open} onOpenChange={close}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Flag className="h-4 w-4 text-amber-600" /> {t("directory.reportTitle")}</DialogTitle>
          <DialogDescription>{entityName} · {t("directory.reportDesc")}</DialogDescription>
        </DialogHeader>
        {state === "sent" ? (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800">
            {t("directory.reportSent")}
          </div>
        ) : (
          <div className="space-y-3">
            <div className="grid gap-1.5">
              <Label htmlFor="report-type">{t("directory.reportType")}</Label>
              <select
                id="report-type"
                className="h-9 rounded-md border bg-background px-2 text-sm"
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
              >
                {Object.keys(REPORT_TYPE_KEYS).map((k) => (
                  <option key={k} value={k}>{t(REPORT_TYPE_KEYS[k])}</option>
                ))}
              </select>
            </div>
            {needsSuggested && (
              <div className="grid gap-1.5">
                <Label htmlFor="report-suggested">{reportType === "WRONG_PHONE" ? t("directory.correctPhone") : t("directory.correctAddress")}</Label>
                <Input id="report-suggested" value={suggestedValue} onChange={(e) => setSuggestedValue(e.target.value)} />
              </div>
            )}
            <div className="grid gap-1.5">
              <Label htmlFor="report-message">{t("directory.reportMessage")}</Label>
              <Textarea id="report-message" rows={3} value={message} onChange={(e) => setMessage(e.target.value)} maxLength={1000} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="report-contact">{t("directory.reportContact")} <span className="text-muted-foreground">({t("common.optional")})</span></Label>
              <Input id="report-contact" value={contact} onChange={(e) => setContact(e.target.value)} maxLength={120} />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => close(false)}>{t("common.cancel")}</Button>
              <Button size="sm" onClick={() => void submit()} disabled={state === "sending" || message.trim().length < 5}>
                {state === "sending" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Flag className="h-4 w-4" />}
                {t("directory.reportSubmit")}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ── compact facility / pharmacy card actions ─────────────────────────────────

export function MapsLinkButton({ href, label }: { href: string; label: string }) {
  return (
    <Button size="sm" variant="outline" asChild>
      <a href={href} target="_blank" rel="noreferrer">
        <ExternalLink className="h-3.5 w-3.5 mr-1" /> {label}
      </a>
    </Button>
  );
}

export function FacilityPlaceLabel({ division, district, upazila, area }: { division?: string | null; district?: string | null; upazila?: string | null; area?: string | null }) {
  return (
    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
      <MapPin className="h-3 w-3" />
      {[area, upazila, district, division].filter(Boolean).join(", ")}
    </span>
  );
}

export function useDependentLocations(initial?: { division?: string; district?: string; upazila?: string }) {
  const [divisions, setDivisions] = useState<Array<{ name: string; nameBangla: string | null }>>([]);
  const [districts, setDistricts] = useState<Array<{ name: string; nameBangla: string | null }>>([]);
  const [upazilas, setUpazilas] = useState<Array<{ name: string; nameBangla: string | null }>>([]);
  const [sel, setSel] = useState<{ division?: string; district?: string; upazila?: string }>(initial ?? {});
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    void apiFetch<{ divisions: Array<{ name: string; nameBangla: string | null }> }>("/api/locations/divisions")
      .then((r) => setDivisions(r.divisions))
      .catch(() => setLoadError(true));
  }, []);

  const pickDivision = useCallback(async (division: string) => {
    setSel({ division: division || undefined });
    setUpazilas([]);
    setDistricts([]);
    setLoadError(false);
    if (division) {
      try {
        const r = await apiFetch<{ districts: Array<{ name: string; nameBangla: string | null }> }>(`/api/locations/districts?division=${encodeURIComponent(division)}`);
        setDistricts(r.districts);
      } catch {
        setLoadError(true);
      }
    }
  }, []);

  const pickDistrict = useCallback(async (division: string | undefined, district: string) => {
    setSel({ division, district: district || undefined });
    setUpazilas([]);
    setLoadError(false);
    if (district && division) {
      try {
        const r = await apiFetch<{ upazilas: Array<{ name: string; nameBangla: string | null }> }>(`/api/locations/upazilas?district=${encodeURIComponent(district)}`);
        setUpazilas(r.upazilas);
      } catch {
        setLoadError(true);
      }
    }
  }, []);

  const pickUpazila = useCallback((division: string | undefined, district: string | undefined, upazila: string) => {
    setSel({ division, district, upazila: upazila || undefined });
  }, []);

  return { divisions, districts, upazilas, sel, loadError, pickDivision, pickDistrict, pickUpazila };
}

export function DependentLocationSelects({ sel, divisions, districts, upazilas, onDivision, onDistrict, onUpazila, className }: {
  sel: { division?: string; district?: string; upazila?: string };
  divisions: Array<{ name: string; nameBangla: string | null }>;
  districts: Array<{ name: string; nameBangla: string | null }>;
  upazilas: Array<{ name: string; nameBangla: string | null }>;
  onDivision: (v: string) => void;
  onDistrict: (v: string) => void;
  onUpazila: (v: string) => void;
  className?: string;
}) {
  const { t, locale } = useI18n();
  const label = (o: { name: string; nameBangla: string | null }) => (locale === "bn" && o.nameBangla ? o.nameBangla : o.name);
  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      <select aria-label={t("common.division")} className="h-9 min-w-[130px] flex-1 rounded-md border bg-background px-2 text-sm" value={sel.division ?? ""} onChange={(e) => onDivision(e.target.value)}>
        <option value="">{t("common.division")}</option>
        {divisions.map((d) => <option key={d.name} value={d.name}>{label(d)}</option>)}
      </select>
      <select aria-label={t("common.district")} className="h-9 min-w-[130px] flex-1 rounded-md border bg-background px-2 text-sm" value={sel.district ?? ""} disabled={!sel.division} onChange={(e) => onDistrict(e.target.value)}>
        <option value="">{t("common.district")}</option>
        {districts.map((d) => <option key={d.name} value={d.name}>{label(d)}</option>)}
      </select>
      <select aria-label={t("common.upazila")} className="h-9 min-w-[130px] flex-1 rounded-md border bg-background px-2 text-sm" value={sel.upazila ?? ""} disabled={!sel.district} onChange={(e) => onUpazila(e.target.value)}>
        <option value="">{t("common.upazila")}</option>
        {upazilas.map((u) => <option key={u.name} value={u.name}>{label(u)}</option>)}
      </select>
    </div>
  );
}

export function DependentLocationError({ className }: { className?: string }) {
  const { t } = useI18n();
  return <p className={cn("text-xs text-destructive", className)}>{t("err.generic")}</p>;
}

/** Category chip grid used on home + directory views. */
export function CategoryChips({ active, onPick, className }: { active?: string; onPick: (v: string | null) => void; className?: string }) {
  const { t } = useI18n();
  const cats = useMemo(
    () => [
      { key: "HOSPITAL", cls: "bg-teal-600" },
      { key: "CLINIC", cls: "bg-sky-600" },
      { key: "DIAGNOSTIC", cls: "bg-violet-600" },
      { key: "PHARMACY", cls: "bg-green-600" },
    ],
    []
  );
  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {cats.map((c) => (
        <button
          key={c.key}
          onClick={() => onPick(active === c.key ? null : c.key)}
          aria-pressed={active === c.key}
          className={cn(
            "inline-flex min-h-[38px] items-center gap-1.5 rounded-full border px-3.5 text-sm font-medium transition-colors",
            active === c.key ? `${c.cls} border-transparent text-white shadow-soft` : "bg-background text-muted-foreground hover:border-emerald-300 hover:text-emerald-800"
          )}
        >
          <span className={cn("h-2.5 w-2.5 rounded-full", active === c.key ? "bg-white/80" : c.cls)} />
          {t(`directory.kind.${c.key}`)}
        </button>
      ))}
    </div>
  );
}
