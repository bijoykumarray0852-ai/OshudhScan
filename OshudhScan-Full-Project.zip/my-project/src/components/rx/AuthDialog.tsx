"use client";
// Sign-in / sign-up dialog with demo account quick-fill.
import { useState } from "react";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAppStore } from "@/lib/store";
import { useI18n } from "@/hooks/use-i18n";
import { apiFetch, ApiClientError } from "@/components/rx/shared";
import type { SessionUser } from "@/lib/auth-types";

const DEMO_ACCOUNTS = [
  { label: "auth.rolePatient", email: "patient@oshudhscan.com", password: "Patient#2026" },
  { label: "auth.rolePharmacy", email: "pharmacy@oshudhscan.com", password: "Pharma#2026" },
  { label: "auth.roleAdmin", email: "admin@oshudhscan.com", password: "Admin#2026" },
];

export function AuthDialog() {
  const { t, locale } = useI18n();
  const open = useAppStore((s) => s.authDialogOpen);
  const mode = useAppStore((s) => s.authMode);
  const closeAuth = useAppStore((s) => s.closeAuth);
  const openAuth = useAppStore((s) => s.openAuth);
  const setUser = useAppStore((s) => s.setUser);
  const setLocale = useAppStore((s) => s.setLocale);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    setError(null);
    if (!email || !password || (mode === "signup" && !name)) {
      setError(t("auth.required"));
      return;
    }
    setBusy(true);
    try {
      const qs = mode === "signup" ? "action=register" : "action=login";
      const res = await apiFetch<{ user: SessionUser }>(`/api/auth?${qs}`, {
        method: "POST",
        body: JSON.stringify(mode === "signup" ? { name, email, password, phone: phone || undefined, locale } : { email, password }),
      });
      setUser(res.user);
      if (res.user.locale && res.user.locale !== locale) setLocale(res.user.locale as "bn" | "en");
      closeAuth();
      setPassword("");
    } catch (err) {
      if (err instanceof ApiClientError) {
        const map: Record<string, string> = {
          INVALID_CREDENTIALS: "auth.invalidCredentials",
          EMAIL_TAKEN: "auth.emailTaken",
          VALIDATION: "auth.weakPassword",
          RATE_LIMITED: "err.rateLimited",
        };
        setError(t((map[err.code] ?? "err.generic") as string));
      } else setError(t("err.generic"));
    } finally {
      setBusy(false);
    }
  };

  const quickFill = (e: (typeof DEMO_ACCOUNTS)[number]) => {
    setEmail(e.email);
    setPassword(e.password);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => (o ? undefined : closeAuth())}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{mode === "signup" ? t("auth.createTitle") : t("auth.welcome")}</DialogTitle>
          <DialogDescription>
            {mode === "signup" ? t("auth.createSubtitle") : t("auth.signInToContinue")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          {mode === "signup" && (
            <div className="space-y-1">
              <Label htmlFor="auth-name">{t("auth.nameLabel")}</Label>
              <Input id="auth-name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
            </div>
          )}
          <div className="space-y-1">
            <Label htmlFor="auth-email">{t("auth.emailLabel")}</Label>
            <Input id="auth-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" inputMode="email" />
          </div>
          {mode === "signup" && (
            <div className="space-y-1">
              <Label htmlFor="auth-phone">
                {t("auth.phoneLabel")} <span className="text-muted-foreground">({t("common.optional")})</span>
              </Label>
              <Input id="auth-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" placeholder="01XXXXXXXXX" />
            </div>
          )}
          <div className="space-y-1">
            <Label htmlFor="auth-password">{t("auth.passwordLabel")}</Label>
            <Input
              id="auth-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === "signup" ? "new-password" : "current-password"}
              onKeyDown={(e) => e.key === "Enter" && void submit()}
            />
            {mode === "signup" && <p className="text-xs text-muted-foreground">{t("auth.passwordHint")}</p>}
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <Button className="w-full" onClick={() => void submit()} disabled={busy}>
            {busy ? t("common.loading") : mode === "signup" ? t("auth.signUp") : t("auth.signIn")}
          </Button>

          <p className="text-sm text-center text-muted-foreground">
            {mode === "signup" ? t("auth.haveAccount") : t("auth.noAccount")}{" "}
            <button
              className="underline underline-offset-2 text-primary"
              onClick={() => openAuth(mode === "signup" ? "signin" : "signup")}
            >
              {mode === "signup" ? t("auth.signIn") : t("auth.signUp")}
            </button>
          </p>

          <div className="rounded-lg border bg-muted/40 p-3">
            <p className="text-xs font-medium mb-2">{t("auth.demoAccounts")}</p>
            <div className="flex flex-col gap-1">
              {DEMO_ACCOUNTS.map((d) => (
                <button
                  key={d.email}
                  className="text-xs text-left underline-offset-2 hover:underline text-muted-foreground"
                  onClick={() => quickFill(d)}
                >
                  {t(d.label as never)} — {d.email}
                </button>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
