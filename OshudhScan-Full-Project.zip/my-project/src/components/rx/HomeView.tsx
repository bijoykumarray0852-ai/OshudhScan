"use client";
// Landing page — premium "Clinical Emerald" design, fully localized.
import {
  ArrowRight,
  BadgeCheck,
  Bot,
  Camera,
  FileWarning,
  HandCoins,
  Languages,
  MapPinned,
  ScanLine,
  ShieldAlert,
  Stethoscope,
  Volume2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAppStore } from "@/lib/store";
import { MARKET_STATS } from "@/lib/finance";
import { useI18n } from "@/hooks/use-i18n";
import { HomeDirectorySection } from "@/components/rx/HomeDirectorySection";
import type { DictKey } from "@/lib/i18n/en";

const PAIN_ICONS = [
  <FileWarning key="1" className="h-5 w-5" />,
  <ShieldAlert key="2" className="h-5 w-5" />,
  <Languages key="3" className="h-5 w-5" />,
  <MapPinned key="4" className="h-5 w-5" />,
];
const STEP_ICONS = [
  <Camera key="1" className="h-4 w-4" />,
  <ScanLine key="2" className="h-4 w-4" />,
  <BadgeCheck key="3" className="h-4 w-4" />,
  <Bot key="4" className="h-4 w-4" />,
  <Volume2 key="5" className="h-4 w-4" />,
  <HandCoins key="6" className="h-4 w-4" />,
];

export function HomeView() {
  const setView = useAppStore((s) => s.setView);
  const { t } = useI18n();

  const painKeys: Array<[DictKey, DictKey]> = [
    ["home.pain1Title", "home.pain1Body"],
    ["home.pain2Title", "home.pain2Body"],
    ["home.pain3Title", "home.pain3Body"],
    ["home.pain4Title", "home.pain4Body"],
  ];
  const stepKeys: DictKey[] = ["home.step1", "home.step2", "home.step3", "home.step4", "home.step5", "home.step6"];

  return (
    <div className="space-y-16">
      {/* Hero — brand mesh + gradient headline (bleeds exactly to main's px-4 edge) */}
      <section className="hero-mesh -mx-4 rounded-b-3xl px-4 pb-10 pt-8 text-center sm:pb-14 sm:pt-12">
        <Badge variant="outline" className="mx-auto gap-1.5 border-emerald-300/70 bg-white/70 text-emerald-800 shadow-soft">
          <Stethoscope className="h-3.5 w-3.5" /> {t("home.badge")}
        </Badge>
        <h1 className="mx-auto mt-5 max-w-3xl text-4xl font-extrabold leading-[1.12] tracking-tight sm:text-5xl">
          {t("home.hero1")}{" "}
          <span className="text-gradient">{t("home.hero2")}</span>
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          {t("home.sub")}
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <Button size="lg" className="btn-brand px-6 text-[15px]" onClick={() => setView("scan")}>
            {t("home.ctaDecode")} <ArrowRight className="ml-1.5 h-4 w-4" />
          </Button>
          <Button size="lg" variant="outline" className="bg-white/70 px-6 text-[15px] shadow-soft backdrop-blur" onClick={() => setView("portal")}>
            {t("home.ctaPartners")}
          </Button>
        </div>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
          <Badge variant="secondary" className="bg-white/70 shadow-soft backdrop-blur">{t("home.chipOcr")}</Badge>
          <Badge variant="secondary" className="bg-white/70 shadow-soft backdrop-blur">{t("home.chipRules")}</Badge>
          <Badge variant="secondary" className="bg-white/70 shadow-soft backdrop-blur">{t("home.chipGraph")}</Badge>
          <Badge variant="secondary" className="bg-white/70 shadow-soft backdrop-blur">{t("home.chipTts")}</Badge>
        </div>
      </section>

      {/* Stats band — glass card over the mesh */}
      <section className="relative -mt-10 grid gap-px overflow-hidden rounded-2xl border border-emerald-100 bg-white shadow-soft sm:grid-cols-3">
        <div className="p-6 text-center sm:p-7 sm:text-left">
          <p className="stat-figure text-3xl font-extrabold text-emerald-700">US$ {MARKET_STATS.marketUsdB}B</p>
          <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
            {t("home.statMarket", { growth: MARKET_STATS.marketGrowthPct })}
          </p>
        </div>
        <div className="border-t border-emerald-100/80 p-6 text-center sm:border-l sm:border-t-0 sm:p-7 sm:text-left">
          <p className="stat-figure text-3xl font-extrabold text-emerald-700">{MARKET_STATS.retailPharmacies}</p>
          <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{t("home.statPharmacies")}</p>
        </div>
        <div className="border-t border-emerald-100/80 p-6 text-center sm:border-l sm:border-t-0 sm:p-7 sm:text-left">
          <p className="stat-figure text-3xl font-extrabold text-emerald-700">100%</p>
          <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{t("home.statHandwritten")}</p>
        </div>
        <p className="col-span-full border-t border-dashed border-emerald-100 bg-emerald-50/40 px-6 py-2 text-center text-[11px] text-muted-foreground sm:text-left">
          {t("home.sources")}
        </p>
      </section>

      {/* National Healthcare Directory finder — location search, shortcuts, nearby, emergency */}
      <HomeDirectorySection />

      {/* Problem */}
      <section className="space-y-7">
        <div className="mx-auto max-w-2xl text-center">
          <p className="divider-label mb-3">OshudhScan</p>
          <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("home.painTitle")}</h2>
          <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground sm:text-base">{t("home.painSub")}</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {painKeys.map(([title, body], i) => (
            <Card key={i} className="card-hover shadow-soft">
              <CardContent className="flex gap-4 p-5">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-red-50 to-red-100 text-red-600 ring-1 ring-red-100">
                  {PAIN_ICONS[i]}
                </span>
                <div>
                  <h3 className="font-semibold leading-snug">{t(title)}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{t(body)}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* How it works strip */}
      <section className="space-y-7">
        <div className="mx-auto max-w-xl text-center">
          <p className="divider-label mb-3">{t("home.demo")}</p>
          <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("home.stepsTitle")}</h2>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {stepKeys.map((key, i) => (
            <Card key={i} className="card-hover border-dashed shadow-soft">
              <CardContent className="flex flex-col items-center gap-2 p-4 text-center">
                <span className="relative flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 text-white shadow-soft">
                  {STEP_ICONS[i]}
                  <span className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-white text-[10px] font-bold text-emerald-700 ring-1 ring-emerald-200">
                    {i + 1}
                  </span>
                </span>
                <span className="text-xs font-semibold leading-tight">{t(key)}</span>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="text-center">
          <Button className="btn-brand" onClick={() => setView("scan")}>
            {t("home.demo")} <ArrowRight className="ml-1.5 h-4 w-4" />
          </Button>
        </div>
      </section>

      {/* For pharmacies teaser — deep emerald panel */}
      <section className="panel-deep grid items-center gap-8 rounded-3xl p-7 text-emerald-50 shadow-lift sm:p-10 lg:grid-cols-2">
        <div className="space-y-4">
          <Badge className="gap-1 border-0 bg-emerald-400/90 text-emerald-950">{t("home.forOwners")}</Badge>
          <h2 className="text-2xl font-bold leading-snug sm:text-3xl">{t("home.ownerTitle")}</h2>
          <p className="text-sm leading-relaxed text-emerald-100/80 sm:text-base">{t("home.ownerBody")}</p>
          <Button variant="secondary" className="mt-2 bg-white text-emerald-900 hover:bg-emerald-50" onClick={() => setView("portal")}>
            {t("home.ownerCta")} <ArrowRight className="ml-1.5 h-4 w-4" />
          </Button>
        </div>
        <div className="grid grid-cols-1 gap-2 text-center min-[480px]:grid-cols-3 min-[480px]:gap-3">
          <div className="rounded-2xl bg-emerald-900/50 p-4 ring-1 ring-emerald-400/20">
            <p className="stat-figure text-2xl font-bold text-emerald-300">৳{MARKET_STATS.leadValueBdt}</p>
            <p className="mt-1 text-[11px] leading-tight text-emerald-200/70">{t("home.kpiLead")}</p>
          </div>
          <div className="rounded-2xl bg-emerald-900/50 p-4 ring-1 ring-emerald-400/20">
            <p className="stat-figure text-2xl font-bold text-emerald-300">৳{MARKET_STATS.avgBasketBdt}</p>
            <p className="mt-1 text-[11px] leading-tight text-emerald-200/70">{t("home.kpiBasket")}</p>
          </div>
          <div className="rounded-2xl bg-emerald-900/50 p-4 ring-1 ring-emerald-400/20">
            <p className="stat-figure text-2xl font-bold text-emerald-300">1.7×</p>
            <p className="mt-1 text-[11px] leading-tight text-emerald-200/70">{t("home.kpiRoi")}</p>
          </div>
        </div>
      </section>
    </div>
  );
}
