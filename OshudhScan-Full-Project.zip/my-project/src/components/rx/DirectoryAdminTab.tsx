"use client";
// Admin — National Directory management: coverage dashboard (from real DB
// records), verification queue, user reports review and data import (CSV/JSON).
import { useCallback, useEffect, useState } from "react";
import { MapPinned, ShieldCheck, Flag, Upload, Database, PhoneOff, Compass } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useI18n } from "@/hooks/use-i18n";
import { apiFetch, ApiClientError, StatCard, EmptyState, LoadingCards, ErrorNote, fmtDate } from "@/components/rx/shared";
import { useDependentLocations, DependentLocationSelects } from "@/components/rx/directory-ui";
import { VERIFICATION_STATUSES } from "@/lib/directory";

interface Coverage {
  totals: { facilities: number; pharmacies: number; locations: number; divisions: number; districts: number; districtsCovered: number; upazilas: number; coverageNote: string };
  facilitiesByType: Array<{ type: string; count: number }>;
  hospitalsByCategory: Array<{ category: string; count: number }>;
  facilitiesByDivision: Array<{ division: string | null; count: number }>;
  pharmaciesByDivision: Array<{ division: string | null; count: number }>;
  facilitiesByVerification: Array<{ status: string; count: number }>;
  pharmaciesByVerification: Array<{ status: string; count: number }>;
  dataGaps: { facilitiesMissingPhone: number; facilitiesMissingCoordinates: number; pharmaciesMissingPhone: number };
}

interface FacilityRow { id: string; name: string; nameBangla: string | null; district: string | null; upazila: string | null; verificationStatus: string; phone: string | null; isPhoneVerified: boolean; lastVerifiedAt: string | null }
interface ReportRow { id: string; entityType: string; entityId: string; reportType: string; message: string; suggestedValue: string | null; reporterName: string | null; reporterContact: string | null; status: string; createdAt: string }
interface JobRow { id: string; sourceType: string; entityType: string; fileName: string | null; status: string; totalRows: number; importedRows: number; duplicateRows: number; errorRows: number; createdAt: string; errors: Array<{ rowNumber: number; message: string }> }

const STATUS_TONE: Record<string, string> = {
  OFFICIALLY_LISTED: "bg-teal-600 text-white", MAP_LISTED: "bg-sky-600 text-white",
  CONTACT_VERIFIED: "bg-emerald-600 text-white", LICENSE_VERIFIED: "bg-emerald-700 text-white",
  ADMIN_VERIFIED: "bg-emerald-600 text-white", UNVERIFIED: "text-muted-foreground",
  TEMPORARILY_CLOSED: "bg-amber-500 text-white", PERMANENTLY_CLOSED: "bg-red-600 text-white",
  REPORTED_INCORRECT: "bg-red-700 text-white",
};

// verification-status enum → i18n key (mirrors directory-ui STATUS_META)
const STATUS_KEY: Record<string, string> = {
  OFFICIALLY_LISTED: "directory.st.offic", MAP_LISTED: "directory.st.map",
  CONTACT_VERIFIED: "directory.st.contact", LICENSE_VERIFIED: "directory.st.license",
  ADMIN_VERIFIED: "directory.st.admin", UNVERIFIED: "directory.st.unver",
  TEMPORARILY_CLOSED: "directory.st.temp", PERMANENTLY_CLOSED: "directory.st.perm",
  REPORTED_INCORRECT: "directory.st.reported",
};

const REPORT_TYPE_KEY: Record<string, string> = {
  WRONG_PHONE: "directory.rt.phone", WRONG_ADDRESS: "directory.rt.address",
  TEMPORARILY_CLOSED: "directory.rt.tempClosed", PERMANENTLY_CLOSED: "directory.rt.permClosed",
  DUPLICATE: "directory.rt.duplicate", WRONG_CATEGORY: "directory.rt.category",
  WRONG_LOCATION: "directory.rt.location", OTHER: "directory.rt.other",
};

const REPORT_STATUS_KEY: Record<string, string> = {
  OPEN: "admin.dir.reportOpen", REVIEWING: "admin.dir.reportReviewing",
  RESOLVED: "admin.dir.reportResolved", REJECTED: "admin.dir.reportRejected",
};

export function DirectoryAdminTab() {
  const { t, locale } = useI18n();
  const [section, setSection] = useState<"coverage" | "verify" | "reports" | "import">("coverage");
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-1.5">
        {(["coverage", "verify", "reports", "import"] as const).map((s) => (
          <Button key={s} size="sm" variant={section === s ? "default" : "outline"} onClick={() => setSection(s)}>
            {s === "coverage" && <Compass className="h-3.5 w-3.5 mr-1" />}
            {s === "verify" && <ShieldCheck className="h-3.5 w-3.5 mr-1" />}
            {s === "reports" && <Flag className="h-3.5 w-3.5 mr-1" />}
            {s === "import" && <Upload className="h-3.5 w-3.5 mr-1" />}
            {t(`admin.dir.${s}`)}
          </Button>
        ))}
      </div>
      {error && <ErrorNote message={error} />}
      {section === "coverage" && <CoverageSection />}
      {section === "verify" && <VerifySection />}
      {section === "reports" && <ReportsSection />}
      {section === "import" && <ImportSection />}
    </div>
  );

  function CoverageSection() {
    const [data, setData] = useState<Coverage | null>(null);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
      void (async () => {
        try { setData(await apiFetch<Coverage>("/api/admin/directory/coverage")); }
        catch (err) { setError(err instanceof ApiClientError ? err.message : t("err.generic")); }
        finally { setLoading(false); }
      })();
    }, [t]);
    if (loading) return <LoadingCards count={4} />;
    if (!data) return <EmptyState title={t("common.noResults")} />;
    const c = data.totals;
    return (
      <div className="space-y-5">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <StatCard label={t("admin.dir.facilities")} value={c.facilities} icon={<MapPinned className="h-4 w-4" />} />
          <StatCard label={t("admin.dir.pharmacies")} value={c.pharmacies} icon={<Database className="h-4 w-4" />} />
          <StatCard label={t("admin.dir.districtsCovered")} value={`${c.districtsCovered}/${c.districts}`} hint={t("admin.dir.honestCoverage")} icon={<Compass className="h-4 w-4" />} tone="brand" />
          <StatCard label={t("admin.dir.upazilas")} value={c.upazilas} icon={<MapPinned className="h-4 w-4" />} />
        </div>
        <p className="rounded-lg border border-dashed bg-emerald-50/40 px-3 py-2 text-xs text-muted-foreground">{c.coverageNote}</p>

        <div className="grid gap-4 md:grid-cols-2">
          <Card className="p-4">
            <h3 className="mb-3 text-sm font-semibold">{t("admin.dir.byType")}</h3>
            <div className="space-y-1.5">
              {data.facilitiesByType.map((r) => (
                <div key={r.type} className="flex items-center justify-between text-sm">
                  <span>{t(`directory.kind.${r.type}`)}</span>
                  <span className="font-semibold tabular-nums">{r.count}</span>
                </div>
              ))}
              {data.hospitalsByCategory.length > 0 && (
                <>
                  <p className="pt-2 text-xs font-medium text-muted-foreground">{t("admin.dir.hospitalCategories")}</p>
                  {data.hospitalsByCategory.map((r) => (
                    <div key={r.category} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{t(`directory.cat.${r.category}`)}</span>
                      <span className="font-semibold tabular-nums">{r.count}</span>
                    </div>
                  ))}
                </>
              )}
            </div>
          </Card>
          <Card className="p-4">
            <h3 className="mb-3 text-sm font-semibold">{t("admin.dir.byDivision")}</h3>
            <div className="space-y-1.5">
              {data.facilitiesByDivision.map((r) => (
                <div key={r.division} className="flex items-center justify-between text-sm">
                  <span>{locale === "bn" ? r.division : r.division}</span>
                  <span className="tabular-nums text-muted-foreground">{r.count} · {data.pharmaciesByDivision.find((p) => p.division === r.division)?.count ?? 0} {t("admin.dir.pharmaciesShort")}</span>
                </div>
              ))}
            </div>
          </Card>
          <Card className="p-4">
            <h3 className="mb-3 text-sm font-semibold">{t("admin.dir.verification")}</h3>
            <div className="space-y-1.5">
              {data.facilitiesByVerification.map((r) => (
                <div key={r.status} className="flex items-center justify-between text-sm">
                  <Badge variant={r.status === "UNVERIFIED" ? "outline" : "default"} className={STATUS_TONE[r.status]}>{t(`directory.st.${r.status.slice(0, 2) === "OF" ? "offic" : r.status.slice(0, 2) === "MA" ? "map" : r.status.slice(0, 2) === "CO" ? "contact" : r.status.slice(0, 2) === "LI" ? "license" : r.status.slice(0, 2) === "AD" ? "admin" : r.status.slice(0, 2) === "UN" ? "unver" : r.status.slice(0, 2) === "TE" ? "temp" : r.status.slice(0, 2) === "PE" ? "perm" : "reported"}`)}</Badge>
                  <span className="font-semibold tabular-nums">{r.count}</span>
                </div>
              ))}
            </div>
          </Card>
          <Card className="p-4">
            <h3 className="mb-3 text-sm font-semibold flex items-center gap-1.5"><PhoneOff className="h-4 w-4 text-amber-600" /> {t("admin.dir.dataGaps")}</h3>
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between"><span>{t("admin.dir.missingPhone")}</span><span className="font-semibold tabular-nums">{data.dataGaps.facilitiesMissingPhone}</span></div>
              <div className="flex justify-between"><span>{t("admin.dir.missingCoords")}</span><span className="font-semibold tabular-nums">{data.dataGaps.facilitiesMissingCoordinates}</span></div>
              <div className="flex justify-between"><span>{t("admin.dir.missingPhonePharm")}</span><span className="font-semibold tabular-nums">{data.dataGaps.pharmaciesMissingPhone}</span></div>
              <p className="pt-2 text-xs text-muted-foreground">{t("admin.dir.dataGapsNote")}</p>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  function VerifySection() {
    const loc = useDependentLocations();
    const [rows, setRows] = useState<FacilityRow[]>([]);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState<string | null>(null);
    const [message, setMessage] = useState<string | null>(null);
    const [loadError, setLoadError] = useState<string | null>(null);
    const [statusChoice, setStatusChoice] = useState<Record<string, string>>({});

    const load = useCallback(async () => {
      setLoading(true);
      setLoadError(null);
      try {
        const params = new URLSearchParams();
        if (loc.sel.division) params.set("division", loc.sel.division);
        if (loc.sel.district) params.set("district", loc.sel.district);
        if (loc.sel.upazila) params.set("upazila", loc.sel.upazila);
        params.set("pageSize", "12");
        const res = await apiFetch<{ hospitals: FacilityRow[] }>(`/api/directory/hospitals?${params}`);
        setRows(res.hospitals);
      } catch (err) {
        setLoadError(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally { setLoading(false); }
    }, [loc.sel, t]);

    useEffect(() => { void load(); }, [load]);

    const verify = async (row: FacilityRow) => {
      const toStatus = statusChoice[row.id] ?? "CONTACT_VERIFIED";
      setBusy(row.id);
      setMessage(null);
      try {
        await apiFetch("/api/admin/directory/verify", {
          method: "POST",
          body: JSON.stringify({ entityType: "FACILITY", entityId: row.id, toStatus, method: t("admin.dir.verifyMethodDefault") }),
        });
        setMessage(`${row.name}: ${toStatus}`);
        await load();
      } catch (err) {
        setMessage(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally { setBusy(null); }
    };

    return (
      <div className="space-y-4">
        <DependentLocationSelects sel={loc.sel} divisions={loc.divisions} districts={loc.districts} upazilas={loc.upazilas}
          onDivision={(v) => void loc.pickDivision(v)} onDistrict={(v) => void loc.pickDistrict(loc.sel.division, v)} onUpazila={(v) => loc.pickUpazila(loc.sel.division, loc.sel.district, v)} />
        {message && <p className="text-sm text-emerald-700">{message}</p>}
        {loadError ? <ErrorNote message={loadError} onRetry={() => void load()} /> : loading ? <LoadingCards count={3} /> : rows.length === 0 ? (
          <EmptyState title={t("common.noResults")} />
        ) : (
          <div className="space-y-2">
            {rows.map((r) => (
              <Card key={r.id} className="p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{locale === "bn" && r.nameBangla ? r.nameBangla : r.name}</p>
                    <p className="text-xs text-muted-foreground">{[r.upazila, r.district].filter(Boolean).join(", ")} · {r.phone ? (r.isPhoneVerified ? t("directory.phoneVerified") : t("directory.phoneUnverified")) : t("directory.phoneUnavailable")} · {t("directory.lastVerified")}: {fmtDate(r.lastVerifiedAt, locale)}</p>
                  </div>
                  <Badge variant={r.verificationStatus === "UNVERIFIED" ? "outline" : "default"} className={STATUS_TONE[r.verificationStatus]}>{t(STATUS_KEY[r.verificationStatus] ?? "directory.st.unver")}</Badge>
                  <select
                    aria-label={t("admin.dir.setStatus")}
                    className="h-8 rounded-md border bg-background px-2 text-xs"
                    value={statusChoice[r.id] ?? ""}
                    onChange={(e) => setStatusChoice((s) => ({ ...s, [r.id]: e.target.value }))}
                  >
                    <option value="">{t("admin.dir.setStatus")}</option>
                    {VERIFICATION_STATUSES.map((s) => <option key={s} value={s}>{t(STATUS_KEY[s] ?? s)}</option>)}
                  </select>
                  <Button size="sm" onClick={() => void verify(r)} disabled={busy === r.id || !statusChoice[r.id]}>
                    <ShieldCheck className="h-3.5 w-3.5 mr-1" /> {t("admin.dir.apply")}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  }

  function ReportsSection() {
    const [rows, setRows] = useState<ReportRow[]>([]);
    const [loading, setLoading] = useState(true);
    const [loadError, setLoadError] = useState<string | null>(null);
    const [notes, setNotes] = useState<Record<string, string>>({});
    const [busy, setBusy] = useState<string | null>(null);

    const load = useCallback(async () => {
      setLoading(true);
      setLoadError(null);
      try { const res = await apiFetch<{ reports: ReportRow[] }>("/api/reports?status=ALL"); setRows(res.reports); }
      catch (err) { setLoadError(err instanceof ApiClientError ? err.message : t("err.generic")); }
      finally { setLoading(false); }
    }, [t]);

    useEffect(() => { void load(); }, [load]);

    const act = async (reportId: string, action: "REVIEWING" | "RESOLVED" | "REJECTED", applyCorrection = false) => {
      setBusy(reportId);
      try {
        await apiFetch("/api/admin/directory/reports", {
          method: "POST",
          body: JSON.stringify({ reportId, action, resolutionNote: notes[reportId], applyCorrection }),
        });
        await load();
      } catch (err) {
        setError(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally { setBusy(null); }
    };

    if (loadError) return <ErrorNote message={loadError} onRetry={() => void load()} />;
    if (loading) return <LoadingCards count={3} />;
    if (rows.length === 0) return <EmptyState title={t("admin.dir.noReports")} icon={<Flag className="h-5 w-5" />} />;
    return (
      <div className="space-y-2">
        {rows.map((r) => (
          <Card key={r.id} className="p-3">
            <div className="flex flex-wrap items-center gap-2 text-sm">
              <Badge variant="outline">{r.entityType === "FACILITY" ? t("admin.dir.entityFacility") : t("admin.dir.entityPharmacy")}</Badge>
              <Badge variant="secondary">{t(REPORT_TYPE_KEY[r.reportType] ?? r.reportType)}</Badge>
              <Badge variant={r.status === "OPEN" ? "default" : "outline"} className={r.status === "OPEN" ? "bg-amber-500 text-white" : ""}>{t(REPORT_STATUS_KEY[r.status] ?? r.status)}</Badge>
              <span className="text-xs text-muted-foreground">{fmtDate(r.createdAt, locale)} · {r.reporterName ?? t("admin.dir.anonymous")}</span>
            </div>
            <p className="mt-1.5 text-sm">{r.message}</p>
            {r.suggestedValue && <p className="mt-0.5 text-xs text-muted-foreground">{t("admin.dir.suggested")}: <span className="font-medium">{r.suggestedValue}</span></p>}
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Input
                className="h-8 flex-1 min-w-[160px] text-xs"
                placeholder={t("admin.dir.resolutionNote")}
                value={notes[r.id] ?? ""}
                onChange={(e) => setNotes((n) => ({ ...n, [r.id]: e.target.value }))}
                aria-label={t("admin.dir.resolutionNote")}
              />
              {r.status === "OPEN" && (
                <Button size="sm" variant="outline" onClick={() => void act(r.id, "REVIEWING")} disabled={busy === r.id}>{t("admin.dir.reviewing")}</Button>
              )}
              {r.suggestedValue && (r.reportType === "WRONG_PHONE" || r.reportType === "WRONG_ADDRESS") && (
                <Button size="sm" onClick={() => void act(r.id, "RESOLVED", true)} disabled={busy === r.id}>{t("admin.dir.resolveApply")}</Button>
              )}
              <Button size="sm" variant="outline" onClick={() => void act(r.id, "RESOLVED")} disabled={busy === r.id}>{t("admin.dir.resolve")}</Button>
              <Button size="sm" variant="ghost" onClick={() => void act(r.id, "REJECTED")} disabled={busy === r.id}>{t("admin.dir.reject")}</Button>
            </div>
          </Card>
        ))}
      </div>
    );
  }

  function ImportSection() {
    const [entityType, setEntityType] = useState<"FACILITY" | "PHARMACY">("FACILITY");
    const [sourceType, setSourceType] = useState("CSV");
    const [format, setFormat] = useState<"CSV" | "JSON">("CSV");
    const [fileName, setFileName] = useState("");
    const [content, setContent] = useState("");
    const [busy, setBusy] = useState(false);
    const [result, setResult] = useState<string | null>(null);
    const [jobs, setJobs] = useState<JobRow[]>([]);

    const loadJobs = useCallback(async () => {
      try { const res = await apiFetch<{ jobs: JobRow[] }>("/api/admin/directory/import"); setJobs(res.jobs); }
      catch { /* ignore */ }
    }, []);
    useEffect(() => { void loadJobs(); }, [loadJobs]);

    const run = async () => {
      setBusy(true);
      setResult(null);
      try {
        const res = await apiFetch<{ job: { status: string; totalRows: number; importedRows: number; duplicateRows: number; errorRows: number } }>("/api/admin/directory/import", {
          method: "POST",
          body: JSON.stringify({ entityType, sourceType, format, fileName: fileName || undefined, content }),
        });
        setResult(`${t("admin.dir.jobStatus." + res.job.status.toLowerCase(), { imported: res.job.importedRows, total: res.job.totalRows })} · ${res.job.duplicateRows} ${t("admin.dir.dup")} · ${res.job.errorRows} ${t("admin.dir.err")}`);
        await loadJobs();
      } catch (err) {
        setResult(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally { setBusy(false); }
    };

    return (
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="p-4 space-y-3">
          <h3 className="flex items-center gap-1.5 text-sm font-semibold"><Upload className="h-4 w-4" /> {t("admin.dir.importTitle")}</h3>
          <div className="flex gap-2">
            <div className="flex gap-1">
              {(["FACILITY", "PHARMACY"] as const).map((k) => (
                <Button key={k} size="sm" variant={entityType === k ? "default" : "outline"} onClick={() => setEntityType(k)}>{k}</Button>
              ))}
            </div>
            <div className="flex gap-1">
              {(["CSV", "JSON"] as const).map((k) => (
                <Button key={k} size="sm" variant={format === k ? "default" : "outline"} onClick={() => setFormat(k)}>{k}</Button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label htmlFor="imp-source">{t("admin.dir.sourceType")}</Label>
              <select id="imp-source" className="h-9 w-full rounded-md border bg-background px-2 text-sm" value={sourceType} onChange={(e) => setSourceType(e.target.value)}>
                {["CSV", "DGHS", "GOOGLE_PLACES", "EXCEL", "JSON", "MANUAL"].map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="imp-file">{t("admin.dir.fileName")}</Label>
              <Input id="imp-file" value={fileName} onChange={(e) => setFileName(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="imp-content">{t("admin.dir.contentLabel")}</Label>
            <Textarea id="imp-content" rows={7} value={content} onChange={(e) => setContent(e.target.value)} className="font-mono text-xs" placeholder={format === "CSV" ? "name,type,district,upazila,address,phone" : '[{"name":"…","district":"…"}]'} />
          </div>
          <Button size="sm" onClick={() => void run()} disabled={busy || !content.trim()}> <Upload className="h-4 w-4 mr-1" /> {t("admin.dir.importRun")}</Button>
          {result && <p className="text-sm text-emerald-700">{result}</p>}
          <p className="text-xs text-muted-foreground">{t("admin.dir.importNote")}</p>
        </Card>

        <Card className="p-4">
          <h3 className="mb-3 text-sm font-semibold">{t("admin.dir.recentJobs")}</h3>
          {jobs.length === 0 ? (
            <p className="py-4 text-sm text-muted-foreground">{t("admin.dir.noJobs")}</p>
          ) : (
            <div className="max-h-[380px] space-y-2 overflow-y-auto pr-1">
              {jobs.map((j) => (
                <div key={j.id} className="rounded-lg border p-2.5 text-xs">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge variant="secondary">{j.entityType === "FACILITY" ? t("admin.dir.entityFacility") : t("admin.dir.entityPharmacy")}</Badge>
                    <Badge variant="outline">{j.sourceType}</Badge>
                    <Badge variant={j.status === "COMPLETED" ? "default" : j.status === "FAILED" ? "destructive" : "outline"}>{j.status}</Badge>
                    <span className="text-muted-foreground">{fmtDate(j.createdAt, locale)}</span>
                  </div>
                  <p className="mt-1 tabular-nums">{j.importedRows}/{j.totalRows} · {j.duplicateRows} {t("admin.dir.dup")} · {j.errorRows} {t("admin.dir.err")}</p>
                  {j.errors.slice(0, 2).map((e) => (
                    <p key={e.rowNumber} className="text-destructive">#{e.rowNumber}: {e.message}</p>
                  ))}
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    );
  }
}
