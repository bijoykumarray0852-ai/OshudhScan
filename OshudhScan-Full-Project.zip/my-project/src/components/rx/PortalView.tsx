"use client";
// Pharmacy Portal 2.0:
//  - Signed-in owners get REAL management: registration, inventory (batches +
//    expiry + expired-block), sales (with stock decrement), staff, branches,
//    suppliers, verification, analytics.
//  - The original demo experience (leads inbox, demo stock toggles, ROI
//    calculator) is preserved below for everyone.
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowUpRight, BellRing, Building2, Calculator, CheckCheck, ClipboardList,
  PackageSearch, ShieldAlert, Timer, Package, Receipt, Users as UsersIcon,
  GitBranch, Truck, ShieldCheck, BarChart3, Plus,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAppStore } from "@/lib/store";
import { useI18n } from "@/hooks/use-i18n";
import { computeRoi, PRO_PRICE_BDT, ROI_DEFAULTS, type RoiInputs } from "@/lib/finance";
import { DRUG_DB } from "@/lib/drug-db";
import { useToast } from "@/hooks/use-toast";
import {
  apiFetch, ApiClientError, LoadingCards, ErrorNote, EmptyState, StatCard, fmtBdt, fmtDate,
} from "@/components/rx/shared";
import { useRequireAuth } from "@/components/rx/shared";

function kpi(label: string, value: string, sub: string, tone: "emerald" | "amber" | "slate" = "emerald") {
  const toneClass = { emerald: "text-emerald-700", amber: "text-amber-600", slate: "text-slate-700" }[tone];
  return (
    <Card>
      <CardContent className="p-4">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={`mt-1 text-2xl font-bold ${toneClass}`}>{value}</p>
        <p className="mt-0.5 text-[11px] text-muted-foreground">{sub}</p>
      </CardContent>
    </Card>
  );
}

interface MyPharmacy { id: string; name: string; status: string; isVerified: boolean; isDemo: boolean; staffRole: string }

export function PortalView() {
  const { t } = useI18n();
  const { user } = useRequireAuth();
  const [myPharmacies, setMyPharmacies] = useState<MyPharmacy[]>([]);
  const [loadingPh, setLoadingPh] = useState(true);

  useEffect(() => {
    void (async () => {
      try {
        const res = await apiFetch<{ pharmacies: MyPharmacy[] }>("/api/auth/me");
        setMyPharmacies(res.pharmacies ?? []);
      } finally {
        setLoadingPh(false);
      }
    })();
  }, []);

  return (
    <div className="space-y-10">
      <header className="space-y-2">
        <Badge variant="outline" className="border-emerald-300 bg-emerald-50 text-emerald-800">
          <Building2 className="mr-1.5 h-3.5 w-3.5" /> {t("portal.title")}
        </Badge>
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("portal.subtitle")}</h2>
      </header>

      {loadingPh ? (
        <LoadingCards count={2} />
      ) : user ? (
        <PharmacyManager pharmacies={myPharmacies} />
      ) : (
        <EmptyState title={t("portal.register")} hint={t("portal.registerDesc")} />
      )}

      {/* ── preserved demo experience ── */}
      <DemoExperience />

      {/* Deep link */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-muted/40 p-4">
        <p className="text-sm text-muted-foreground">
          {t("portal.comparePlans")}
        </p>
        <Button variant="outline" onClick={() => useAppStore.getState().setView("pricing")}>
          {t("portal.seePricing")} <ArrowUpRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

// ── real pharmacy management ──────────────────────────────────────────────────

interface InvRow {
  id: string; medicineId: string; brand: string; generic: string; strength: string | null; form: string;
  batchNumber: string | null; mfgDate: string | null; expiryDate: string | null;
  purchasePrice: number | null; sellingPrice: number | null; quantity: number; lowStockThreshold: number;
  status: string; expired: boolean; expiringIn90Days: boolean; stockStatus: string; updatedAt: string;
}
interface SaleRow { id: string; invoiceNo: string; items: { label: string; quantity: number; unitPrice: number }[]; totalBdt: number; soldAt: string }
interface StaffRow { id: string; role: string; userId: string; name: string; email: string }
interface BranchRow { id: string; name: string; addressLine: string; district: string; phone: string | null; isMain: boolean }
interface SupplierRow { id: string; name: string; contactPerson: string | null; phone: string | null; email: string | null }
interface VerifResp { status: string; isVerified: boolean; requests: { id: string; licenseNumber: string; licenseType: string; status: string; reviewNote: string | null; submittedAt: string }[] }
interface AnalyticsResp {
  daily: { date: string; revenue: number; count: number }[];
  month: { revenue: number; count: number };
  leads: { total: number; newCount: number; accepted: number; acceptRate: number };
  inventory: { stocked: number; lowStock: { brand: string; strength: string | null; quantity: number }[]; outOfStock: { brand: string; strength: string | null }[]; expiringSoon: { brand: string; strength: string | null; expiryDate: string; batch: string | null; quantity: number }[]; expired: { brand: string; strength: string | null; expiryDate: string; batch: string | null }[] };
}

function PharmacyManager({ pharmacies }: { pharmacies: MyPharmacy[] }) {
  const { t, locale } = useI18n();
  const { toast } = useToast();
  const [pharmacyId, setPharmacyId] = useState<string | null>(pharmacies[0]?.id ?? null);
  const [tab, setTab] = useState("inventory");
  const [error, setError] = useState<string | null>(null);

  const [inventory, setInventory] = useState<InvRow[]>([]);
  const [medOptions, setMedOptions] = useState<{ id: string; brand: string; strength: string | null }[]>([]);
  const [sales, setSales] = useState<{ sales: SaleRow[]; today: { revenue: number; count: number }; month: { revenue: number; count: number } } | null>(null);
  const [staff, setStaff] = useState<StaffRow[]>([]);
  const [branches, setBranches] = useState<BranchRow[]>([]);
  const [suppliers, setSuppliers] = useState<SupplierRow[]>([]);
  const [verif, setVerif] = useState<VerifResp | null>(null);
  const [analytics, setAnalytics] = useState<AnalyticsResp | null>(null);
  const [reservations, setReservations] = useState<{ id: string; medicineLabel: string; quantity: number; status: string; requesterName: string; requesterPhone: string; createdAt: string }[]>([]);
  const [reloadKey, setReloadKey] = useState(0);

  const reload = () => setReloadKey((k) => k + 1);

  useEffect(() => {
    if (!pharmacyId) return;
    let cancelled = false;
    void (async () => {
      try {
        const [inv, meds, sal, stf, br, sup, vf, an, rs] = await Promise.all([
          apiFetch<{ inventory: InvRow[] }>(`/api/pharmacies/${pharmacyId}/inventory`),
          apiFetch<{ medicines: { id: string; brand: string; strength: string | null }[] }>("/api/medicines"),
          apiFetch<{ sales: SaleRow[]; today: { revenue: number; count: number }; month: { revenue: number; count: number } }>(`/api/pharmacies/${pharmacyId}/sales`).catch(() => null),
          apiFetch<{ staff: StaffRow[] }>(`/api/pharmacies/${pharmacyId}/staff`),
          apiFetch<{ branches: BranchRow[] }>(`/api/pharmacies/${pharmacyId}/branches`).catch(() => null),
          apiFetch<{ suppliers: SupplierRow[] }>(`/api/pharmacies/${pharmacyId}/suppliers`).catch(() => null),
          apiFetch<VerifResp>(`/api/pharmacies/${pharmacyId}/verify`),
          apiFetch<AnalyticsResp>(`/api/analytics/pharmacy?pharmacyId=${pharmacyId}`).catch(() => null),
          apiFetch<{ reservations: typeof reservations }>(`/api/reservations?pharmacyId=${pharmacyId}`),
        ]);
        if (cancelled) return;
        setInventory(inv.inventory);
        setMedOptions(meds.medicines);
        if (sal) setSales(sal);
        setStaff(stf.staff);
        if (br) setBranches(br.branches);
        if (sup) setSuppliers(sup.suppliers);
        setVerif(vf);
        if (an) setAnalytics(an);
        setReservations(rs.reservations);
      } catch (err) {
        if (!cancelled) setError(err instanceof ApiClientError ? err.message : t("err.generic"));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [pharmacyId, reloadKey, t]);

  if (pharmacies.length === 0) return <RegistrationForm />;
  const pharmacy = pharmacies.find((p) => p.id === pharmacyId) ?? pharmacies[0];
  const lowStockCount = inventory.filter((i) => i.quantity <= i.lowStockThreshold && !i.expired).length;
  const expiredCount = inventory.filter((i) => i.expired).length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <select
          className="h-9 rounded-md border bg-background px-2 text-sm"
          value={pharmacyId ?? ""}
          onChange={(e) => setPharmacyId(e.target.value)}
          aria-label={t("portal.selectPharmacy")}
        >
          {pharmacies.map((p) => (
            <option key={p.id} value={p.id}>{p.isDemo ? t("portal.demoOption", { name: p.name }) : p.name}</option>
          ))}
        </select>
        {pharmacy.isVerified ? (
          <Badge className="bg-teal-600 text-white"><ShieldCheck className="h-3 w-3 mr-1" />{t("portal.verifiedBadge")}</Badge>
        ) : (
          <Badge variant="secondary">{t("portal.pendingReview")}</Badge>
        )}
      </div>

      {error && <ErrorNote message={error} onRetry={reload} />}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label={t("portal.kpiLeads")} value={analytics?.leads.newCount ?? 0} icon={<BellRing className="h-4 w-4" />} />
        <StatCard label={t("portal.kpiStocked")} value={analytics?.inventory.stocked ?? inventory.length} hint={t("portal.lowStockCount", { count: lowStockCount })} icon={<Package className="h-4 w-4" />} />
        <StatCard label={t("portal.kpiRevenue")} value={fmtBdt(analytics?.month.revenue ?? sales?.month.revenue ?? 0)} icon={<Receipt className="h-4 w-4" />} />
        <StatCard label={t("portal.expired")} value={expiredCount} hint={expiredCount > 0 ? t("portal.expiryReport") : undefined} icon={<ShieldAlert className="h-4 w-4" />} />
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex flex-wrap h-auto gap-1 w-full justify-start">
          <TabsTrigger value="inventory">{t("portal.inventory")}</TabsTrigger>
          <TabsTrigger value="sales">{t("portal.sales")}</TabsTrigger>
          <TabsTrigger value="reservations">{t("notif.reservation")} ({reservations.filter((r) => r.status === "NEW").length})</TabsTrigger>
          <TabsTrigger value="staff">{t("portal.staff")}</TabsTrigger>
          <TabsTrigger value="branches">{t("portal.branches")}</TabsTrigger>
          <TabsTrigger value="suppliers">{t("portal.suppliers")}</TabsTrigger>
          <TabsTrigger value="verification">{t("portal.verification")}</TabsTrigger>
          <TabsTrigger value="analytics">{t("portal.analytics")}</TabsTrigger>
        </TabsList>

        {/* Inventory */}
        <TabsContent value="inventory" className="mt-4">
          <InventoryTab inventory={inventory} medOptions={medOptions} pharmacyId={pharmacyId!} reload={reload} />
        </TabsContent>

        {/* Sales */}
        <TabsContent value="sales" className="mt-4">
          <SalesTab pharmacyId={pharmacyId!} sales={sales} reload={reload} />
        </TabsContent>

        {/* Reservations */}
        <TabsContent value="reservations" className="mt-4 space-y-2">
          {reservations.length === 0 ? (
            <EmptyState title={t("common.empty")} hint={t("find.reserveDesc")} />
          ) : (
            reservations.map((r) => (
              <Card key={r.id} className="p-3 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-medium text-sm">{r.medicineLabel} × {r.quantity}</p>
                  <p className="text-xs text-muted-foreground">{r.requesterName} · {r.requesterPhone} · {fmtDate(r.createdAt, locale)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={r.status === "NEW" ? "secondary" : "default"}>{r.status}</Badge>
                  {r.status === "NEW" && (
                    <div className="flex gap-1.5">
                      <Button size="sm" onClick={async () => { await apiFetch("/api/reservations", { method: "PATCH", body: JSON.stringify({ reservationId: r.id, status: "CONFIRMED" }) }); reload(); }}>
                        {t("common.confirm")}
                      </Button>
                      <Button size="sm" variant="ghost" onClick={async () => { await apiFetch("/api/reservations", { method: "PATCH", body: JSON.stringify({ reservationId: r.id, status: "DECLINED" }) }); reload(); }}>
                        {t("common.cancel")}
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            ))
          )}
        </TabsContent>

        {/* Staff */}
        <TabsContent value="staff" className="mt-4">
          <StaffTab pharmacyId={pharmacyId!} staff={staff} reload={reload} />
        </TabsContent>

        {/* Branches */}
        <TabsContent value="branches" className="mt-4">
          <BranchesTab pharmacyId={pharmacyId!} branches={branches} reload={reload} />
        </TabsContent>

        {/* Suppliers */}
        <TabsContent value="suppliers" className="mt-4">
          <SuppliersTab pharmacyId={pharmacyId!} suppliers={suppliers} reload={reload} />
        </TabsContent>

        {/* Verification */}
        <TabsContent value="verification" className="mt-4">
          <VerificationTab pharmacyId={pharmacyId!} verif={verif} reload={reload} />
        </TabsContent>

        {/* Analytics */}
        <TabsContent value="analytics" className="mt-4">
          {analytics ? (
            <div className="grid gap-3 md:grid-cols-2">
              <Card className="p-4">
                <h3 className="font-semibold text-sm mb-2">{t("portal.dailySales")} (14d)</h3>
                <div className="flex items-end gap-1 h-24">
                  {analytics.daily.map((d) => (
                    <div key={d.date} className="flex-1" title={`${d.date}: ${fmtBdt(d.revenue)}`}>
                      <div className="w-full bg-emerald-600/80 rounded-t" style={{ height: `${Math.max(2, (d.revenue / Math.max(1, ...analytics.daily.map((x) => x.revenue))) * 100)}%` }} />
                    </div>
                  ))}
                </div>
              </Card>
              <Card className="p-4">
                <h3 className="font-semibold text-sm mb-2">{t("portal.lowStockItems")}</h3>
                {analytics.inventory.lowStock.length === 0 ? (
                  <p className="text-sm text-muted-foreground">{t("common.empty")}</p>
                ) : (
                  <ul className="text-sm space-y-1">
                    {analytics.inventory.lowStock.map((i, idx) => (
                      <li key={idx} className="flex justify-between"><span>{i.brand} {i.strength}</span><Badge variant="secondary">{i.quantity}</Badge></li>
                    ))}
                  </ul>
                )}
              </Card>
              <Card className="p-4 md:col-span-2">
                <h3 className="font-semibold text-sm mb-2">{t("portal.expiryReport")}</h3>
                {analytics.inventory.expiringSoon.length === 0 && analytics.inventory.expired.length === 0 ? (
                  <p className="text-sm text-muted-foreground">{t("common.empty")}</p>
                ) : (
                  <div className="grid gap-2 sm:grid-cols-2">
                    <div>
                      <p className="text-xs font-medium text-amber-600 mb-1">{t("portal.expiringSoon")}</p>
                      {analytics.inventory.expiringSoon.map((i, idx) => (
                        <p key={idx} className="text-sm">{i.brand} {i.strength} — {fmtDate(i.expiryDate, locale)} (batch {i.batch ?? "—"})</p>
                      ))}
                    </div>
                    <div>
                      <p className="text-xs font-medium text-red-600 mb-1">{t("portal.expired")}</p>
                      {analytics.inventory.expired.map((i, idx) => (
                        <p key={idx} className="text-sm">{i.brand} {i.strength} — {fmtDate(i.expiryDate, locale)}</p>
                      ))}
                    </div>
                  </div>
                )}
              </Card>
            </div>
          ) : (
            <LoadingCards />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

// inventory CRUD
function InventoryTab({ inventory, medOptions, pharmacyId, reload }: {
  inventory: InvRow[]; medOptions: { id: string; brand: string; strength: string | null }[]; pharmacyId: string; reload: () => void;
}) {
  const { t } = useI18n();
  const { toast } = useToast();
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ medicineId: "", batchNumber: "", mfgDate: "", expiryDate: "", purchasePrice: "", sellingPrice: "", quantity: "0" });
  const [busy, setBusy] = useState(false);

  const add = async () => {
    setBusy(true);
    try {
      await apiFetch(`/api/pharmacies/${pharmacyId}/inventory`, {
        method: "POST",
        body: JSON.stringify({
          medicineId: form.medicineId,
          batchNumber: form.batchNumber || undefined,
          mfgDate: form.mfgDate || undefined,
          expiryDate: form.expiryDate || undefined,
          purchasePrice: form.purchasePrice ? Number(form.purchasePrice) : undefined,
          sellingPrice: form.sellingPrice ? Number(form.sellingPrice) : undefined,
          quantity: Number(form.quantity || 0),
        }),
      });
      toast({ title: t("portal.invAdded") });
      setShowAdd(false);
      setForm({ medicineId: "", batchNumber: "", mfgDate: "", expiryDate: "", purchasePrice: "", sellingPrice: "", quantity: "0" });
      await reload();
    } catch (err) {
      toast({ title: err instanceof ApiClientError ? err.message : t("err.generic"), variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const setQty = async (row: InvRow, quantity: number) => {
    try {
      await apiFetch(`/api/pharmacies/${pharmacyId}/inventory`, {
        method: "PATCH",
        body: JSON.stringify({ inventoryId: row.id, quantity }),
      });
      await reload();
    } catch (err) {
      toast({ title: err instanceof ApiClientError ? err.message : t("err.generic"), variant: "destructive" });
    }
  };

  const remove = async (row: InvRow) => {
    if (!window.confirm(t("common.confirmDelete"))) return;
    await apiFetch(`/api/pharmacies/${pharmacyId}/inventory?inventoryId=${row.id}`, { method: "DELETE" });
    await reload();
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">{t("portal.expiredBlock")}</p>
        <Button size="sm" onClick={() => setShowAdd((v) => !v)}><Plus className="h-4 w-4 mr-1" />{t("portal.addMedicine")}</Button>
      </div>

      {showAdd && (
        <Card className="p-4 space-y-3">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1 sm:col-span-2">
              <Label>{t("common.medicine")}</Label>
              <select className="h-9 w-full rounded-md border bg-background px-2 text-sm" value={form.medicineId} onChange={(e) => setForm({ ...form, medicineId: e.target.value })}>
                <option value="">{t("common.select")}</option>
                {medOptions.map((m) => <option key={m.id} value={m.id}>{m.brand} {m.strength ?? ""}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <Label>{t("portal.batch")}</Label>
              <Input value={form.batchNumber} onChange={(e) => setForm({ ...form, batchNumber: e.target.value })} />
            </div>
            <div className="space-y-1">
              <Label>{t("portal.mfg")}</Label>
              <Input type="date" value={form.mfgDate} onChange={(e) => setForm({ ...form, mfgDate: e.target.value })} />
            </div>
            <div className="space-y-1">
              <Label>{t("portal.expiry")}</Label>
              <Input type="date" value={form.expiryDate} onChange={(e) => setForm({ ...form, expiryDate: e.target.value })} />
            </div>
            <div className="space-y-1">
              <Label>{t("common.quantity")}</Label>
              <Input type="number" min={0} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
            </div>
            <div className="space-y-1">
              <Label>{t("portal.purchasePrice")}</Label>
              <Input type="number" min={0} value={form.purchasePrice} onChange={(e) => setForm({ ...form, purchasePrice: e.target.value })} />
            </div>
            <div className="space-y-1">
              <Label>{t("portal.sellingPrice")}</Label>
              <Input type="number" min={0} value={form.sellingPrice} onChange={(e) => setForm({ ...form, sellingPrice: e.target.value })} />
            </div>
          </div>
          <Button size="sm" onClick={() => void add()} disabled={busy || !form.medicineId}>{busy ? t("common.loading") : t("common.save")}</Button>
        </Card>
      )}

      <div className="overflow-x-auto rounded-lg border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left">
            <tr>
              <th className="px-3 py-2 font-medium">{t("common.medicine")}</th>
              <th className="px-3 py-2 font-medium">{t("portal.batch")}</th>
              <th className="px-3 py-2 font-medium">{t("portal.expiry")}</th>
              <th className="px-3 py-2 font-medium">{t("common.quantity")}</th>
              <th className="px-3 py-2 font-medium">{t("common.price")}</th>
              <th className="px-3 py-2 font-medium">{t("common.status")}</th>
              <th className="px-3 py-2" />
            </tr>
          </thead>
          <tbody className="divide-y">
            {inventory.map((row) => (
              <tr key={row.id} className={row.expired ? "bg-red-50/60 dark:bg-red-950/20" : row.quantity <= row.lowStockThreshold ? "bg-amber-50/60 dark:bg-amber-950/10" : ""}>
                <td className="px-3 py-2">
                  <p className="font-medium">{row.brand} {row.strength}</p>
                  <p className="text-xs text-muted-foreground">{row.generic}</p>
                </td>
                <td className="px-3 py-2 text-muted-foreground">{row.batchNumber ?? "—"}</td>
                <td className="px-3 py-2 text-muted-foreground">{fmtDate(row.expiryDate)}</td>
                <td className="px-3 py-2">
                  <Input
                    type="number"
                    min={0}
                    defaultValue={row.quantity}
                    className="h-8 w-20"
                    onBlur={(e) => {
                      const v = parseInt(e.target.value, 10);
                      if (!Number.isNaN(v) && v !== row.quantity) void setQty(row, v);
                    }}
                    disabled={row.expired}
                    aria-label={t("common.quantity")}
                  />
                </td>
                <td className="px-3 py-2">{fmtBdt(row.sellingPrice)}</td>
                <td className="px-3 py-2">
                  {row.expired ? <Badge className="bg-red-700 text-white">{t("portal.expired")}</Badge>
                    : row.expiringIn90Days ? <Badge className="bg-amber-500 text-white">{t("portal.expiringSoon")}</Badge>
                    : row.quantity <= row.lowStockThreshold ? <Badge variant="secondary">{t("portal.lowStockWarn")}</Badge>
                    : <Badge variant="outline">{t("portal.stockOk")}</Badge>}
                </td>
                <td className="px-3 py-2">
                  <Button size="sm" variant="ghost" onClick={() => void remove(row)} aria-label={t("common.delete")}>{t("common.delete")}</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// sales
function SalesTab({ pharmacyId, sales, reload }: { pharmacyId: string; sales: { sales: SaleRow[]; today: { revenue: number; count: number }; month: { revenue: number; count: number } } | null; reload: () => void }) {
  const { t, locale } = useI18n();
  const { toast } = useToast();
  const [show, setShow] = useState(false);
  const [lines, setLines] = useState([{ inventoryId: "", label: "", quantity: "1", unitPrice: "0" }]);

  const record = async () => {
    const valid = lines.filter((l) => l.inventoryId && Number(l.quantity) > 0);
    try {
      for (const l of valid) {
        const inv = await apiFetch<{ inventory: Array<{ id: string; medicineId: string; brand: string; sellingPrice: number | null }> }>(`/api/pharmacies/${pharmacyId}/inventory`);
        const row = inv.inventory.find((x) => x.id === l.inventoryId);
        if (!row) continue;
        await apiFetch(`/api/pharmacies/${pharmacyId}/sales`, {
          method: "POST",
          body: JSON.stringify({
            items: [{ medicineId: row.medicineId, label: l.label || row.brand, quantity: Number(l.quantity), unitPrice: Number(l.unitPrice) || row.sellingPrice || 0 }],
          }),
        });
      }
      toast({ title: t("portal.saleRecorded") });
      setShow(false);
      setLines([{ inventoryId: "", label: "", quantity: "1", unitPrice: "0" }]);
      await reload();
    } catch (err) {
      toast({ title: err instanceof ApiClientError ? err.message : t("err.generic"), variant: "destructive" });
    }
  };

  const invRows = useMemo(() => sales?.sales ?? [], [sales]);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="grid grid-cols-2 gap-3">
          <StatCard label={t("portal.dailySales")} value={fmtBdt(sales?.today.revenue ?? 0)} hint={t("portal.salesCount", { count: sales?.today.count ?? 0 })} />
          <StatCard label={t("portal.monthlySales")} value={fmtBdt(sales?.month.revenue ?? 0)} hint={t("portal.salesCount", { count: sales?.month.count ?? 0 })} />
        </div>
        <Button size="sm" onClick={() => setShow((v) => !v)}><Receipt className="h-4 w-4 mr-1" />{t("portal.recordSale")}</Button>
      </div>

      {show && (
        <Card className="p-4 space-y-3">
          {lines.map((l, i) => (
            <SaleLine key={i} line={l} pharmacyId={pharmacyId} onChange={(next) => setLines((cur) => cur.map((x, j) => (j === i ? next : x)))} />
          ))}
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setLines((cur) => [...cur, { inventoryId: "", label: "", quantity: "1", unitPrice: "0" }])}>
              <Plus className="h-4 w-4 mr-1" />{t("common.add")}
            </Button>
            <Button size="sm" onClick={() => void record()}>{t("common.save")}</Button>
          </div>
        </Card>
      )}

      {invRows.length === 0 ? (
        <EmptyState title={t("portal.noSales")} />
      ) : (
        <div className="space-y-2">
          {invRows.map((s) => (
            <Card key={s.id} className="p-3 flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-medium text-sm">{s.invoiceNo}</p>
                <p className="text-xs text-muted-foreground">{s.items.map((i) => `${i.label}×${i.quantity}`).join(" · ")} · {fmtDate(s.soldAt, locale)}</p>
              </div>
              <span className="font-semibold">{fmtBdt(s.totalBdt)}</span>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function SaleLine({ line, pharmacyId, onChange }: { line: { inventoryId: string; label: string; quantity: string; unitPrice: string }; pharmacyId: string; onChange: (l: { inventoryId: string; label: string; quantity: string; unitPrice: string }) => void }) {
  const { t } = useI18n();
  const [rows, setRows] = useState<InvRow[]>([]);
  useEffect(() => {
    void (async () => {
      const res = await apiFetch<{ inventory: InvRow[] }>(`/api/pharmacies/${pharmacyId}/inventory`);
      setRows(res.inventory.filter((r) => !r.expired && r.quantity > 0));
    })();
  }, [pharmacyId]);
  return (
    <div className="grid grid-cols-3 gap-2">
      <select className="h-9 rounded-md border bg-background px-2 text-sm col-span-2" value={line.inventoryId} onChange={(e) => {
        const row = rows.find((r) => r.id === e.target.value);
        onChange({ ...line, inventoryId: e.target.value, label: row ? `${row.brand} ${row.strength ?? ""}` : "", unitPrice: row?.sellingPrice?.toString() ?? "0" });
      }}>
        <option value="">{t("common.select")}</option>
        {rows.map((r) => <option key={r.id} value={r.id}>{r.brand} {r.strength} ({r.quantity})</option>)}
      </select>
      <Input type="number" min={1} value={line.quantity} onChange={(e) => onChange({ ...line, quantity: e.target.value })} aria-label={t("common.quantity")} />
    </div>
  );
}

// staff / branches / suppliers / verification / registration
function StaffTab({ pharmacyId, staff, reload }: { pharmacyId: string; staff: StaffRow[]; reload: () => void }) {
  const { t } = useI18n();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("PHARMACIST");
  const roleLabels: Record<string, string> = {
    OWNER: t("portal.roleOwner"),
    PHARMACIST: t("portal.rolePharmacist"),
    MANAGER: t("portal.roleManager"),
    INVENTORY_STAFF: t("portal.roleInventory"),
  };
  const add = async () => {
    try {
      await apiFetch(`/api/pharmacies/${pharmacyId}/staff`, { method: "POST", body: JSON.stringify({ email, role }) });
      toast({ title: t("portal.staffAdded") });
      setEmail("");
      await reload();
    } catch (err) {
      toast({ title: err instanceof ApiClientError ? err.message : t("err.generic"), variant: "destructive" });
    }
  };
  return (
    <div className="space-y-3">
      <Card className="p-4 flex flex-wrap items-end gap-3">
        <div className="space-y-1"><Label htmlFor="st-email">{t("common.email")}</Label><Input id="st-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div className="space-y-1">
          <Label>{t("portal.staffRole")}</Label>
          <select className="h-9 rounded-md border bg-background px-2 text-sm" value={role} onChange={(e) => setRole(e.target.value)}>
            {["PHARMACIST", "MANAGER", "INVENTORY_STAFF"].map((r) => <option key={r} value={r}>{roleLabels[r]}</option>)}
          </select>
        </div>
        <Button size="sm" onClick={() => void add()} disabled={!email}><UsersIcon className="h-4 w-4 mr-1" />{t("portal.addStaff")}</Button>
      </Card>
      <div className="space-y-2">
        {staff.map((s) => (
          <Card key={s.id} className="p-3 flex items-center justify-between">
            <div><p className="text-sm font-medium">{s.name}</p><p className="text-xs text-muted-foreground">{s.email}</p></div>
            <Badge variant="secondary">{roleLabels[s.role] ?? s.role}</Badge>
          </Card>
        ))}
      </div>
    </div>
  );
}

function BranchesTab({ pharmacyId, branches, reload }: { pharmacyId: string; branches: BranchRow[]; reload: () => void }) {
  const { t } = useI18n();
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [district, setDistrict] = useState("Dhaka");
  const add = async () => {
    await apiFetch(`/api/pharmacies/${pharmacyId}/branches`, { method: "POST", body: JSON.stringify({ name, addressLine: address, district }) });
    setName(""); setAddress("");
    await reload();
  };
  return (
    <div className="space-y-3">
      <Card className="p-4 flex flex-wrap items-end gap-3">
        <div className="space-y-1"><Label>{t("common.name")}</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div className="space-y-1"><Label>{t("common.address")}</Label><Input value={address} onChange={(e) => setAddress(e.target.value)} /></div>
        <div className="space-y-1"><Label>{t("common.district")}</Label><Input value={district} onChange={(e) => setDistrict(e.target.value)} className="w-28" /></div>
        <Button size="sm" onClick={() => void add()} disabled={!name || !address}><GitBranch className="h-4 w-4 mr-1" />{t("portal.addBranch")}</Button>
      </Card>
      <div className="space-y-2">
        {branches.map((b) => (
          <Card key={b.id} className="p-3 flex items-center justify-between">
            <div><p className="text-sm font-medium">{b.name} {b.isMain && <Badge className="ml-1">{t("portal.mainBranch")}</Badge>}</p><p className="text-xs text-muted-foreground">{b.addressLine}</p></div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function SuppliersTab({ pharmacyId, suppliers, reload }: { pharmacyId: string; suppliers: SupplierRow[]; reload: () => void }) {
  const { t } = useI18n();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const add = async () => {
    await apiFetch(`/api/pharmacies/${pharmacyId}/suppliers`, { method: "POST", body: JSON.stringify({ name, phone: phone || undefined }) });
    setName(""); setPhone("");
    await reload();
  };
  return (
    <div className="space-y-3">
      <Card className="p-4 flex flex-wrap items-end gap-3">
        <div className="space-y-1"><Label>{t("common.name")}</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div className="space-y-1"><Label>{t("common.phone")}</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
        <Button size="sm" onClick={() => void add()} disabled={!name}><Truck className="h-4 w-4 mr-1" />{t("portal.addSupplier")}</Button>
      </Card>
      <div className="space-y-2">
        {suppliers.map((s) => (
          <Card key={s.id} className="p-3 flex items-center justify-between">
            <p className="text-sm font-medium">{s.name}</p>
            <p className="text-xs text-muted-foreground">{s.phone ?? "—"}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}

function VerificationTab({ pharmacyId, verif, reload }: { pharmacyId: string; verif: VerifResp | null; reload: () => void }) {
  const { t, locale } = useI18n();
  const { toast } = useToast();
  const [licenseNumber, setLicenseNumber] = useState(verif?.requests[0]?.licenseNumber ?? "");
  const [licenseType, setLicenseType] = useState("RETAIL");
  const licenseLabels: Record<string, string> = {
    RETAIL: t("portal.licenseType.RETAIL"),
    WHOLESALE: t("portal.licenseType.WHOLESALE"),
    RETAIL_WHOLESALE: t("portal.licenseType.RETAIL_WHOLESALE"),
  };
  const submit = async () => {
    try {
      await apiFetch(`/api/pharmacies/${pharmacyId}/verify`, {
        method: "POST",
        body: JSON.stringify({ licenseNumber, licenseType }),
      });
      toast({ title: t("portal.registered") });
      await reload();
    } catch (err) {
      toast({ title: err instanceof ApiClientError ? err.message : t("err.generic"), variant: "destructive" });
    }
  };
  if (!verif) return <LoadingCards />;
  return (
    <div className="space-y-3">
      <Card className="p-4 flex items-center justify-between">
        <div>
          <p className="font-medium text-sm">{t("portal.verification")}</p>
          <p className="text-xs text-muted-foreground">{t("portal.registerDesc")}</p>
        </div>
        <Badge variant={verif.status === "VERIFIED" ? "default" : verif.status === "REJECTED" ? "destructive" : "secondary"}>{verif.status}</Badge>
      </Card>
      {verif.status !== "VERIFIED" && (
        <Card className="p-4 flex flex-wrap items-end gap-3">
          <div className="space-y-1"><Label>{t("portal.licenseNumber")}</Label><Input value={licenseNumber} onChange={(e) => setLicenseNumber(e.target.value)} /></div>
          <div className="space-y-1">
            <Label>{t("portal.licenseType")}</Label>
            <select className="h-9 rounded-md border bg-background px-2 text-sm" value={licenseType} onChange={(e) => setLicenseType(e.target.value)}>
              {["RETAIL", "WHOLESALE", "RETAIL_WHOLESALE"].map((x) => <option key={x} value={x}>{licenseLabels[x]}</option>)}
            </select>
          </div>
          <Button size="sm" onClick={() => void submit()} disabled={!licenseNumber}>{verif.requests.length ? t("portal.resubmit") : t("common.submit")}</Button>
        </Card>
      )}
      {verif.requests.map((r) => (
        <Card key={r.id} className="p-3 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">{r.licenseNumber} · {licenseLabels[r.licenseType] ?? r.licenseType}</p>
            {r.reviewNote && <p className="text-xs text-destructive">{r.reviewNote}</p>}
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={r.status === "APPROVED" ? "default" : r.status === "REJECTED" ? "destructive" : "secondary"}>{r.status}</Badge>
            <span className="text-xs text-muted-foreground">{fmtDate(r.submittedAt, locale)}</span>
          </div>
        </Card>
      ))}
    </div>
  );
}

function RegistrationForm() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [form, setForm] = useState({
    name: "", contactPhone: "", addressLine: "", division: "Dhaka", district: "Dhaka",
    licenseNumber: "", licenseType: "RETAIL", pharmacistName: "", pharmacistReg: "",
    lat: undefined as number | undefined, lng: undefined as number | undefined,
    open: "08:00", close: "23:00",
  });
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const licenseLabels: Record<string, string> = {
    RETAIL: t("portal.licenseType.RETAIL"),
    WHOLESALE: t("portal.licenseType.WHOLESALE"),
    RETAIL_WHOLESALE: t("portal.licenseType.RETAIL_WHOLESALE"),
  };

  const captureGps = () => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setForm((f) => ({ ...f, lat: pos.coords.latitude, lng: pos.coords.longitude })),
      () => toast({ title: t("common.locationDenied"), variant: "destructive" })
    );
  };

  const submit = async () => {
    setBusy(true);
    try {
      await apiFetch("/api/pharmacies", {
        method: "POST",
        body: JSON.stringify({
          name: form.name,
          contactPhone: form.contactPhone,
          addressLine: form.addressLine,
          division: form.division,
          district: form.district,
          lat: form.lat,
          lng: form.lng,
          openingHours: { open: form.open, close: form.close },
          licenseNumber: form.licenseNumber,
          licenseType: form.licenseType,
          pharmacistName: form.pharmacistName || undefined,
          pharmacistReg: form.pharmacistReg || undefined,
        }),
      });
      setDone(true);
    } catch (err) {
      toast({ title: err instanceof ApiClientError ? err.message : t("err.generic"), variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return <Card className="p-5 border-emerald-300 bg-emerald-50/60 dark:bg-emerald-950/20"><p className="font-medium">{t("portal.registered")}</p></Card>;
  }

  return (
    <Card className="p-4 max-w-2xl space-y-3">
      <h3 className="font-semibold">{t("portal.register")}</h3>
      <p className="text-sm text-muted-foreground">{t("portal.registerDesc")}</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1"><Label>{t("portal.pharmacyName")}</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
        <div className="space-y-1"><Label>{t("common.phone")}</Label><Input value={form.contactPhone} onChange={(e) => setForm({ ...form, contactPhone: e.target.value })} placeholder="01XXXXXXXXX" /></div>
        <div className="space-y-1 sm:col-span-2"><Label>{t("common.address")}</Label><Input value={form.addressLine} onChange={(e) => setForm({ ...form, addressLine: e.target.value })} /></div>
        <div className="space-y-1"><Label>{t("common.division")}</Label><Input value={form.division} onChange={(e) => setForm({ ...form, division: e.target.value })} /></div>
        <div className="space-y-1"><Label>{t("common.district")}</Label><Input value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} /></div>
        <div className="space-y-1"><Label>{t("portal.licenseNumber")}</Label><Input value={form.licenseNumber} onChange={(e) => setForm({ ...form, licenseNumber: e.target.value })} /></div>
        <div className="space-y-1">
          <Label>{t("portal.licenseType")}</Label>
          <select className="h-9 w-full rounded-md border bg-background px-2 text-sm" value={form.licenseType} onChange={(e) => setForm({ ...form, licenseType: e.target.value })}>
            {["RETAIL", "WHOLESALE", "RETAIL_WHOLESALE"].map((x) => <option key={x} value={x}>{licenseLabels[x]}</option>)}
          </select>
        </div>
        <div className="space-y-1"><Label>{t("portal.pharmacistName")}</Label><Input value={form.pharmacistName} onChange={(e) => setForm({ ...form, pharmacistName: e.target.value })} /></div>
        <div className="space-y-1"><Label>{t("portal.pharmacistReg")}</Label><Input value={form.pharmacistReg} onChange={(e) => setForm({ ...form, pharmacistReg: e.target.value })} /></div>
        <div className="space-y-1"><Label>{t("portal.hoursFrom")}</Label><Input type="time" value={form.open} onChange={(e) => setForm({ ...form, open: e.target.value })} /></div>
        <div className="space-y-1"><Label>{t("portal.hoursTo")}</Label><Input type="time" value={form.close} onChange={(e) => setForm({ ...form, close: e.target.value })} /></div>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button size="sm" variant="outline" onClick={captureGps}>
          <GitBranch className="h-4 w-4 mr-1" /> {t("portal.gpsCapture")}
        </Button>
        {form.lat !== undefined && <span className="text-xs text-muted-foreground">{form.lat.toFixed(4)}, {form.lng?.toFixed(4)}</span>}
      </div>
      <Button onClick={() => void submit()} disabled={busy || !form.name || !form.contactPhone || !form.addressLine || !form.licenseNumber}>
        {busy ? t("common.loading") : t("common.submit")}
      </Button>
    </Card>
  );
}

// ── preserved demo experience (leads inbox, demo stock toggles, ROI) ─────────

function DemoExperience() {
  const { t } = useI18n();
  const { toast } = useToast();
  const leads = useAppStore((s) => s.leads);
  const acceptLead = useAppStore((s) => s.acceptLead);
  const acceptedLeads = useAppStore((s) => s.acceptedLeads);
  const [roi, setRoi] = useState<RoiInputs>(ROI_DEFAULTS);
  const [stock, setStock] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(
      DRUG_DB.filter((d) => ["napa", "seclo", "alatrol", "neurob", "amodis", "comet", "flexi", "antazol"].includes(d.id)).map((d) => [d.id, true])
    )
  );
  const roiResult = useMemo(() => computeRoi(roi), [roi]);
  const newLeads = leads.filter((l) => l.status === "new");
  const stockedCount = Object.values(stock).filter(Boolean).length;

  const slider = (label: string, key: keyof RoiInputs, min: number, max: number, step: number, format: (v: number) => string) => (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium">{format(roi[key])}</span>
      </div>
      <Slider min={min} max={max} step={step} value={[roi[key]]} onValueChange={(v) => setRoi((r) => ({ ...r, [key]: v[0] }))} aria-label={label} />
    </div>
  );

  return (
    <div className="space-y-6">
      <Badge variant="outline" className="border-emerald-300 bg-emerald-50 text-emerald-800">
        <Building2 className="mr-1.5 h-3.5 w-3.5" /> {t("portalDemo.header")}
      </Badge>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {kpi(t("portalDemo.kpi.newLeads"), String(newLeads.length), t("portalDemo.kpi.newLeadsSub", { count: leads.length }))}
        {kpi(t("portalDemo.kpi.accepted"), String(acceptedLeads), t("portalDemo.kpi.acceptedSub"), "slate")}
        {kpi(t("portalDemo.kpi.valuePerFill"), "৳90", t("portalDemo.kpi.valuePerFillSub"), "slate")}
        {kpi(
          t("portalDemo.kpi.projected"),
          `৳${Math.round(roiResult.monthlyProfitBdt).toLocaleString("en-IN")}`,
          t("portalDemo.kpi.projectedSub", { roi: roiResult.roiX.toFixed(1), price: PRO_PRICE_BDT.toLocaleString("en-IN") }),
          roiResult.roiX >= 1 ? "emerald" : "amber"
        )}
      </div>

      <section className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <h3 className="flex items-center gap-2 font-semibold"><BellRing className="h-4 w-4 text-emerald-700" /> {t("portalDemo.leadsInbox")}</h3>
              <Badge variant="outline" className="text-[11px]">{t("portalDemo.liveBadge")}</Badge>
            </div>
            {leads.length === 0 ? (
              <div className="mt-4 rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
                <ClipboardList className="mx-auto mb-2 h-8 w-8 opacity-40" />
                {t("portalDemo.noLeadsBefore")}{" "}
                <span className="font-medium text-foreground">{t("portalDemo.scanDecode")}</span>{" "}
                {t("portalDemo.noLeadsAfter")}
              </div>
            ) : (
              <div className="thin-scroll mt-4 max-h-96 space-y-3 overflow-y-auto pr-1">
                {leads.map((lead) => {
                  const mins = Math.max(1, Math.round((Date.now() - lead.createdAt) / 60000));
                  return (
                    <div key={lead.id} className="rounded-lg border p-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs text-muted-foreground">{lead.patientRef}</span>
                          <span className="text-xs text-muted-foreground">{t("portalDemo.minsAgo", { mins })}</span>
                          <span className="text-xs text-muted-foreground">{t("portalDemo.distance", { km: lead.distanceKm })}</span>
                        </div>
                        {lead.safetyFlag === "major" && (
                          <Badge className="bg-red-600 text-[10px]"><ShieldAlert className="mr-1 h-3 w-3" /> {t("portalDemo.safetyFlag")}</Badge>
                        )}
                      </div>
                      <p className="mt-1.5 text-sm">{lead.items.join(" · ")}</p>
                      <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground">{t("portalDemo.estBasket", { basket: lead.estBasketBdt, value: Math.round(lead.estBasketBdt * 0.14) })}</span>
                        {lead.status === "new" ? (
                          <Button
                            size="sm"
                            onClick={() => {
                              acceptLead(lead.id);
                              toast({ title: t("portalDemo.toastAccepted"), description: t("portalDemo.toastClaimed", { ref: lead.patientRef }) });
                            }}
                          >
                            <CheckCheck className="mr-1.5 h-3.5 w-3.5" /> {t("portalDemo.acceptLead")}
                          </Button>
                        ) : (
                          <Badge variant="outline" className="border-emerald-300 bg-emerald-50 text-emerald-700 text-[11px]">{t("portalDemo.accepted")}</Badge>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardContent className="p-5">
            <h3 className="flex items-center gap-2 font-semibold"><PackageSearch className="h-4 w-4 text-emerald-700" /> {t("portalDemo.stockListing")}</h3>
            <p className="mt-1 text-xs text-muted-foreground">{t("portalDemo.stockHint")}</p>
            <div className="thin-scroll mt-3 max-h-64 space-y-1 overflow-y-auto pr-1">
              {DRUG_DB.map((d) => (
                <div key={d.id} className="flex items-center justify-between gap-2 rounded-md px-2 py-1.5 hover:bg-muted/50">
                  <div className="min-w-0"><p className="truncate text-sm">{d.brand} <span className="text-[11px] text-muted-foreground">({d.generic.split(" ")[0]})</span></p></div>
                  <Switch checked={Boolean(stock[d.id])} onCheckedChange={(v) => setStock((s) => ({ ...s, [d.id]: v }))} aria-label={t("portalDemo.toggleStock", { brand: d.brand })} />
                </div>
              ))}
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              <span className="font-medium text-emerald-700">{stockedCount}/{DRUG_DB.length}</span> {t("portalDemo.skusListed")}
            </p>
          </CardContent>
        </Card>
      </section>

      <section>
        <Card>
          <CardContent className="p-5 sm:p-6">
            <div className="flex items-center gap-2">
              <Calculator className="h-5 w-5 text-emerald-700" />
              <h3 className="font-semibold">{t("portalDemo.roiTitle", { price: PRO_PRICE_BDT.toLocaleString("en-IN") })}</h3>
            </div>
            <div className="mt-5 grid gap-6 lg:grid-cols-2">
              <div className="space-y-5">
                {slider(t("portalDemo.sliderDecodedRx"), "decodedRxPerDay", 10, 300, 5, (v) => String(v))}
                {slider(t("portalDemo.sliderCapture"), "capturePct", 2, 20, 1, (v) => `${v}%`)}
                {slider(t("portalDemo.sliderFill"), "fillPct", 10, 60, 1, (v) => `${v}%`)}
                {slider(t("portalDemo.sliderBasket"), "basketBdt", 200, 1500, 50, (v) => `৳${v}`)}
                {slider(t("portalDemo.sliderMargin"), "marginPct", 8, 25, 1, (v) => `${v}%`)}
              </div>
              <div className="rounded-xl border bg-emerald-50/50 p-5">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><p className="text-xs text-muted-foreground">{t("portalDemo.resultLeadsPerDay")}</p><p className="text-xl font-bold">{roiResult.leadsPerDay.toFixed(1)}</p></div>
                  <div><p className="text-xs text-muted-foreground">{t("portalDemo.resultFillsPerDay")}</p><p className="text-xl font-bold">{roiResult.ordersPerDay.toFixed(1)}</p></div>
                  <div><p className="text-xs text-muted-foreground">{t("portalDemo.resultMonthlyGross")}</p><p className="text-xl font-bold">৳{Math.round(roiResult.monthlyProfitBdt).toLocaleString("en-IN")}</p></div>
                  <div>
                    <p className="text-xs text-muted-foreground">{t("portalDemo.resultNetVsPro")}</p>
                    <p className={`text-xl font-bold ${roiResult.netBdt >= 0 ? "text-emerald-700" : "text-red-600"}`}>
                      {roiResult.netBdt >= 0 ? "+" : "−"}৳{Math.abs(Math.round(roiResult.netBdt)).toLocaleString("en-IN")}
                    </p>
                  </div>
                </div>
                <div className="mt-4 rounded-lg bg-emerald-600 p-4 text-white">
                  <p className="text-xs opacity-80">{t("portalDemo.roiBoxLabel", { price: PRO_PRICE_BDT.toLocaleString("en-IN") })}</p>
                  <p className="text-3xl font-extrabold">{roiResult.roiX.toFixed(1)}×</p>
                  <p className="mt-1 text-[11px] opacity-80">
                    {t("portalDemo.roiWithRefill")} <span className="font-semibold">{roiResult.roiXWithRefill.toFixed(1)}×</span>
                  </p>
                </div>
                <p className="mt-3 flex items-start gap-1.5 text-[11px] text-muted-foreground">
                  <Timer className="mt-0.5 h-3 w-3 shrink-0" />
                  {t("portalDemo.payback", { days: roiResult.monthlyProfitBdt > 0 ? Math.max(1, Math.round(PRO_PRICE_BDT / (roiResult.monthlyProfitBdt / 30))) : "∞" })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
