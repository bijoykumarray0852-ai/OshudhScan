"use client";
import type { SampleRx } from "@/lib/samples";

interface Props {
  sample: SampleRx;
  compact?: boolean;
}

export function PrescriptionPaper({ sample, compact = false }: Props) {
  return (
    <div
      className={`rx-paper relative rounded-lg border border-amber-900/20 shadow-sm ${
        compact ? "p-3" : "p-4 sm:p-5"
      }`}
    >
      <div className={compact ? "space-y-1" : "space-y-2"}>
        <div className={`flex items-start justify-between gap-2 ${compact ? "mb-1" : "mb-2"}`}>
          <div className="font-hand leading-tight text-sky-950">
            <div className={compact ? "text-base" : "text-xl sm:text-2xl"}>{sample.doctor}</div>
            {!compact && <div className="text-sm text-sky-900/70">{sample.degrees}</div>}
          </div>
          <div className="font-hand text-right text-sky-950/80 text-[11px] sm:text-xs leading-tight">
            <div>{sample.chamber}</div>
            <div>{sample.reg}</div>
          </div>
        </div>

        <div className="border-t border-dashed border-sky-900/30 pt-1.5">
          <div className="flex flex-wrap items-baseline justify-between gap-x-4 font-hand text-sky-950 text-xs sm:text-sm">
            <span>
              <span className="text-sky-900/60">Patient:</span>{" "}
              <span className="font-semibold">{sample.patient}</span>
            </span>
            <span className="text-sky-900/60">Date: {sample.date}</span>
          </div>
        </div>

        <div className={`pt-1 ${compact ? "space-y-1" : "space-y-1.5"}`}>
          {sample.ocr.medicines.map((m, i) => (
            <div key={i} className="font-hand flex items-baseline justify-between gap-3 text-sm sm:text-base text-sky-950">
              <span>
                <span className="text-emerald-800 mr-1">{i + 1})</span>
                {m.brand_raw}
              </span>
              <span className="text-right whitespace-nowrap">
                {m.dose ? `${m.dose} — ${m.duration ?? ""}` : "PRN"}
              </span>
            </div>
          ))}
        </div>

        <div className="flex items-end justify-between pt-1.5">
          <span className="font-bangla text-[11px] sm:text-xs text-purple-900/70">{sample.banglaNote}</span>
          <span className="font-hand text-base sm:text-lg text-purple-800/90 italic">{sample.doctor}</span>
        </div>
      </div>
    </div>
  );
}
