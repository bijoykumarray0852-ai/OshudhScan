"use client";
// Settings: language, large-text mode, low-internet mode, account info, demo credentials.
import { Globe, Type, UserRound, Info, WifiLow } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useI18n } from "@/hooks/use-i18n";
import { useAppStore } from "@/lib/store";
import { PageHeader } from "@/components/rx/shared";

export function SettingsView() {
  const { t, locale } = useI18n();
  const largeText = useAppStore((s) => s.largeText);
  const setLargeText = useAppStore((s) => s.setLargeText);
  const liteMode = useAppStore((s) => s.liteMode);
  const setLiteMode = useAppStore((s) => s.setLiteMode);
  const setLocale = useAppStore((s) => s.setLocale);
  const user = useAppStore((s) => s.user);
  const openAuth = useAppStore((s) => s.openAuth);

  return (
    <>
      <PageHeader title={t("settings.title")} icon={<Info className="h-6 w-6" />} />
      <div className="max-w-2xl space-y-4">
        <Card className="p-4">
          <h2 className="font-semibold flex items-center gap-2"><Globe className="h-4 w-4" /> {t("settings.language")}</h2>
          <p className="text-sm text-muted-foreground mt-1">{t("settings.languageDesc")}</p>
          <div className="flex gap-2 mt-3">
            <Button size="sm" variant={locale === "bn" ? "default" : "outline"} onClick={() => setLocale("bn")}>
              বাংলা
            </Button>
            <Button size="sm" variant={locale === "en" ? "default" : "outline"} onClick={() => setLocale("en")}>
              English
            </Button>
          </div>
        </Card>

        <Card className="p-4">
          <h2 className="font-semibold flex items-center gap-2"><Type className="h-4 w-4" /> {t("settings.largeText")}</h2>
          <p className="text-sm text-muted-foreground mt-1">{t("settings.largeTextDesc")}</p>
          <div className="mt-3">
            <Switch checked={largeText} onCheckedChange={setLargeText} aria-label={t("settings.largeText")} />
          </div>
        </Card>

        <Card className="p-4">
          <h2 className="font-semibold flex items-center gap-2"><WifiLow className="h-4 w-4" /> {t("lite.title")}</h2>
          <p className="text-sm text-muted-foreground mt-1">{t("lite.settingsDesc")}</p>
          <div className="mt-3">
            <Switch checked={liteMode} onCheckedChange={setLiteMode} aria-label={t("lite.title")} />
          </div>
        </Card>

        <Card className="p-4">
          <h2 className="font-semibold flex items-center gap-2"><UserRound className="h-4 w-4" /> {t("settings.account")}</h2>
          {user ? (
            <div className="text-sm mt-2 space-y-1">
              <p><span className="text-muted-foreground">{t("common.name")}:</span> {user.name}</p>
              <p><span className="text-muted-foreground">{t("common.email")}:</span> {user.email}</p>
              <p><span className="text-muted-foreground">{t("auth.role")}:</span> {user.role}</p>
              <p className="text-xs text-muted-foreground mt-2">{t("privacy.whoSeesBody")}</p>
            </div>
          ) : (
            <div className="mt-3">
              <Button size="sm" onClick={() => openAuth("signin")}>{t("auth.signIn")}</Button>
            </div>
          )}
        </Card>

        <Card className="p-4">
          <h2 className="font-semibold">{t("settings.about")}</h2>
          <p className="text-sm text-muted-foreground mt-1">
            OshudhScan 2.0 — {t("app.tagline")}. {t("settings.version")}: 2.0.0-demo
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            AI: GLM-4.5V vision OCR · Bengali LLM explainer · Bengali TTS. Safety: deterministic rule engine (governed registry). Demo knowledge base: 26 medicines; verified directory data only.
          </p>
        </Card>
      </div>
    </>
  );
}
