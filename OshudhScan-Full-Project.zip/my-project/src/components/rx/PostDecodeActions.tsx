"use client";
// Post-decode actions: save the prescription to history + create reminder
// schedules from the decoded dose notation (explicit user confirmation
// required — OshudhScan never activates a schedule silently).
import { useState } from "react";
import { BookmarkPlus, AlarmClockPlus, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useI18n } from "@/hooks/use-i18n";
import { useAppStore } from "@/lib/store";
import { apiFetch, ApiClientError } from "@/components/rx/shared";
import type { DecodeResponse } from "@/lib/types";

function slotsFromDose(dose: string | null): string[] {
  if (!dose) return [];
  const parts = dose.split("+").map((p) => parseInt(p, 10));
  if (parts.length !== 3) return [];
  const out: string[] = [];
  if (parts[0] > 0) out.push("MORNING");
  if (parts[1] > 0) out.push("AFTERNOON");
  if (parts[2] > 0) out.push("NIGHT");
  return out;
}

function durationDays(duration: string | null): number | undefined {
  if (!duration) return undefined;
  const d = duration.match(/(\d+)\s*day/i);
  if (d) return parseInt(d[1], 10);
  const w = duration.match(/(\d+)\s*week/i);
  if (w) return parseInt(w[1], 10) * 7;
  const m = duration.match(/(\d+)\s*month/i);
  if (m) return parseInt(m[1], 10) * 30;
  return undefined;
}

export function PostDecodeActions({ decoded }: { decoded: DecodeResponse }) {
  const { t } = useI18n();
  const user = useAppStore((s) => s.user);
  const openAuth = useAppStore((s) => s.openAuth);
  const savedId = useAppStore((s) => s.savedPrescriptionId);
  const setSavedId = useAppStore((s) => s.setSavedPrescriptionId);
  const setView = useAppStore((s) => s.setView);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const matched = decoded.medicines.filter((m) => m.brand && m.dose);
  const medicines = decoded.medicines.filter((m) => m.brand);

  const saveRx = async () => {
    if (!user) { openAuth("signin"); return; }
    if (savedId) return;
    setBusy(true);
    try {
      const res = await apiFetch<{ prescription: { id: string } }>("/api/prescriptions", {
        method: "POST",
        body: JSON.stringify({
          doctorName: decoded.ocr?.doctor ?? undefined,
          prescribedAt: decoded.ocr?.date ?? undefined,
          medicines: medicines.map((m) => ({
            rawLine: `${m.brandRaw} ${m.strength ?? ""} ${m.dose ?? ""} ${m.duration ?? ""}`.trim(),
            brandRaw: m.brandRaw,
            matchedBrand: m.brand,
            generic: m.generic,
            strength: m.strength,
            doseText: m.dose,
            perDay: m.perDay ?? undefined,
            slots: slotsFromDose(m.dose),
            durationDays: m.days ?? undefined,
            meal: m.meal ?? undefined,
            matchMethod: m.matchMethod,
            confidence: m.confidence,
            priceBdt: m.lineTotalBdt ?? undefined,
            genericPriceBdt: m.genericLineTotalBdt ?? undefined,
          })),
          findings: decoded.findings,
          totals: decoded.totals,
        }),
      });
      setSavedId(res.prescription.id);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setBusy(false);
    }
  };

  const createReminders = async () => {
    if (!user) { openAuth("signin"); return; }
    if (!confirmed) { setError(t("rem.mustConfirm")); return; }
    setBusy(true);
    setError(null);
    let count = 0;
    try {
      for (const m of matched) {
        const slots = slotsFromDose(m.dose);
        if (slots.length === 0) continue;
        await apiFetch("/api/reminders/schedules", {
          method: "POST",
          body: JSON.stringify({
            medicineLabel: `${m.brand}${m.strength ? " " + m.strength : ""}`,
            slots,
            perDay: slots.length,
            durationDays: m.days ?? undefined,
            meal: m.meal ?? undefined,
            confirmed: true,
          }),
        });
        count++;
      }
      setCreated(count);
      setDialogOpen(false);
    } catch (err) {
      // partial success is real: schedules already created stay created
      if (count > 0) {
        setCreated(count);
        setError(t("rem.partialCreated", { count }));
      } else {
        setError(err instanceof ApiClientError ? err.message : t("err.generic"));
      }
    } finally {
      setBusy(false);
    }
  };

  if (decoded.source !== "sample" && medicines.length === 0) return null;

  return (
    <Card className="mt-4">
      <CardContent className="flex flex-wrap items-center gap-3 p-4">
        <Button variant="outline" onClick={() => void saveRx()} disabled={busy || Boolean(savedId)}>
          <BookmarkPlus className="h-4 w-4 mr-1.5" />
          {savedId ? t("scan.saved") : t("scan.saveHistory")}
        </Button>
        <Button variant="outline" onClick={() => { setDialogOpen(true); setCreated(0); }}>
          <AlarmClockPlus className="h-4 w-4 mr-1.5" /> {t("scan.createReminders")}
        </Button>
        {created > 0 && (
          <Button variant="ghost" onClick={() => setView("patient")}>
            <CheckCircle2 className="h-4 w-4 mr-1.5 text-emerald-600" />
            {created} {t("rem.created")} → {t("patient.reminders")}
          </Button>
        )}
        {!user && <p className="text-xs text-muted-foreground">{t("scan.signinToSave")}</p>}
        {error && <p className="text-xs text-destructive">{error}</p>}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={(o) => (o ? undefined : setDialogOpen(false))}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t("rem.createTitle")}</DialogTitle>
            <DialogDescription>{t("rem.createDesc")}</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-[50vh] overflow-y-auto thin-scroll">
            {matched.length === 0 && (
              <p className="text-sm text-muted-foreground">{t("common.noResults")}</p>
            )}
            {matched.map((m) => {
              const slots = slotsFromDose(m.dose);
              const slotWord = (s: string) => (s === "MORNING" ? t("rem.slotMorning") : s === "AFTERNOON" ? t("rem.slotAfternoon") : t("rem.slotNight"));
              return (
                <div key={m.brandRaw} className="flex items-center justify-between gap-2 rounded-lg border p-2.5 text-sm">
                  <span className="font-medium">{m.brand}{m.strength ? ` ${m.strength}` : ""}</span>
                  <span className="text-muted-foreground">{slots.map(slotWord).join(" · ")}</span>
                </div>
              );
            })}
            <div className="flex items-start gap-2 text-sm">
              <Checkbox
                id="rem-confirm"
                checked={confirmed}
                onCheckedChange={(v) => setConfirmed(Boolean(v))}
                className="mt-0.5"
                aria-labelledby="rem-confirm-label"
              />
              <Label htmlFor="rem-confirm" id="rem-confirm-label" className="font-normal leading-snug">
                {t("rem.confirmCheck")}
              </Label>
            </div>
          </div>
          <Button className="w-full" onClick={() => void createReminders()} disabled={busy || matched.length === 0}>
            {busy ? t("common.loading") : t("rem.create")}
          </Button>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
