"use client";
// Admin dashboard: platform stats, pharmacy verification queue, users,
// clinical-rule governance, facilities (verified data only), audit trail.
import { useCallback, useEffect, useState } from "react";
import { ShieldCheck, Building2, Users, Activity, ScrollText, Landmark, Plus, Check, X, Pause, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useI18n } from "@/hooks/use-i18n";
import { useAppStore } from "@/lib/store";
import { DirectoryAdminTab } from "@/components/rx/DirectoryAdminTab";
import {
  apiFetch, ApiClientError, PageHeader, StatCard, EmptyState, LoadingCards, ErrorNote, fmtDate,
} from "@/components/rx/shared";

interface Stats {
  stats: { patients: number; pharmacies: number; verifiedPharmacies: number; pendingVerifications: number; scans: number; medicines: number; rules: number; facilities: number };
  scansByDay: { date: string; count: number }[];
  topMedicines: { brand: string; count: number }[];
  coverage: { district: string; pharmacies: number }[];
}
interface PharmacyAdminRow {
  id: string; name: string; district: string; upazila: string | null; addressLine: string;
  contactPhone: string; licenseNumber: string | null; status: string; isVerified: boolean; isDemo: boolean;
  createdAt: string; owner: { name: string; email: string } | null; inventoryCount: number;
  latestVerification: { id: string; licenseType: string; pharmacistName: string | null; pharmacistReg: string | null; submittedAt: string; status: string } | null;
}
interface UserRow { id: string; name: string; email: string; role: string; locale: string; createdAt: string }
interface RuleRow {
  ruleId: string; title: string; severity: string; triggerDescription: string; clinicalExplanation: string;
  recommendedAction: string; evidenceSource: string; evidenceLevel: string; lastReviewedAt: string | null;
  reviewer: string | null; status: string; enabled: boolean;
}
interface AuditRow { id: string; action: string; entity: string; entityId: string | null; user: { name: string; role: string } | null; ip: string | null; createdAt: string }

export function AdminView() {
  const { t, locale } = useI18n();
  const user = useAppStore((s) => s.user);
  const [tab, setTab] = useState("stats");

  if (!user || user.role !== "ADMIN") {
    return (
      <>
        <PageHeader title={t("admin.title")} subtitle={t("admin.subtitle")} icon={<ShieldCheck className="h-6 w-6" />} />
        <EmptyState title={t("admin.adminOnly")} hint={t("auth.signInToContinue")} />
      </>
    );
  }

  return (
    <>
      <PageHeader title={t("admin.title")} subtitle={t("admin.subtitle")} icon={<ShieldCheck className="h-6 w-6" />} />
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex flex-wrap h-auto gap-1 w-full justify-start">
          <TabsTrigger value="stats">{t("admin.stats")}</TabsTrigger>
          <TabsTrigger value="queue">{t("admin.verifyQueue")}</TabsTrigger>
          <TabsTrigger value="users">{t("admin.users")}</TabsTrigger>
          <TabsTrigger value="rules">{t("admin.rules")}</TabsTrigger>
          <TabsTrigger value="facilities">{t("admin.facilities")}</TabsTrigger>
          <TabsTrigger value="directory">{t("admin.dir.tab")}</TabsTrigger>
          <TabsTrigger value="audit">{t("admin.audit")}</TabsTrigger>
        </TabsList>
        <TabsContent value="stats" className="mt-4"><StatsTab /></TabsContent>
        <TabsContent value="queue" className="mt-4"><QueueTab /></TabsContent>
        <TabsContent value="users" className="mt-4"><UsersTab /></TabsContent>
        <TabsContent value="rules" className="mt-4"><RulesTab /></TabsContent>
        <TabsContent value="facilities" className="mt-4"><FacilitiesAdminTab /></TabsContent>
        <TabsContent value="directory" className="mt-4"><DirectoryAdminTab /></TabsContent>
        <TabsContent value="audit" className="mt-4"><AuditTab /></TabsContent>
      </Tabs>
    </>
  );

  function StatsTab() {
    const [data, setData] = useState<Stats | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    useEffect(() => {
      void (async () => {
        try {
          const res = await apiFetch<Stats>("/api/admin/stats");
          setData(res);
        } catch (err) {
          setError(err instanceof ApiClientError ? err.message : t("err.generic"));
        } finally {
          setLoading(false);
        }
      })();
    }, [t]);
    if (error) return <ErrorNote message={error} />;
    if (loading || !data) return <LoadingCards count={4} />;
    const s = data.stats;
    return (
      <div className="space-y-5">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <StatCard label={t("admin.patients")} value={s.patients} icon={<Users className="h-4 w-4" />} />
          <StatCard label={t("admin.pharmacies")} value={s.pharmacies} hint={`${s.verifiedPharmacies} ${t("admin.verifiedPharmacies").toLowerCase()}`} icon={<Building2 className="h-4 w-4" />} />
          <StatCard label={t("admin.scans")} value={s.scans} icon={<Activity className="h-4 w-4" />} />
          <StatCard label={t("admin.medicines")} value={s.medicines} hint={`${s.rules} ${t("admin.rules").toLowerCase()} · ${s.facilities} ${t("admin.facilities").toLowerCase()}`} icon={<PillIcon />} />
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <Card className="p-4">
            <h2 className="font-semibold text-sm mb-2">{t("admin.platformUsage")}</h2>
            <div className="flex items-end gap-1 h-28">
              {data.scansByDay.map((d) => (
                <div key={d.date} className="flex-1 flex flex-col items-center gap-1" title={`${d.date}: ${d.count}`}>
                  <div className="w-full bg-emerald-600/80 rounded-t" style={{ height: `${Math.max(2, (d.count / Math.max(1, ...data.scansByDay.map((x) => x.count))) * 100)}%` }} />
                  <span className="text-[9px] text-muted-foreground">{d.date.slice(8)}</span>
                </div>
              ))}
            </div>
          </Card>
          <Card className="p-4">
            <h2 className="font-semibold text-sm mb-2">{t("admin.topMedicines")}</h2>
            {data.topMedicines.length === 0 ? (
              <p className="text-sm text-muted-foreground">{t("common.empty")}</p>
            ) : (
              <ul className="space-y-1.5">
                {data.topMedicines.map((m) => (
                  <li key={m.brand} className="flex items-center justify-between text-sm">
                    <span>{m.brand}</span>
                    <Badge variant="secondary">{m.count}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
        <Card className="p-4">
          <h2 className="font-semibold text-sm mb-2">{t("admin.coverage")}</h2>
          <div className="flex flex-wrap gap-2">
            {data.coverage.map((c) => (
              <Badge key={c.district} variant="outline">{c.district}: {c.pharmacies}</Badge>
            ))}
          </div>
        </Card>
      </div>
    );
  }

  function QueueTab() {
    const [rows, setRows] = useState<PharmacyAdminRow[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [actionMsg, setActionMsg] = useState<string | null>(null);
    const [filter, setFilter] = useState("PENDING");
    const [note, setNote] = useState<Record<string, string>>({});

    const load = useCallback(async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await apiFetch<{ pharmacies: PharmacyAdminRow[] }>(`/api/admin/pharmacies?status=${filter}`);
        setRows(res.pharmacies);
      } catch (err) {
        setError(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally {
        setLoading(false);
      }
    }, [filter, t]);

    useEffect(() => {
      void load();
    }, [load]);

    const decide = async (pharmacyId: string, decision: "APPROVE" | "REJECT") => {
      setActionMsg(null);
      try {
        await apiFetch("/api/admin/pharmacies", {
          method: "PATCH",
          body: JSON.stringify({ pharmacyId, decision, reviewNote: note[pharmacyId] || undefined }),
        });
        await load();
      } catch (err) {
        setActionMsg(err instanceof ApiClientError ? err.message : t("err.generic"));
      }
    };

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap gap-1.5">
          {["PENDING", "VERIFIED", "REJECTED", "ALL"].map((f) => (
            <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)} aria-pressed={filter === f}>{t(`admin.status.${f}`)}</Button>
          ))}
        </div>
        {actionMsg && <ErrorNote message={actionMsg} />}
        {error ? (
          <ErrorNote message={error} onRetry={() => void load()} />
        ) : loading ? (
          <LoadingCards />
        ) : rows.length === 0 ? (
          <EmptyState title={t("admin.noPending")} />
        ) : (
          <div className="space-y-3">
            {rows.map((p) => (
              <Card key={p.id} className="p-4">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold">
                      {p.name} {p.isDemo && <Badge variant="secondary">{t("common.demoData")}</Badge>}
                    </p>
                    <p className="text-sm text-muted-foreground">{p.addressLine} · {p.district}{p.upazila ? ` / ${p.upazila}` : ""}</p>
                    <p className="text-sm text-muted-foreground">
                      {t("portal.licenseNumber")}: {p.licenseNumber ?? "—"} · {p.contactPhone} · {t("admin.itemsCount", { count: p.inventoryCount })}
                    </p>
                    {p.latestVerification && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {p.latestVerification.licenseType} · {p.latestVerification.pharmacistName ?? "—"} ({p.latestVerification.pharmacistReg ?? "—"}) · {fmtDate(p.latestVerification.submittedAt, locale)}
                      </p>
                    )}
                  </div>
                  <Badge variant={p.status === "VERIFIED" ? "default" : p.status === "PENDING" ? "secondary" : "destructive"}>{t(`admin.status.${p.status}`)}</Badge>
                </div>
                {p.status !== "VERIFIED" && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    <Input
                      value={note[p.id] ?? ""}
                      onChange={(e) => setNote((n) => ({ ...n, [p.id]: e.target.value }))}
                      placeholder={t("admin.reviewNote")}
                      className="max-w-xs"
                    />
                    <Button size="sm" onClick={() => void decide(p.id, "APPROVE")}><Check className="h-4 w-4 mr-1" />{t("admin.approve")}</Button>
                    <Button size="sm" variant="destructive" onClick={() => void decide(p.id, "REJECT")}><X className="h-4 w-4 mr-1" />{t("admin.reject")}</Button>
                  </div>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  }

  function UsersTab() {
    const [rows, setRows] = useState<UserRow[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [q, setQ] = useState("");
    const load = useCallback(async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await apiFetch<{ users: UserRow[] }>(`/api/admin/users?q=${encodeURIComponent(q)}`);
        setRows(res.users);
      } catch (err) {
        setError(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally {
        setLoading(false);
      }
    }, [q, t]);
    useEffect(() => {
      void load();
    }, [load]);

    const changeRole = async (userId: string, role: string) => {
      try {
        await apiFetch("/api/admin/users", { method: "PATCH", body: JSON.stringify({ userId, role }) });
        await load();
      } catch (err) {
        setError(err instanceof ApiClientError ? err.message : t("err.generic"));
      }
    };

    return (
      <div className="space-y-3">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("common.search")} aria-label={t("common.search")} className="max-w-sm" onKeyDown={(e) => e.key === "Enter" && void load()} />
        {error && <ErrorNote message={error} onRetry={() => void load()} />}
        {loading ? (
          <LoadingCards />
        ) : (
          <div className="overflow-x-auto rounded-lg border">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left">
                <tr>
                  <th className="px-3 py-2 font-medium">{t("common.name")}</th>
                  <th className="px-3 py-2 font-medium">{t("common.email")}</th>
                  <th className="px-3 py-2 font-medium">{t("admin.userRole")}</th>
                  <th className="px-3 py-2 font-medium">{t("admin.userJoined")}</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {rows.map((u) => (
                  <tr key={u.id}>
                    <td className="px-3 py-2">{u.name}</td>
                    <td className="px-3 py-2 text-muted-foreground">{u.email}</td>
                    <td className="px-3 py-2">
                      <select
                        className="h-8 rounded border bg-background px-1.5 text-xs"
                        value={u.role}
                        onChange={(e) => void changeRole(u.id, e.target.value)}
                        aria-label={t("admin.userRole")}
                      >
                        {["PATIENT", "PHARMACY_OWNER", "PHARMACY_STAFF", "PHARMACIST", "ADMIN"].map((r) => <option key={r}>{r}</option>)}
                      </select>
                    </td>
                    <td className="px-3 py-2 text-muted-foreground">{fmtDate(u.createdAt, locale)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    );
  }

  function RulesTab() {
    const [rules, setRules] = useState<RuleRow[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [actionMsg, setActionMsg] = useState<string | null>(null);
    useEffect(() => {
      void (async () => {
        try {
          const res = await apiFetch<{ rules: RuleRow[] }>("/api/admin/rules");
          setRules(res.rules);
        } catch (err) {
          setError(err instanceof ApiClientError ? err.message : t("err.generic"));
        } finally {
          setLoading(false);
        }
      })();
    }, [t]);

    const act = async (ruleId: string, action: "RETIRE" | "ENABLE" | "REVIEW") => {
      setActionMsg(null);
      try {
        await apiFetch("/api/admin/rules", { method: "PATCH", body: JSON.stringify({ ruleId, action }) });
        const res = await apiFetch<{ rules: RuleRow[] }>("/api/admin/rules");
        setRules(res.rules);
      } catch (err) {
        setActionMsg(err instanceof ApiClientError ? err.message : t("err.generic"));
      }
    };

    if (error) return <ErrorNote message={error} onRetry={() => window.location.reload()} />;
    if (loading) return <LoadingCards />;
    return (
      <div className="space-y-3">
        {actionMsg && <ErrorNote message={actionMsg} />}
        <p className="text-xs text-muted-foreground">{t("admin.ruleRequiresReview")}</p>
        {rules.map((r) => (
          <Card key={r.ruleId} className={`p-4 ${!r.enabled ? "opacity-70" : ""}`}>
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <p className="font-semibold text-sm">{r.ruleId} — {r.title}</p>
                <p className="text-sm text-muted-foreground mt-1">{r.triggerDescription}</p>
                <p className="text-xs text-muted-foreground mt-1">{r.clinicalExplanation}</p>
                <p className="text-xs mt-1"><span className="font-medium">{t("med.reviewAction")}:</span> {r.recommendedAction}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {t("admin.ruleEvidence")}: {r.evidenceSource} · {t("admin.ruleLevel")}: {r.evidenceLevel}
                </p>
                <p className="text-xs text-muted-foreground">
                  {t("admin.ruleReviewed")}: {fmtDate(r.lastReviewedAt, locale)} · {t("admin.ruleReviewer")}: {r.reviewer ?? "—"}
                </p>
              </div>
              <div className="flex flex-col items-end gap-2">
                <Badge className={r.severity === "MAJOR" ? "bg-red-600 text-white" : r.severity === "MODERATE" ? "bg-amber-500 text-white" : "bg-slate-500 text-white"}>
                  {r.severity === "MAJOR" ? t("rx.sevMajor") : r.severity === "MODERATE" ? t("rx.sevModerate") : t("rx.sevMinor")}
                </Badge>
                <Badge variant={r.enabled ? "default" : "outline"}>{r.status}</Badge>
                <div className="flex gap-1.5">
                  {r.enabled ? (
                    <Button size="sm" variant="outline" onClick={() => void act(r.ruleId, "RETIRE")}>
                      <Pause className="h-3.5 w-3.5 mr-1" />{t("admin.ruleRetire")}
                    </Button>
                  ) : (
                    <Button size="sm" onClick={() => void act(r.ruleId, "ENABLE")}>{t("admin.ruleEnable")}</Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => void act(r.ruleId, "REVIEW")} aria-label={t("admin.ruleMarkReviewed")}><Save className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    );
  }

  function FacilitiesAdminTab() {
    const [busy, setBusy] = useState(false);
    const [message, setMessage] = useState<string | null>(null);
    const [form, setForm] = useState({ name: "", district: "", addressLine: "", phone: "", source: "", kind: "FACILITY", type: "HOSPITAL", specialty: "" });
    const [bar, setBar] = useState({ medicineId: "", barcode: "" });

    const addFacility = async () => {
      setBusy(true);
      setMessage(null);
      try {
        await apiFetch("/api/admin/facilities", {
          method: "POST",
          body: JSON.stringify({
            kind: form.kind,
            name: form.name,
            type: form.type,
            ownership: "PUBLIC",
            district: form.district,
            addressLine: form.addressLine,
            phone: form.phone || undefined,
            doctorSpecialty: form.kind === "DOCTOR" ? form.specialty : undefined,
            source: form.source,
          }),
        });
        setMessage(t("admin.facilityAdded"));
        setForm({ ...form, name: "", addressLine: "", phone: "", source: "" });
      } catch (err) {
        setMessage(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally {
        setBusy(false);
      }
    };

    const attachBarcode = async () => {
      setBusy(true);
      setMessage(null);
      try {
        await apiFetch("/api/admin/facilities", { method: "PATCH", body: JSON.stringify(bar) });
        setMessage(t("admin.barcodeAttached"));
      } catch (err) {
        setMessage(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally {
        setBusy(false);
      }
    };

    return (
      <div className="grid gap-4 md:grid-cols-2 max-w-3xl">
        <Card className="p-4 space-y-3">
          <h2 className="font-semibold text-sm flex items-center gap-2"><Landmark className="h-4 w-4" /> {t("admin.addFacility")}</h2>
          <div className="flex gap-1.5">
            {["FACILITY", "DOCTOR"].map((k) => (
              <Button key={k} size="sm" variant={form.kind === k ? "default" : "outline"} onClick={() => setForm({ ...form, kind: k })}>{k}</Button>
            ))}
          </div>
          <div className="space-y-1">
            <Label htmlFor="af-name">{t("common.name")}</Label>
            <Input id="af-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          {form.kind === "FACILITY" ? (
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label htmlFor="af-type">{t("common.type")}</Label>
                <select id="af-type" className="h-9 w-full rounded-md border bg-background px-2 text-sm" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} aria-label={t("common.type")}>
                  {["HOSPITAL", "CLINIC", "DIAGNOSTIC", "BLOOD_BANK"].map((x) => <option key={x}>{x}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="af-district">{t("common.district")}</Label>
                <Input id="af-district" value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} />
              </div>
            </div>
          ) : (
            <div className="space-y-1">
              <Label htmlFor="af-spec">{t("care.specialty")}</Label>
              <Input id="af-spec" value={form.specialty} onChange={(e) => setForm({ ...form, specialty: e.target.value })} />
            </div>
          )}
          <div className="space-y-1">
            <Label htmlFor="af-addr">{t("common.address")}</Label>
            <Input id="af-addr" value={form.addressLine} onChange={(e) => setForm({ ...form, addressLine: e.target.value })} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="af-phone">{t("common.phone")}</Label>
            <Input id="af-phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="01XXXXXXXXX" />
          </div>
          <div className="space-y-1">
            <Label htmlFor="af-source">{t("admin.sourceLabel")}</Label>
            <Input id="af-source" value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })} placeholder={t("admin.sourceHint")} />
          </div>
          <Button size="sm" onClick={() => void addFacility()} disabled={busy || !form.name || !form.source}>
            <Plus className="h-4 w-4 mr-1" /> {t("common.submit")}
          </Button>
        </Card>

        <Card className="p-4 space-y-3">
          <h2 className="font-semibold text-sm">{t("admin.attachBarcode")}</h2>
          <div className="space-y-1">
            <Label htmlFor="bc-med">{t("admin.medicineId")}</Label>
            <Input id="bc-med" value={bar.medicineId} onChange={(e) => setBar({ ...bar, medicineId: e.target.value })} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="bc-code">{t("med.barcode")}</Label>
            <Input id="bc-code" value={bar.barcode} onChange={(e) => setBar({ ...bar, barcode: e.target.value })} placeholder="8951000000000" />
          </div>
          <Button size="sm" onClick={() => void attachBarcode()} disabled={busy || !bar.medicineId || !bar.barcode}>
            {t("common.save")}
          </Button>
          {message && <p className="text-sm text-emerald-700">{message}</p>}
        </Card>
      </div>
    );
  }

  function AuditTab() {
    const [rows, setRows] = useState<AuditRow[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    useEffect(() => {
      void (async () => {
        try {
          const res = await apiFetch<{ logs: AuditRow[] }>("/api/admin/audit");
          setRows(res.logs);
        } catch (err) {
          setError(err instanceof ApiClientError ? err.message : t("err.generic"));
        } finally {
          setLoading(false);
        }
      })();
    }, [t]);
    if (error) return <ErrorNote message={error} />;
    if (loading) return <LoadingCards />;
    if (rows.length === 0) return <EmptyState title={t("common.empty")} />;
    return (
      <div className="overflow-x-auto rounded-lg border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left">
            <tr>
              <th className="px-3 py-2 font-medium">{t("admin.auditAction")}</th>
              <th className="px-3 py-2 font-medium">{t("admin.auditEntity")}</th>
              <th className="px-3 py-2 font-medium">{t("admin.auditUser")}</th>
              <th className="px-3 py-2 font-medium">{t("admin.auditIp")}</th>
              <th className="px-3 py-2 font-medium">{t("common.date")}</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {rows.map((l) => (
              <tr key={l.id}>
                <td className="px-3 py-2 font-medium">{l.action}</td>
                <td className="px-3 py-2 text-muted-foreground">{l.entity}{l.entityId ? ` · ${l.entityId.slice(0, 10)}…` : ""}</td>
                <td className="px-3 py-2 text-muted-foreground">{l.user ? `${l.user.name} (${l.user.role})` : "—"}</td>
                <td className="px-3 py-2 text-muted-foreground">{l.ip ?? "—"}</td>
                <td className="px-3 py-2 text-muted-foreground">{new Date(l.createdAt).toLocaleString(locale === "bn" ? "bn-BD" : "en-GB")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

function PillIcon() {
  return <span className="text-xs font-semibold">Rx</span>;
}
