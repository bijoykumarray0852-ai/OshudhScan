"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertOctagon,
  AlertTriangle,
  BadgeCheck,
  Building2,
  Clock,
  Info,
  Loader2,
  MapPin,
  Moon,
  ShieldCheck,
  Star,
  Sun,
  Sunrise,
  Volume2,
  Square,
  Tag,
  TrendingDown,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { matchPharmacies } from "@/lib/pharmacies";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/hooks/use-i18n";
import { useAppStore } from "@/lib/store";
import { fmtBdt } from "./shared";
import type { DecodeResponse, Finding, MatchedMedicine } from "@/lib/types";

interface ExplainResult {
  generatedBy: string;
  items: Array<{ id: string; brand: string; bangla: string; note: string }>;
  summary: string;
}

interface Props {
  decoded: DecodeResponse;
  sampleTitle: string | null;
  explain: ExplainResult | null;
}

const SEVERITY_STYLE: Record<string, { card: string; icon: React.ReactNode; label: string }> = {
  major: {
    card: "border-red-300 bg-red-50/70",
    icon: <AlertOctagon className="h-5 w-5 text-red-600" />,
    label: "bg-red-600 text-white",
  },
  moderate: {
    card: "border-amber-300 bg-amber-50/70",
    icon: <AlertTriangle className="h-5 w-5 text-amber-600" />,
    label: "bg-amber-500 text-white",
  },
  minor: {
    card: "border-border bg-muted/40",
    icon: <Info className="h-5 w-5 text-slate-500" />,
    label: "bg-slate-500 text-white",
  },
  info: {
    card: "border-border bg-muted/40",
    icon: <Info className="h-5 w-5 text-slate-500" />,
    label: "bg-slate-500 text-white",
  },
};

function DoseSlots({ dose }: { dose: string | null }) {
  const { t } = useI18n();
  if (!dose) return <span className="text-xs text-muted-foreground">{t("rx.prn")}</span>;
  const parts = dose.split("+").map((p) => parseInt(p, 10) > 0);
  const icons = [
    { on: parts[0], icon: <Sunrise className="h-3.5 w-3.5" />, name: t("rx.slotMorning") },
    { on: parts[1], icon: <Sun className="h-3.5 w-3.5" />, name: t("rx.slotNoon") },
    { on: parts[2], icon: <Moon className="h-3.5 w-3.5" />, name: t("rx.slotNight") },
  ];
  return (
    <span className="inline-flex items-center gap-1">
      <span className="font-mono text-xs">{dose}</span>
      <span className="inline-flex items-center gap-0.5 text-muted-foreground">
        {icons.map((s, i) => (
          <span
            key={i}
            className={s.on ? "text-emerald-600" : "text-muted-foreground/30"}
            aria-label={s.name}
            aria-hidden={s.on ? undefined : "true"}
            title={s.name}
          >
            {s.icon}
          </span>
        ))}
      </span>
    </span>
  );
}

function MedicineCard({ m }: { m: MatchedMedicine }) {
  const { t } = useI18n();
  const confPct = Math.round(m.confidence * 100);
  const methodKey: Record<string, string> = {
    exact: "rx.methodExact",
    alias: "rx.methodAlias",
    fuzzy: "rx.methodFuzzy",
    generic: "rx.methodGeneric",
    unmatched: "rx.methodUnmatched",
  };
  return (
    <Card className={m.brand ? "" : "border-dashed opacity-80"}>
      <CardContent className="p-4 space-y-2.5">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-semibold">{m.brand ?? `? ${m.brandRaw}`}</span>
              {m.strength && <Badge variant="secondary" className="font-mono text-[11px]">{m.strength}</Badge>}
              {m.manufacturer && <Badge variant="outline" className="text-[11px] text-muted-foreground">{m.manufacturer}</Badge>}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {t("rx.writtenAs")} <span className="font-mono">“{m.brandRaw}”</span>
            </p>
          </div>
          <Badge
            variant="outline"
            className={
              confPct >= 90
                ? "border-emerald-300 bg-emerald-50 text-emerald-700"
                : confPct >= 72
                  ? "border-amber-300 bg-amber-50 text-amber-700"
                  : "border-red-300 bg-red-50 text-red-600"
            }
          >
            <BadgeCheck className="mr-1 h-3 w-3" /> {t(methodKey[m.matchMethod] ?? "rx.methodUnmatched")} · {confPct}%
          </Badge>
        </div>

        {m.brand && (
          <div className="rounded-md bg-emerald-50/70 border border-emerald-200/70 px-3 py-2">
            <p className="text-sm">
              <span className="text-muted-foreground">{t("rx.genericLabel")}: </span>
              <span className="font-medium text-emerald-900">{m.generic}</span>
            </p>
            {m.genericBangla && (
              <p className="font-bangla text-sm text-emerald-800/80">
                <span>{t("rx.genericBanglaLabel")}: </span>{m.genericBangla}
              </p>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" /> <DoseSlots dose={m.dose} />
          </span>
          {m.duration && <span>· {m.duration}</span>}
          {m.qty !== null && <span>· {t("rx.unitsTotal", { qty: m.qty })}</span>}
          {m.meal && m.meal !== "any" && (
            <span>· {m.meal === "after" ? t("rx.afterFood") : t("rx.beforeFood")}</span>
          )}
        </div>

        {m.brand && m.unitPriceBdt !== null && (
          <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
            <span className="inline-flex items-center gap-1 text-muted-foreground">
              <Tag className="h-3.5 w-3.5" /> {fmtBdt(m.unitPriceBdt)}/{t("rx.unit")}
              {m.qty !== null && <span>× {m.qty} = <span className="font-medium text-foreground">{fmtBdt(m.lineTotalBdt)}</span></span>}
            </span>
            {m.genericUnitPriceBdt !== null && (
              <span className="text-emerald-700">
                {t("rx.genericPrice")}: {fmtBdt(m.genericUnitPriceBdt)}/{t("rx.unit")}
                {m.qty !== null && m.genericLineTotalBdt !== null && <> · {fmtBdt(m.genericLineTotalBdt)}</>}
              </span>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function FindingCard({ f }: { f: Finding }) {
  const { t } = useI18n();
  const style = SEVERITY_STYLE[f.severity];
  const severityKey = f.severity === "major" ? "rx.sevMajor" : f.severity === "moderate" ? "rx.sevModerate" : "rx.sevMinor";
  return (
    <div className={`rounded-lg border p-4 ${style.card}`}>
      <div className="flex items-start gap-3">
        {style.icon}
        <div className="min-w-0 flex-1 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide ${style.label}`}>
              {t(severityKey)}
            </span>
            <span className="font-medium leading-snug">{f.title}</span>
          </div>
          <p className="text-sm text-muted-foreground">{f.detail}</p>
          <p className="rounded-md bg-background/80 px-3 py-2 text-sm">
            <span className="font-medium">{t("rx.whatToDo")}: </span>{f.action}
          </p>
          <div className="flex flex-wrap items-center gap-1.5">
            {f.drugs.map((d, i) => (
              <Badge key={i} variant="secondary" className="text-[11px]">{d}</Badge>
            ))}
            <span className="ml-auto font-mono text-[10px] text-muted-foreground/70">{f.source}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function PharmacyCard({ match, leadSent }: { match: ReturnType<typeof matchPharmacies>[number]; leadSent: boolean }) {
  const { t } = useI18n();
  const ph = match.pharmacy;
  return (
    <Card className={ph.open ? "" : "opacity-75"}>
      <CardContent className="p-4 space-y-2.5">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 shrink-0 text-emerald-700" />
              <span className="font-medium truncate">{ph.name}</span>
            </div>
            <p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3" /> {ph.area} · {ph.distanceKm} km
              <span className="inline-flex items-center gap-0.5"><Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {ph.rating}</span>
            </p>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Badge className={ph.open ? "bg-emerald-600" : "bg-slate-400"}>{ph.open ? t("common.openNow") : t("common.closed")}</Badge>
            {ph.partner && <Badge variant="outline" className="text-[10px]">{t("rx.leadEnginePro")}</Badge>}
          </div>
        </div>

        <div>
          <div className="mb-1 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">{t("rx.stockCoverage")}</span>
            <span className={match.coveragePct === 100 ? "font-semibold text-emerald-700" : "font-semibold text-amber-600"}>
              {match.coveragePct}%
            </span>
          </div>
          <Progress value={match.coveragePct} className="h-2" aria-label={t("rx.stockCoverage")} />
          <div className="mt-1.5 flex flex-wrap gap-1">
            {match.stockedBrands.map((b) => (
              <Badge key={b} variant="secondary" className="text-[10px] bg-emerald-50 text-emerald-800 border-emerald-200">{b}</Badge>
            ))}
            {match.missingBrands.map((b) => (
              <Badge key={b} variant="secondary" className="text-[10px] line-through opacity-60">{b}</Badge>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{ph.leadStat}</span>
          {leadSent && (
            <span className="inline-flex items-center gap-1.5 font-medium text-emerald-700">
              <span className="relative flex h-2 w-2 text-emerald-600 pulse-ring" /> {t("rx.leadSent")}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export function ResultsTabs({ decoded, sampleTitle, explain }: Props) {
  const { t } = useI18n();
  const { toast } = useToast();
  const setView = useAppStore((s) => s.setView);
  const matches = useMemo(() => matchPharmacies(decoded), [decoded]);
  const [audioState, setAudioState] = useState<"idle" | "loading" | "playing">("idle");
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const majors = decoded.findings.filter((f) => f.severity === "major").length;
  const moderates = decoded.findings.filter((f) => f.severity === "moderate").length;
  const minors = decoded.findings.filter((f) => f.severity === "minor").length;

  // stop playback when the results unmount (new decode, tab switch away)
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (typeof window !== "undefined" && window.speechSynthesis) window.speechSynthesis.cancel();
    };
  }, []);

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    if (typeof window !== "undefined" && window.speechSynthesis) window.speechSynthesis.cancel();
    setAudioState("idle");
  };

  const playText = async (text: string) => {
    if (audioState === "playing") {
      stopAudio();
      return;
    }
    setAudioState("loading");
    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) throw new Error("TTS unavailable");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onended = () => setAudioState("idle");
      audio.onerror = () => setAudioState("idle");
      await audio.play();
      setAudioState("playing");
    } catch {
      // Fallback: browser speech synthesis
      if (typeof window !== "undefined" && window.speechSynthesis) {
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = "bn-BD";
        utter.rate = 0.9;
        utter.onend = () => setAudioState("idle");
        window.speechSynthesis.speak(utter);
        setAudioState("playing");
        toast({
          title: t("rx.ttsFallbackTitle"),
          description: t("rx.ttsFallbackDesc"),
        });
      } else {
        setAudioState("idle");
        toast({
          title: t("rx.ttsUnavailableTitle"),
          description: t("rx.ttsUnavailableDesc"),
          variant: "destructive",
        });
      }
    }
  };

  const fullBangla = explain
    ? [explain.summary, ...explain.items.map((i) => i.bangla)].join(" ")
    : "";

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-xl font-bold tracking-tight">
          {t("rx.decodedResult")} {sampleTitle && <span className="text-muted-foreground">— {sampleTitle}</span>}
        </h3>
        <Badge variant="outline" className="font-mono text-[10px]">
          {t("rx.engine")}: {decoded.engine}
        </Badge>
      </div>

      <Tabs defaultValue="decoded">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="decoded">{t("rx.tabDecoded")} ({decoded.totals.itemsRecognized}/{decoded.totals.itemsTotal})</TabsTrigger>
          <TabsTrigger value="safety">
            <span className="inline-flex items-center gap-1.5">
              {t("rx.tabSafety")}
              {majors > 0 && (
                <span className="rounded-full bg-red-600 px-1.5 text-[10px] font-bold text-white">{majors}</span>
              )}
              {majors === 0 && moderates > 0 && (
                <span className="rounded-full bg-amber-500 px-1.5 text-[10px] font-bold text-white">{moderates}</span>
              )}
              {majors === 0 && moderates === 0 && minors > 0 && (
                <span className="rounded-full bg-slate-400 px-1.5 text-[10px] font-bold text-white">{minors}</span>
              )}
            </span>
          </TabsTrigger>
          <TabsTrigger value="dosage">{t("rx.tabDosage")}</TabsTrigger>
          <TabsTrigger value="pharmacies">{t("rx.tabPharmacies")} ({matches.length})</TabsTrigger>
        </TabsList>

        {/* Decoded */}
        <TabsContent value="decoded" className="space-y-4">
          <Card>
            <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4 text-sm">
              <div>
                <p className="font-medium">{decoded.ocr?.doctor ?? t("rx.unknownPrescriber")}</p>
                <p className="text-xs text-muted-foreground">
                  {t("rx.date")}: {decoded.ocr?.date ?? "—"} ·{" "}
                  {decoded.source === "sample" ? t("rx.curatedSample", { title: sampleTitle ?? "" }) : t("rx.uploadedPhoto", { title: sampleTitle ?? "" })}
                </p>
              </div>
              <div className="text-right">
                {decoded.totals.brandBdt !== null && (
                  <>
                    <p className="text-xs text-muted-foreground">{t("rx.fullCourse")}</p>
                    <p className="font-semibold">
                      {fmtBdt(Math.round(decoded.totals.brandBdt))}{" "}
                      <span className="font-normal text-emerald-700">
                        → {t("rx.genericSave", { generic: fmtBdt(Math.round(decoded.totals.genericBdt ?? 0)), save: fmtBdt(Math.round(decoded.totals.savingsBdt ?? 0)), pct: decoded.totals.savingsPct ?? 0 })}
                      </span>
                    </p>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-3 md:grid-cols-2">
            {decoded.medicines.map((m, i) => (
              <MedicineCard key={i} m={m} />
            ))}
          </div>
          <p className="text-[11px] text-muted-foreground">
            {t("rx.priceDisclaimer")}
          </p>
        </TabsContent>

        {/* Safety */}
        <TabsContent value="safety" className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            {majors > 0 && <Badge className="bg-red-600"><AlertOctagon className="mr-1 h-3 w-3" /> {t("rx.sevMajor")} {majors}</Badge>}
            {moderates > 0 && <Badge className="bg-amber-500">{t("rx.sevModerate")} {moderates}</Badge>}
            {minors > 0 && <Badge variant="secondary">{t("rx.sevMinor")} {minors}</Badge>}
            {decoded.findings.length === 0 && (
              <Badge className="bg-emerald-600"><ShieldCheck className="mr-1 h-3 w-3" /> {t("rx.cleanCheck")}</Badge>
            )}
            <span className="text-xs text-muted-foreground">
              {t("rx.deterministicNote")}
            </span>
          </div>

          {decoded.findings.length === 0 ? (
            <Card className="border-emerald-200 bg-emerald-50/50">
              <CardContent className="flex items-start gap-3 p-4">
                <ShieldCheck className="mt-0.5 h-5 w-5 text-emerald-600" />
                <div>
                  <p className="font-medium text-emerald-900">{t("rx.noConflicts")}</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {t("rx.kbCoverageNote")}
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {decoded.findings.map((f, i) => (
                <FindingCard key={i} f={f} />
              ))}
            </div>
          )}

          <p className="text-[11px] italic text-muted-foreground">
            {t("rx.decisionSupportNote")}
          </p>
        </TabsContent>

        {/* Dosage */}
        <TabsContent value="dosage" className="space-y-4">
          {explain ? (
            <>
              <Card className="bg-emerald-50/60 border-emerald-200">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-xs font-medium uppercase tracking-wide text-emerald-700">{t("rx.patientCard")}</p>
                      <p className="font-bangla mt-1 text-base leading-relaxed text-emerald-950">{explain.summary}</p>
                      <p className="mt-1 text-[11px] text-muted-foreground">
                        {explain.generatedBy === "llm" ? t("rx.generatedByLlm") : t("rx.generatedByTemplate")}
                      </p>
                    </div>
                    <Button onClick={() => void playText(fullBangla)} size="sm" className="shrink-0">
                      {audioState === "loading" ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : audioState === "playing" ? (
                        <Square className="mr-2 h-4 w-4" />
                      ) : (
                        <Volume2 className="mr-2 h-4 w-4" />
                      )}
                      {audioState === "playing" ? t("scan.stop") : t("scan.playAll")}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <div className="grid gap-3 md:grid-cols-2">
                {explain.items.map((item, i) => {
                  const m = decoded.medicines[i];
                  return (
                    <Card key={item.id || i}>
                      <CardContent className="p-4 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold">{item.brand}</span>
                          <Button variant="ghost" size="sm" className="h-8 px-2" onClick={() => void playText(item.bangla)} aria-label={t("rx.playFor", { brand: item.brand })}>
                            <Volume2 className="h-4 w-4 text-emerald-700" />
                          </Button>
                        </div>
                        <p className="font-bangla text-lg leading-relaxed">{item.bangla}</p>
                        {item.note && (
                          <p className="font-bangla rounded-md bg-amber-50 border border-amber-200 px-3 py-2 text-sm text-amber-900">
                            ⚠ {item.note}
                          </p>
                        )}
                        {m?.generic && (
                          <p className="text-xs text-muted-foreground">{t("rx.molecule")}: {m.generic}</p>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </>
          ) : (
            <Card>
              <CardContent className="p-6 text-sm text-muted-foreground">
                {t("rx.explainFailed")}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Pharmacies */}
        <TabsContent value="pharmacies" className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <Badge variant="outline"><MapPin className="mr-1 h-3 w-3" /> {t("rx.demoLocation")}</Badge>
            <span className="text-xs text-muted-foreground">
              {t("rx.pharmaciesStock", { count: matches.length })}
            </span>
          </div>
          {matches.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-sm text-muted-foreground">{t("rx.noStockMatches")}</CardContent>
            </Card>
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {matches.map((match) => (
                <PharmacyCard key={match.pharmacy.id} match={match} leadSent={match.pharmacy.partner} />
              ))}
            </div>
          )}
          <Separator />
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <TrendingDown className="h-4 w-4 shrink-0 text-emerald-600" />
            <span>
              {t("rx.demandSignal")}{" "}
              <button className="font-medium text-foreground underline underline-offset-2 hover:text-emerald-800" onClick={() => setView("pricing")}>
                {t("rx.pricingLink")}
              </button>
            </span>
          </div>
        </TabsContent>
      </Tabs>
    </section>
  );
}
