"use client";
// Healthcare Map — all directory categories on one interactive OpenStreetMap
// canvas with category filters, name search, cascading location filters and
// GPS nearby. Selection details use the standard Radix dialog (focus trap,
// Esc-to-close, real backdrop).
import { useCallback, useEffect, useMemo, useState } from "react";
import { Map as MapIcon, Search, MapPin, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useI18n } from "@/hooks/use-i18n";
import { apiFetch, ApiClientError, PageHeader, EmptyState, ErrorNote, LoadingCards, LocationPicker, type LocationSel } from "@/components/rx/shared";
import { MapCanvas, MapMarker, VerificationBadge, PhoneLine, MapsLinkButton } from "@/components/rx/directory-ui";
import type { FacilityRow, PharmacyRow } from "@/lib/directory-server";

interface SearchResp {
  facilities: { rows: FacilityRow[]; total: number };
  pharmacies: { rows: PharmacyRow[]; total: number };
}

const DEFAULT_CENTER = { lat: 23.8103, lng: 90.4125 }; // Dhaka
const KINDS = ["HOSPITAL", "CLINIC", "DIAGNOSTIC", "PHARMACY"] as const;

export function MapView() {
  const { t, locale } = useI18n();
  const [q, setQ] = useState("");
  const [kinds, setKinds] = useState<Set<string>>(new Set(KINDS));
  const [center, setCenter] = useState(DEFAULT_CENTER);
  const [loc, setLoc] = useState<LocationSel>({});
  const [geo, setGeo] = useState<{ lat: number; lng: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<SearchResp | null>(null);
  const [selected, setSelected] = useState<(FacilityRow | PharmacyRow) | null>(null);

  // location filters are the latest intent — they override a stale GPS point
  const [manualLoc, setManualLoc] = useState(false);

  const search = useCallback(
    async (opts: { q: string; origin?: { lat: number; lng: number } | null; loc?: LocationSel }) => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams();
        if (opts.q) params.set("q", opts.q);
        if (opts.origin) {
          params.set("lat", String(opts.origin.lat));
          params.set("lng", String(opts.origin.lng));
        } else {
          if (opts.loc?.division) params.set("division", opts.loc.division);
          if (opts.loc?.district) params.set("district", opts.loc.district);
          if (opts.loc?.upazila) params.set("upazila", opts.loc.upazila);
        }
        const res = await apiFetch<SearchResp>(`/api/directory/search?${params}`);
        setData(res);
      } catch (err) {
        setError(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally {
        setLoading(false);
      }
    },
    [t]
  );

  // initial load — Dhaka-centred preview, matching the home page
  useEffect(() => {
    void search({ q: "", origin: DEFAULT_CENTER });
  }, [search]);

  const markers: MapMarker[] = useMemo(() => {
    if (!data) return [];
    const out: MapMarker[] = [];
    if (kinds.has("HOSPITAL"))
      for (const f of data.facilities.rows.filter((r) => r.type === "HOSPITAL" && r.lat != null && r.lng != null))
        out.push({ id: `f-${f.id}`, lat: f.lat as number, lng: f.lng as number, label: locale === "bn" && f.nameBangla ? f.nameBangla : f.name, kind: "HOSPITAL", href: f.mapsSearchUrl });
    if (kinds.has("CLINIC"))
      for (const f of data.facilities.rows.filter((r) => r.type === "CLINIC" && r.lat != null && r.lng != null))
        out.push({ id: `f-${f.id}`, lat: f.lat as number, lng: f.lng as number, label: locale === "bn" && f.nameBangla ? f.nameBangla : f.name, kind: "CLINIC", href: f.mapsSearchUrl });
    if (kinds.has("DIAGNOSTIC"))
      for (const f of data.facilities.rows.filter((r) => r.type === "DIAGNOSTIC" && r.lat != null && r.lng != null))
        out.push({ id: `f-${f.id}`, lat: f.lat as number, lng: f.lng as number, label: locale === "bn" && f.nameBangla ? f.nameBangla : f.name, kind: "DIAGNOSTIC", href: f.mapsSearchUrl });
    if (kinds.has("PHARMACY"))
      for (const p of data.pharmacies.rows.filter((r) => r.lat != null && r.lng != null))
        out.push({ id: `p-${p.id}`, lat: p.lat as number, lng: p.lng as number, label: locale === "bn" && p.nameBangla ? p.nameBangla : p.name, kind: "PHARMACY", href: p.mapsSearchUrl });
    return out;
  }, [data, kinds, locale]);

  const useMyLocation = () => {
    if (!("geolocation" in navigator)) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const c = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setGeo(c);
        setCenter(c);
        setManualLoc(false);
        void search({ q, origin: c });
        setLocating(false);
      },
      () => setLocating(false),
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 }
    );
  };

  // manual location picked → recentre the map on the district centroid and
  // switch to name-based filtering (clears any GPS point)
  const pickLocation = (sel: LocationSel) => {
    setLoc(sel);
    setManualLoc(true);
    setGeo(null);
    if (sel.lat != null && sel.lng != null) setCenter({ lat: sel.lat, lng: sel.lng });
    const next: LocationSel = { ...sel };
    void search({ q, loc: next });
  };

  const isFacility = (r: FacilityRow | PharmacyRow): r is FacilityRow => "type" in r && "hospitalCategory" in r;
  const displayName = (r: FacilityRow | PharmacyRow) => (locale === "bn" && r.nameBangla ? r.nameBangla : r.name);

  const currentOrigin = manualLoc ? null : geo ?? DEFAULT_CENTER;
  const currentLoc = manualLoc ? loc : undefined;

  return (
    <>
      <PageHeader title={t("map.title")} subtitle={t("map.subtitle")} icon={<MapIcon className="h-6 w-6" />} eyebrow={t("map.eyebrow")} />

      <Card className="p-4 mb-5 space-y-3 shadow-soft">
        <div className="flex gap-2">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("map.searchPlaceholder")}
            aria-label={t("map.searchPlaceholder")}
            onKeyDown={(e) => e.key === "Enter" && void search({ q, origin: currentOrigin, loc: currentLoc })}
          />
          <Button onClick={() => void search({ q, origin: currentOrigin, loc: currentLoc })} aria-label={t("common.search")} disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          </Button>
          <Button variant={geo ? "default" : "outline"} onClick={useMyLocation} disabled={locating} aria-label={t("common.nearMe")}>
            {locating ? <Loader2 className="h-4 w-4 animate-spin" /> : <MapPin className="h-4 w-4" />}
            <span className="hidden sm:inline ml-1">{t("common.nearMe")}</span>
          </Button>
        </div>
        <LocationPicker value={loc} onChange={pickLocation} />
        <div className="flex flex-wrap gap-2">
          {KINDS.map((k) => (
            <button
              key={k}
              onClick={() => setKinds((s) => { const n = new Set(s); if (n.has(k)) n.delete(k); else n.add(k); return n; })}
              aria-pressed={kinds.has(k)}
              className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm font-medium transition-colors ${
                kinds.has(k) ? "border-transparent bg-teal-600 text-white shadow-soft" : "bg-background text-muted-foreground hover:border-emerald-300 hover:text-emerald-800"
              }`}
            >
              <span className={`h-2.5 w-2.5 rounded-full ${kinds.has(k) ? "bg-white/80" : "bg-teal-500"}`} />
              {t(`directory.kind.${k}`)}
            </button>
          ))}
        </div>
      </Card>

      {error && <ErrorNote message={error} onRetry={() => void search({ q, origin: currentOrigin, loc: currentLoc })} />}

      {loading && !data ? (
        <LoadingCards count={3} />
      ) : (
        <div className="grid gap-4 lg:grid-cols-[2fr_1fr]">
          <MapCanvas center={center} markers={markers} height={480} />

          <Card className="p-3 max-h-[520px] overflow-y-auto">
            <p className="mb-2 text-xs font-medium text-muted-foreground">{markers.length} {t("map.markersShown")}</p>
            {markers.length === 0 ? (
              <EmptyState title={t("common.noResults")} hint={t("map.noMarkers")} />
            ) : (
              <div className="space-y-2">
                {markers.map((m) => {
                  const row = m.id.startsWith("p-")
                    ? data?.pharmacies.rows.find((r) => `p-${r.id}` === m.id)
                    : data?.facilities.rows.find((r) => `f-${r.id}` === m.id);
                  if (!row) return null;
                  return (
                    <button
                      key={m.id}
                      onClick={() => setSelected(row)}
                      className="w-full rounded-lg border p-2.5 text-left text-sm transition-colors hover:border-teal-300 hover:bg-teal-50/40"
                    >
                      <p className="truncate font-medium">{displayName(row)}</p>
                      <p className="truncate text-xs text-muted-foreground">{row.addressLine}</p>
                    </button>
                  );
                })}
              </div>
            )}
          </Card>
        </div>
      )}

      {/* compact info card for a selected marker — Radix dialog so Esc works,
          focus is trapped and the backdrop dims */}
      <Dialog open={Boolean(selected)} onOpenChange={(o) => (o ? undefined : setSelected(null))}>
        <DialogContent className="sm:max-w-sm">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle>{displayName(selected)}</DialogTitle>
                <DialogDescription>{selected.addressLine}</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 text-sm">
                <div className="flex flex-wrap gap-2">
                  <VerificationBadge status={selected.verificationStatus} />
                  {isFacility(selected) && selected.emergency && (
                    <span className="rounded bg-red-600 px-1.5 py-0.5 text-[11px] font-medium text-white">{t("directory.emergency")}</span>
                  )}
                </div>
                {isFacility(selected) ? (
                  <PhoneLine phone={selected.phone} isPhoneVerified={selected.isPhoneVerified} />
                ) : (
                  <PhoneLine phone={selected.contactPhone || null} />
                )}
                <div className="flex flex-wrap gap-2">
                  {isFacility(selected) ? (
                    selected.phone ? (
                      <Button size="sm" variant="outline" asChild><a href={`tel:${selected.phone}`}>{t("common.call")}</a></Button>
                    ) : null
                  ) : (
                    selected.contactPhone ? (
                      <Button size="sm" variant="outline" asChild><a href={`tel:${selected.contactPhone}`}>{t("common.call")}</a></Button>
                    ) : null
                  )}
                  <MapsLinkButton href={selected.mapsSearchUrl} label={t("common.openInMaps")} />
                  {selected.mapsDirectionsUrl && <MapsLinkButton href={selected.mapsDirectionsUrl} label={t("common.directions")} />}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
