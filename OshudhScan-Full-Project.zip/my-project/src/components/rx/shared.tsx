"use client";
// Shared UI primitives for OshudhScan 2.0 views.
import { useCallback, useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { MapPin, ShieldCheck, ShieldAlert, FlaskConical, Clock } from "lucide-react";
import { formatDistance } from "@/lib/geo";
import { cn } from "@/lib/utils";
import { useI18n } from "@/hooks/use-i18n";
import { useAppStore } from "@/lib/store";

// ── API helper ────────────────────────────────────────────────────────────────

export class ApiClientError extends Error {
  code: string;
  status: number;
  constructor(code: string, message: string, status: number) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

export async function apiFetch<T = Record<string, unknown>>(
  url: string,
  init?: RequestInit
): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    });
  } catch {
    throw new ApiClientError("NETWORK", "Network problem", 0);
  }
  let body: Record<string, unknown> = {};
  try {
    body = await res.json();
  } catch {
    // non-JSON (shouldn't happen for JSON APIs)
  }
  if (!res.ok || body.ok === false) {
    throw new ApiClientError(
      String(body.code ?? "ERROR"),
      String(body.error ?? `Request failed (${res.status})`),
      res.status
    );
  }
  return body as T;
}

// ── page scaffolding ──────────────────────────────────────────────────────────

export function PageHeader({ title, subtitle, icon, eyebrow }: { title: string; subtitle?: string; icon?: React.ReactNode; eyebrow?: string }) {
  return (
    <div className="mb-6">
      {eyebrow && <p className="divider-label mb-2.5 max-w-[280px]">{eyebrow}</p>}
      <div className="flex items-start gap-3">
        {icon && (
          <div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-50 to-emerald-100 text-emerald-700 ring-1 ring-emerald-200/70">
            {icon}
          </div>
        )}
        <div>
          <h1 className="text-xl md:text-2xl font-bold tracking-tight">{title}</h1>
          {subtitle && <p className="mt-1 max-w-2xl text-sm leading-relaxed text-muted-foreground">{subtitle}</p>}
        </div>
      </div>
    </div>
  );
}

export function SectionTitle({ title, subtitle, className }: { title: string; subtitle?: string; className?: string }) {
  return (
    <div className={className}>
      <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
      {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
    </div>
  );
}

export function StatCard({ label, value, hint, icon, tone = "default" }: { label: string; value: string | number; hint?: string; icon?: React.ReactNode; tone?: "default" | "brand" | "warn" | "danger" }) {
  const toneCls =
    tone === "brand"
      ? "from-emerald-500 to-emerald-700 text-white"
      : tone === "warn"
        ? "from-amber-100 to-amber-200 text-amber-700"
        : tone === "danger"
          ? "from-red-100 to-red-200 text-red-700"
          : "from-emerald-50 to-emerald-100 text-emerald-700";
  return (
    <Card className="card-hover p-4 shadow-soft">
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        {icon && <span className={`flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br ${toneCls}`}>{icon}</span>}
      </div>
      <p className="stat-figure mt-1 text-2xl font-bold tabular-nums">{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </Card>
  );
}

export function EmptyState({ title, hint, action, icon }: { title: string; hint?: string; action?: React.ReactNode; icon?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-emerald-900/15 bg-gradient-to-b from-white to-emerald-50/40 px-6 py-12 text-center">
      <span className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-emerald-600 shadow-soft ring-1 ring-emerald-100">
        {icon ?? <MapPin className="h-5 w-5" />}
      </span>
      <p className="font-semibold">{title}</p>
      {hint && <p className="mt-1.5 max-w-sm text-sm leading-relaxed text-muted-foreground">{hint}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function LoadingCards({ count = 3 }: { count?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <Skeleton key={i} className="h-20 w-full" />
      ))}
    </div>
  );
}

export function ErrorNote({ message, onRetry }: { message: string; onRetry?: () => void }) {
  const { t } = useI18n();
  return (
    <div className="rounded-lg border border-destructive/40 bg-destructive/5 p-4 text-sm flex items-start gap-3">
      <span>{message}</span>
      {onRetry && (
        <Button size="sm" variant="outline" onClick={onRetry} className="ml-auto shrink-0">
          {t("common.retry")}
        </Button>
      )}
    </div>
  );
}

// ── status badges ─────────────────────────────────────────────────────────────

export function VerifiedBadge({ verified, demo }: { verified: boolean; demo?: boolean }) {
  const { t } = useI18n();
  return (
    <span className="inline-flex items-center gap-1.5 flex-wrap">
      {verified ? (
        <Badge className="bg-teal-600 text-white gap-1">
          <ShieldCheck className="h-3 w-3" /> {t("common.verified")}
        </Badge>
      ) : (
        <Badge variant="outline" className="text-muted-foreground gap-1">
          <ShieldAlert className="h-3 w-3" /> {t("common.unverified")}
        </Badge>
      )}
      {demo && <Badge variant="secondary">{t("common.demoData")}</Badge>}
    </span>
  );
}

const STOCK_STYLES: Record<string, string> = {
  IN_STOCK: "bg-emerald-600 text-white",
  LOW_STOCK: "bg-amber-500 text-white",
  OUT_OF_STOCK: "bg-red-600 text-white",
  STALE: "bg-slate-500 text-white",
  UNKNOWN: "bg-slate-400 text-white",
  EXPIRED: "bg-red-700 text-white",
};

const STOCK_KEYS: Record<string, "find.stockIn" | "find.stockLow" | "find.stockOut" | "find.stockStale" | "find.stockUnknown"> = {
  IN_STOCK: "find.stockIn",
  LOW_STOCK: "find.stockLow",
  OUT_OF_STOCK: "find.stockOut",
  STALE: "find.stockStale",
  UNKNOWN: "find.stockUnknown",
};

export function StockBadge({ status }: { status: string }) {
  const { t } = useI18n();
  return (
    <Badge className={cn("font-medium", STOCK_STYLES[status] ?? STOCK_STYLES.UNKNOWN)}>
      {t(STOCK_KEYS[status] ?? "find.stockUnknown")}
    </Badge>
  );
}

/** Honest freshness line: "updated 2h ago" / "updated just now". */
export function Freshness({ updatedAt }: { updatedAt: string | Date }) {
  const { t } = useI18n();
  const ms = Date.now() - new Date(updatedAt).getTime();
  const mins = Math.max(0, Math.round(ms / 60000));
  let ago: string;
  if (mins < 2) ago = t("find.updatedJustNow");
  else if (mins < 60) ago = t("find.updatedAgo", { ago: `${mins} min` });
  else if (mins < 60 * 24) ago = t("find.updatedAgo", { ago: `${Math.round(mins / 60)}h` });
  else ago = t("find.updatedAgo", { ago: `${Math.round(mins / (60 * 24))}d` });
  return (
    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
      <Clock className="h-3 w-3" /> {ago}
    </span>
  );
}

export function DistanceLabel({ km }: { km: number | null }) {
  const { t } = useI18n();
  if (km === null) return null;
  return (
    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
      <MapPin className="h-3 w-3" /> {t("find.distanceAway", { dist: formatDistance(km) })}
    </span>
  );
}

export function SourceNote({ source, className }: { source: string; className?: string }) {
  const { t } = useI18n();
  return (
    <p className={cn("text-xs text-muted-foreground flex items-center gap-1", className)}>
      <FlaskConical className="h-3 w-3 shrink-0" />
      <span>
        {t("common.dataSource")}: {source}
      </span>
    </p>
  );
}

// ── location picker (division → district → upazila) ──────────────────────────

export interface LocationSel {
  division?: string;
  district?: string;
  upazila?: string;
  lat?: number;
  lng?: number;
}

export interface LocationOption {
  id: string;
  name: string;
  nameBangla: string | null;
  lat?: number | null;
  lng?: number | null;
}

export function LocationPicker({
  value,
  onChange,
  className,
}: {
  value: LocationSel;
  onChange: (sel: LocationSel) => void;
  className?: string;
}) {
  const { t, locale } = useI18n();
  const [divisions, setDivisions] = useState<LocationOption[]>([]);
  const [districts, setDistricts] = useState<LocationOption[]>([]);
  const [upazilas, setUpazilas] = useState<LocationOption[]>([]);
  const [loading, setLoading] = useState(false);

  const label = (o: LocationOption) => (locale === "bn" && o.nameBangla ? o.nameBangla : o.name);

  const loadDivisions = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch<{ locations: LocationOption[] }>("/api/locations?level=DIVISION");
      setDivisions(res.locations);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadDivisions();
  }, [loadDivisions]);

  const pickDivision = async (name: string) => {
    onChange({ division: name });
    setUpazilas([]);
    const res = await apiFetch<{ locations: LocationOption[] }>(`/api/locations?level=DISTRICT&division=${encodeURIComponent(name)}`);
    setDistricts(res.locations);
  };
  const pickDistrict = async (o: LocationOption) => {
    onChange({ division: value.division, district: o.name, lat: o.lat ?? undefined, lng: o.lng ?? undefined });
    const res = await apiFetch<{ locations: LocationOption[] }>(`/api/locations?level=UPAZILA&district=${encodeURIComponent(o.name)}`);
    setUpazilas(res.locations);
  };

  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      <select
        aria-label={t("common.division")}
        className="h-9 rounded-md border bg-background px-2 text-sm"
        value={value.division ?? ""}
        onChange={(e) => void pickDivision(e.target.value)}
      >
        <option value="">{t("common.division")}</option>
        {divisions.map((d) => (
          <option key={d.id} value={d.name}>
            {label(d)}
          </option>
        ))}
      </select>
      <select
        aria-label={t("common.district")}
        className="h-9 rounded-md border bg-background px-2 text-sm"
        value={value.district ?? ""}
        onChange={(e) => {
          const opt = districts.find((d) => d.name === e.target.value);
          if (opt) void pickDistrict(opt);
        }}
        disabled={!value.division}
      >
        <option value="">{t("common.district")}</option>
        {districts.map((d) => (
          <option key={d.id} value={d.name}>
            {label(d)}
          </option>
        ))}
      </select>
      {upazilas.length > 0 && (
        <select
          aria-label={t("common.upazila")}
          className="h-9 rounded-md border bg-background px-2 text-sm"
          value={value.upazila ?? ""}
          onChange={(e) => onChange({ ...value, upazila: e.target.value || undefined })}
        >
          <option value="">{t("common.upazila")}</option>
          {upazilas.map((u) => (
            <option key={u.id} value={u.name}>
              {label(u)}
            </option>
          ))}
        </select>
      )}
      {loading && <span className="text-xs text-muted-foreground">{t("common.loading")}</span>}
    </div>
  );
}

// ── misc ──────────────────────────────────────────────────────────────────────

export function useRequireAuth() {
  const { t } = useI18n();
  const user = useAppStore((s) => s.user);
  const openAuth = useAppStore((s) => s.openAuth);
  return {
    user,
    t,
    /** returns true when signed in; otherwise opens the auth dialog */
    requireAuth: () => {
      if (user) return true;
      openAuth("signin");
      return false;
    },
    AuthGate: ({ children }: { children: React.ReactNode }) =>
      user ? (
        <>{children}</>
      ) : (
        <EmptyState
          title={t("auth.signInToContinue")}
          hint={t("common.privacyNote")}
          action={
            <Button onClick={() => openAuth("signin")}>{t("auth.signIn")}</Button>
          }
        />
      ),
  };
}

export function fmtBdt(n: number | null | undefined): string {
  if (n === null || n === undefined) return "—";
  return `৳${Number.isInteger(n) ? n.toLocaleString("en-IN") : n.toFixed(2)}`;
}

export function fmtDate(d: string | Date | null | undefined, locale = "en"): string {
  if (!d) return "—";
  const date = new Date(d);
  return date.toLocaleDateString(locale === "bn" ? "bn-BD" : "en-GB", { day: "numeric", month: "short", year: "numeric" });
}
