"use client";
// Low Internet Mode UI: banner that suggests lite mode on slow connections,
// and a compact header toggle. The LiteMapPlaceholder is rendered instead of
// the real map when lite mode is on — maps load only when the user asks.
import { useState } from "react";
import { WifiHigh, WifiLow, Map as MapIcon, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useI18n } from "@/hooks/use-i18n";
import { useLiteMode } from "@/lib/lite";

export function LiteModeSuggestBanner() {
  const { t } = useI18n();
  const { suggest, setLiteMode, liteMode } = useLiteMode();
  const [dismissed, setDismissed] = useState(false);
  if (liteMode || dismissed) return null;

  // Slow connection reported by the browser — offer the one-tap switch.
  if (suggest) {
    return (
      <div className="mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2.5 text-sm text-amber-900">
        <WifiLow className="h-4 w-4 shrink-0" />
        <span className="min-w-0 flex-1">{t("lite.suggest")}</span>
        <Button size="sm" variant="outline" className="h-8 border-amber-400 bg-white text-amber-900 hover:bg-amber-100" onClick={() => setLiteMode(true)}>
          {t("lite.turnOn")}
        </Button>
        <Button size="icon" variant="ghost" className="h-7 w-7 shrink-0 text-amber-700" aria-label={t("common.close")} onClick={() => setDismissed(true)}>
          <X className="h-4 w-4" />
        </Button>
      </div>
    );
  }
  return null;
}

/** Compact pill toggle used in the app header (visible on all screens). */
export function LiteModeToggle() {
  const { t } = useI18n();
  const { liteMode, setLiteMode, slow } = useLiteMode();
  return (
    <Button
      variant="outline"
      size="sm"
      className={`h-9 gap-1.5 rounded-full bg-white/70 shadow-soft backdrop-blur ${liteMode ? "border-emerald-500 text-emerald-800" : ""}`}
      onClick={() => setLiteMode(!liteMode)}
      aria-pressed={liteMode}
      aria-label={t("lite.title")}
      title={t("lite.title")}
    >
      {liteMode ? <WifiLow className="h-4 w-4" /> : <WifiHigh className={`h-4 w-4 ${slow ? "text-amber-600" : ""}`} />}
      <span className="hidden min-[430px]:inline">{t("lite.short")}</span>
    </Button>
  );
}

/**
 * Text-first substitute for a heavy map. Shows nothing but a small card with a
 * "load map" affordance so tiles/Leaflet only download when explicitly asked.
 */
export function LiteMapPlaceholder({ onLoad, className, compact }: { onLoad: () => void; className?: string; compact?: boolean }) {
  const { t } = useI18n();
  return (
    <Card className={`flex flex-col items-center justify-center gap-2 border-dashed bg-emerald-50/30 px-4 text-center ${compact ? "py-5" : "py-10"} ${className ?? ""}`}>
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-emerald-600 shadow-soft ring-1 ring-emerald-100">
        <MapIcon className="h-5 w-5" />
      </span>
      <p className="text-sm font-medium">{t("lite.mapHidden")}</p>
      <p className="max-w-xs text-xs leading-relaxed text-muted-foreground">{t("lite.mapHiddenHint")}</p>
      <Button size="sm" variant="outline" onClick={onLoad}>{t("lite.loadMap")}</Button>
    </Card>
  );
}
