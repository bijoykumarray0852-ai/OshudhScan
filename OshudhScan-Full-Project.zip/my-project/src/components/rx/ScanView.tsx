"use client";
import { useCallback, useRef, useState } from "react";
import { Camera, Loader2, RefreshCw, Sparkles, TriangleAlert, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SAMPLES, type SampleRx } from "@/lib/samples";
import { useAppStore } from "@/lib/store";
import { PostDecodeActions } from "@/components/rx/PostDecodeActions";
import { PipelineStages, type Stage, type StageStatus } from "./PipelineStages";
import { PrescriptionPaper } from "./PrescriptionPaper";
import { ResultsTabs } from "./ResultsTabs";
import { matchPharmacies } from "@/lib/pharmacies";
import { worstSeverity } from "@/lib/interactions";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/hooks/use-i18n";
import { apiFetch, ApiClientError, PageHeader } from "./shared";
import type { DecodeResponse } from "@/lib/types";

export function buildStages(t: (k: string, v?: Record<string, string | number>) => string): Stage[] {
  return [
    { key: "capture", label: t("scan.stage.capture"), detail: t("scan.stage.captureDetail") },
    { key: "ocr", label: t("scan.stage.ocr"), detail: t("scan.stage.ocrDetail") },
    { key: "kg", label: t("scan.stage.kg"), detail: t("scan.stage.kgDetail") },
    { key: "safety", label: t("scan.stage.safety"), detail: t("scan.stage.safetyDetail") },
    { key: "explain", label: t("scan.stage.explain"), detail: t("scan.stage.explainDetail") },
    { key: "stock", label: t("scan.stage.stock"), detail: t("scan.stage.stockDetail") },
  ];
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

type RunState = "idle" | "running" | "done" | "error";

export function ScanView() {
  const { t } = useI18n();
  const { toast } = useToast();
  const setDecoded = useAppStore((s) => s.setDecoded);
  const pushLeads = useAppStore((s) => s.pushLeads);
  const decoded = useAppStore((s) => s.decoded);
  const decodedSampleTitle = useAppStore((s) => s.decodedSampleTitle);
  const uploadedImagePreview = useAppStore((s) => s.uploadedImagePreview);

  const [runState, setRunState] = useState<RunState>(decoded ? "done" : "idle");
  const [statuses, setStatuses] = useState<Record<string, StageStatus>>({});
  const [stageDetail, setStageDetail] = useState<Record<string, string>>({});
  const [explainMeta, setExplainMeta] = useState<{ generatedBy: string; items: Array<{ id: string; brand: string; bangla: string; note: string }>; summary: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyUpload, setBusyUpload] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);
  const runIdRef = useRef(0);

  const STAGES = buildStages(t);

  const setStage = (key: string, status: StageStatus, detail?: string) => {
    setStatuses((s) => ({ ...s, [key]: status }));
    if (detail !== undefined) setStageDetail((d) => ({ ...d, [key]: detail }));
  };

  const resetStages = () => {
    const all: Record<string, StageStatus> = {};
    for (const st of STAGES) all[st.key] = "pending";
    setStatuses(all);
    setStageDetail({});
    setExplainMeta(null);
    setError(null);
  };

  const run = useCallback(
    async (payload: { sampleId?: string; imageBase64?: string; imagePreview?: string | null; title?: string | null }) => {
      const runId = ++runIdRef.current;
      resetStages();
      setRunState("running");

      const alive = () => runId === runIdRef.current;

      // Stage 1 — capture & preprocess
      setStage("capture", "running", payload.imageBase64 ? t("scan.stage.captureRunning") : t("scan.stage.captureSample"));
      await sleep(650);
      if (!alive()) return;
      setStage("capture", "done", payload.imageBase64 ? t("scan.stage.captureDone") : t("scan.stage.captureSampleDone"));

      // Stage 2 — OCR
      setStage(
        "ocr",
        payload.sampleId ? "skipped" : "running",
        payload.sampleId ? t("scan.stage.ocrSkipped") : t("scan.stage.ocrReading")
      );

      let data: DecodeResponse | null = null;
      try {
        data = await apiFetch<DecodeResponse>("/api/decode", {
          method: "POST",
          body: JSON.stringify(payload.sampleId ? { sampleId: payload.sampleId } : { imageBase64: payload.imageBase64 }),
        });
      } catch (e) {
        if (!alive()) return;
        setError(e instanceof ApiClientError ? e.message : t("scan.decodeRequestFailed"));
        setRunState("error");
        setStage("ocr", "pending");
        return;
      }
      if (!alive()) return;
      if (!data.ok) {
        setError(data.error ?? t("scan.couldNotDecode"));
        setRunState("error");
        setStage("ocr", "pending");
        return;
      }

      setStage(
        "ocr",
        payload.sampleId ? "skipped" : "done",
        payload.sampleId
          ? t("scan.stage.ocrSampleDone")
          : t("scan.stage.ocrDone", { lines: data.ocr?.medicines.length ?? 0, doctor: data.ocr?.doctor ?? "—" })
      );

      // Kick off Bangla explanation in parallel with the remaining animation.
      // Network failure must never break the pipeline — degrade to the
      // template dosage card instead (explain.ok=false path below).
      const explainPromise = (async () => {
        const items = data!.medicines.map((m, i) => ({
          id: `med-${i}`,
          brandRaw: m.brandRaw,
          brand: m.brand,
          generic: m.generic,
          strength: m.strength,
          dose: m.dose,
          duration: m.duration,
          meal: m.meal,
          therapeuticClass: m.therapeuticClass,
        }));
        return apiFetch<{ ok: boolean; generatedBy: string; items: Array<{ id: string; brand: string; bangla: string; note: string }>; summary: string }>(
          "/api/explain",
          { method: "POST", body: JSON.stringify({ items }) }
        );
      })().catch(() => ({ ok: false as const, generatedBy: "template", items: [], summary: "" }));

      // Stage 3 — brand mapping
      setStage("kg", "running");
      await sleep(550);
      if (!alive()) return;
      const avgConf = data.medicines.length
        ? Math.round((data.medicines.reduce((a, m) => a + m.confidence, 0) / data.medicines.length) * 100)
        : 0;
      setStage("kg", "done", t("scan.stage.kgDone", {
        matched: data.totals.itemsRecognized,
        total: data.totals.itemsTotal,
        conf: avgConf,
        generics: data.medicines.filter((m) => m.generic).length,
      }));

      // Stage 4 — safety engine
      setStage("safety", "running");
      await sleep(600);
      if (!alive()) return;
      const majors = data.findings.filter((f) => f.severity === "major").length;
      const moderates = data.findings.filter((f) => f.severity === "moderate").length;
      const minors = data.findings.filter((f) => f.severity === "minor").length;
      setStage(
        "safety",
        "done",
        data.findings.length === 0
          ? t("scan.stage.safetyClean")
          : t("scan.stage.safetyFindings", { total: data.findings.length, majors, moderates, minors })
      );

      // Stage 5 — Bangla explainer
      setStage("explain", "running");
      const explain = await explainPromise;
      if (!alive()) return;
      setExplainMeta(explain.ok ? explain : null);
      setStage(
        "explain",
        "done",
        explain.ok
          ? t("scan.stage.explainDone", { lines: explain.items.length, by: explain.generatedBy === "llm" ? "LLM" : t("scan.stage.templateFallback") })
          : t("scan.stage.explainUnavailable")
      );

      // Stage 6 — pharmacy stock match + leads
      setStage("stock", "running");
      await sleep(500);
      if (!alive()) return;
      const matches = matchPharmacies(data);
      const fullMatches = matches.filter((m) => m.coveragePct === 100);
      const leads = matches.slice(0, 5).map((m, i) => ({
        id: `lead-${Date.now()}-${i}`,
        createdAt: Date.now() - i * 40_000,
        pharmacyName: m.pharmacy.name,
        patientRef: `R-${String(Math.floor(1000 + Math.random() * 9000))}`,
        items: data!.medicines.filter((mm) => mm.brand).slice(0, 4).map((mm) => `${mm.brand}${mm.strength ? " " + mm.strength : ""}`),
        safetyFlag: worstSeverity(data!.findings),
        distanceKm: m.pharmacy.distanceKm,
        estBasketBdt: Math.round(data!.totals.brandBdt ?? 650),
        status: "new" as const,
      }));
      pushLeads(leads);
      setStage("stock", "done", t("scan.stage.stockDone", { pharmacies: matches.length, full: fullMatches.length, leads: leads.length }));

      // commit to global store + show results
      setDecoded(data, payload.title ?? null, payload.imagePreview ?? null);
      setRunState("done");
      toast({
        title: majors > 0 ? t("scan.toastMajor", { majors }) : t("scan.toastDecoded"),
        description:
          majors > 0
            ? t("scan.toastMajorDesc")
            : t("scan.toastDesc", { recognized: data.totals.itemsRecognized, total: data.totals.itemsTotal }),
      });
      setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 150);
    },
    // STAGES is rebuilt on every render from t(); run only needs the setters
    // and t is stable per locale — list t to refresh strings on locale switch.
    [pushLeads, setDecoded, toast, t]
  );

  const handleFile = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast({ title: t("scan.pleaseImage"), variant: "destructive" });
      return;
    }
    setBusyUpload(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error(t("scan.couldNotReadFile")));
        reader.readAsDataURL(file);
      });
      const img = new Image();
      img.src = dataUrl;
      await new Promise((resolve, reject) => { img.onload = resolve; img.onerror = reject; });
      const max = 1024;
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error(t("scan.canvasUnavailable"));
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const resized = canvas.toDataURL("image/jpeg", 0.85);
      const base64 = resized.split(",")[1];
      await run({ imageBase64: base64, imagePreview: resized, title: file.name.slice(0, 24) });
    } catch (e) {
      toast({ title: t("scan.uploadFailed"), description: e instanceof Error ? e.message : t("err.generic"), variant: "destructive" });
    } finally {
      setBusyUpload(false);
    }
  };

  const allDone = runState === "done" && decoded;

  return (
    <div className="space-y-8">
      <PageHeader title={t("scan.pageTitle")} subtitle={t("scan.pageSubtitle")} icon={<Sparkles className="h-6 w-6" />} />

      {/* Input row */}
      <div className="grid gap-4 md:grid-cols-3">
        {SAMPLES.map((sample) => (
          <SampleCard key={sample.id} sample={sample} onRun={() => run({ sampleId: sample.id, title: sample.title })} disabled={runState === "running"} />
        ))}
      </div>

      {/* Upload + pipeline */}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
          <Card className="border-dashed">
            <CardContent className="p-6">
              <div className="flex flex-col items-center gap-3 text-center">
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-50 text-emerald-700">
                  <Camera className="h-6 w-6" />
                </span>
                <div>
                  <p className="font-medium">{t("scan.uploadTitle")}</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {t("scan.uploadDesc")}
                  </p>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="sr-only"
                  aria-label={t("scan.uploadTitle")}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void handleFile(f);
                    e.target.value = "";
                  }}
                />
                <Button onClick={() => fileInputRef.current?.click()} disabled={busyUpload || runState === "running"}>
                  {busyUpload ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                  {busyUpload ? t("scan.decoding") : t("scan.choosePhoto")}
                </Button>
                {uploadedImagePreview && (
                  <div className="relative mt-2 w-full max-w-sm overflow-hidden rounded-lg border">
                    <img src={uploadedImagePreview} alt={t("scan.uploadTitle")} className="max-h-64 w-full object-contain bg-muted" />
                    {runState === "running" && (
                      <div className="absolute inset-0" aria-hidden="true">
                        <div className="scanline absolute left-0 h-0.5 w-full bg-emerald-500" />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {error && (
            <Card className="border-destructive/40 bg-destructive/5">
              <CardContent className="flex items-start gap-3 p-4">
                <TriangleAlert className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-destructive">{t("scan.decodeFailed")}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{error}</p>
                  <Button size="sm" variant="outline" className="mt-2" onClick={() => { setRunState("idle"); setError(null); }}>
                    <RefreshCw className="mr-2 h-3.5 w-3.5" /> {t("scan.tryAgain")}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <Card>
          <CardContent className="p-4 sm:p-6">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">{t("scan.pipelineLive")}</h3>
              {runState === "running" && <Badge variant="outline" className="animate-pulse">{t("scan.processing")}</Badge>}
              {runState === "done" && <Badge className="bg-emerald-600">{t("scan.complete")}</Badge>}
            </div>
            <PipelineStages stages={STAGES} statuses={statuses} currentDetail={stageDetail} />
          </CardContent>
        </Card>
      </div>

      {/* Results */}
      <div ref={resultsRef}>
        {allDone && decoded && (
          <>
            <ResultsTabs decoded={decoded} sampleTitle={decodedSampleTitle} explain={explainMeta} />
            <PostDecodeActions decoded={decoded} />
          </>
        )}
      </div>
    </div>
  );
}

function SampleCard({ sample, onRun, disabled }: { sample: SampleRx; onRun: () => void; disabled?: boolean }) {
  const { t } = useI18n();
  return (
    <div className="group space-y-2">
      <PrescriptionPaper sample={sample} compact />
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{sample.title}</p>
          <p className="text-[11px] leading-tight text-muted-foreground">{sample.expectedHeadline}</p>
        </div>
        <Button size="sm" onClick={onRun} disabled={disabled} className="shrink-0">
          <Sparkles className="mr-1.5 h-3.5 w-3.5" /> {t("scan.decodeCta")}
        </Button>
      </div>
    </div>
  );
}
