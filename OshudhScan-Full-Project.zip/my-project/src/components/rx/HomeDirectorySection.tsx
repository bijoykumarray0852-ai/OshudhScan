"use client";
// Home page National Directory finder — large location search bar (division →
// district → upazila), current-location button, category shortcuts, nearby
// hospitals & pharmacies previews and the emergency directory shortcut.
import { useCallback, useEffect, useState } from "react";
import { Building2, Stethoscope, FlaskConical, Pill, Siren, MapPin, Search, Navigation, ArrowRight, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useI18n } from "@/hooks/use-i18n";
import { useAppStore } from "@/lib/store";
import { apiFetch, ApiClientError, ErrorNote } from "@/components/rx/shared";
import { DependentLocationSelects, useDependentLocations, MapsLinkButton, PhoneLine } from "@/components/rx/directory-ui";
import type { FacilityRow, PharmacyRow } from "@/lib/directory-server";

interface SearchResp {
  facilities: { rows: FacilityRow[]; total: number };
  pharmacies: { rows: PharmacyRow[]; total: number };
}

export function HomeDirectorySection() {
  const { t, locale } = useI18n();
  const setView = useAppStore((s) => s.setView);
  const loc = useDependentLocations();
  const [q, setQ] = useState("");
  const [geo, setGeo] = useState<{ lat: number; lng: number } | null>(null);
  const [geoState, setGeoState] = useState<"idle" | "locating" | "denied" | "ok">("idle");
  const [locating, setLocating] = useState(false);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<SearchResp | null>(null);
  const [error, setError] = useState<string | null>(null);

  const search = useCallback(async (lat?: number, lng?: number) => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (q) params.set("q", q);
      if (lat != null && lng != null) { params.set("lat", String(lat)); params.set("lng", String(lng)); }
      else {
        if (loc.sel.division) params.set("division", loc.sel.division);
        if (loc.sel.district) params.set("district", loc.sel.district);
        if (loc.sel.upazila) params.set("upazila", loc.sel.upazila);
      }
      const res = await apiFetch<SearchResp>(`/api/directory/search?${params}`);
      setData(res);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setLoading(false);
    }
  }, [q, loc.sel, t]);

  // initial preview — Dhaka centre (same default as the map view) so the
  // "nearby" cards show actually-nearby records until the user picks a
  // location or taps near-me
  useEffect(() => { void search(23.8103, 90.4125); }, []);

  // picking any manual location immediately re-searches with those filters —
  // waiting for a second "Search" click made it look like location selection
  // did nothing (the original bug report)
  useEffect(() => {
    if (loc.sel.division || loc.sel.district || loc.sel.upazila) void search();
  }, [loc.sel]);

  const useMyLocation = () => {
    if (!("geolocation" in navigator)) {
      setGeoState("denied");
      return;
    }
    setLocating(true);
    setGeoState("locating");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeo({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGeoState("ok");
        void search(pos.coords.latitude, pos.coords.longitude);
        setLocating(false);
      },
      () => {
        setGeo(null);
        setGeoState("denied");
        setLocating(false);
      },
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 }
    );
  };

  // picking a manual location is the most recent intent — drop the GPS point
  // so it can no longer silently override the division/district selection
  const clearGeo = () => { setGeo(null); setGeoState("idle"); };
  const pickDivision = (v: string) => { clearGeo(); void loc.pickDivision(v); };
  const pickDistrict = (v: string) => { clearGeo(); void loc.pickDistrict(loc.sel.division, v); };
  const pickUpazila = (v: string) => { clearGeo(); loc.pickUpazila(loc.sel.division, loc.sel.district, v); };

  const shortcuts = [
    { key: "HOSPITAL", icon: <Building2 className="h-5 w-5" />, view: "directory" as const, tab: null },
    { key: "CLINIC", icon: <Stethoscope className="h-5 w-5" />, view: "directory" as const, tab: null },
    { key: "DIAGNOSTIC", icon: <FlaskConical className="h-5 w-5" />, view: "directory" as const, tab: null },
    { key: "PHARMACY", icon: <Pill className="h-5 w-5" />, view: "find" as const, tab: null },
  ];

  const nearbyHospitals = (data?.facilities.rows ?? []).filter((f) => f.type === "HOSPITAL").slice(0, 3);
  const nearbyPharmacies = (data?.pharmacies.rows ?? []).slice(0, 3);

  return (
    <section className="space-y-6">
      <div className="mx-auto max-w-2xl text-center">
        <p className="divider-label mb-3">{t("homeDir.eyebrow")}</p>
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("homeDir.title")}</h2>
        <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground sm:text-base">{t("homeDir.sub")}</p>
      </div>

      {/* search panel */}
      <Card className="mx-auto max-w-3xl p-4 shadow-soft sm:p-5">
        <div className="flex flex-col gap-2.5">
          <div className="flex gap-2">
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("homeDir.searchPlaceholder")}
              aria-label={t("homeDir.searchPlaceholder")}
              className="h-11 text-[15px]"
              onKeyDown={(e) => e.key === "Enter" && void search(geo?.lat, geo?.lng)}
            />
            <Button className="btn-brand h-11 px-4" onClick={() => void search(geo?.lat, geo?.lng)} aria-label={t("common.search")}>
              <Search className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <DependentLocationSelects
              sel={loc.sel}
              divisions={loc.divisions}
              districts={loc.districts}
              upazilas={loc.upazilas}
              onDivision={pickDivision}
              onDistrict={pickDistrict}
              onUpazila={pickUpazila}
              className="flex-1"
            />
            <Button variant={geo ? "default" : "outline"} className="h-9" onClick={useMyLocation} disabled={locating}>
              {locating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Navigation className="h-4 w-4" />}
              <span className="ml-1">{locating ? t("common.locating") : t("common.nearMe")}</span>
            </Button>
          </div>
        </div>
        {geoState === "denied" && <p className="mt-2 text-xs text-destructive">{t("common.locationDenied")}</p>}
        {error && (
          <div className="mt-2">
            <ErrorNote message={error} onRetry={() => void search(geo?.lat, geo?.lng)} />
          </div>
        )}

        {/* category shortcuts */}
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {shortcuts.map((s) => (
            <button
              key={s.key}
              onClick={() => setView(s.view)}
              className="card-hover flex flex-col items-center gap-1.5 rounded-xl border bg-gradient-to-b from-white to-emerald-50/50 px-3 py-3.5 text-center transition-colors hover:border-emerald-300"
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-teal-600/10 text-teal-700">{s.icon}</span>
              <span className="text-xs font-semibold">{t(`directory.kind.${s.key}`)}</span>
            </button>
          ))}
        </div>
      </Card>

      {/* nearby previews */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="card-hover shadow-soft">
          <CardContent className="p-4">
            <div className="mb-3 flex items-center justify-between">
              <p className="flex items-center gap-2 text-sm font-semibold">
                <Building2 className="h-4 w-4 text-teal-700" /> {t("homeDir.nearbyHospitals")}
              </p>
              <Badge variant="secondary" className="text-[11px]">{data?.facilities.total ?? 0} {t("common.results")}</Badge>
            </div>
            {loading ? (
              <div className="flex items-center gap-2 py-6 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> {t("common.loading")}</div>
            ) : nearbyHospitals.length === 0 ? (
              <p className="py-4 text-sm text-muted-foreground">{t("homeDir.noNearby")}</p>
            ) : (
              <div className="space-y-2.5">
                {nearbyHospitals.map((f) => (
                  <div key={f.id} className="rounded-lg border p-2.5">
                    <p className="text-sm font-medium leading-snug">{locale === "bn" && f.nameBangla ? f.nameBangla : f.name}</p>
                    <p className="text-xs text-muted-foreground">{[f.area, f.district].filter(Boolean).join(", ")}</p>
                    <div className="mt-1.5"><PhoneLine phone={f.phone} isPhoneVerified={f.isPhoneVerified} /></div>
                  </div>
                ))}
                <Button variant="ghost" size="sm" className="w-full" onClick={() => setView("directory")}>
                  {t("homeDir.viewAll")} <ArrowRight className="ml-1 h-3.5 w-3.5" />
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="card-hover shadow-soft">
          <CardContent className="p-4">
            <div className="mb-3 flex items-center justify-between">
              <p className="flex items-center gap-2 text-sm font-semibold">
                <Pill className="h-4 w-4 text-emerald-700" /> {t("homeDir.nearbyPharmacies")}
              </p>
              <Badge variant="secondary" className="text-[11px]">{data?.pharmacies.total ?? 0} {t("common.results")}</Badge>
            </div>
            {loading ? (
              <div className="flex items-center gap-2 py-6 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> {t("common.loading")}</div>
            ) : nearbyPharmacies.length === 0 ? (
              <p className="py-4 text-sm text-muted-foreground">{t("homeDir.noNearby")}</p>
            ) : (
              <div className="space-y-2.5">
                {nearbyPharmacies.map((p) => (
                  <div key={p.id} className="rounded-lg border p-2.5">
                    <p className="text-sm font-medium leading-snug">{locale === "bn" && p.nameBangla ? p.nameBangla : p.name}</p>
                    <p className="text-xs text-muted-foreground">{[p.area, p.district].filter(Boolean).join(", ")}</p>
                    <div className="mt-1.5 flex items-center justify-between gap-2">
                      <PhoneLine phone={p.contactPhone || null} />
                      {p.mapsDirectionsUrl && <MapsLinkButton href={p.mapsDirectionsUrl} label={t("common.directions")} />}
                    </div>
                  </div>
                ))}
                <Button variant="ghost" size="sm" className="w-full" onClick={() => setView("find")}>
                  {t("homeDir.viewAll")} <ArrowRight className="ml-1 h-3.5 w-3.5" />
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* emergency + map shortcuts */}
      <div className="grid gap-4 md:grid-cols-2">
        <button onClick={() => setView("care")} className="card-hover group rounded-2xl border border-red-200 bg-gradient-to-br from-red-50 to-white p-5 text-left shadow-soft transition-colors hover:border-red-300">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-red-600 text-white shadow-soft">
              <Siren className="h-5 w-5" />
            </span>
            <div>
              <p className="font-bold text-red-800">{t("homeDir.emergencyTitle")}</p>
              <p className="text-xs leading-relaxed text-red-700/80">{t("homeDir.emergencySub")}</p>
            </div>
            <ArrowRight className="ml-auto h-4 w-4 text-red-500 transition-transform group-hover:translate-x-1" />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Badge className="bg-red-600 text-white">999</Badge>
            <Badge variant="outline" className="border-red-200 text-red-700">{t("homeDir.emergencyChip1")}</Badge>
            <Badge variant="outline" className="border-red-200 text-red-700">{t("homeDir.emergencyChip2")}</Badge>
          </div>
        </button>
        <button onClick={() => setView("map")} className="card-hover group rounded-2xl border border-teal-200 bg-gradient-to-br from-teal-50 to-white p-5 text-left shadow-soft transition-colors hover:border-teal-300">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-600 text-white shadow-soft">
              <MapPin className="h-5 w-5" />
            </span>
            <div>
              <p className="font-bold text-teal-800">{t("homeDir.mapTitle")}</p>
              <p className="text-xs leading-relaxed text-teal-700/80">{t("homeDir.mapSub")}</p>
            </div>
            <ArrowRight className="ml-auto h-4 w-4 text-teal-600 transition-transform group-hover:translate-x-1" />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Badge variant="outline" className="border-teal-200 text-teal-700">{t("directory.kind.HOSPITAL")}</Badge>
            <Badge variant="outline" className="border-teal-200 text-teal-700">{t("directory.kind.PHARMACY")}</Badge>
            <Badge variant="outline" className="border-teal-200 text-teal-700">{t("directory.kind.DIAGNOSTIC")}</Badge>
          </div>
        </button>
      </div>
    </section>
  );
}
