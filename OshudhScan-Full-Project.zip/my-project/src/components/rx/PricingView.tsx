"use client";
// Pricing — premium localized business-model page (finance data lives in lib/finance).
import { Check, Landmark, Sparkles, TrendingUp } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DISTRIBUTOR_CARD, PRICING_TIERS, PROJECTION, MARKET_STATS } from "@/lib/finance";
import { useAppStore } from "@/lib/store";
import { useI18n } from "@/hooks/use-i18n";

export function PricingView() {
  const setView = useAppStore((s) => s.setView);
  const { t } = useI18n();
  const projectionData = PROJECTION.map((p) => ({
    year: p.year,
    Subscription: p.subscription,
    "Data & partnership": p.partnership,
  }));

  return (
    <div className="space-y-12">
      <header className="hero-mesh -mx-4 rounded-b-[2rem] px-4 py-9 text-center sm:-mx-6 sm:px-6 sm:py-11">
        <Badge variant="outline" className="mx-auto gap-1.5 border-emerald-300/70 bg-white/70 text-emerald-800 shadow-soft">
          <TrendingUp className="h-3.5 w-3.5" /> {t("pricing.badge")}
        </Badge>
        <h1 className="mx-auto mt-4 max-w-2xl text-3xl font-extrabold tracking-tight sm:text-4xl">
          <span className="text-gradient">{t("pricing.title")}</span>
        </h1>
        <p className="mx-auto mt-3 max-w-3xl text-sm leading-relaxed text-muted-foreground sm:text-base">
          {t("pricing.sub")}
        </p>
      </header>

      {/* Tiers */}
      <div className="grid gap-4 lg:grid-cols-3">
        {PRICING_TIERS.map((tier) => {
          const highlight = tier.id === "pro";
          return (
            <Card
              key={tier.id}
              className={`card-hover relative ${highlight ? "border-emerald-500 shadow-lift lg:-translate-y-1.5" : "shadow-soft"}`}
            >
              {highlight && <div className="absolute inset-x-0 top-0 h-1 rounded-t-xl bg-gradient-to-r from-emerald-400 via-emerald-500 to-teal-400" />}
              <CardContent className="flex h-full flex-col p-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold">{tier.name}</h3>
                  {highlight && (
                    <Badge className="gap-1 bg-emerald-600 text-white shadow-soft">
                      <Sparkles className="h-3 w-3" /> {t("pricing.popular")}
                    </Badge>
                  )}
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{tier.tagline}</p>
                <p className="mt-4">
                  <span className="stat-figure text-4xl font-extrabold text-emerald-800">
                    {tier.priceBdt === 0 ? "৳0" : `৳${tier.priceBdt.toLocaleString("en-IN")}`}
                  </span>
                  <span className="text-sm text-muted-foreground"> / {tier.period}</span>
                </p>
                <ul className="mt-5 flex-1 space-y-2.5 text-sm text-muted-foreground">
                  {tier.features.map((f, i) => (
                    <li key={i} className="flex gap-2 leading-relaxed">
                      <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-emerald-100">
                        <Check className="h-2.5 w-2.5 text-emerald-700" />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>
                <Button
                  className={`mt-6 ${highlight ? "btn-brand" : ""}`}
                  variant={highlight ? "default" : "outline"}
                  onClick={() => setView("portal")}
                >
                  {tier.cta}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Distributor partnership */}
      <Card className="card-hover border-amber-200 bg-gradient-to-br from-amber-50/60 to-white shadow-soft">
        <CardContent className="flex flex-col gap-3 p-6 sm:flex-row sm:items-start">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-100 to-amber-200 text-amber-700 ring-1 ring-amber-200">
            <Landmark className="h-5 w-5" />
          </span>
          <div>
            <h3 className="font-semibold">{t("pricing.distributorTitle")}</h3>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{DISTRIBUTOR_CARD.body}</p>
            <ul className="mt-3 space-y-1.5 text-sm">
              {DISTRIBUTOR_CARD.bullets.map((b, i) => (
                <li key={i} className="flex gap-2 text-muted-foreground">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" /> {b}
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Projection */}
      <section className="grid gap-5 lg:grid-cols-5">
        <Card className="shadow-soft lg:col-span-3">
          <CardContent className="p-6">
            <h3 className="font-semibold">{t("pricing.chartTitle")}</h3>
            <div className="mt-4 h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={projectionData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#dfe9e4" />
                  <XAxis dataKey="year" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} unit="M" width={40} />
                  <Tooltip formatter={(v: number | string) => `৳${v}M`} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="Subscription" stackId="a" fill="#059669" radius={[0, 0, 4, 4]} />
                  <Bar dataKey="Data & partnership" stackId="a" fill="#d97706" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">{t("pricing.chartNote")}</p>
          </CardContent>
        </Card>

        <div className="space-y-5 lg:col-span-2">
          <Card className="shadow-soft">
            <CardContent className="p-6">
              <h3 className="font-semibold">{t("pricing.assumptions")}</h3>
              <ul className="mt-3.5 space-y-2.5 text-sm">
                <li className="flex justify-between gap-3 border-b border-dashed border-emerald-100 pb-2"><span className="text-muted-foreground">{t("pricing.assumeMarket")}</span><span className="font-medium text-foreground">US$ {MARKET_STATS.marketUsdB}B, +{MARKET_STATS.marketGrowthPct}%</span></li>
                <li className="flex justify-between gap-3 border-b border-dashed border-emerald-100 pb-2"><span className="text-muted-foreground">{t("pricing.assumePharmacies")}</span><span className="font-medium text-foreground">{MARKET_STATS.retailPharmacies}</span></li>
                <li className="flex justify-between gap-3 border-b border-dashed border-emerald-100 pb-2"><span className="text-muted-foreground">{t("pricing.assumeBasket")}</span><span className="font-medium text-foreground">৳{MARKET_STATS.avgBasketBdt}</span></li>
                <li className="flex justify-between gap-3 border-b border-dashed border-emerald-100 pb-2"><span className="text-muted-foreground">{t("pricing.assumeLead")}</span><span className="font-medium text-foreground">৳{MARKET_STATS.leadValueBdt}</span></li>
                <li className="flex justify-between gap-3 border-b border-dashed border-emerald-100 pb-2"><span className="text-muted-foreground">{t("pricing.assumeRefill")}</span><span className="font-medium text-foreground">{t("pricing.assumeRefillVal")}</span></li>
                <li className="flex justify-between gap-3 border-b border-dashed border-emerald-100 pb-2"><span className="text-muted-foreground">{t("pricing.assumeFee")}</span><span className="font-medium text-foreground">{t("pricing.assumeFeeVal")}</span></li>
                <li className="flex justify-between gap-3"><span className="text-muted-foreground">{t("pricing.assumeChurn")}</span><span className="font-medium text-foreground">{t("pricing.assumeChurnVal")}</span></li>
              </ul>
            </CardContent>
          </Card>
          <Card className="border-emerald-200 bg-gradient-to-br from-emerald-50/70 to-white shadow-soft">
            <CardContent className="p-6 text-sm leading-relaxed text-emerald-950/80">
              <h3 className="font-semibold text-emerald-900">{t("pricing.whyTitle")}</h3>
              <p className="mt-2.5">{t("pricing.whyBody")}</p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
