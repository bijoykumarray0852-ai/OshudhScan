"use client";
// Care: guarded AI health assistant, hospital/clinic/diagnostic directory,
// verified national emergency numbers. The assistant is clearly labelled as
// information-only and never diagnoses/prescribes.
import { useCallback, useEffect, useRef, useState } from "react";
import { Hospital, Siren, Send, Phone, MapPin, Navigation, ShieldCheck, ShieldAlert, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useI18n } from "@/hooks/use-i18n";
import {
  apiFetch, ApiClientError, PageHeader, EmptyState, LoadingCards, ErrorNote,
  LocationPicker, type LocationSel,
} from "@/components/rx/shared";

interface ChatMsg { role: string; content: string; citations?: { ref: string; label: string }[] | null }
interface FacilityRow {
  id: string; name: string; nameBangla: string | null; type: string; ownership: string | null;
  district: string | null; area: string | null; addressLine: string; phone: string | null;
  isPhoneVerified: boolean; emergency: boolean; specialties: string[]; services: string[];
  lat: number | null; lng: number | null;
  distanceKm: number | null; source: string;
}

const NATIONAL_NUMBERS = [
  { phone: "999", bn: "জাতীয় জরুরি সেবা (পুলিশ/ফায়ার/অ্যাম্বুলেন্স)", en: "National Emergency Service (police/fire/ambulance)" },
  { phone: "16263", bn: "স্বাস্থ্য বাতায়ন — ডাক্তার পরামর্শ (২৪ ঘণ্টা)", en: "Shastho Batayon — doctor advice line (24/7)" },
  { phone: "333", bn: "জাতীয় হেল্পলাইন (নাগরিক সেবা)", en: "National citizen helpline" },
  { phone: "10666", bn: "আইইডিসিআর — রোগ সংক্রান্ত পরামর্শ", en: "IEDCR — disease control advice" },
  { phone: "109", bn: "নারী ও শিশু সহায়তা", en: "Women & children helpline" },
  { phone: "1098", bn: "শিশু হেল্পলাইন", en: "Child helpline" },
];

function typeKey(tp: string): string {
  const map: Record<string, string> = { HOSPITAL: "care.typeHospital", CLINIC: "care.typeClinic", DIAGNOSTIC: "care.typeDiagnostic", BLOOD_BANK: "care.typeBlood", AMBULANCE_SERVICE: "care.typeAmbulance" };
  return map[tp] ?? tp;
}

export function CareView() {
  const { t } = useI18n();
  const [tab, setTab] = useState("assistant");
  return (
    <>
      <PageHeader title={t("care.title")} subtitle={t("care.subtitle")} icon={<Hospital className="h-6 w-6" />} />
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex flex-wrap h-auto gap-1 w-full justify-start">
          <TabsTrigger value="assistant">{t("care.assistant")}</TabsTrigger>
          <TabsTrigger value="hospitals">{t("care.hospitals")}</TabsTrigger>
          <TabsTrigger value="emergency">{t("care.emergency")}</TabsTrigger>
        </TabsList>
        <TabsContent value="assistant" className="mt-4"><AssistantTab /></TabsContent>
        <TabsContent value="hospitals" className="mt-4"><FacilitiesTab /></TabsContent>
        <TabsContent value="emergency" className="mt-4"><EmergencyTab /></TabsContent>
      </Tabs>
    </>
  );
}

// ── assistant ─────────────────────────────────────────────────────────────────

function AssistantTab() {
  const { t, locale } = useI18n();
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [conversationId, setConversationId] = useState<string | undefined>(undefined);
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMessages([{ role: "ASSISTANT", content: t("care.assistantGreeting") }]);
  }, [locale]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setBusy(true);
    setError(null);
    setMessages((m) => [...m, { role: "USER", content: text }]);
    setInput("");
    try {
      const res = await apiFetch<{ conversationId: string; reply: string; citations: { ref: string; label: string }[] }>("/api/assistant", {
        method: "POST",
        body: JSON.stringify({ conversationId, message: text, locale }),
      });
      setConversationId(res.conversationId);
      setMessages((m) => [...m, { role: "ASSISTANT", content: res.reply, citations: res.citations }]);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-2xl space-y-3">
      <Card className="p-4 flex flex-col h-[520px]">
        <div className="flex-1 overflow-y-auto thin-scroll space-y-3 pr-1">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "USER" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm whitespace-pre-wrap ${
                  m.role === "USER" ? "bg-emerald-600 text-white rounded-br-sm" : "bg-muted rounded-bl-sm"
                }`}
              >
                {m.content}
                {m.citations && m.citations.length > 0 && (
                  <div className="mt-2 border-t pt-1.5 space-y-0.5">
                    {m.citations.map((c, j) => (
                      <p key={j} className="text-[11px] opacity-75">— {c.label}</p>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {busy && <p className="text-xs text-muted-foreground animate-pulse">{t("common.loading")}</p>}
          <div ref={bottom} />
        </div>
        <div className="flex gap-2 pt-3 border-t">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t("care.assistantPlaceholder")}
            onKeyDown={(e) => e.key === "Enter" && void send()}
            disabled={busy}
            aria-label={t("care.assistantPlaceholder")}
          />
          <Button onClick={() => void send()} disabled={busy || !input.trim()} aria-label={t("care.ask")}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </Card>
      {error && <ErrorNote message={error} />}
      <p className="text-xs text-muted-foreground">{t("care.assistantDisclaimer")}</p>
    </div>
  );
}

// ── facilities ────────────────────────────────────────────────────────────────

function FacilitiesTab() {
  const { t, locale } = useI18n();
  const [q, setQ] = useState("");
  const [type, setType] = useState("ALL");
  const [loc, setLoc] = useState<LocationSel>({});
  const [rows, setRows] = useState<FacilityRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [apptFor, setApptFor] = useState<FacilityRow | null>(null);
  const [apptName, setApptName] = useState("");
  const [apptPhone, setApptPhone] = useState("");
  const [apptSent, setApptSent] = useState(false);
  const [apptBusy, setApptBusy] = useState(false);
  const [apptError, setApptError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (q) params.set("q", q);
      if (type !== "ALL") params.set("type", type);
      if (loc.district) params.set("district", loc.district);
      const res = await apiFetch<{ facilities: FacilityRow[] }>(`/api/healthcare/facilities?${params}`);
      setRows(res.facilities);
      setLoaded(true);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setLoading(false);
    }
  }, [q, type, loc.district]);

  useEffect(() => {
    void load();
  }, [load]);

  const requestAppt = async () => {
    if (!apptFor || !apptName || !apptPhone) return;
    setApptBusy(true);
    setApptError(null);
    try {
      await apiFetch("/api/healthcare/appointments", {
        method: "POST",
        body: JSON.stringify({ facilityId: apptFor.id, requesterName: apptName, requesterPhone: apptPhone }),
      });
      setApptSent(true);
    } catch (err) {
      setApptError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setApptBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("care.facilitySearch")} className="max-w-sm" aria-label={t("care.facilitySearch")} onKeyDown={(e) => e.key === "Enter" && void load()} />
        <Button onClick={() => void load()} aria-label={t("common.search")}><Search className="h-4 w-4" /></Button>
        <LocationPicker value={loc} onChange={setLoc} />
      </div>
      <div className="flex flex-wrap gap-1.5">
        {["ALL", "HOSPITAL", "CLINIC", "DIAGNOSTIC", "BLOOD_BANK"].map((tp) => (
          <Button key={tp} size="sm" variant={type === tp ? "default" : "outline"} onClick={() => setType(tp)}>
            {tp === "ALL" ? t("common.all") : t(typeKey(tp))}
          </Button>
        ))}
      </div>

      {error && <ErrorNote message={error} onRetry={load} />}
      {loading ? (
        <LoadingCards count={4} />
      ) : rows.length === 0 ? (
        <EmptyState title={loaded ? t("care.facilitiesEmpty") : t("common.loading")} hint={t("common.noResultsHint")} />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {rows.map((f) => (
            <Card key={f.id} className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">{locale === "bn" && f.nameBangla ? f.nameBangla : f.name}</p>
                  <p className="text-sm text-muted-foreground">{f.addressLine}</p>
                  <div className="flex flex-wrap gap-1.5 mt-1.5">
                    <Badge variant="secondary">{t(typeKey(f.type))}</Badge>
                    {f.ownership && <Badge variant="outline">{f.ownership}</Badge>}
                    {f.emergency && <Badge className="bg-red-600 text-white">EM</Badge>}
                    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                      {f.isPhoneVerified ? <ShieldCheck className="h-3 w-3 text-emerald-600" /> : <ShieldAlert className="h-3 w-3" />}
                      {f.isPhoneVerified ? t("care.verifiedNumber") : t("care.unverifiedNumber")}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 mt-3">
                {f.phone && f.isPhoneVerified ? (
                  <Button size="sm" variant="outline" asChild><a href={`tel:${f.phone}`}><Phone className="h-3.5 w-3.5 mr-1" />{f.phone}</a></Button>
                ) : null}
                {f.lat != null && (
                  <Button size="sm" variant="outline" asChild>
                    <a href={`https://www.openstreetmap.org/?mlat=${f.lat}&mlon=${f.lng}#map=16/${f.lat}/${f.lng}`} target="_blank" rel="noreferrer">
                      <Navigation className="h-3.5 w-3.5 mr-1" />{t("common.directions")}
                    </a>
                  </Button>
                )}
                <Button size="sm" variant="ghost" onClick={() => { setApptFor(f); setApptSent(false); }}>
                  {t("care.requestAppointment")}
                </Button>
              </div>
              <p className="text-[11px] text-muted-foreground mt-2">{f.source}</p>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={Boolean(apptFor)} onOpenChange={(o) => (o ? undefined : setApptFor(null))}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{t("care.requestAppointment")}</DialogTitle>
            <DialogDescription>{apptFor?.name}</DialogDescription>
          </DialogHeader>
          {apptSent ? (
            <p className="text-sm text-emerald-700">{t("care.apptRequested")}</p>
          ) : (
            <div className="space-y-3">
              <div className="grid gap-1.5">
                <Label htmlFor="appt-name">{t("common.name")}</Label>
                <Input id="appt-name" value={apptName} onChange={(e) => setApptName(e.target.value)} placeholder={t("common.name")} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="appt-phone">{t("common.phone")}</Label>
                <Input id="appt-phone" value={apptPhone} onChange={(e) => setApptPhone(e.target.value)} placeholder="01XXXXXXXXX" type="tel" inputMode="tel" />
              </div>
              {apptError && <p className="text-sm text-destructive">{apptError}</p>}
              <Button className="w-full" onClick={() => void requestAppt()} disabled={!apptName || !apptPhone || apptBusy}>
                {apptBusy ? t("common.loading") : t("common.submit")}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── emergency ─────────────────────────────────────────────────────────────────

function EmergencyTab() {
  const { t, locale } = useI18n();
  const [rows, setRows] = useState<FacilityRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    void (async () => {
      try {
        const res = await apiFetch<{ facilities: FacilityRow[] }>("/api/healthcare/facilities?emergency=1");
        setRows(res.facilities);
      } catch (err) {
        setError(err instanceof ApiClientError ? err.message : t("err.generic"));
      } finally {
        setLoading(false);
      }
    })();
  }, [t]);

  const hospitals = rows.filter((r) => r.type === "HOSPITAL");

  return (
    <div className="space-y-5">
      <Card className="p-4 border-red-300 bg-red-50/60 dark:bg-red-950/20 dark:border-red-900">
        <h2 className="font-semibold flex items-center gap-2">
          <Siren className="h-5 w-5 text-red-600" /> {t("care.emergencyTitle")}
        </h2>
        <p className="text-sm text-muted-foreground mt-1">{t("care.emergencyDesc")}</p>
        <div className="grid gap-2 sm:grid-cols-2 mt-3">
          {NATIONAL_NUMBERS.map((n) => (
            <a
              key={n.phone}
              href={`tel:${n.phone}`}
              aria-label={`${locale === "bn" ? n.bn : n.en} — ${n.phone}`}
              className="flex items-center justify-between gap-3 rounded-lg border bg-background px-3 py-2.5 hover:bg-muted"
            >
              <div>
                <p className="font-bold tabular-nums text-lg">{n.phone}</p>
                <p className="text-xs text-muted-foreground">{locale === "bn" ? n.bn : n.en}</p>
              </div>
              <Phone className="h-4 w-4 text-emerald-700 shrink-0" />
            </a>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1.5">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
          {t("care.verifiedNumber")} · {t("care.noSimulate")}
        </p>
      </Card>

      <div>
        <h2 className="font-semibold mb-2">{t("care.nearestEmergency")}</h2>
        {loading ? (
          <LoadingCards count={3} />
        ) : error ? (
          <ErrorNote message={error} />
        ) : hospitals.length === 0 ? (
          <EmptyState title={t("care.emergencyEmptyTitle")} hint={t("care.emergencyEmptyHint")} />
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {hospitals.map((f) => (
              <Card key={f.id} className="p-3">
                <p className="font-semibold text-sm">{locale === "bn" && f.nameBangla ? f.nameBangla : f.name}</p>
                <p className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="h-3 w-3" /> {f.addressLine}</p>
                <div className="flex gap-2 mt-2">
                  {f.phone && f.isPhoneVerified && (
                    <Button size="sm" variant="outline" asChild><a href={`tel:${f.phone}`}><Phone className="h-3.5 w-3.5 mr-1" />{t("care.callNow")}</a></Button>
                  )}
                  {f.lat != null && (
                    <Button size="sm" variant="outline" asChild>
                      <a href={`https://www.openstreetmap.org/?mlat=${f.lat}&mlon=${f.lng}#map=15/${f.lat}/${f.lng}`} target="_blank" rel="noreferrer">
                        <Navigation className="h-3.5 w-3.5 mr-1" />{t("common.directions")}
                      </a>
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
        <p className="text-xs text-muted-foreground mt-2">{t("care.dataSourceNote")}</p>
      </div>
    </div>
  );
}
