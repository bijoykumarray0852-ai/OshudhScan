"use client";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Bot,
  Braces,
  Camera,
  FileDigit,
  Languages,
  ScanLine,
  ShieldCheck,
  Store,
} from "lucide-react";
import { useI18n } from "@/hooks/use-i18n";
import type { DictKey } from "@/lib/i18n/en";

function buildPipeline(t: (key: DictKey) => string) {
  return [
  {
    icon: <Camera className="h-4 w-4" />,
    title: t("arch.pipeline.capture.title"),
    stack: t("arch.pipeline.capture.stack"),
    detail: t("arch.pipeline.capture.detail"),
  },
  {
    icon: <ScanLine className="h-4 w-4" />,
    title: t("arch.pipeline.ocr.title"),
    stack: t("arch.pipeline.ocr.stack"),
    detail: t("arch.pipeline.ocr.detail"),
  },
  {
    icon: <Braces className="h-4 w-4" />,
    title: t("arch.pipeline.resolver.title"),
    stack: t("arch.pipeline.resolver.stack"),
    detail: t("arch.pipeline.resolver.detail"),
  },
  {
    icon: <ShieldCheck className="h-4 w-4" />,
    title: t("arch.pipeline.safety.title"),
    stack: t("arch.pipeline.safety.stack"),
    detail: t("arch.pipeline.safety.detail"),
  },
  {
    icon: <Languages className="h-4 w-4" />,
    title: t("arch.pipeline.explainer.title"),
    stack: t("arch.pipeline.explainer.stack"),
    detail: t("arch.pipeline.explainer.detail"),
  },
  {
    icon: <Store className="h-4 w-4" />,
    title: t("arch.pipeline.routing.title"),
    stack: t("arch.pipeline.routing.stack"),
    detail: t("arch.pipeline.routing.detail"),
  },
  ];
}

const KG_NODES = [
  { id: "flexi", label: "Flexi", x: 90, y: 70, type: "brand" },
  { id: "napa", label: "Napa", x: 90, y: 170, type: "brand" },
  { id: "warf", label: "Warf", x: 90, y: 270, type: "brand" },
  { id: "aceclo", label: "Aceclofenac", x: 250, y: 45, type: "generic" },
  { id: "para", label: "Paracetamol", x: 250, y: 120, type: "generic" },
  { id: "warfarin", label: "Warfarin", x: 250, y: 270, type: "generic" },
  { id: "nsaid", label: "NSAID class", x: 410, y: 80, type: "class" },
  { id: "analgesic", label: "Analgesic", x: 410, y: 170, type: "class" },
  { id: "anticoag", label: "Anticoagulant", x: 410, y: 270, type: "class" },
  { id: "r1", label: "R1: MAJOR", x: 520, y: 175, type: "rule" },
];

const KG_EDGES: Array<[string, string]> = [
  ["flexi", "aceclo"],
  ["flexi", "para"],
  ["napa", "para"],
  ["warf", "warfarin"],
  ["aceclo", "nsaid"],
  ["para", "analgesic"],
  ["warfarin", "anticoag"],
  ["nsaid", "r1"],
  ["anticoag", "r1"],
];

const nodeColor: Record<string, { fill: string; stroke: string }> = {
  brand: { fill: "#ecfdf5", stroke: "#059669" },
  generic: { fill: "#f0fdfa", stroke: "#0d9488" },
  class: { fill: "#fffbeb", stroke: "#d97706" },
  rule: { fill: "#fef2f2", stroke: "#dc2626" },
};

function KgGraph() {
  const { t } = useI18n();
  const nodeMap = new Map(KG_NODES.map((n) => [n.id, n]));
  return (
    <svg viewBox="0 0 600 320" className="w-full" role="img" aria-label={t("arch.kg.ariaLabel")}>
      {KG_EDGES.map(([a, b], i) => {
        const na = nodeMap.get(a);
        const nb = nodeMap.get(b);
        if (!na || !nb) return null;
        const isRule = a === "r1" || b === "r1";
        return (
          <g key={i}>
            <line
              x1={na.x}
              y1={na.y}
              x2={nb.x}
              y2={nb.y}
              stroke={isRule ? "#dc2626" : "#94a3b8"}
              strokeWidth={isRule ? 2.5 : 1.5}
              strokeDasharray={isRule ? undefined : "4 3"}
            />
          </g>
        );
      })}
      {KG_NODES.map((n) => {
        const c = nodeColor[n.type];
        const w = Math.max(52, n.label.length * 8.5);
        return (
          <g key={n.id}>
            <rect
              x={n.x - w / 2}
              y={n.y - 16}
              width={w}
              height={32}
              rx={16}
              fill={c.fill}
              stroke={c.stroke}
              strokeWidth={1.5}
            />
            <text
              x={n.x}
              y={n.y + 4}
              textAnchor="middle"
              fontSize={12}
              fontWeight={n.type === "rule" ? 700 : 500}
              fill={n.type === "rule" ? "#dc2626" : "#1e293b"}
            >
              {n.label}
            </text>
          </g>
        );
      })}
      <text x={90} y={308} textAnchor="middle" fontSize={11} fill="#059669">{t("arch.kg.legend.brand")}</text>
      <text x={250} y={308} textAnchor="middle" fontSize={11} fill="#0d9488">{t("arch.kg.legend.molecule")}</text>
      <text x={410} y={308} textAnchor="middle" fontSize={11} fill="#d97706">{t("arch.kg.legend.class")}</text>
      <text x={520} y={308} textAnchor="middle" fontSize={11} fill="#dc2626">{t("arch.kg.legend.rule")}</text>
    </svg>
  );
}

export function ArchitectureView() {
  const { t } = useI18n();
  const pipeline = buildPipeline(t);
  return (
    <div className="space-y-10">
      <header className="space-y-2">
        <Badge variant="outline" className="border-emerald-300 bg-emerald-50 text-emerald-800">
          <FileDigit className="mr-1.5 h-3.5 w-3.5" /> {t("arch.badge")}
        </Badge>
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("arch.title")}</h2>
        <p className="max-w-3xl text-sm text-muted-foreground sm:text-base">
          {t("arch.subtitle")}
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-2">
        {pipeline.map((p, i) => (
          <Card key={i} className="transition-shadow hover:shadow-md">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-700">
                  {p.icon}
                </span>
                <h3 className="font-semibold">{p.title}</h3>
              </div>
              <p className="mt-3 rounded-md bg-muted/60 px-3 py-2 font-mono text-[11px] leading-relaxed text-muted-foreground">
                {p.stack}
              </p>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.detail}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Knowledge graph */}
      <section className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardContent className="p-5">
            <h3 className="font-semibold">{t("arch.kg.title")}</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              {t("arch.kg.desc")}
            </p>
            <div className="mt-4 rounded-lg border bg-background p-3">
              <KgGraph />
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">
              {t("arch.kg.demoNote")}
            </p>
          </CardContent>
        </Card>

        <div className="space-y-4 lg:col-span-2">
          <Card className="border-emerald-200 bg-emerald-50/40">
            <CardContent className="p-5">
              <h3 className="flex items-center gap-2 font-semibold text-emerald-900">
                <Bot className="h-5 w-5" /> {t("arch.notWrapper.title")}
              </h3>
              <ul className="mt-3 space-y-2.5 text-sm text-emerald-950/80">
                <li className="flex gap-2"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700" /> {t("arch.notWrapper.safety")}</li>
                <li className="flex gap-2"><Braces className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700" /> {t("arch.notWrapper.graph")}</li>
                <li className="flex gap-2"><FileDigit className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700" /> {t("arch.notWrapper.confidence")}</li>
                <li className="flex gap-2"><Languages className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700" /> {t("arch.notWrapper.llm")}</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <h3 className="font-semibold">{t("arch.models.title")}</h3>
              <div className="mt-3 space-y-2 font-mono text-[11px] leading-relaxed text-muted-foreground">
                <p>{t("arch.models.vision")}</p>
                <p>{t("arch.models.matching")}</p>
                <p>{t("arch.models.safety")}</p>
                <p>{t("arch.models.explainer")}</p>
                <p>{t("arch.models.tts")}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
