"use client";
// Medicine Intelligence: KB browser with full clinical fields, deterministic
// interaction checker, generic alternatives (never auto-substitution),
// barcode lookup (identification only, never authenticity) and pack-label
// scanning (draft extraction, pharmacist verification required).
import { useCallback, useEffect, useRef, useState } from "react";
import { Pill, ShieldCheck, ScanBarcode, Camera, ArrowLeftRight, Plus, AlertTriangle, XCircle, Info, Search, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useI18n } from "@/hooks/use-i18n";
import {
  apiFetch, ApiClientError, PageHeader, EmptyState, LoadingCards, ErrorNote, fmtBdt, fmtDate,
} from "@/components/rx/shared";

interface MedicineRow {
  id: string; legacyId: string | null; brand: string; generic: string; genericBangla: string | null;
  strength: string | null; form: string; therapeuticClass: string; manufacturer: string;
  unitPriceBdt: number; genericUnitPriceBdt: number | null; meal: string | null;
  indications: string | null; sideEffects: string | null; storage: string | null; contraindications: string | null;
  source: string | null; lastReviewedAt: string | null; isDemo: boolean; hasBarcode: boolean;
}
interface Finding {
  id: string; severity: string; type: string; title: string; detail: string; action: string; drugs: string[]; source: string;
}
interface CheckResp {
  generatedBy: string;
  resolved: { input: string; brand: string | null; generic: string | null; matchMethod: string; confidence: number }[];
  findings: Finding[];
  note: string;
}
interface AltResp {
  reference: { brand: string; generic: string; strength: string | null; unitPriceBdt: number };
  alternatives: { id: string; brand: string; strength: string | null; form: string; manufacturer: string; unitPriceBdt: number; savingsPct: number | null }[];
  savingsPct: number | null;
  disclaimer: string;
}
interface PacketResp {
  ok?: boolean;
  degraded?: boolean;
  extracted?: { brandRaw: string | null; strength: string | null; batchNumber: string | null; mfgDate: string | null; expiryDate: string | null; barcodeDigits: string | null };
  matchedBrand?: { brand: string; confidence: number; method: string } | null;
  barcodeRegistered?: boolean | null;
  note?: string;
}

const SEV_STYLE: Record<string, { card: string; badge: string }> = {
  major: { card: "border-red-300 bg-red-50/70 dark:bg-red-950/20 dark:border-red-900", badge: "bg-red-600 text-white" },
  moderate: { card: "border-amber-300 bg-amber-50/70 dark:bg-amber-950/20 dark:border-amber-900", badge: "bg-amber-500 text-white" },
  minor: { card: "border-slate-300 bg-slate-50 dark:bg-slate-900/40", badge: "bg-slate-500 text-white" },
  info: { card: "border-slate-200", badge: "bg-slate-400 text-white" },
};

export function MedicineView() {
  const { t, locale } = useI18n();
  const [tab, setTab] = useState("browse");
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [meds, setMeds] = useState<MedicineRow[]>([]);
  const [total, setTotal] = useState(0);
  const [selected, setSelected] = useState<MedicineRow | null>(null);
  const [alts, setAlts] = useState<AltResp | null>(null);
  const [altsFailed, setAltsFailed] = useState(false);

  // checker state
  const [items, setItems] = useState<Array<{ name: string; dose: string }>>([
    { name: "", dose: "" },
  ]);
  const [checking, setChecking] = useState(false);
  const [checkResult, setCheckResult] = useState<CheckResp | null>(null);
  const [checkError, setCheckError] = useState<string | null>(null);

  // barcode state
  const [barcode, setBarcode] = useState("");
  const [bcResult, setBcResult] = useState<{ found: boolean; medicine?: Record<string, unknown>; note?: string } | null>(null);
  const [barcodeBusy, setBarcodeBusy] = useState(false);
  const [barcodeError, setBarcodeError] = useState<string | null>(null);

  // packet scan state
  const [packetBusy, setPacketBusy] = useState(false);
  const [packet, setPacket] = useState<PacketResp | null>(null);
  const packetInput = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ medicines: MedicineRow[]; total: number }>(`/api/medicines?q=${encodeURIComponent(q)}`);
      setMeds(res.medicines);
      setTotal(res.total);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setLoading(false);
    }
  }, [q]);

  useEffect(() => {
    void load();
  }, [load]);

  const openDetails = async (m: MedicineRow) => {
    setSelected(m);
    setAlts(null);
    setAltsFailed(false);
    const res = await apiFetch<AltResp>(`/api/medicines/alternatives?id=${m.id}`).catch(() => null);
    if (!res) setAltsFailed(true);
    setAlts(res);
  };

  const runCheck = async () => {
    const valid = items.filter((i) => i.name.trim());
    if (valid.length === 0) return;
    setChecking(true);
    setCheckResult(null);
    setCheckError(null);
    try {
      const res = await apiFetch<CheckResp>("/api/medicines/check", {
        method: "POST",
        body: JSON.stringify({ items: valid.map((i) => ({ name: i.name, dose: i.dose || undefined })) }),
      });
      setCheckResult(res);
    } catch (err) {
      // surface on THIS tab, not the browse tab's shared error state
      setCheckError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setChecking(false);
    }
  };

  const lookupBarcode = async () => {
    setBcResult(null);
    setBarcodeError(null);
    setBarcodeBusy(true);
    try {
      const res = await apiFetch<{ found: boolean; medicine?: Record<string, unknown>; note?: string }>(`/api/medicines/barcode?code=${encodeURIComponent(barcode)}`);
      setBcResult(res);
    } catch (err) {
      setBarcodeError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setBarcodeBusy(false);
    }
  };

  const scanPacket = async (file: File) => {
    setPacketBusy(true);
    setPacket(null);
    try {
      // resize via canvas to keep the payload small (mirrors ScanView)
      const bitmap = await createImageBitmap(file);
      const scale = Math.min(1, 1024 / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(bitmap.width * scale);
      canvas.height = Math.round(bitmap.height * scale);
      canvas.getContext("2d")?.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const base64 = canvas.toDataURL("image/jpeg", 0.85).split(",")[1];
      const res = await apiFetch<PacketResp>("/api/medicines/scan-packet", {
        method: "POST",
        body: JSON.stringify({ imageBase64: base64 }),
      });
      setPacket(res);
    } catch (err) {
      setPacket({ ok: false, degraded: true, note: err instanceof Error ? err.message : t("med.scanFailed") });
    } finally {
      setPacketBusy(false);
    }
  };

  return (
    <>
      <PageHeader title={t("med.title")} subtitle={t("med.subtitle")} icon={<Pill className="h-6 w-6" />} />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex flex-wrap h-auto gap-1 w-full justify-start">
          <TabsTrigger value="browse">{t("common.search")}</TabsTrigger>
          <TabsTrigger value="checker">{t("med.checker")}</TabsTrigger>
          <TabsTrigger value="barcode">{t("med.barcode")}</TabsTrigger>
          <TabsTrigger value="packet">{t("med.packetScan")}</TabsTrigger>
        </TabsList>

        {/* browse */}
        <TabsContent value="browse" className="mt-4 space-y-4">
          <div className="flex gap-2">
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("med.searchPlaceholder")} aria-label={t("med.searchPlaceholder")} />
            <Button onClick={() => void load()} aria-label={t("common.search")}><Search className="h-4 w-4" /></Button>
          </div>
          <p className="text-xs text-muted-foreground">{t("med.count", { count: total })}</p>
          {error && <ErrorNote message={error} onRetry={load} />}
          {loading ? (
            <LoadingCards count={5} />
          ) : meds.length === 0 ? (
            <EmptyState title={t("med.notFound")} hint={t("common.noResultsHint")} />
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {meds.map((m) => (
                <Card key={m.id} className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold">{m.brand} {m.strength && <span className="text-muted-foreground font-normal">{m.strength}</span>}</p>
                      <p className="text-sm text-muted-foreground">
                        {m.generic}
                        {locale === "bn" && m.genericBangla ? ` · ${m.genericBangla}` : ""}
                      </p>
                    </div>
                    <span className="font-semibold tabular-nums">{fmtBdt(m.unitPriceBdt)}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    <Badge variant="secondary">{m.form}</Badge>
                    <Badge variant="outline">{m.therapeuticClass}</Badge>
                    {m.isDemo && <Badge variant="outline">{t("med.demoKb")}</Badge>}
                  </div>
                  {m.indications && <p className="text-sm mt-2 text-muted-foreground line-clamp-2">{m.indications}</p>}
                  <div className="flex flex-wrap gap-2 mt-3">
                    <Button size="sm" variant="outline" onClick={() => void openDetails(m)}>{t("common.details")}</Button>
                    <Button size="sm" variant="ghost" onClick={() => { setItems([{ name: m.brand, dose: "" }]); setTab("checker"); }}>
                      <ShieldCheck className="h-3.5 w-3.5 mr-1" /> {t("med.checker")}
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* interaction checker */}
        <TabsContent value="checker" className="mt-4 space-y-4">
          <p className="text-sm text-muted-foreground max-w-2xl">{t("med.checkerDesc")}</p>
          <Card className="p-4 space-y-3 max-w-2xl">
            {items.map((item, i) => (
              <div key={i} className="flex gap-2">
                <Input
                  value={item.name}
                  onChange={(e) => setItems((cur) => cur.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))}
                  placeholder={t("med.medicineExample")}
                  aria-label={t("med.addMedicine")}
                />
                <Input
                  value={item.dose}
                  onChange={(e) => setItems((cur) => cur.map((x, j) => (j === i ? { ...x, dose: e.target.value } : x)))}
                  placeholder="1+0+1"
                  className="w-28 shrink-0"
                  aria-label={t("med.doseLabel")}
                />
                {items.length > 1 && (
                  <Button size="icon" variant="ghost" onClick={() => setItems((cur) => cur.filter((_, j) => j !== i))} aria-label={t("common.remove")}>
                    <XCircle className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" onClick={() => setItems((cur) => [...cur, { name: "", dose: "" }])}>
                <Plus className="h-4 w-4 mr-1" /> {t("med.addMedicine")}
              </Button>
              <Button onClick={() => void runCheck()} disabled={checking}>
                <ShieldCheck className="h-4 w-4 mr-1" /> {checking ? t("med.checking") : t("med.check")}
              </Button>
            </div>
          </Card>

          {checkError && <ErrorNote message={checkError} onRetry={() => void runCheck()} />}

          {checkResult && (
            <div className="space-y-3 max-w-2xl">
              {checkResult.resolved.some((r) => !r.brand) && (
                <ErrorNote message={t("med.notFound") + " — " + checkResult.resolved.filter((r) => !r.brand).map((r) => r.input).join(", ")} />
              )}
              {checkResult.findings.length === 0 ? (
                <Card className="p-4 flex items-center gap-3 border-emerald-300 bg-emerald-50/60 dark:bg-emerald-950/20">
                  <ShieldCheck className="h-5 w-5 text-emerald-600" />
                  <p className="font-medium">{t("med.allClear")}</p>
                </Card>
              ) : (
                checkResult.findings.map((f) => {
                  const style = SEV_STYLE[f.severity] ?? SEV_STYLE.info;
                  return (
                    <Card key={f.id} className={`p-4 ${style.card}`}>
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-semibold text-sm">{f.title}</p>
                        <Badge className={style.badge}>{f.severity}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1.5">{f.detail}</p>
                      <p className="text-sm mt-2"><span className="font-medium">{t("med.reviewAction")}:</span> {f.action}</p>
                      <p className="text-xs text-muted-foreground mt-2">{f.source}</p>
                      <p className="text-xs text-muted-foreground">{t("med.interactionRule", { id: f.id })}</p>
                    </Card>
                  );
                })
              )}
              <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                <AlertTriangle className="h-3.5 w-3.5" /> {t("med.alwaysAsk")}
              </p>
            </div>
          )}
        </TabsContent>

        {/* barcode */}
        <TabsContent value="barcode" className="mt-4 max-w-2xl space-y-4">
          <p className="text-sm text-muted-foreground flex items-start gap-2">
            <Info className="h-4 w-4 mt-0.5 shrink-0" />
            {t("med.barcodeDesc")}
          </p>
          <Card className="p-4 space-y-3">
            <div className="flex gap-2">
              <Input value={barcode} onChange={(e) => setBarcode(e.target.value)} placeholder="e.g. 8951000123456" inputMode="numeric" aria-label={t("med.barcode")} />
              <Button onClick={() => void lookupBarcode()} disabled={barcode.length < 4 || barcodeBusy}>
                {barcodeBusy && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                <ScanBarcode className="h-4 w-4 mr-1" /> {t("med.barcodeLookup")}
              </Button>
            </div>
            {barcodeError && <ErrorNote message={barcodeError} onRetry={() => void lookupBarcode()} />}
            {bcResult && !bcResult.found && (
              <Card className="p-3 text-sm bg-muted/40">
                <p className="font-medium">{t("med.barcodeNotFound")}</p>
                <p className="text-muted-foreground mt-1">{bcResult.note}</p>
              </Card>
            )}
            {bcResult?.found && (
              <Card className="p-3 text-sm border-emerald-300 bg-emerald-50/60 dark:bg-emerald-950/20">
                <p className="font-semibold">{t("med.barcodeRegistered")}</p>
                <p className="mt-1">{String(bcResult.medicine?.brand ?? "")} — {String(bcResult.medicine?.generic ?? "")} {String(bcResult.medicine?.strength ?? "")}</p>
                <p className="text-muted-foreground mt-1">{String(bcResult.medicine?.manufacturer ?? "")} · {fmtBdt(Number(bcResult.medicine?.unitPriceBdt ?? 0))}</p>
                <Badge variant="outline" className="mt-2">{t("med.authenticityNote")}</Badge>
              </Card>
            )}
          </Card>
        </TabsContent>

        {/* pack scan */}
        <TabsContent value="packet" className="mt-4 max-w-2xl space-y-4">
          <p className="text-sm text-muted-foreground">{t("med.packetScanDesc")}</p>
          <Card className="p-4 space-y-3">
            <div className="grid gap-1.5">
              <Label htmlFor="packet-file" className="text-sm font-medium">{t("med.packetChooseImage")}</Label>
              <Input
                id="packet-file"
                ref={packetInput}
                type="file"
                accept="image/*"
                capture="environment"
                aria-label={t("med.packetChooseImage")}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void scanPacket(f);
                }}
              />
            </div>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Camera className="h-3.5 w-3.5" /> {t("med.reviewPending")}
            </p>
            {packetBusy && <LoadingCards count={1} />}
            {packet && !packet.degraded && packet.extracted && (
              <Card className="p-3 text-sm">
                <p className="font-semibold">
                  {packet.matchedBrand ? `${packet.matchedBrand.brand} (${Math.round(packet.matchedBrand.confidence * 100)}%)` : packet.extracted.brandRaw ?? "—"}
                </p>
                <dl className="mt-2 space-y-1 text-muted-foreground">
                  <div><dt className="inline">{t("portal.batch")}: </dt><dd className="inline">{packet.extracted.batchNumber ?? "—"}</dd></div>
                  <div><dt className="inline">{t("portal.mfg")}: </dt><dd className="inline">{packet.extracted.mfgDate ?? "—"}</dd></div>
                  <div><dt className="inline">{t("portal.expiry")}: </dt><dd className="inline">{packet.extracted.expiryDate ?? "—"}</dd></div>
                  {packet.extracted.barcodeDigits && (
                    <div>
                      <dt className="inline">{t("med.barcode")}: </dt><dd className="inline">{packet.extracted.barcodeDigits}</dd>
                      {packet.barcodeRegistered !== null && (
                        <Badge variant={packet.barcodeRegistered ? "default" : "outline"} className="ml-2">
                          {packet.barcodeRegistered ? t("med.barcodeRegistered") : t("med.barcodeNotFound")}
                        </Badge>
                      )}
                    </div>
                  )}
                </dl>
              </Card>
            )}
            {packet?.degraded && <ErrorNote message={packet.note ?? t("med.scanFailed")} />}
          </Card>
        </TabsContent>
      </Tabs>

      {/* details dialog */}
      <Dialog open={Boolean(selected)} onOpenChange={(o) => (o ? undefined : setSelected(null))}>
        <DialogContent className="sm:max-w-xl max-h-[85vh] overflow-y-auto">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle>{selected.brand} {selected.strength}</DialogTitle>
                <DialogDescription>
                  {selected.generic} · {selected.manufacturer} · {selected.form}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-3 text-sm">
                <div className="grid grid-cols-2 gap-2">
                  <p><span className="text-muted-foreground">{t("med.priceBdt")}:</span> <span className="font-medium">{fmtBdt(selected.unitPriceBdt)}</span></p>
                  {selected.meal && <p><span className="text-muted-foreground">{t("med.meal")}:</span> {selected.meal === "AFTER_MEAL" ? t("med.afterMeal") : selected.meal === "BEFORE_MEAL" ? t("med.beforeMeal") : t("med.anyTime")}</p>}
                </div>
                {[
                  [t("med.indications"), selected.indications],
                  [t("med.contraindications"), selected.contraindications],
                  [t("med.sideEffects"), selected.sideEffects],
                  [t("med.storage"), selected.storage],
                ].map(([label, val]) =>
                  val ? (
                    <div key={label as string}>
                      <p className="font-medium">{label}</p>
                      <p className="text-muted-foreground">{val}</p>
                    </div>
                  ) : null
                )}
                {altsFailed && !alts && (
                  <ErrorNote message={t("med.alternativesFailed")} onRetry={() => selected && void openDetails(selected)} />
                )}
                {alts && (
                  <div>
                    <p className="font-medium flex items-center gap-1.5">
                      <ArrowLeftRight className="h-4 w-4" /> {t("med.alternatives")}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">{t("med.alternativesDesc")}</p>
                    {alts.alternatives.length === 0 ? (
                      <p className="text-sm text-muted-foreground mt-2">{t("common.noResults")}</p>
                    ) : (
                      <ul className="mt-2 divide-y">
                        {alts.alternatives.map((a) => (
                          <li key={a.id} className="py-2 flex items-center justify-between gap-2">
                            <div>
                              <p className="font-medium">{a.brand} {a.strength}</p>
                              <p className="text-xs text-muted-foreground">{a.manufacturer} · {a.form}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium tabular-nums">{fmtBdt(a.unitPriceBdt)}</p>
                              {a.savingsPct !== null && a.savingsPct > 0 && (
                                <Badge variant="secondary" className="mt-0.5">{t("med.savePct", { pct: a.savingsPct })}</Badge>
                              )}
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
                {selected.source && <p className="text-xs text-muted-foreground">{t("common.dataSource")}: {selected.source}</p>}
                {selected.lastReviewedAt && (
                  <p className="text-xs text-muted-foreground">{t("med.reviewedBy", { date: fmtDate(selected.lastReviewedAt, locale) })}</p>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
