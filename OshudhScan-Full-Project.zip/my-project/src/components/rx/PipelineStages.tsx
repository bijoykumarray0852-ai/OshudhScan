"use client";
import { Check, Loader2, CircleDashed, MinusCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/hooks/use-i18n";

export type StageStatus = "pending" | "running" | "done" | "skipped";

export interface Stage {
  key: string;
  label: string;
  detail: string;
}

interface Props {
  stages: Stage[];
  statuses: Record<string, StageStatus>;
  currentDetail?: Record<string, string>;
}

export function PipelineStages({ stages, statuses, currentDetail }: Props) {
  const { t } = useI18n();
  return (
    <ol className="space-y-2" aria-live="polite">
      {stages.map((stage, idx) => {
        const status = statuses[stage.key] ?? "pending";
        return (
          <li
            key={stage.key}
            className={cn(
              "flex items-start gap-3 rounded-lg border p-3 transition-all duration-300",
              status === "running" && "border-emerald-500/60 bg-emerald-50/60 shadow-sm",
              status === "done" && "border-emerald-200 bg-emerald-50/30",
              status === "pending" && "border-border bg-muted/30 opacity-60",
              status === "skipped" && "border-border bg-muted/20 opacity-50"
            )}
            aria-current={status === "running" ? "step" : undefined}
          >
            <div className="mt-0.5 shrink-0">
              {status === "done" && (
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-white">
                  <Check className="h-3.5 w-3.5" />
                </span>
              )}
              {status === "running" && (
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600/90 text-white">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                </span>
              )}
              {status === "pending" && (
                <span className="flex h-6 w-6 items-center justify-center rounded-full border border-border bg-background text-muted-foreground">
                  <CircleDashed className="h-3.5 w-3.5" />
                </span>
              )}
              {status === "skipped" && (
                <span className="flex h-6 w-6 items-center justify-center rounded-full border border-dashed border-muted-foreground/40 bg-background text-muted-foreground">
                  <MinusCircle className="h-3.5 w-3.5" />
                </span>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-x-2 text-sm font-medium">
                <span className="text-muted-foreground/70">{idx + 1}.</span>
                <span>{stage.label}</span>
                {status === "running" && (
                  <span className="text-xs font-normal text-emerald-700">{t("pipeline.working")}</span>
                )}
                {status === "skipped" && (
                  <span className="text-xs font-normal text-muted-foreground">{t("pipeline.bypassed")}</span>
                )}
              </div>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {currentDetail?.[stage.key] ?? stage.detail}
              </p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
