"use client";
// Patient dashboard: overview, prescriptions, reminders, documents, family,
// notifications, profile & privacy — designed for ordinary users including
// elderly/low-literacy patients (large-text mode supported app-wide).
import { useCallback, useEffect, useRef, useState } from "react";
import { Pill, FileText, Bell, FolderOpen, Users, UserRound, ShieldCheck, Plus, Download, Trash2, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useI18n } from "@/hooks/use-i18n";
import { useAppStore } from "@/lib/store";
import {
  apiFetch, ApiClientError, PageHeader, StatCard, EmptyState, LoadingCards, ErrorNote,
  fmtBdt, fmtDate, useRequireAuth,
} from "@/components/rx/shared";

interface UpcomingDose {
  id: string; scheduleId: string; medicineLabel: string; meal: string | null;
  instructionBangla: string | null; instructionEnglish: string | null;
  dueAt: string; slot: string; status: string;
}
interface ScheduleRow {
  id: string; medicineLabel: string; strength: string | null; slots: string[];
  customTimes: Record<string, string> | null; perDay: number; startDate: string; endDate: string | null;
  durationDays: number | null; meal: string | null; instructionBangla: string | null; instructionEnglish: string | null;
  status: string; familyMember: { name: string; relation: string } | null; stockDays: number | null;
  refillNeeded: boolean; adherence: number | null; todayDoses: { id: string; dueAt: string; slot: string; status: string }[];
  totalDoses: number; pendingDoses: number;
}
interface RxRow {
  id: string; doctorName: string | null; facility: string | null; patientName: string | null;
  familyMember: { name: string; relation: string } | null; createdAt: string; source: string;
  items: { id: string; brand: string | null; generic: string | null; strength: string | null; dose: string | null; durationDays: number | null }[];
  totals: { brandBdt: number | null; genericBdt: number | null; savingsPct: number | null } | null;
  schedules: { id: string; status: string; medicineLabel: string }[];
  findings: { id: string; severity: string; title: string }[];
}
interface DocRow { id: string; title: string; category: string; fileName: string; mimeType: string; sizeBytes: number; docDate: string | null; createdAt: string }
interface FamilyRow { id: string; name: string; relation: string; ageYears: number | null; allergies: string[]; chronicConditions: string[] }
interface NotifRow { id: string; type: string; title: string; body: string; readAt: string | null; createdAt: string }
interface ProfileData {
  user: { name: string; email: string; phone: string | null; locale: string; largeText: boolean };
  profile: { gender: string | null; bloodGroup: string | null; heightCm: number | null; weightKg: number | null; allergies: string[]; chronicConditions: string[]; district: string | null; emergencyContact: { name: string; phone: string } | null } | null;
  consents: { type: string; granted: boolean }[];
  completion: number;
}

const RELATIONS = ["SELF", "SPOUSE", "FATHER", "MOTHER", "SON", "DAUGHTER", "OTHER"];

function slotWord(slot: string, t: (k: string) => string) {
  return slot === "MORNING" ? t("rem.slotMorning") : slot === "AFTERNOON" ? t("rem.slotAfternoon") : t("rem.slotNight");
}

export function PatientView() {
  const { t, locale } = useI18n();
  const { user, AuthGate } = useRequireAuth();
  const setView = useAppStore((s) => s.setView);
  const setUnread = useAppStore((s) => s.setUnreadNotifications);
  const setUser = useAppStore((s) => s.setUser);
  const decoded = useAppStore((s) => s.decoded);

  const [tab, setTab] = useState("overview");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [upcoming, setUpcoming] = useState<UpcomingDose[]>([]);
  const [schedules, setSchedules] = useState<ScheduleRow[]>([]);
  const [rxs, setRxs] = useState<RxRow[]>([]);
  const [docs, setDocs] = useState<DocRow[]>([]);
  const [family, setFamily] = useState<FamilyRow[]>([]);
  const [notifs, setNotifs] = useState<NotifRow[]>([]);
  const [profile, setProfile] = useState<ProfileData | null>(null);

  const reload = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [due, sched, rx, doc, fam, notif, prof] = await Promise.all([
        apiFetch<{ upcoming: UpcomingDose[]; unreadNotifications: number }>("/api/reminders/due"),
        apiFetch<{ schedules: ScheduleRow[] }>("/api/reminders/schedules"),
        apiFetch<{ prescriptions: RxRow[] }>("/api/prescriptions"),
        apiFetch<{ documents: DocRow[] }>("/api/documents"),
        apiFetch<{ members: FamilyRow[] }>("/api/family"),
        apiFetch<{ notifications: NotifRow[]; unread: number }>("/api/notifications"),
        apiFetch<ProfileData>("/api/patients/profile"),
      ]);
      setUpcoming(due.upcoming);
      setSchedules(sched.schedules);
      setRxs(rx.prescriptions);
      setDocs(doc.documents);
      setFamily(fam.members);
      setNotifs(notif.notifications);
      setUnread(notif.unread);
      setProfile(prof);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) void reload();
  }, [user, reload]);

  if (!user) {
    return (
      <>
        <PageHeader title={t("patient.title")} subtitle={t("patient.subtitle")} icon={<UserRound className="h-6 w-6" />} />
        <AuthGate>
          <span />
        </AuthGate>
      </>
    );
  }

  const activeCourses = schedules.filter((s) => s.status === "ACTIVE");
  const adherenceVals = schedules.map((s) => s.adherence).filter((v): v is number => v !== null);
  const adherence7d = adherenceVals.length ? Math.round(adherenceVals.reduce((a, b) => a + b, 0) / adherenceVals.length) : null;

  return (
    <>
      <PageHeader title={t("patient.title")} subtitle={t("patient.subtitle")} icon={<UserRound className="h-6 w-6" />} />

      {error && <ErrorNote message={error} onRetry={() => void reload()} />}

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex flex-wrap h-auto gap-1 w-full justify-start">
          <TabsTrigger value="overview">{t("patient.overview")}</TabsTrigger>
          <TabsTrigger value="reminders">{t("patient.reminders")}</TabsTrigger>
          <TabsTrigger value="prescriptions">{t("patient.prescriptions")}</TabsTrigger>
          <TabsTrigger value="documents">{t("patient.documents")}</TabsTrigger>
          <TabsTrigger value="family">{t("patient.family")}</TabsTrigger>
          <TabsTrigger value="notifications">{t("patient.notifications")}{notifs.filter((n) => !n.readAt).length > 0 ? ` (${notifs.filter((n) => !n.readAt).length})` : ""}</TabsTrigger>
          <TabsTrigger value="profile">{t("patient.profile")}</TabsTrigger>
          <TabsTrigger value="privacy">{t("patient.privacy")}</TabsTrigger>
        </TabsList>

        {/* ── Overview ── */}
        <TabsContent value="overview" className="space-y-5 mt-4">
          {loading ? (
            <LoadingCards count={3} />
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                <StatCard label={t("patient.activeCourses")} value={activeCourses.length} icon={<Pill className="h-4 w-4" />} />
                <StatCard label={t("patient.upcomingDoses")} value={upcoming.length} hint={upcoming[0] ? `${slotWord(upcoming[0].slot, t)} · ${new Date(upcoming[0].dueAt).toLocaleTimeString(locale === "bn" ? "bn-BD" : "en-GB", { hour: "2-digit", minute: "2-digit" })}` : undefined} icon={<Bell className="h-4 w-4" />} />
                <StatCard label={t("patient.recentPrescriptions")} value={rxs.length} icon={<FileText className="h-4 w-4" />} />
                <StatCard label={t("patient.adherence")} value={adherence7d !== null ? `${adherence7d}%` : "—"} icon={<ShieldCheck className="h-4 w-4" />} />
              </div>

              {profile && (
                <Card className="p-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{t("patient.completion")}</span>
                    <span className="tabular-nums text-muted-foreground">{profile.completion}%</span>
                  </div>
                  <Progress value={profile.completion} className="mt-2" />
                  {profile.completion < 100 && (
                    <Button size="sm" variant="outline" className="mt-3" onClick={() => setTab("profile")}>
                      {t("patient.profile")}
                    </Button>
                  )}
                </Card>
              )}

              {/* Upcoming doses — simple, big-tap-target cards */}
              <div>
                <h2 className="font-semibold mb-2">{t("patient.upcomingDoses")}</h2>
                {upcoming.length === 0 ? (
                  <EmptyState
                    title={t("patient.noReminders")}
                    action={decoded ? <Button size="sm" onClick={() => setTab("reminders")}>{t("scan.createReminders")}</Button> : <Button size="sm" onClick={() => setView("scan")}>{t("nav.scan")}</Button>}
                  />
                ) : (
                  <div className="grid gap-3 md:grid-cols-2">
                    {upcoming.map((d) => (
                      <DoseCard key={d.id} dose={d} onLogged={() => void reload()} />
                    ))}
                  </div>
                )}
              </div>

              <div>
                <h2 className="font-semibold mb-2">{t("patient.recentPrescriptions")}</h2>
                {rxs.length === 0 ? (
                  <EmptyState title={t("patient.noPrescriptions")} action={<Button size="sm" onClick={() => setView("scan")}>{t("nav.scan")}</Button>} />
                ) : (
                  <RxList rxs={rxs.slice(0, 3)} onChanged={reload} locale={locale} />
                )}
              </div>
            </>
          )}
        </TabsContent>

        {/* ── Reminders ── */}
        <TabsContent value="reminders" className="mt-4">
          <RemindersTab schedules={schedules} onChanged={reload} loading={loading} onGoScan={() => setView("scan")} decodedReady={Boolean(decoded)} />
        </TabsContent>

        {/* ── Prescriptions ── */}
        <TabsContent value="prescriptions" className="mt-4">
          {loading ? <LoadingCards /> : rxs.length === 0 ? (
            <EmptyState title={t("patient.noPrescriptions")} hint={t("scan.signinToSave")} action={<Button size="sm" onClick={() => setView("scan")}>{t("nav.scan")}</Button>} />
          ) : (
            <RxList rxs={rxs} onChanged={reload} locale={locale} />
          )}
        </TabsContent>

        {/* ── Documents ── */}
        <TabsContent value="documents" className="mt-4">
          <DocumentsTab docs={docs} onChanged={reload} loading={loading} />
        </TabsContent>

        {/* ── Family ── */}
        <TabsContent value="family" className="mt-4">
          <FamilyTab members={family} onChanged={reload} />
        </TabsContent>

        {/* ── Notifications ── */}
        <TabsContent value="notifications" className="mt-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold">{t("patient.notifications")}</h2>
            <Button
              size="sm"
              variant="outline"
              onClick={async () => {
                await apiFetch("/api/notifications", { method: "PATCH", body: JSON.stringify({ all: true }) });
                await reload();
              }}
            >
              {t("patient.markAllRead")}
            </Button>
          </div>
          {notifs.length === 0 ? (
            <EmptyState title={t("patient.noNotifications")} />
          ) : (
            <div className="space-y-2">
              {notifs.map((n) => (
                <Card key={n.id} className={`p-3 ${n.readAt ? "" : "border-emerald-600/40 bg-emerald-50/40 dark:bg-emerald-950/20"}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-medium text-sm">{n.title}</p>
                      <p className="text-sm text-muted-foreground mt-0.5">{n.body}</p>
                    </div>
                    <span className="text-xs text-muted-foreground shrink-0">{fmtDate(n.createdAt, locale)}</span>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ── Profile ── */}
        <TabsContent value="profile" className="mt-4">
          {profile && <ProfileTab data={profile} onChanged={reload} />}
        </TabsContent>

        {/* ── Privacy ── */}
        <TabsContent value="privacy" className="mt-4">
          {profile && <PrivacyTab data={profile} onChanged={reload} onDeleted={() => setUser(null)} />}
        </TabsContent>
      </Tabs>
    </>
  );
}

// ── dose card with Taken / Skip / Snooze ──────────────────────────────────────

function DoseCard({ dose, onLogged }: { dose: UpcomingDose; onLogged: () => void }) {
  const { t, locale } = useI18n();
  const [busy, setBusy] = useState(false);
  const time = new Date(dose.dueAt).toLocaleTimeString(locale === "bn" ? "bn-BD" : "en-GB", { hour: "2-digit", minute: "2-digit" });
  const instruction = locale === "bn" ? dose.instructionBangla : dose.instructionEnglish;

  const log = async (action: "TAKEN" | "SKIPPED" | "SNOOZED") => {
    setBusy(true);
    try {
      await apiFetch("/api/reminders/logs", { method: "POST", body: JSON.stringify({ reminderId: dose.id, action }) });
      onLogged();
    } catch {
      // dose logging must never crash the card — surface via the shared toast
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-semibold">{dose.medicineLabel}</p>
          <p className="text-sm text-muted-foreground">
            {slotWord(dose.slot, t)} · {t("rem.doseAt", { time })}
            {dose.meal === "after" ? ` · ${t("med.afterMeal")}` : dose.meal === "before" ? ` · ${t("med.beforeMeal")}` : ""}
          </p>
          {instruction && <p className="font-bangla text-sm mt-1 text-emerald-800 dark:text-emerald-300">{instruction}</p>}
        </div>
        <Badge variant="outline">{t("rem.pending")}</Badge>
      </div>
      <div className="flex gap-2 mt-3">
        <Button size="sm" className="flex-1" disabled={busy} onClick={() => void log("TAKEN")}>
          {t("patient.takeDose")}
        </Button>
        <Button size="sm" variant="outline" className="flex-1" disabled={busy} onClick={() => void log("SKIPPED")}>
          {t("patient.skipDose")}
        </Button>
        <Button size="sm" variant="ghost" disabled={busy} onClick={() => void log("SNOOZED")}>
          {t("patient.snoozeDose")}
        </Button>
      </div>
      <p className="text-[11px] text-muted-foreground mt-2">{t("rem.disclaimer")}</p>
    </Card>
  );
}

// ── reminders tab ─────────────────────────────────────────────────────────────

function RemindersTab({ schedules, onChanged, loading, onGoScan, decodedReady }: {
  schedules: ScheduleRow[]; onChanged: () => Promise<void>; loading: boolean; onGoScan: () => void; decodedReady: boolean;
}) {
  const { t } = useI18n();
  const [creating, setCreating] = useState(false);
  const [label, setLabel] = useState("");
  const [slots, setSlots] = useState<string[]>(["MORNING"]);
  const [duration, setDuration] = useState<string>("");
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const create = async () => {
    setError(null);
    if (!label) { setError(t("common.required")); return; }
    if (!confirmed) { setError(t("rem.mustConfirm")); return; }
    setBusy(true);
    try {
      await apiFetch("/api/reminders/schedules", {
        method: "POST",
        body: JSON.stringify({
          medicineLabel: label,
          slots,
          perDay: slots.length,
          durationDays: duration ? parseInt(duration, 10) : undefined,
          meal: "any",
          confirmed,
        }),
      });
      setLabel(""); setSlots(["MORNING"]); setDuration(""); setConfirmed(false); setCreating(false);
      await onChanged();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setBusy(false);
    }
  };

  const stop = async (id: string) => {
    await apiFetch("/api/reminders/schedules", { method: "PATCH", body: JSON.stringify({ id, action: "STOP" }) });
    await onChanged();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground max-w-xl">{t("rem.createDesc")}</p>
        <Button size="sm" onClick={() => setCreating((v) => !v)}>
          <Plus className="h-4 w-4 mr-1" /> {t("rem.create")}
        </Button>
      </div>

      {creating && (
        <Card className="p-4 space-y-3">
          <div className="space-y-1">
            <Label htmlFor="rem-label">{t("rem.medicineLabel")}</Label>
            <Input id="rem-label" value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Napa 500 mg" />
          </div>
          <div className="space-y-1">
            <Label>{t("rem.slots")}</Label>
            <div className="flex flex-wrap gap-3">
              {(["MORNING", "AFTERNOON", "NIGHT"] as const).map((s) => (
                <label key={s} className="flex items-center gap-1.5 text-sm">
                  <input
                    type="checkbox"
                    className="h-4 w-4 accent-emerald-600"
                    checked={slots.includes(s)}
                    onChange={(e) => setSlots((cur) => (e.target.checked ? [...cur, s] : cur.filter((x) => x !== s)))}
                  />
                  {slotWord(s, t)}
                </label>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 max-w-sm">
            <div className="space-y-1">
              <Label htmlFor="rem-days">{t("rem.duration")}</Label>
              <Input id="rem-days" type="number" min={1} max={720} value={duration} onChange={(e) => setDuration(e.target.value)} placeholder={t("rem.durationOpen")} />
            </div>
          </div>
          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" className="mt-0.5 h-4 w-4 accent-emerald-600" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
            <span>{t("rem.confirmCheck")}</span>
          </label>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <div className="flex gap-2">
            <Button size="sm" onClick={() => void create()} disabled={busy}>{busy ? t("common.loading") : t("rem.create")}</Button>
            <Button size="sm" variant="ghost" onClick={() => setCreating(false)}>{t("common.cancel")}</Button>
          </div>
          {decodedReady && (
            <p className="text-xs text-muted-foreground">
              {t("rem.sourceRx")}: {t("scan.createReminders")} → <button className="underline text-primary" onClick={onGoScan}>{t("nav.scan")}</button>
            </p>
          )}
        </Card>
      )}

      {loading ? (
        <LoadingCards />
      ) : schedules.length === 0 ? (
        <EmptyState title={t("patient.noReminders")} />
      ) : (
        <div className="space-y-3">
          {schedules.map((s) => (
            <Card key={s.id} className="p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">{s.medicineLabel}</p>
                  <p className="text-sm text-muted-foreground">
                    {t("rem.perDay", { perDay: s.perDay })} · {s.slots.map((sl) => slotWord(sl, t)).join(" · ")}
                    {s.familyMember ? ` · ${s.familyMember.name}` : ""}
                  </p>
                  {s.instructionBangla && <p className="font-bangla text-sm mt-1 text-emerald-800 dark:text-emerald-300">{s.instructionBangla}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={s.status === "ACTIVE" ? "default" : s.status === "COMPLETED" ? "secondary" : "outline"}>
                    {s.status === "ACTIVE" ? t("rem.active") : s.status === "COMPLETED" ? t("rem.completed") : s.status === "CANCELLED" ? t("rem.cancelled") : t("rem.draft")}
                  </Badge>
                  {s.status === "ACTIVE" && (
                    <Button size="sm" variant="outline" onClick={() => void stop(s.id)}>{t("rem.stopReminders")}</Button>
                  )}
                </div>
              </div>
              <div className="flex flex-wrap gap-3 mt-3 text-sm text-muted-foreground">
                <span>{s.totalDoses} doses · {s.pendingDoses} {t("rem.pending").toLowerCase()}</span>
                {s.adherence !== null && <span>{t("patient.adherence")}: {s.adherence}%</span>}
                {s.endDate && <span>{t("common.date")}: {fmtDate(s.startDate)} → {fmtDate(s.endDate)}</span>}
                {s.refillNeeded && <Badge className="bg-amber-500 text-white">{t("rem.refillTitle")}</Badge>}
              </div>
              <p className="text-[11px] text-muted-foreground mt-2">{t("rem.editNote")}</p>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ── prescriptions list ────────────────────────────────────────────────────────

function RxList({ rxs, onChanged, locale }: { rxs: RxRow[]; onChanged: () => Promise<void>; locale: string }) {
  const { t } = useI18n();
  const playQueue = useRef<HTMLAudioElement | null>(null);
  const [playingId, setPlayingId] = useState<string | null>(null);

  const speak = async (rx: RxRow) => {
    // reuse the existing Bangla TTS pipeline for a spoken summary
    const lines = rx.items.map((i) => `${i.brand ?? ""} ${i.strength ?? ""} ${i.dose ?? ""}`).join(". ");
    setPlayingId(rx.id);
    try {
      const res = await fetch("/api/tts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: lines }) });
      if (res.ok) {
        const blob = await res.blob();
        const audio = new Audio(URL.createObjectURL(blob));
        playQueue.current = audio;
        audio.onended = () => setPlayingId(null);
        await audio.play().catch(() => setPlayingId(null));
      } else setPlayingId(null);
    } catch {
      setPlayingId(null);
    }
  };

  const remove = async (id: string) => {
    if (!window.confirm(t("common.confirmDelete"))) return;
    await apiFetch(`/api/prescriptions?id=${id}`, { method: "DELETE" });
    await onChanged();
  };

  return (
    <div className="space-y-3">
      {rxs.map((rx) => (
        <Card key={rx.id} className="p-4">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <p className="font-semibold">{rx.doctorName ?? "—"}</p>
              <p className="text-sm text-muted-foreground">
                {rx.facility ? `${rx.facility} · ` : ""}
                {rx.familyMember ? `${rx.familyMember.name} (${rx.familyMember.relation}) · ` : ""}
                {fmtDate(rx.createdAt, locale)}
              </p>
            </div>
            <div className="flex gap-1.5">
              <Button size="sm" variant="outline" onClick={() => void speak(rx)} aria-label={t("scan.play")}>
                <Play className="h-3.5 w-3.5" />
              </Button>
              <Button size="sm" variant="ghost" onClick={() => void remove(rx.id)} aria-label={t("common.delete")}>
                <Trash2 className="h-3.5 w-3.5 text-destructive" />
              </Button>
            </div>
          </div>
          <ul className="mt-2 space-y-1">
            {rx.items.map((it) => (
              <li key={it.id} className="text-sm flex flex-wrap items-baseline gap-x-2">
                <span className="font-medium">{it.brand ?? "—"}</span>
                {it.strength && <span className="text-muted-foreground">{it.strength}</span>}
                {it.dose && <Badge variant="secondary" className="font-bangla">{it.dose}</Badge>}
                {it.durationDays && <span className="text-xs text-muted-foreground">{it.durationDays}d</span>}
              </li>
            ))}
          </ul>
          {rx.totals && rx.totals.brandBdt !== null && (
            <p className="text-xs text-muted-foreground mt-2">
              {t("scan.totalBrand")}: {fmtBdt(rx.totals.brandBdt)} · {t("scan.totalGeneric")}: {fmtBdt(rx.totals.genericBdt)}
              {rx.totals.savingsPct !== null ? ` · ${t("scan.savings")} ${rx.totals.savingsPct}%` : ""}
            </p>
          )}
          {rx.findings.some((f) => f.severity === "major") && (
            <Badge variant="destructive" className="mt-2">{t("patient.majorFlags", { count: rx.findings.filter((f) => f.severity === "major").length })}</Badge>
          )}
        </Card>
      ))}
      {playingId && <p className="text-xs text-muted-foreground" aria-live="polite">{t("scan.playing")}</p>}
    </div>
  );
}

// ── documents vault ───────────────────────────────────────────────────────────

function DocumentsTab({ docs, onChanged, loading }: { docs: DocRow[]; onChanged: () => Promise<void>; loading: boolean }) {
  const { t, locale } = useI18n();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("PRESCRIPTION");
  const [file, setFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const upload = async () => {
    setError(null);
    if (!file) { setError(t("patient.docFile") + ": " + t("common.required")); return; }
    if (file.size > 10 * 1024 * 1024) { setError(t("patient.docSizeLimit")); return; }
    setBusy(true);
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("title", title || file.name);
      form.append("category", category);
      const res = await fetch("/api/documents", { method: "POST", body: form });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { code?: string; error?: string };
        throw new ApiClientError(String(body.code ?? "ERROR"), String(body.error ?? `Upload failed (${res.status})`), res.status);
      }
      setTitle(""); setFile(null); setCategory("PRESCRIPTION");
      if (inputRef.current) inputRef.current.value = "";
      await onChanged();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id: string) => {
    if (!window.confirm(t("common.confirmDelete"))) return;
    await apiFetch(`/api/documents/${id}`, { method: "DELETE" });
    await onChanged();
  };

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <Label htmlFor="doc-title">{t("patient.docTitle")}</Label>
            <Input id="doc-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t("patient.docTitle")} />
          </div>
          <div className="space-y-1">
            <Label>{t("patient.docCategory")}</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="PRESCRIPTION">Prescription</SelectItem>
                <SelectItem value="LAB_REPORT">Lab report</SelectItem>
                <SelectItem value="DIAGNOSTIC">Diagnostic</SelectItem>
                <SelectItem value="OTHER">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="space-y-1">
          <Label htmlFor="doc-file">{t("patient.docFile")} — PDF, JPG, PNG (&lt;10MB)</Label>
          <Input id="doc-file" type="file" accept=".pdf,image/jpeg,image/png,image/webp" ref={inputRef} onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
        </div>
        {error && <p className="text-sm text-destructive">{error}</p>}
        <Button size="sm" onClick={() => void upload()} disabled={busy}>
          <FolderOpen className="h-4 w-4 mr-1" /> {busy ? t("common.loading") : t("patient.uploadDoc")}
        </Button>
        <p className="text-xs text-muted-foreground">{t("privacy.whoSeesBody")}</p>
      </Card>

      {loading ? (
        <LoadingCards />
      ) : docs.length === 0 ? (
        <EmptyState title={t("patient.docEmpty")} />
      ) : (
        <div className="space-y-2">
          {docs.map((d) => (
            <Card key={d.id} className="p-3 flex flex-wrap items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="font-medium text-sm truncate max-w-[280px]">{d.title}</p>
                <p className="text-xs text-muted-foreground">
                  {d.category.replace("_", " ")} · {(d.sizeBytes / 1024).toFixed(0)} KB · {fmtDate(d.docDate ?? d.createdAt, locale)}
                </p>
              </div>
              <div className="flex gap-1.5">
                <Button size="sm" variant="outline" asChild>
                  <a href={`/api/documents/${d.id}`} target="_blank" rel="noreferrer">{d.mimeType === "application/pdf" ? "Open" : "Preview"}</a>
                </Button>
                <Button size="sm" variant="outline" asChild>
                  <a href={`/api/documents/${d.id}?download=1`} download>{t("patient.docDownload")}</a>
                </Button>
                <Button size="sm" variant="ghost" onClick={() => void remove(d.id)} aria-label={t("common.delete")}>
                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ── family ────────────────────────────────────────────────────────────────────

function FamilyTab({ members, onChanged }: { members: FamilyRow[]; onChanged: () => Promise<void> }) {
  const { t } = useI18n();
  const [name, setName] = useState("");
  const [relation, setRelation] = useState("SPOUSE");
  const [age, setAge] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const add = async () => {
    if (!name) return;
    setBusy(true);
    setError(null);
    try {
      await apiFetch("/api/family", {
        method: "POST",
        body: JSON.stringify({ name, relation, ageYears: age ? parseInt(age, 10) : undefined }),
      });
      setName(""); setAge(""); await onChanged();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setBusy(false);
    }
  };
  const remove = async (id: string) => {
    if (!window.confirm(t("common.confirmDelete"))) return;
    setError(null);
    try {
      await apiFetch(`/api/family?id=${id}`, { method: "DELETE" });
      await onChanged();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    }
  };

  return (
    <div className="space-y-4">
      <Card className="p-4">
        {error && <p className="mb-3 text-sm text-destructive">{error}</p>}
        <div className="grid gap-3 sm:grid-cols-4 sm:items-end">
          <div className="space-y-1">
            <Label htmlFor="fam-name">{t("patient.familyName")}</Label>
            <Input id="fam-name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>{t("patient.relation")}</Label>
            <Select value={relation} onValueChange={setRelation}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {RELATIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label htmlFor="fam-age">{t("patient.dob")}</Label>
            <Input id="fam-age" type="number" min={0} max={120} value={age} onChange={(e) => setAge(e.target.value)} placeholder="age" />
          </div>
          <Button onClick={() => void add()} disabled={busy || !name}>
            <Users className="h-4 w-4 mr-1" /> {t("patient.addFamily")}
          </Button>
        </div>
      </Card>

      {members.length === 0 ? (
        <EmptyState title={t("common.empty")} hint={t("patient.addFamily")} />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {members.map((m) => (
            <Card key={m.id} className="p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold">{m.name}</p>
                  <p className="text-sm text-muted-foreground">{m.relation}{m.ageYears !== null ? ` · ${m.ageYears}` : ""}</p>
                </div>
                <Button size="sm" variant="ghost" onClick={() => void remove(m.id)} aria-label={t("common.delete")}>
                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                </Button>
              </div>
              {m.allergies.length > 0 && (
                <p className="text-sm mt-2"><span className="text-muted-foreground">{t("patient.allergies")}:</span> {m.allergies.join(", ")}</p>
              )}
              {m.chronicConditions.length > 0 && (
                <p className="text-sm"><span className="text-muted-foreground">{t("patient.chronic")}:</span> {m.chronicConditions.join(", ")}</p>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ── profile ───────────────────────────────────────────────────────────────────

function ProfileTab({ data, onChanged }: { data: ProfileData; onChanged: () => Promise<void> }) {
  const { t } = useI18n();
  const { setLargeText, largeText } = useAppStore();
  const [name, setName] = useState(data.user.name);
  const [phone, setPhone] = useState(data.user.phone ?? "");
  const [bloodGroup, setBloodGroup] = useState(data.profile?.bloodGroup ?? "");
  const [height, setHeight] = useState(data.profile?.heightCm?.toString() ?? "");
  const [weight, setWeight] = useState(data.profile?.weightKg?.toString() ?? "");
  const [allergies, setAllergies] = useState((data.profile?.allergies ?? []).join(", "));
  const [chronic, setChronic] = useState((data.profile?.chronicConditions ?? []).join(", "));
  const [ecName, setEcName] = useState(data.profile?.emergencyContact?.name ?? "");
  const [ecPhone, setEcPhone] = useState(data.profile?.emergencyContact?.phone ?? "");
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const save = async () => {
    setBusy(true);
    setSaved(false);
    setError(null);
    try {
      await apiFetch("/api/patients/profile", {
        method: "PATCH",
        body: JSON.stringify({
          name,
          phone: phone || null,
          bloodGroup: bloodGroup || null,
          heightCm: height ? parseInt(height, 10) : null,
          weightKg: weight ? parseInt(weight, 10) : null,
          allergies: allergies ? allergies.split(",").map((s) => s.trim()).filter(Boolean) : [],
          chronicConditions: chronic ? chronic.split(",").map((s) => s.trim()).filter(Boolean) : [],
          emergencyContact: ecName && ecPhone ? { name: ecName, phone: ecPhone } : null,
        }),
      });
      setSaved(true);
      await onChanged();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="p-4 max-w-2xl space-y-4">
      {error && <ErrorNote message={error} />}
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1">
          <Label htmlFor="prof-name">{t("common.name")}</Label>
          <Input id="prof-name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="prof-phone">{t("common.phone")}</Label>
          <Input id="prof-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="01XXXXXXXXX" />
        </div>
        <div className="space-y-1">
          <Label>{t("patient.bloodGroup")}</Label>
          <Select value={bloodGroup} onValueChange={setBloodGroup}>
            <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
            <SelectContent>
              {["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"].map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label htmlFor="prof-h">{t("patient.height")}</Label>
            <Input id="prof-h" type="number" value={height} onChange={(e) => setHeight(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="prof-w">{t("patient.weight")}</Label>
            <Input id="prof-w" type="number" value={weight} onChange={(e) => setWeight(e.target.value)} />
          </div>
        </div>
        <div className="space-y-1">
          <Label htmlFor="prof-allergy">{t("patient.allergies")} <span className="text-muted-foreground">({t("common.optional")})</span></Label>
          <Input id="prof-allergy" value={allergies} onChange={(e) => setAllergies(e.target.value)} placeholder="Penicillin, dust…" />
        </div>
        <div className="space-y-1">
          <Label htmlFor="prof-chronic">{t("patient.chronic")}</Label>
          <Input id="prof-chronic" value={chronic} onChange={(e) => setChronic(e.target.value)} placeholder="Diabetes, hypertension…" />
        </div>
        <div className="space-y-1">
          <Label htmlFor="prof-ec">{t("patient.emergencyContact")}</Label>
          <Input id="prof-ec" value={ecName} onChange={(e) => setEcName(e.target.value)} placeholder={t("common.name")} className="mb-2" />
          <Input type="tel" value={ecPhone} onChange={(e) => setEcPhone(e.target.value)} placeholder="01XXXXXXXXX" />
        </div>
        <div className="space-y-1 flex flex-col justify-end">
          <Label>{t("settings.largeText")}</Label>
          <Switch checked={largeText} onCheckedChange={setLargeText} />
        </div>
      </div>
      <div className="flex items-center gap-3">
        <Button onClick={() => void save()} disabled={busy}>{busy ? t("common.loading") : t("common.save")}</Button>
        {saved && <span className="text-sm text-emerald-700 dark:text-emerald-400">{t("patient.profileSaved")}</span>}
      </div>
    </Card>
  );
}

// ── privacy ───────────────────────────────────────────────────────────────────

function PrivacyTab({ data, onChanged, onDeleted }: { data: ProfileData; onChanged: () => Promise<void>; onDeleted: () => void }) {
  const { t } = useI18n();
  const [consents, setConsents] = useState<Record<string, boolean>>(
    Object.fromEntries(["DATA_PROCESSING", "MARKETING", "GPS"].map((c) => [c, data.consents.find((x) => x.type === c)?.granted ?? false]))
  );
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [deleted, setDeleted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [consentError, setConsentError] = useState<string | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);

  const saveConsent = async (type: string, granted: boolean) => {
    setConsents((c) => ({ ...c, [type]: granted }));
    setConsentError(null);
    try {
      await apiFetch("/api/patients/profile", { method: "PATCH", body: JSON.stringify({ consents: [{ type, granted }] }) });
    } catch (err) {
      setConsentError(err instanceof ApiClientError ? err.message : t("err.generic"));
    }
  };

  const exportData = async () => {
    setExportError(null);
    try {
      const res = await apiFetch<{ export: Record<string, unknown> }>("/api/patients/profile", {
        method: "POST",
        body: JSON.stringify({ action: "EXPORT", password }),
      });
      const blob = new Blob([JSON.stringify(res.export, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "oshudhscan-my-data.json";
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setExportError(err instanceof ApiClientError ? err.message : t("err.generic"));
    }
  };

  const deleteAccount = async () => {
    setBusy(true);
    setError(null);
    try {
      await apiFetch("/api/patients/profile", { method: "POST", body: JSON.stringify({ action: "DELETE", password }) });
      setDeleted(true);
      onDeleted();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-2xl space-y-4">
      <Card className="p-4">
        <h2 className="font-semibold">{t("privacy.title")}</h2>
        <p className="text-sm text-muted-foreground mt-1">{t("privacy.whoSeesBody")}</p>
        <div className="mt-4 space-y-3">
          {(
            [
              ["DATA_PROCESSING", "privacy.consentData"],
              ["GPS", "privacy.consentGps"],
              ["MARKETING", "privacy.consentMarketing"],
            ] as const
          ).map(([type, key]) => (
            <label key={type} className="flex items-start justify-between gap-3 text-sm">
              <span className="max-w-md">{t(key)}</span>
              <Switch checked={consents[type]} onCheckedChange={(v) => void saveConsent(type, v)} aria-label={t(key)} />
            </label>
          ))}
        </div>
        {consentError && <p className="text-sm text-destructive">{consentError}</p>}
      </Card>

      <Card className="p-4 space-y-3">
        <h2 className="font-semibold">{t("privacy.exportData")}</h2>
        <p className="text-xs text-muted-foreground">{t("privacy.exportHint")}</p>
        <div className="flex gap-2">
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder={t("auth.passwordLabel")} className="max-w-xs" aria-label={t("auth.passwordLabel")} />
          <Button variant="outline" onClick={() => void exportData()} disabled={!password}>
            <Download className="h-4 w-4 mr-1" /> {t("privacy.exportJson")}
          </Button>
        </div>
        {exportError && <p className="text-sm text-destructive">{exportError}</p>}
      </Card>

      <Card className="p-4 space-y-3 border-destructive/40">
        <h2 className="font-semibold text-destructive">{t("privacy.deleteAccount")}</h2>
        <p className="text-sm text-muted-foreground">{t("privacy.deleteWarn")}</p>
        <div className="flex gap-2">
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder={t("auth.passwordLabel")} className="max-w-xs" aria-label={t("auth.passwordLabel")} />
          <Button variant="destructive" onClick={() => void deleteAccount()} disabled={!password || busy}>
            {busy ? t("common.loading") : t("privacy.deleteAccount")}
          </Button>
        </div>
        {error && <p className="text-sm text-destructive">{error}</p>}
        {deleted && <p className="text-sm text-emerald-700">{t("privacy.deleted")}</p>}
      </Card>
    </div>
  );
}
