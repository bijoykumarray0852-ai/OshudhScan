"use client";
// Pharmacy Finder: GPS or manual location, distance/open/verified filters,
// name & medicine search, list + OpenStreetMap map views, reservations,
// one-tap calling, and "report incorrect information" for every listing.
import { useCallback, useEffect, useState } from "react";
import { MapPin, Search, Phone, Navigation, Star, Map as MapIcon, ListFilter, Pill, AlertTriangle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useI18n } from "@/hooks/use-i18n";
import { useAppStore } from "@/lib/store";
import { useLiteMode } from "@/lib/lite";
import {
  apiFetch, ApiClientError, PageHeader, EmptyState, LoadingCards, ErrorNote,
  VerifiedBadge, StockBadge, Freshness, DistanceLabel, LocationPicker, fmtBdt, type LocationSel,
} from "@/components/rx/shared";
import { ReportDialog } from "@/components/rx/directory-ui";
import { LiteModeSuggestBanner, LiteMapPlaceholder } from "@/components/rx/lite-ui";
import { DISTANCE_FILTERS } from "@/lib/geo";

interface PharmacyRow {
  id: string; name: string; nameBangla: string | null; contactPhone: string;
  addressLine: string; district: string; upazila: string | null; area: string | null;
  lat: number | null; lng: number | null; rating: number; isVerified: boolean; isDemo: boolean;
  services: string | null; openNow: boolean; distanceKm: number | null; stockedCount: number;
  stock: { status: string; quantity: number; updatedAt: string; sellingPrice: number | null; medicineLabel: string } | null;
}
interface AvailabilityResult {
  pharmacyId: string; pharmacyName: string; addressLine: string; division: string | null; district: string; area: string | null;
  contactPhone: string; lat: number | null; lng: number | null; isVerified: boolean; isDemo: boolean;
  distanceKm: number | null; stockStatus: string; quantity: number; indicativePrice: number | null;
  lastStockUpdate: string;
}
interface AvailabilityResp {
  medicines: { id: string; brand: string; generic: string; genericBangla: string | null; strength: string | null; form: string; unitPriceBdt: number }[];
  results: AvailabilityResult[];
}

const DEFAULT_CENTER = { lat: 23.8103, lng: 90.4125 }; // Dhaka

export function FindView() {
  const { t, locale } = useI18n();
  const user = useAppStore((s) => s.user);
  const openAuth = useAppStore((s) => s.openAuth);
  const favorites = useAppStore((s) => s.favorites);
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);
  // Low Internet Mode: the OSM iframe stays hidden until explicitly loaded.
  const { liteMode } = useLiteMode();
  const [liteMapOpen, setLiteMapOpen] = useState(false);

  // search state
  const [mode, setMode] = useState<"pharmacies" | "medicine">("pharmacies");
  const [q, setQ] = useState("");
  const [medQ, setMedQ] = useState("");
  const [loc, setLoc] = useState<LocationSel>({});
  const [geo, setGeo] = useState<{ lat: number; lng: number } | null>(null);
  const [geoState, setGeoState] = useState<"idle" | "locating" | "denied" | "ok">("idle");
  const [distance, setDistance] = useState(10);
  const [openOnly, setOpenOnly] = useState(false);
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [selected, setSelected] = useState<PharmacyRow | null>(null);
  const [reporting, setReporting] = useState<PharmacyRow | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rows, setRows] = useState<PharmacyRow[]>([]);
  const [total, setTotal] = useState(0);
  const [geoApplied, setGeoApplied] = useState(false);
  const [reservedOk, setReservedOk] = useState(false);
  const [reserveBusy, setReserveBusy] = useState(false);
  const [reserveError, setReserveError] = useState<string | null>(null);

  // availability state
  const [avLoading, setAvLoading] = useState(false);
  const [av, setAv] = useState<AvailabilityResp | null>(null);
  const [reserving, setReserving] = useState<AvailabilityResult | null>(null);

  const searchPharmacies = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (q) params.set("q", q);
      if (geo) { params.set("lat", String(geo.lat)); params.set("lng", String(geo.lng)); }
      else {
        if (loc.division) params.set("division", loc.division);
        if (loc.district) params.set("district", loc.district);
        if (loc.upazila) params.set("upazila", loc.upazila);
      }
      params.set("distance", String(distance));
      if (openOnly) params.set("openNow", "1");
      if (verifiedOnly) params.set("verified", "1");
      const res = await apiFetch<{ pharmacies: PharmacyRow[]; total: number; geoApplied: boolean }>(`/api/pharmacies?${params}`);
      setRows(res.pharmacies);
      setTotal(res.total);
      setGeoApplied(res.geoApplied);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setLoading(false);
    }
  }, [q, geo, loc.division, loc.district, loc.upazila, distance, openOnly, verifiedOnly, t]);

  const searchAvailability = useCallback(async () => {
    if (!medQ.trim()) return;
    setAvLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      params.set("q", medQ);
      if (geo) { params.set("lat", String(geo.lat)); params.set("lng", String(geo.lng)); }
      else {
        if (loc.division) params.set("division", loc.division);
        if (loc.district) params.set("district", loc.district);
        if (loc.upazila) params.set("upazila", loc.upazila);
      }
      params.set("distance", String(distance));
      const res = await apiFetch<AvailabilityResp>(`/api/availability?${params}`);
      setAv(res);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setAvLoading(false);
    }
  }, [medQ, geo, loc.division, loc.district, loc.upazila, distance, t]);

  // initial load
  useEffect(() => {
    void searchPharmacies();
  }, []);

  const useMyLocation = () => {
    if (!("geolocation" in navigator)) {
      setGeoState("denied");
      return;
    }
    setGeoState("locating");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeo({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGeoState("ok");
      },
      () => setGeoState("denied"),
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 }
    );
  };

  const reserve = async (r: AvailabilityResult, quantity: number) => {
    if (!user) { openAuth("signin"); return; }
    if (!av?.medicines[0]) return;
    setReserveBusy(true);
    setReserveError(null);
    try {
      await apiFetch("/api/reservations", {
        method: "POST",
        body: JSON.stringify({ pharmacyId: r.pharmacyId, medicineId: av.medicines[0].id, quantity }),
      });
      setReservedOk(true);
      setTimeout(() => setReserving(null), 1200);
    } catch (err) {
      setReserveError(err instanceof ApiClientError ? err.message : t("err.generic"));
    } finally {
      setReserveBusy(false);
    }
  };

  const parseServices = (svc: string | null): string[] => {
    try { return svc ? JSON.parse(svc) : []; } catch { return []; }
  };

  const placeLabel = geo ? t("common.myLocation") : loc.district ?? loc.division ?? t("directory.wholeBangladesh");
  const center = geo ?? (loc.lat && loc.lng ? { lat: loc.lat, lng: loc.lng } : DEFAULT_CENTER);

  return (
    <>
      <PageHeader title={t("find.title")} subtitle={t("find.subtitle")} icon={<MapPin className="h-6 w-6" />} />

      <LiteModeSuggestBanner />

      {/* mode switch */}
      <div className="flex gap-2 mb-4">
        <Button variant={mode === "pharmacies" ? "default" : "outline"} size="sm" onClick={() => setMode("pharmacies")}>
          {t("find.byName")}
        </Button>
        <Button variant={mode === "medicine" ? "default" : "outline"} size="sm" onClick={() => setMode("medicine")}>
          {t("find.byMedicine")}
        </Button>
      </div>

      {/* search + filters */}
      <Card className="p-4 mb-5 space-y-3">
        {mode === "pharmacies" ? (
          <div className="flex gap-2">
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("find.byName")}
              aria-label={t("find.byName")}
              onKeyDown={(e) => e.key === "Enter" && void searchPharmacies()}
            />
            <Button onClick={() => void searchPharmacies()} aria-label={t("common.search")}>
              <Search className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="flex gap-2">
            <Input
              value={medQ}
              onChange={(e) => setMedQ(e.target.value)}
              placeholder={t("find.medicinePlaceholder")}
              aria-label={t("find.byMedicine")}
              onKeyDown={(e) => e.key === "Enter" && void searchAvailability()}
            />
            <Button onClick={() => void searchAvailability()} aria-label={t("common.search")}>
              <Search className="h-4 w-4" />
            </Button>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <Button size="sm" variant={geo ? "default" : "outline"} onClick={useMyLocation} disabled={geoState === "locating"}>
            <MapPin className="h-4 w-4 mr-1" />
            {geoState === "locating" ? t("common.locating") : t("find.useLocation")}
          </Button>
          <LocationPicker value={loc} onChange={setLoc} />
          {geoState === "denied" && <p className="text-xs text-destructive">{t("common.locationDenied")}</p>}
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">{t("find.radius")}</span>
            <div className="flex gap-1">
              {DISTANCE_FILTERS.map((d) => (
                <Button key={d} size="sm" variant={distance === d ? "default" : "outline"} className="h-8 px-2.5" onClick={() => setDistance(d)}>
                  {d}{t("common.km")}
                </Button>
              ))}
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <Switch checked={openOnly} onCheckedChange={setOpenOnly} aria-label={t("find.openFilter")} />
            {t("find.openFilter")}
          </label>
          <label className="flex items-center gap-2 text-sm">
            <Switch checked={verifiedOnly} onCheckedChange={setVerifiedOnly} aria-label={t("find.verifiedFilter")} />
            {t("find.verifiedFilter")}
          </label>
          {mode === "pharmacies" && (
            <Button size="sm" variant="outline" onClick={() => setShowMap((v) => !v)}>
              {showMap ? <><ListFilter className="h-4 w-4 mr-1" />{t("find.listView")}</> : <><MapIcon className="h-4 w-4 mr-1" />{t("find.mapView")}</>}
            </Button>
          )}
        </div>
        <p className="text-xs text-muted-foreground">{t("common.locateHint")}</p>
      </Card>

      {error && <ErrorNote message={error} onRetry={mode === "pharmacies" ? searchPharmacies : searchAvailability} />}

      <p className="text-sm text-muted-foreground mb-3">
        {t("find.showingFor", { place: placeLabel })}
        {mode === "pharmacies" ? ` · ${total} ${t("common.results")}` : ""}
      </p>

      {/* results */}
      {mode === "pharmacies" ? (
        loading ? (
          <LoadingCards count={4} />
        ) : showMap ? (
          liteMode && !liteMapOpen ? (
            <LiteMapPlaceholder onLoad={() => setLiteMapOpen(true)} />
          ) : (
            <Card className="overflow-hidden">
              <iframe
                title="OpenStreetMap"
                className="w-full h-[420px] border-0"
                src={`https://www.openstreetmap.org/export/embed.html?bbox=${center.lng - 0.06},${center.lat - 0.04},${center.lng + 0.06},${center.lat + 0.04}&layer=mapnik&marker=${center.lat},${center.lng}`}
                loading="lazy"
              />
            </Card>
          )
        ) : rows.length === 0 ? (
          <EmptyState title={t("find.noPharmacies")} hint={t("find.noPharmaciesHint")} />
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {rows.map((p) => (
              <Card key={p.id} className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold">{locale === "bn" && p.nameBangla ? p.nameBangla : p.name}</p>
                    <p className="text-sm text-muted-foreground">{p.addressLine}</p>
                    <div className="flex flex-wrap items-center gap-2 mt-1.5">
                      <VerifiedBadge verified={p.isVerified} demo={p.isDemo} />
                      <Badge variant={p.openNow ? "default" : "outline"} className={p.openNow ? "bg-emerald-600 text-white" : ""}>
                        {p.openNow ? t("common.openNow") : t("common.closed")}
                      </Badge>
                      <DistanceLabel km={p.distanceKm} />
                      {p.rating > 0 && (
                        <span className="inline-flex items-center gap-0.5 text-xs text-muted-foreground">
                          <Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {p.rating}
                        </span>
                      )}
                    </div>
                  </div>
                  <button
                    className={`shrink-0 text-lg ${favorites.includes(p.id) ? "text-red-500" : "text-muted-foreground/50"}`}
                    onClick={() => toggleFavorite(p.id)}
                    aria-label={t("find.favorite")}
                  >
                    ♥
                  </button>
                </div>
                {p.stock && (
                  <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
                    <Pill className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="font-medium">{p.stock.medicineLabel}</span>
                    <StockBadge status={p.stock.status} />
                    {p.stock.sellingPrice !== null && <span className="text-muted-foreground">{fmtBdt(p.stock.sellingPrice)}</span>}
                    <Freshness updatedAt={p.stock.updatedAt} />
                  </div>
                )}
                <div className="flex flex-wrap gap-2 mt-3">
                  <Button size="sm" variant="outline" asChild>
                    <a href={`tel:${p.contactPhone}`}><Phone className="h-3.5 w-3.5 mr-1" />{t("common.call")}</a>
                  </Button>
                  {p.lat !== null && p.lng !== null && (
                    <Button size="sm" variant="outline" asChild>
                      <a href={`https://www.openstreetmap.org/?mlat=${p.lat}&mlon=${p.lng}#map=17/${p.lat}/${p.lng}`} target="_blank" rel="noreferrer">
                        <Navigation className="h-3.5 w-3.5 mr-1" />{t("common.directions")}
                      </a>
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => setSelected(p)}>{t("common.details")}</Button>
                  <Button size="sm" variant="ghost" className="text-amber-700 hover:text-amber-800" onClick={() => setReporting(p)}>
                    <AlertTriangle className="h-3.5 w-3.5 mr-1" />{t("directory.report")}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2">{p.stockedCount} {t("find.inventory").toLowerCase()} · {t("find.callFirst")}</p>
              </Card>
            ))}
          </div>
        )
      ) : (
        // medicine availability results
        avLoading ? (
          <LoadingCards count={4} />
        ) : !av ? (
          <EmptyState title={t("find.byMedicine")} hint={t("find.medicinePlaceholder")} />
        ) : av.results.length === 0 ? (
          <EmptyState title={t("common.noResults")} hint={t("common.noResultsHint")} />
        ) : (
          <div className="space-y-3">
            {av.medicines[0] && (
              <Card className="p-3 text-sm">
                <span className="font-semibold">{av.medicines[0].brand}</span>{" "}
                <span className="text-muted-foreground">
                  {av.medicines[0].generic} {av.medicines[0].strength ? `· ${av.medicines[0].strength}` : ""} · {fmtBdt(av.medicines[0].unitPriceBdt)}
                </span>
              </Card>
            )}
            {av.results.map((r) => (
              <Card key={r.pharmacyId} className="p-4">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold">{r.pharmacyName}</p>
                    <p className="text-sm text-muted-foreground">{r.addressLine}</p>
                    <div className="flex flex-wrap items-center gap-2 mt-1.5">
                      <VerifiedBadge verified={r.isVerified} demo={r.isDemo} />
                      <StockBadge status={r.stockStatus} />
                      <span className="text-sm">{r.quantity > 0 ? `${r.quantity} ${t("common.quantity").toLowerCase()}` : ""}</span>
                      {r.indicativePrice !== null && <span className="text-sm font-medium">{fmtBdt(r.indicativePrice)}</span>}
                      <Freshness updatedAt={r.lastStockUpdate} />
                      <DistanceLabel km={r.distanceKm} />
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    <Button size="sm" variant="outline" asChild>
                      <a href={`tel:${r.contactPhone}`}><Phone className="h-3.5 w-3.5 mr-1" />{t("common.call")}</a>
                    </Button>
                    <Button size="sm" variant="outline" asChild>
                      <a href={`https://www.openstreetmap.org/?mlat=${r.lat}&mlon=${r.lng}#map=17/${r.lat}/${r.lng}`} target="_blank" rel="noreferrer">
                        <Navigation className="h-3.5 w-3.5 mr-1" />{t("common.directions")}
                      </a>
                    </Button>
                    <Button size="sm" onClick={() => setReserving(r)}>{t("find.reserve")}</Button>
                  </div>
                </div>
              </Card>
            ))}
            <p className="text-xs text-muted-foreground">{t("find.reserveDesc")}</p>
          </div>
        )
      )}

      {/* pharmacy details dialog */}
      <Dialog open={Boolean(selected)} onOpenChange={(o) => (o ? undefined : setSelected(null))}>
        <DialogContent className="sm:max-w-lg">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle>{selected.name}</DialogTitle>
                <DialogDescription>{selected.addressLine}</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 text-sm">
                <div className="flex flex-wrap gap-2">
                  <VerifiedBadge verified={selected.isVerified} demo={selected.isDemo} />
                  <Badge variant={selected.openNow ? "default" : "outline"}>{selected.openNow ? t("common.openNow") : t("common.closed")}</Badge>
                  {parseServices(selected.services).map((s) => (
                    <Badge key={s} variant="secondary">{s.replace(/_/g, " ")}</Badge>
                  ))}
                </div>
                <p><span className="text-muted-foreground">{t("common.phone")}:</span> {selected.contactPhone}</p>
                <p><span className="text-muted-foreground">{t("common.address")}:</span> {[selected.area, selected.upazila, selected.district].filter(Boolean).join(", ")}</p>
                {selected.lat !== null && selected.lng !== null && (
                  liteMode && !liteMapOpen ? (
                    <LiteMapPlaceholder compact onLoad={() => setLiteMapOpen(true)} />
                  ) : (
                    <div className="rounded-lg overflow-hidden border">
                      <iframe
                        title="pharmacy map"
                        className="w-full h-52 border-0"
                        src={`https://www.openstreetmap.org/export/embed.html?bbox=${selected.lng - 0.01},${selected.lat - 0.007},${selected.lng + 0.01},${selected.lat + 0.007}&layer=mapnik&marker=${selected.lat},${selected.lng}`}
                        loading="lazy"
                      />
                    </div>
                  )
                )}
                <p className="text-xs text-muted-foreground">{t("find.reserveDesc")}</p>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" asChild><a href={`tel:${selected.contactPhone}`}><Phone className="h-3.5 w-3.5 mr-1" />{t("common.call")}</a></Button>
                  <Button size="sm" variant="ghost" className="text-amber-700 hover:text-amber-800" onClick={() => { setReporting(selected); setSelected(null); }}>
                    <AlertTriangle className="h-3.5 w-3.5 mr-1" />{t("directory.report")}
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* reservation dialog */}
      <Dialog
        open={Boolean(reserving)}
        onOpenChange={(o) => {
          if (o) { setReservedOk(false); setReserveError(null); }
          else setReserving(null);
        }}
      >
        <DialogContent className="sm:max-w-sm">
          {reserving && (
            <>
              <DialogHeader>
                <DialogTitle>{t("find.reserve")}</DialogTitle>
                <DialogDescription>
                  {av?.medicines[0]?.brand} @ {reserving.pharmacyName}
                </DialogDescription>
              </DialogHeader>
              <p className="text-sm text-muted-foreground">{t("find.reserveDesc")}</p>
              {!user ? (
                <Button onClick={() => { setReserving(null); openAuth("signin"); }} className="w-full">
                  {t("auth.signIn")}
                </Button>
              ) : (
                <Button
                  onClick={() => void reserve(reserving, 1)}
                  disabled={reserveBusy}
                  className="w-full"
                >
                  {reserveBusy && <Loader2 className="h-4 w-4 animate-spin" />}
                  {t("common.confirm")}
                </Button>
              )}
              {reserveError && <p className="text-sm text-destructive">{reserveError}</p>}
              {reservedOk && <p className="text-sm text-emerald-700">{t("find.reserved")}</p>}
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* report incorrect information (pharmacy) */}
      <ReportDialog
        entityType="PHARMACY"
        entityId={reporting?.id ?? ""}
        entityName={reporting ? (locale === "bn" && reporting.nameBangla ? reporting.nameBangla : reporting.name) : ""}
        open={Boolean(reporting)}
        onOpenChange={(o) => (o ? undefined : setReporting(null))}
      />
    </>
  );
}
