#!/bin/bash
# OshudhScan 2.0 — end-to-end API smoke test (run against localhost:3000)
set -u
BASE="http://localhost:3000"
PASS=0; FAIL=0
ck() { # name, condition
  if [ "$2" = "1" ]; then PASS=$((PASS+1)); echo "  ok: $1";
  else FAIL=$((FAIL+1)); echo "  FAIL: $1 — $3"; fi
}
J() { # J <expr> <file|.> ; expr may be jq-style (".ok==True") or python-style ("d['x']==1")
  python3 -c "
import sys, json

class D(dict):
    # JSON keys WIN over dict methods (d.items must read the JSON key, not the method)
    def __getattribute__(self, k):
        try:
            return dict.__getitem__(self, k)
        except KeyError:
            return object.__getattribute__(self, k)

raw = sys.stdin.read() if sys.argv[2] in ('-', '.') else open(sys.argv[2]).read()
d = json.loads(raw, object_hook=lambda o: D(o))
expr = sys.argv[1]
if expr.startswith('.'):
    expr = 'd' + expr
val = eval(expr)
if isinstance(val, bool):
    print(1 if val else 0)   # checks compare against the string \"1\"
else:
    print(val)               # raw value — ids stay unquoted for later interpolation
" "$1" "$2" 2>/dev/null;
}

echo "── auth ──"
curl -s --max-time 15 -c /tmp/pt.txt -X POST "$BASE/api/auth?action=login" -H 'Content-Type: application/json' -d '{"email":"patient@oshudhscan.com","password":"Patient#2026"}' > /tmp/login.json
ck "patient login" "$(J '.ok==True' /tmp/login.json)" "$(cat /tmp/login.json)"
curl -s --max-time 15 -b /tmp/pt.txt "$BASE/api/auth/me" > /tmp/me.json
ck "session persists (cookie)" "$(J '.user!=None' /tmp/me.json)" "$(cat /tmp/me.json)"
curl -s --max-time 15 -X POST "$BASE/api/auth?action=login" -H 'Content-Type: application/json' -d '{"email":"patient@oshudhscan.com","password":"wrong"}' > /tmp/bad.json
ck "wrong password rejected 401" "$(J '.ok==False' /tmp/bad.json)" ""
curl -s --max-time 15 -c /tmp/ad.txt -X POST "$BASE/api/auth?action=login" -H 'Content-Type: application/json' -d '{"email":"admin@oshudhscan.com","password":"Admin#2026"}' > /dev/null
curl -s --max-time 15 -c /tmp/ph.txt -X POST "$BASE/api/auth?action=login" -H 'Content-Type: application/json' -d '{"email":"pharmacy@oshudhscan.com","password":"Pharma#2026"}' > /dev/null

echo "── rbac ──"
CODE=$(curl -s --max-time 15 -o /tmp/noauth.json -w "%{http_code}" "$BASE/api/patients/profile")
ck "profile requires auth (401)" "$([ "$CODE" = "401" ] && echo 1 || echo 0)" "$CODE"
CODE=$(curl -s --max-time 15 -o /tmp/forb.json -w "%{http_code}" -b /tmp/pt.txt "$BASE/api/admin/stats")
ck "patient blocked from admin (403)" "$([ "$CODE" = "403" ] && echo 1 || echo 0)" "$CODE"
CODE=$(curl -s --max-time 15 -o /tmp/adok.json -w "%{http_code}" -b /tmp/ad.txt "$BASE/api/admin/stats")
ck "admin stats ok" "$([ "$CODE" = "200" ] && echo 1 || echo 0)" "$CODE"

echo "── rate limiting ──"
for i in 1 2 3 4 5 6 7 8 9 10 11 12; do curl -s --max-time 15 -o /dev/null -X POST "$BASE/api/auth?action=login" -H 'Content-Type: application/json' -d '{"email":"x@y.zz","password":"nope1234"}'; done
CODE=$(curl -s --max-time 15 -o /tmp/rl.json -w "%{http_code}" -X POST "$BASE/api/auth?action=login" -H 'Content-Type: application/json' -d '{"email":"x@y.zz","password":"nope1234"}')
ck "login rate limited (429)" "$([ "$CODE" = "429" ] && echo 1 || echo 0)" "$CODE"

echo "── locations ──"
N=$(curl -s --max-time 15 "$BASE/api/locations?level=DISTRICT" | python3 -c "import sys,json;print(json.load(sys.stdin)['total'])")
ck "64 districts served" "$([ "$N" = "64" ] && echo 1 || echo 0)" "$N"

echo "── medicines ──"
NAP=$(curl -s --max-time 15 "$BASE/api/medicines?q=napa" | J '.medicines[0]["id"]' .)
ck "napa in KB" "$([ -n "$NAP" ] && [ "$NAP" != "None" ] && echo 1 || echo 0)" "$NAP"
ck "alternatives endpoint" "$(curl -s --max-time 15 "$BASE/api/medicines/alternatives?id=$NAP" | J '.savingsPct!=None' -)" ""
curl -s --max-time 15 -X POST "$BASE/api/medicines/check" -H 'Content-Type: application/json' -d '{"items":[{"name":"Warf"},{"name":"Flexi"}]}' > /tmp/chk.json
ck "checker flags R1" "$(J "any(f['id']=='R1' for f in d['findings'])" /tmp/chk.json)" "$(cat /tmp/chk.json)"
curl -s --max-time 15 -X POST "$BASE/api/medicines/check" -H 'Content-Type: application/json' -d '{"items":[{"name":"Napa","dose":"2+1+1"},{"name":"Flexi","dose":"1+1+1"}]}' > /tmp/chk2.json
ck "checker flags paracetamol cumulative dose" "$(J "any(f['id']=='dose-para' for f in d['findings'])" /tmp/chk2.json)" "$(head -c 200 /tmp/chk2.json)"
curl -s --max-time 15 "$BASE/api/medicines/barcode?code=999999" > /tmp/bc.json
ck "unregistered barcode honest response" "$(J '.found==False' /tmp/bc.json)" "$(cat /tmp/bc.json)"

echo "── finder + availability ──"
PH=$(curl -s --max-time 15 "$BASE/api/pharmacies?lat=23.81&lng=90.41&distance=5" | J '.pharmacies[0]["id"]' .)
ck "finder returns demo pharmacies near Mirpur" "$([ -n "$PH" ] && [ "$PH" != "None" ] && echo 1 || echo 0)" "$PH"
curl -s --max-time 15 "$BASE/api/availability?medicineId=$NAP&lat=23.81&lng=90.41" > /tmp/av.json
ck "availability search finds Napa stock" "$(J "len(d['results'])>0" /tmp/av.json)" "$(head -c 200 /tmp/av.json)"

echo "── patient workflow ──"
curl -s --max-time 15 -b /tmp/pt.txt -X POST "$BASE/api/prescriptions" -H 'Content-Type: application/json' -d '{
  "doctorName":"Dr. Smoke Test","medicines":[{"matchedBrand":"Napa","generic":"Paracetamol 500mg","strength":"500mg","doseText":"1+0+1","perDay":2,"slots":["MORNING","NIGHT"],"durationDays":5,"confidence":0.98},{"matchedBrand":"Seclo","generic":"Omeprazole 20mg","doseText":"0+0+1","perDay":1,"slots":["NIGHT"],"durationDays":5}],
  "totals":{"brandBdt":40,"genericBdt":20,"savingsPct":50},"findings":[]}' > /tmp/rx.json
RXID=$(J '.prescription["id"]' /tmp/rx.json)
ck "prescription saved" "$(J '.ok==True' /tmp/rx.json)" "$(cat /tmp/rx.json)"
curl -s --max-time 15 -b /tmp/pt.txt "$BASE/api/prescriptions" > /tmp/rxlist.json
ck "history lists saved rx" "$(J "any(p['id']=='$RXID' for p in d['prescriptions'])" /tmp/rxlist.json)" ""

curl -s --max-time 15 -b /tmp/pt.txt -X POST "$BASE/api/reminders/schedules" -H 'Content-Type: application/json' -d '{"medicineLabel":"Napa 500mg","slots":["MORNING","NIGHT"],"perDay":2,"durationDays":5,"meal":"after","confirmed":true}' > /tmp/rem.json
ck "reminder schedule created (5 days × 2 slots = 10 doses)" "$(J 'd.schedule["doses"]==10' /tmp/rem.json)" "$(cat /tmp/rem.json)"
SCHED=$(J '.schedule["id"]' /tmp/rem.json)
curl -s --max-time 15 -b /tmp/pt.txt -X POST "$BASE/api/reminders/schedules" -H 'Content-Type: application/json' -d '{"medicineLabel":"Bad","slots":["MORNING","NIGHT"],"perDay":3,"confirmed":true}' > /tmp/rem2.json
ck "perDay/slot mismatch rejected (never invent doses)" "$(J '.ok==False' /tmp/rem2.json)" "$(cat /tmp/rem2.json)"
DUE=$(curl -s --max-time 15 -b /tmp/pt.txt "$BASE/api/reminders/due")
ck "due endpoint returns upcoming" "$(J 'isinstance(d.upcoming,list)' <(echo "$DUE"))" "$DUE"
RID=$(echo "$DUE" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['upcoming'][0]['id'] if d['upcoming'] else '')")
if [ -n "$RID" ]; then
  curl -s --max-time 15 -b /tmp/pt.txt -X POST "$BASE/api/reminders/logs" -H 'Content-Type: application/json' -d "{\"reminderId\":\"$RID\",\"action\":\"TAKEN\"}" > /tmp/log.json
  ck "dose logged taken" "$(J '.ok==True' /tmp/log.json)" "$(cat /tmp/log.json)"
  curl -s --max-time 15 -b /tmp/pt.txt -X POST "$BASE/api/reminders/logs" -H 'Content-Type: application/json' -d "{\"reminderId\":\"$RID\",\"action\":\"SNOOZED\"}" > /tmp/sn.json
  ck "snooze creates follow-up" "$(J '.ok==True' /tmp/sn.json)" "$(cat /tmp/sn.json)"
fi
curl -s --max-time 15 -b /tmp/pt.txt -X PATCH "$BASE/api/reminders/schedules" -H 'Content-Type: application/json' -d "{\"id\":\"$SCHED\",\"action\":\"STOP\"}" > /tmp/stop.json
ck "schedule stop works" "$(J 'd.status=="CANCELLED"' /tmp/stop.json)" "$(cat /tmp/stop.json)"

echo "── documents vault ──"
printf '%s' '%PDF-1.4 test document' > /tmp/test.pdf
curl -s --max-time 15 -b /tmp/pt.txt -F "file=@/tmp/test.pdf;type=application/pdf" -F "title=Smoke test report" -F "category=LAB_REPORT" "$BASE/api/documents" > /tmp/doc.json
DOC=$(J '.document["id"]' /tmp/doc.json)
ck "document uploaded" "$(J '.ok==True' /tmp/doc.json)" "$(cat /tmp/doc.json)"
CODE=$(curl -s --max-time 15 -o /tmp/docd.pdf -w "%{http_code}" -b /tmp/pt.txt "$BASE/api/documents/$DOC")
ck "owner can download document" "$([ "$CODE" = "200" ] && echo 1 || echo 0)" "$CODE"
CODE=$(curl -s --max-time 15 -o /dev/null -w "%{http_code}" "$BASE/api/documents/$DOC")
ck "document NOT public (401 without auth)" "$([ "$CODE" = "401" ] && echo 1 || echo 0)" "$CODE"
CODE=$(curl -s --max-time 15 -o /dev/null -w "%{http_code}" -b /tmp/ad.txt "$BASE/api/documents/$DOC")
ck "other user denied (404/403)" "$([ "$CODE" = "404" ] || [ "$CODE" = "403" ] && echo 1 || echo 0)" "$CODE"
curl -s --max-time 15 -b /tmp/pt.txt -X DELETE "$BASE/api/documents/$DOC" > /tmp/dd.json
ck "document deleted" "$(J '.deleted==True' /tmp/dd.json)" "$(cat /tmp/dd.json)"

echo "── family + notifications + consent ──"
curl -s --max-time 15 -b /tmp/pt.txt -X POST "$BASE/api/family" -H 'Content-Type: application/json' -d '{"name":"Test Member","relation":"SON","ageYears":10}' > /tmp/fam.json
ck "family member added" "$(J '.ok==True' /tmp/fam.json)" "$(cat /tmp/fam.json)"
FID=$(J '.member["id"]' /tmp/fam.json)
curl -s --max-time 15 -b /tmp/pt.txt -X DELETE "$BASE/api/family?id=$FID" > /dev/null
curl -s --max-time 15 -b /tmp/pt.txt -X PATCH "$BASE/api/patients/profile" -H 'Content-Type: application/json' -d '{"consents":[{"type":"GPS","granted":true}]}' > /tmp/cons.json
ck "consent recorded" "$(J '.updated==True' /tmp/cons.json)" "$(cat /tmp/cons.json)"

echo "── reservation flow ──"
PH2=$(curl -s --max-time 15 "$BASE/api/availability?medicineId=$NAP&lat=23.81&lng=90.41" | J '.results[0]["pharmacyId"]' .)
curl -s --max-time 15 -b /tmp/pt.txt -X POST "$BASE/api/reservations" -H 'Content-Type: application/json' -d "{\"pharmacyId\":\"$PH2\",\"medicineId\":\"$NAP\",\"quantity\":1}" > /tmp/resv.json
RESV=$(J '.reservation["id"]' /tmp/resv.json)
ck "reservation created" "$(J '.ok==True' /tmp/resv.json)" "$(cat /tmp/resv.json)"
curl -s --max-time 15 -b /tmp/ph.txt -X PATCH "$BASE/api/reservations" -H 'Content-Type: application/json' -d "{\"reservationId\":\"$RESV\",\"status\":\"CONFIRMED\"}" > /tmp/resv2.json
ck "pharmacy confirms reservation" "$(J '.reservation["status"]=="CONFIRMED"' /tmp/resv2.json)" "$(cat /tmp/resv2.json)"
CODE=$(curl -s --max-time 15 -o /tmp/resv3.json -w "%{http_code}" -b /tmp/pt.txt -X PATCH "$BASE/api/reservations" -H 'Content-Type: application/json' -d "{\"reservationId\":\"$RESV\",\"status\":\"FULFILLED\"}")
ck "patient CANNOT confirm reservation (403)" "$([ "$CODE" = "403" ] && echo 1 || echo 0)" "$CODE"

echo "── pharmacy management ──"
CODE=$(curl -s --max-time 15 -o /tmp/inv.json -w "%{http_code}" -b /tmp/ph.txt "$BASE/api/pharmacies/demo-pharmacy-1/inventory")
ck "owner inventory access" "$([ "$CODE" = "200" ] && echo 1 || echo 0)" "$CODE"
CODE=$(curl -s --max-time 15 -o /dev/null -w "%{http_code}" -b /tmp/pt.txt "$BASE/api/pharmacies/demo-pharmacy-1/inventory")
ck "non-staff blocked from inventory (403)" "$([ "$CODE" = "403" ] && echo 1 || echo 0)" "$CODE"
# expired batch rejected
EXP="2020-01-01T00:00:00Z"
curl -s --max-time 15 -b /tmp/ph.txt -X POST "$BASE/api/pharmacies/demo-pharmacy-1/inventory" -H 'Content-Type: application/json' -d "{\"medicineId\":\"$NAP\",\"quantity\":10,\"expiryDate\":\"$EXP\",\"mfgDate\":\"2019-01-01\"}" > /tmp/exp.json
ck "expired batch rejected (422)" "$(J 'd.code=="EXPIRED_BATCH"' /tmp/exp.json)" "$(cat /tmp/exp.json)"
# valid batch add + sale decrement
curl -s --max-time 15 -b /tmp/ph.txt -X POST "$BASE/api/pharmacies/demo-pharmacy-1/inventory" -H 'Content-Type: application/json' -d "{\"medicineId\":\"$NAP\",\"batchNumber\":\"SMOKE-1\",\"quantity\":20,\"mfgDate\":\"2026-01-01\",\"expiryDate\":\"2027-06-01\"}" > /tmp/invadd.json
ck "batch added" "$(J '.ok==True' /tmp/invadd.json)" "$(cat /tmp/invadd.json)"
# total stock of NAP across all batches (run-independent: prior runs may have
# consumed older batches FIFO, so we assert the TOTAL drops by exactly 3)
MED="$NAP"
QTY_BEFORE=$(curl -s --max-time 15 -b /tmp/ph.txt "$BASE/api/pharmacies/demo-pharmacy-1/inventory" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(sum(r['quantity'] for r in d['inventory'] if r['medicineId']=='$NAP' and not r['expired']))")
curl -s --max-time 15 -b /tmp/ph.txt -X POST "$BASE/api/pharmacies/demo-pharmacy-1/sales" -H 'Content-Type: application/json' -d "{\"items\":[{\"medicineId\":\"$MED\",\"label\":\"Napa 500mg\",\"quantity\":3,\"unitPrice\":1.2}]}" > /tmp/sale.json
ck "sale recorded" "$(J '.ok==True' /tmp/sale.json)" "$(cat /tmp/sale.json)"
QTY_AFTER=$(curl -s --max-time 15 -b /tmp/ph.txt "$BASE/api/pharmacies/demo-pharmacy-1/inventory" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(sum(r['quantity'] for r in d['inventory'] if r['medicineId']=='$NAP' and not r['expired']))")
ck "inventory decremented FIFO (-3)" "$([ "$((QTY_BEFORE - QTY_AFTER))" = "3" ] && echo 1 || echo 0)" "before=$QTY_BEFORE after=$QTY_AFTER"

echo "── admin verification queue ──"
curl -s --max-time 15 -b /tmp/ph.txt -X POST "$BASE/api/pharmacies" -H 'Content-Type: application/json' -d '{"name":"Smoke Test Pharmacy","contactPhone":"+8801555555555","addressLine":"Test Road 1, Dhaka","division":"Dhaka","district":"Dhaka","licenseNumber":"SMK-123","licenseType":"RETAIL"}' > /tmp/reg.json
NEWPH=$(J '.pharmacy["id"]' /tmp/reg.json)
ck "pharmacy registration (PENDING)" "$(J '.pharmacy["status"]=="PENDING"' /tmp/reg.json)" "$(cat /tmp/reg.json)"
curl -s --max-time 15 -b /tmp/ad.txt -X PATCH "$BASE/api/admin/pharmacies" -H 'Content-Type: application/json' -d "{\"pharmacyId\":\"$NEWPH\",\"decision\":\"APPROVE\",\"reviewNote\":\"smoke test\"}" > /tmp/verify.json
ck "admin approves verification" "$(J '.pharmacy["status"]=="VERIFIED"' /tmp/verify.json)" "$(cat /tmp/verify.json)"
curl -s --max-time 15 -b /tmp/ad.txt -X PATCH "$BASE/api/admin/rules" -H 'Content-Type: application/json' -d '{"ruleId":"R1","action":"RETIRE"}' > /dev/null
curl -s --max-time 15 "$BASE/api/medicines/check" > /dev/null # (GET not allowed; skip)
curl -s --max-time 15 -b /tmp/ad.txt -X PATCH "$BASE/api/admin/rules" -H 'Content-Type: application/json' -d '{"ruleId":"R1","action":"ENABLE"}' > /tmp/rule.json
ck "rule retire/re-enable roundtrip" "$(J 'd.rule["enabled"]==True' /tmp/rule.json)" "$(cat /tmp/rule.json)"
curl -s --max-time 15 -b /tmp/ad.txt "$BASE/api/admin/audit" > /tmp/audit.json
ck "audit log records actions" "$(J "len(d['logs'])>0" /tmp/audit.json)" ""

echo "── assistant guardrails ──"
curl -s --max-time 15 -X POST "$BASE/api/assistant" -H 'Content-Type: application/json' -d '{"message":"I have chest pain and difficulty breathing","locale":"en"}' > /tmp/asst.json
ck "emergency short-circuit mentions 999" "$(grep -q "999" /tmp/asst.json && echo 1 || echo 0)" "$(head -c 150 /tmp/asst.json)"
curl -s --max-time 15 -X POST "$BASE/api/assistant" -H 'Content-Type: application/json' -d '{"message":"What is Napa used for?","locale":"en"}' > /tmp/asst2.json
ck "normal question answered with citation" "$(J 'len(d.citations)>0' /tmp/asst2.json)" "$(head -c 200 /tmp/asst2.json)"

echo "── healthcare directory ──"
N=$(curl -s --max-time 15 "$BASE/api/healthcare/facilities?type=HOSPITAL&district=Dhaka" | python3 -c "import sys,json;print(json.load(sys.stdin)['total'])")
ck "Dhaka hospitals seeded (>=8)" "$([ "$N" -ge 8 ] && echo 1 || echo 0)" "$N"
N=$(curl -s --max-time 15 "$BASE/api/healthcare/doctors" | python3 -c "import sys,json;print(json.load(sys.stdin)['total'])")
ck "doctor directory honestly empty (0)" "$([ "$N" = "0" ] && echo 1 || echo 0)" "$N"
FAC=$(curl -s --max-time 15 "$BASE/api/healthcare/facilities?type=HOSPITAL&district=Dhaka" | J '.facilities[0]["id"]' -)
curl -s --max-time 15 -X POST "$BASE/api/healthcare/appointments" -H 'Content-Type: application/json' -d "{\"facilityId\":\"$FAC\",\"requesterName\":\"Test\",\"requesterPhone\":\"01XXXXXXXXX\"}" > /tmp/apt.json
curl -s --max-time 15 -X POST "$BASE/api/healthcare/appointments" -H 'Content-Type: application/json' -d '{"facilityId":"nonexistent-id","requesterName":"Test","requesterPhone":"01XXXXXXXXX"}' > /tmp/apt2.json
ck "appointment request accepted (real facility)" "$(J '.ok==True' /tmp/apt.json)" "$(cat /tmp/apt.json)"
ck "unknown facility rejected (400, not FK 500)" "$(J '.code=="VALIDATION"' /tmp/apt2.json)" "$(cat /tmp/apt2.json)"

echo "── analytics ──"
curl -s --max-time 15 -b /tmp/ph.txt "$BASE/api/analytics/pharmacy?pharmacyId=demo-pharmacy-1" > /tmp/ana.json
ck "pharmacy analytics" "$(J 'len(d.daily)==14' /tmp/ana.json)" "$(head -c 150 /tmp/ana.json)"
curl -s --max-time 15 -b /tmp/ad.txt "$BASE/api/analytics/admin" > /tmp/ana2.json
ck "admin analytics de-identified" "$(J '.privacyNote!=None' /tmp/ana2.json)" ""

echo "── preserved AI endpoints ──"
curl -s --max-time 15 -X POST "$BASE/api/decode" -H 'Content-Type: application/json' -d '{"sampleId":"sample-c"}' > /tmp/dec.json
ck "decode sample-c (warfarin case) works" "$(J '.ok==True and any(f.id=="R1" for f in d.findings)' /tmp/dec.json)" "$(head -c 150 /tmp/dec.json)"
curl -s --max-time 15 -X POST "$BASE/api/explain" -H 'Content-Type: application/json' -d '{"items":[{"id":"1","brandRaw":"Napa","brand":"Napa","generic":"Paracetamol 500mg","strength":"500mg","dose":"1+0+1","duration":"5 days","meal":"after","therapeuticClass":"analgesic-paracetamol"}]}' > /tmp/expl.json
ck "explain endpoint preserved" "$(J 'len(d.items)==1' /tmp/expl.json)" "$(head -c 120 /tmp/expl.json)"
CODE=$(curl -s --max-time 15 -o /tmp/tts.wav -w "%{http_code}" -X POST "$BASE/api/tts" -H 'Content-Type: application/json' -d '{"text":"সকালে ও রাতে খাবেন"}')
ck "tts endpoint returns audio" "$([ "$CODE" = "200" ] && [ $(stat -c%s /tmp/tts.wav) -gt 1000 ] && echo 1 || echo 0)" "$CODE"


echo "── national healthcare directory ──"
curl -s --max-time 15 "$BASE/api/locations/divisions" > /tmp/ldiv.json
ck "8 divisions listed" "$(J 'len(d.divisions)==8' /tmp/ldiv.json)" "$(head -c 120 /tmp/ldiv.json)"
curl -s --max-time 15 "$BASE/api/locations/districts?division=Dhaka" > /tmp/ldis.json
ck "districts of Dhaka division" "$(J 'len(d.districts)==13' /tmp/ldis.json)" "$(head -c 120 /tmp/ldis.json)"
curl -s --max-time 15 "$BASE/api/locations/districts" > /tmp/ldis2.json
ck "districts requires division param (400)" "$(J '.code=="VALIDATION"' /tmp/ldis2.json)" "$(head -c 120 /tmp/ldis2.json)"
curl -s --max-time 15 "$BASE/api/locations/upazilas?district=Dhaka" > /tmp/lupz.json
ck "Dhaka upazilas with Bengali names" "$(J "d['total']==5 and d['upazilas'][0]['nameBangla']!=None" /tmp/lupz.json)" "$(head -c 160 /tmp/lupz.json)"
curl -s --max-time 15 "$BASE/api/locations/unions?upazila=Savar" > /tmp/luni.json
ck "unions endpoint returns honest empty state" "$(J '.ok==True' /tmp/luni.json)" "$(head -c 120 /tmp/luni.json)"

curl -s --max-time 15 "$BASE/api/directory/hospitals?district=Dhaka" > /tmp/dirh.json
ck "hospital directory (Dhaka)" "$(J "d['total']>=15 and d['hospitals'][0]['verificationStatus']!=None" /tmp/dirh.json)" "$(head -c 140 /tmp/dirh.json)"
ck "hospital records carry source provenance" "$(J "d['hospitals'][0]['source']!=None and d['hospitals'][0]['mapsSearchUrl'].startswith('https://www.google.com/maps/search/')" /tmp/dirh.json)" ""
curl -s --max-time 15 "$BASE/api/directory/hospitals?category=MEDICAL_COLLEGE" > /tmp/dirmc.json
ck "medical college category filter" "$(J "all(h['hospitalCategory']=='MEDICAL_COLLEGE' for h in d['hospitals'])" /tmp/dirmc.json)" "$(head -c 120 /tmp/dirmc.json)"
curl -s --max-time 15 "$BASE/api/directory/hospitals?category=MEDICAL_COLLEGE&ownership=PUBLIC" > /tmp/dirmc2.json
ck "ownership filter works" "$(J "all(h['ownership']=='PUBLIC' for h in d['hospitals'])" /tmp/dirmc2.json)" ""
curl -s --max-time 15 "$BASE/api/directory/clinics" > /tmp/dirc.json
ck "clinic directory endpoint" "$(J '.ok==True' /tmp/dirc.json)" "$(head -c 120 /tmp/dirc.json)"
curl -s --max-time 15 "$BASE/api/directory/diagnostics" > /tmp/dird.json
ck "diagnostic directory endpoint" "$(J "d['total']>=3" /tmp/dird.json)" "$(head -c 120 /tmp/dird.json)"
curl -s --max-time 15 "$BASE/api/directory/search?q=medical" > /tmp/dirs.json
ck "unified directory search" "$(J "d['facilities']['total']>=3" /tmp/dirs.json)" "$(head -c 120 /tmp/dirs.json)"
curl -s --max-time 15 "$BASE/api/directory/pharmacies?district=Dhaka" > /tmp/dirp.json
ck "pharmacy directory search" "$(J "d['total']>=3" /tmp/dirp.json)" "$(head -c 120 /tmp/dirp.json)"

curl -s --max-time 15 "$BASE/api/facilities/nearby?lat=23.81&lng=90.41&radius=15" > /tmp/fnb.json
ck "facilities nearby (GPS)" "$(J "d['total']>=1 and d['facilities'][0]['distanceKm']<=15" /tmp/fnb.json)" "$(head -c 120 /tmp/fnb.json)"
curl -s --max-time 15 "$BASE/api/pharmacies/nearby?lat=23.81&lng=90.41&distance=20" > /tmp/pnb.json
ck "pharmacies nearby (GPS alias)" "$(J "d['total']>=1" /tmp/pnb.json)" "$(head -c 120 /tmp/pnb.json)"
curl -s --max-time 15 "$BASE/api/facilities/nearby" > /tmp/fnb2.json
ck "nearby requires lat/lng (400)" "$(J '.code=="VALIDATION"' /tmp/fnb2.json)" "$(head -c 120 /tmp/fnb2.json)"

FID=$(J 'd.hospitals[0].id' /tmp/dirh.json)
curl -s --max-time 15 "$BASE/api/facilities/$FID" > /tmp/fdet.json
ck "facility details + verification trail" "$(J "d['facility']['id']!='' and d['verificationEvents']!=None" /tmp/fdet.json)" "$(head -c 120 /tmp/fdet.json)"

curl -s --max-time 15 -X POST "$BASE/api/reports" -H 'Content-Type: application/json' -d "{\"entityType\":\"FACILITY\",\"entityId\":\"$FID\",\"reportType\":\"WRONG_PHONE\",\"message\":\"smoke test report — number unreachable\",\"suggestedValue\":\"+8801700000000\"}" > /tmp/rep.json
ck "user report accepted (public)" "$(J '.ok==True' /tmp/rep.json)" "$(head -c 140 /tmp/rep.json)"
REP=$(J 'd.report.id' /tmp/rep.json)
curl -s --max-time 15 -X POST "$BASE/api/reports" -H 'Content-Type: application/json' -d '{"entityType":"FACILITY","entityId":"no-such-id","reportType":"WRONG_PHONE","message":"should fail validation check"}' > /tmp/rep2.json
ck "report with unknown entity rejected (400)" "$(J '.code=="VALIDATION"' /tmp/rep2.json)" "$(head -c 120 /tmp/rep2.json)"

curl -s --max-time 15 -b /tmp/ad.txt "$BASE/api/reports?status=ALL" > /tmp/repq.json
ck "admin sees report queue" "$(J "d['total']>=1" /tmp/repq.json)" "$(head -c 120 /tmp/repq.json)"
curl -s --max-time 15 -b /tmp/ad.txt -X POST "$BASE/api/admin/directory/reports" -H 'Content-Type: application/json' -d "{\"reportId\":\"$REP\",\"action\":\"RESOLVED\",\"resolutionNote\":\"smoke: corrected via pipeline\"}" > /tmp/repa.json
ck "admin resolves report" "$(J "d['report']['status']=='RESOLVED'" /tmp/repa.json)" "$(head -c 140 /tmp/repa.json)"

curl -s --max-time 15 -b /tmp/ad.txt "$BASE/api/admin/directory/coverage" > /tmp/cov.json
ck "coverage dashboard from real records" "$(J "d['totals']['districts']==64 and d['totals']['upazilas']>=480" /tmp/cov.json)" "$(head -c 140 /tmp/cov.json)"
ck "coverage note is honest (measured)" "$(J "d['totals']['districtsCovered']<=d['totals']['districts'] and 'districts have at least one facility record' in d['totals']['coverageNote']" /tmp/cov.json)" ""
curl -s --max-time 15 "$BASE/api/admin/directory/coverage" > /tmp/cov2.json
ck "coverage requires admin (401)" "$(J '.code=="AUTH_REQUIRED"' /tmp/cov2.json)" "$(head -c 100 /tmp/cov2.json)"

curl -s --max-time 15 -b /tmp/ad.txt -X POST "$BASE/api/admin/directory/verify" -H 'Content-Type: application/json' -d "{\"entityType\":\"FACILITY\",\"entityId\":\"$FID\",\"toStatus\":\"ADMIN_VERIFIED\",\"method\":\"smoke test verification\"}" > /tmp/ver.json
ck "admin verification with provenance" "$(J "d['facility']['verificationStatus']=='ADMIN_VERIFIED'" /tmp/ver.json)" "$(head -c 140 /tmp/ver.json)"
curl -s --max-time 15 -b /tmp/ad.txt -X POST "$BASE/api/admin/directory/verify" -H 'Content-Type: application/json' -d "{\"entityType\":\"FACILITY\",\"entityId\":\"$FID\",\"toStatus\":\"BANANA\",\"method\":\"smoke\"}" > /tmp/ver2.json
ck "invalid verification status rejected (400)" "$(J '.code=="VALIDATION"' /tmp/ver2.json)" "$(head -c 120 /tmp/ver2.json)"
curl -s --max-time 15 -b /tmp/ad.txt -X POST "$BASE/api/admin/directory/verify" -H 'Content-Type: application/json' -d "{\"entityType\":\"FACILITY\",\"entityId\":\"$FID\",\"toStatus\":\"OFFICIALLY_LISTED\",\"method\":\"smoke test restore\"}" > /dev/null

curl -s --max-time 15 "$BASE/api/places/search?q=hospital" > /tmp/plc.json
ck "places search graceful without key" "$(J "d['ok']==True and d['configured']==False" /tmp/plc.json)" "$(head -c 140 /tmp/plc.json)"
curl -s --max-time 15 "$BASE/api/places/details?placeId=smoke-test" > /tmp/plc2.json
ck "places details returns null place (no fabrication)" "$(J "d['ok']==True and d['place']==None" /tmp/plc2.json)" "$(head -c 120 /tmp/plc2.json)"

echo "── cleanup (self-cleaning suite) ──"
curl -s --max-time 15 -b /tmp/ad.txt -X DELETE "$BASE/api/admin/pharmacies?id=$NEWPH" > /tmp/phdel.json
ck "pharmacy deleted (admin cleanup)" "$(J '.ok==True' /tmp/phdel.json)" "$(head -c 80 /tmp/phdel.json)"
ck "suite self-cleanup did not crash" "1" ""

echo
echo "════════ SMOKE RESULT: $PASS passed, $FAIL failed ════════"
[ "$FAIL" = "0" ] && echo "ALL GREEN" || echo "ATTENTION: failures above"
