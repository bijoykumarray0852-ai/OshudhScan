// OshudhScan 2.0 unit tests — run with: bun test
import { describe, expect, test } from "bun:test";
import { matchBrand, parseDose, parseDuration, normalizeBrand } from "../src/lib/match";
import { runSafetyEngine, worstSeverity } from "../src/lib/interactions";
import { expandSchedule, isMissed, isCourseComplete, refillNeeded, adherencePct } from "../src/lib/reminders";
import { haversineKm, formatDistance, stockStatus, isExpiredBatch, osmEmbedUrl } from "../src/lib/geo";
import { isOpenNow } from "../src/lib/hours";
import { translate, isLocale } from "../src/lib/i18n";
import { en } from "../src/lib/i18n/en";
import { bn } from "../src/lib/i18n/bn";
import { templateExplain, toBanglaDigits } from "../src/lib/bangla";
import { DISTRICTS, DIVISIONS } from "../src/lib/data/locations";
import { EMERGENCY_SERVICES } from "../src/lib/data/emergency";
import type { MatchedMedicine } from "../src/lib/types";

function med(partial: Partial<MatchedMedicine>): MatchedMedicine {
  return {
    brandRaw: partial.brand ?? "x", brand: null, manufacturer: null, generic: null,
    genericBangla: null, strength: null, form: null, therapeuticClass: null, dose: null,
    duration: null, meal: null, unitPriceBdt: null, genericUnitPriceBdt: null,
    matchMethod: "unmatched", confidence: 0, perDay: null, days: null, qty: null,
    lineTotalBdt: null, genericLineTotalBdt: null, ...partial,
  };
}

// ── brand resolver ────────────────────────────────────────────────────────────
describe("brand resolver", () => {
  test("exact match", () => {
    expect(matchBrand("Napa")?.drug.brand).toBe("Napa");
    expect(matchBrand("Napa")?.method).toBe("exact");
  });
  test("exact with strength suffix", () => {
    expect(matchBrand("seclo20")?.drug.brand).toBe("Seclo");
  });
  test("alias match (spelling variants hit the alias tier)", () => {
    expect(matchBrand("seklo")?.drug.brand).toBe("Seclo");
    expect(matchBrand("seklo")?.method).toBe("alias");
    expect(matchBrand("nappa")?.drug.brand).toBe("Napa");
    expect(matchBrand("warfarin")?.method).toBe("alias");
  });
  test("fuzzy OCR noise above 72% gate", () => {
    expect(matchBrand("Secio")?.drug.brand).toBe("Seclo");
    expect(matchBrand("Secio")?.method).toBe("fuzzy");
  });
  test("below-confidence noise returns null", () => {
    expect(matchBrand("Zzzqqq")).toBeNull();
    expect(matchBrand("Xyzqwr")).toBeNull();
  });
  test("generic molecule match", () => {
    expect(matchBrand("paracetamol 500")?.drug.id).toBe("napa");
  });
  test("dose parsing 1+0+1", () => {
    expect(parseDose("1+0+1")).toEqual({ perDay: 2, slots: [true, false, true] });
    expect(parseDose("1+1+1")?.perDay).toBe(3);
    expect(parseDose("abc")).toBeNull();
    expect(parseDose(null)).toBeNull();
  });
  test("duration parsing", () => {
    expect(parseDuration("5 days")).toBe(5);
    expect(parseDuration("1 month")).toBe(30);
    expect(parseDuration("2 weeks")).toBe(14);
    expect(parseDuration("as needed")).toBeNull();
  });
  test("normalizeBrand strips non-alphanumerics", () => {
    expect(normalizeBrand("Napa-500")).toBe("napa500");
  });
});

// ── safety engine ─────────────────────────────────────────────────────────────
describe("safety engine (deterministic)", () => {
  test("R1: warfarin + NSAID is MAJOR", () => {
    const findings = runSafetyEngine([
      med({ brand: "Warf", generic: "Warfarin 2mg", therapeuticClass: "anticoagulant", dose: "1+0+0", perDay: 1 }),
      med({ brand: "Flexi", generic: "Aceclofenac+Paracetamol 100/325mg", therapeuticClass: "nsaid-combo", dose: "1+1+1", perDay: 3 }),
    ]);
    const r1 = findings.find((f) => f.id === "R1");
    expect(r1).toBeDefined();
    expect(r1?.severity).toBe("major");
    expect(worstSeverity(findings)).toBe("major");
  });

  test("R3: two NSAIDs flagged", () => {
    const findings = runSafetyEngine([
      med({ brand: "Flexi", generic: "Aceclofenac+Paracetamol", therapeuticClass: "nsaid-combo", dose: "1+1+1", perDay: 3 }),
      med({ brand: "Aceclo", generic: "Aceclofenac 100mg", therapeuticClass: "nsaid", dose: "1+1+1", perDay: 2 }),
    ]);
    expect(findings.find((f) => f.id === "R3")).toBeDefined();
  });

  test("R4: PPI duplicate", () => {
    const findings = runSafetyEngine([
      med({ brand: "Seclo", generic: "Omeprazole 20mg", therapeuticClass: "ppi", dose: "0+0+1", perDay: 1 }),
      med({ brand: "Losectil", generic: "Omeprazole 20mg", therapeuticClass: "ppi", dose: "0+0+1", perDay: 1 }),
    ]);
    expect(findings.find((f) => f.id === "R4")).toBeDefined();
  });

  test("R8: metronidazole alcohol guard always fires", () => {
    const findings = runSafetyEngine([med({ brand: "Amodis", generic: "Metronidazole 400mg", therapeuticClass: "nitroimidazole", dose: "1+1+1", perDay: 3 })]);
    expect(findings.find((f) => f.id === "R8")?.severity).toBe("major");
  });

  test("P1: paracetamol >3g/day cumulative guard", () => {
    const findings = runSafetyEngine([
      med({ brand: "Napa", generic: "Paracetamol 500mg", therapeuticClass: "analgesic-paracetamol", dose: "1+1+1", perDay: 3 }),
      med({ brand: "Ace", generic: "Paracetamol 500mg", therapeuticClass: "analgesic-paracetamol", dose: "1+1+1", perDay: 3 }),
      med({ brand: "Comet", generic: "Paracetamol 500mg", therapeuticClass: "analgesic-paracetamol", dose: "1+1+1", perDay: 3 }),
    ]);
    expect(findings.find((f) => f.id === "dose-para")?.severity).toBe("major");
  });

  test("D1: same generic two brands", () => {
    const findings = runSafetyEngine([
      med({ brand: "Napa", generic: "Paracetamol 500mg", therapeuticClass: "analgesic-paracetamol", dose: "1+0+1", perDay: 2 }),
      med({ brand: "Ace", generic: "Paracetamol 500mg", therapeuticClass: "analgesic-paracetamol", dose: "1+0+1", perDay: 2 }),
    ]);
    expect(findings.find((f) => f.id.startsWith("dup-"))).toBeDefined();
  });

  test("unmatched line surfaces for pharmacist review", () => {
    const findings = runSafetyEngine([med({ brandRaw: "Zzzq", brand: null })]);
    expect(findings.find((f) => f.id.startsWith("unmatched-"))).toBeDefined();
  });

  test("governance: retired rule does not fire", () => {
    const meds = [
      med({ brand: "Warf", generic: "Warfarin 2mg", therapeuticClass: "anticoagulant", dose: "1+0+0", perDay: 1 }),
      med({ brand: "Flexi", generic: "Aceclofenac+Paracetamol", therapeuticClass: "nsaid-combo", dose: "1+1+1", perDay: 3 }),
    ];
    expect(runSafetyEngine(meds).some((f) => f.id === "R1")).toBe(true);
    expect(runSafetyEngine(meds, ["R1"]).some((f) => f.id === "R1")).toBe(false);
  });

  test("clean prescription produces no major findings", () => {
    const findings = runSafetyEngine([
      med({ brand: "Napa", generic: "Paracetamol 500mg", therapeuticClass: "analgesic-paracetamol", dose: "1+0+1", perDay: 2, days: 5 }),
      med({ brand: "Seclo", generic: "Omeprazole 20mg", therapeuticClass: "ppi", dose: "0+0+1", perDay: 1, days: 5 }),
      med({ brand: "Alatrol", generic: "Cetirizine 10mg", therapeuticClass: "antihistamine", dose: "0+0+1", perDay: 1, days: 5 }),
    ]);
    expect(findings.filter((f) => f.severity === "major")).toHaveLength(0);
  });
});

// ── reminders ─────────────────────────────────────────────────────────────────
describe("reminder scheduling", () => {
  test("expandSchedule creates dose rows for each slot and day", () => {
    const start = new Date(2026, 0, 1);
    const doses = expandSchedule(["MORNING", "NIGHT"], start, 5);
    expect(doses).toHaveLength(10);
    expect(doses[0].dueAt.getHours()).toBe(8);
    expect(doses[1].dueAt.getHours()).toBe(21);
  });
  test("custom times respected", () => {
    const start = new Date(2026, 0, 1);
    const doses = expandSchedule(["MORNING"], start, 2, { MORNING: "07:30" });
    expect(doses[0].dueAt.getHours()).toBe(7);
    expect(doses[0].dueAt.getMinutes()).toBe(30);
  });
  test("open-ended schedules cap at 30-day horizon", () => {
    const start = new Date(2026, 0, 1);
    const doses = expandSchedule(["MORNING"], start, null);
    expect(doses).toHaveLength(30);
  });
  test("missed dose detection after 3h threshold", () => {
    const now = new Date();
    const due = new Date(now.getTime() - 4 * 3600 * 1000);
    expect(isMissed(due, "PENDING", now)).toBe(true);
    expect(isMissed(due, "TAKEN", now)).toBe(false);
    expect(isMissed(new Date(now.getTime() - 30 * 60000), "PENDING", now)).toBe(false);
  });
  test("course completion requires all doses logged", () => {
    expect(isCourseComplete([{ status: "TAKEN" }, { status: "SKIPPED" }], new Date(Date.now() - 86400000))).toBe(true);
    expect(isCourseComplete([{ status: "TAKEN" }, { status: "PENDING" }], new Date(Date.now() - 86400000))).toBe(false);
  });
  test("refill needed at low stock or near course end", () => {
    expect(refillNeeded(2, 1, 10)).toBe(true);
    expect(refillNeeded(10, 8, 10)).toBe(true);
    expect(refillNeeded(10, 2, 10)).toBe(false);
    expect(refillNeeded(null, 9, 10)).toBe(false);
  });
  test("adherence percentage", () => {
    expect(adherencePct([{ status: "TAKEN" }, { status: "TAKEN" }, { status: "MISSED" }])).toBe(67);
    expect(adherencePct([{ status: "PENDING" }])).toBeNull();
  });
});

// ── geo + hours ───────────────────────────────────────────────────────────────
describe("geo & opening hours", () => {
  test("haversine: Mirpur to Savar ~13-15 km", () => {
    const km = haversineKm({ lat: 23.81, lng: 90.41 }, { lat: 23.858, lng: 90.2666 });
    expect(km).toBeGreaterThan(11);
    expect(km).toBeLessThan(17);
  });
  test("haversine: zero distance", () => {
    expect(haversineKm({ lat: 23.8, lng: 90.4 }, { lat: 23.8, lng: 90.4 })).toBeCloseTo(0, 5);
  });
  test("distance formatting", () => {
    expect(formatDistance(0.4)).toBe("400 m");
    expect(formatDistance(5.234)).toBe("5.2 km");
    expect(formatDistance(14)).toBe("14 km");
  });
  test("stock freshness statuses", () => {
    const now = new Date();
    expect(stockStatus(50, new Date(now.getTime() - 3600 * 1000), now)).toBe("IN_STOCK");
    expect(stockStatus(5, new Date(now.getTime() - 3600 * 1000), now)).toBe("LOW_STOCK");
    expect(stockStatus(0, new Date(now.getTime() - 3600 * 1000), now)).toBe("OUT_OF_STOCK");
    expect(stockStatus(50, new Date(now.getTime() - 96 * 3600 * 1000), now)).toBe("STALE");
    expect(stockStatus(null, null, now)).toBe("UNKNOWN");
  });
  test("expired batch detection", () => {
    expect(isExpiredBatch(new Date(2020, 0, 1))).toBe(true);
    expect(isExpiredBatch(new Date(2099, 0, 1))).toBe(false);
    expect(isExpiredBatch(null)).toBe(false);
  });
  test("open now evaluation with simple hours", () => {
    // 10:00 Dhaka time → construct a UTC instant that is 10:00 BD
    const bd10 = new Date(Date.UTC(2026, 0, 1, 4, 0)); // 10:00 UTC+6
    const hours = JSON.stringify({ open: "08:00", close: "22:00" });
    expect(isOpenNow(hours, false, bd10)).toBe(true);
    const bd23 = new Date(Date.UTC(2026, 0, 1, 17, 0)); // 23:00 BD
    expect(isOpenNow(hours, false, bd23)).toBe(false);
    expect(isOpenNow(hours, true, bd23)).toBe(true);
  });
  test("overnight hours (20:00–02:00) open at midnight", () => {
    const bd00 = new Date(Date.UTC(2026, 0, 1, 18, 0)); // 00:00 BD
    expect(isOpenNow(JSON.stringify({ open: "20:00", close: "02:00" }), false, bd00)).toBe(true);
  });
  test("OSM embed url includes marker and bbox", () => {
    const url = osmEmbedUrl({ lat: 23.81, lng: 90.41 }, 2);
    expect(url).toContain("openstreetmap.org/export/embed.html");
    expect(url).toContain("marker=23.81000,90.41000");
    expect(url).toContain("bbox=");
  });
});

// ── i18n ──────────────────────────────────────────────────────────────────────
describe("i18n", () => {
  test("bn and en dictionaries have identical key sets", () => {
    const enKeys = Object.keys(en).sort();
    const bnKeys = Object.keys(bn).sort();
    expect(bnKeys).toEqual(enKeys);
    expect(enKeys.length).toBeGreaterThan(180);
  });
  test("no empty translations", () => {
    for (const [k, v] of Object.entries(bn)) expect(String(v).length, k).toBeGreaterThan(0);
  });
  test("translate uses locale + variable interpolation", () => {
    expect(translate("en", "scan.recognized", { recognized: 3, total: 4 })).toContain("3 of 4");
    expect(translate("bn", "scan.recognized", { recognized: 3, total: 4 })).toContain("4 টির মধ্যে 3 টি");
  });
  test("fallback to English for missing bn key and unknown key", () => {
    expect(translate("bn", "nav.home")).toBe("হোম");
    expect(translate("en", "totally.unknown.key")).toBe("totally.unknown.key");
  });
  test("isLocale gate", () => {
    expect(isLocale("bn")).toBe(true);
    expect(isLocale("fr")).toBe(false);
  });
  test("medicine identity is never translated", () => {
    // brand/generic/strength keys must not appear in dictionaries
    expect(en["med.searchPlaceholder"]).toContain("Napa");
    expect(JSON.stringify(bn)).not.toContain("প্যারাসিটামল ৫০০ মিগ্রা"); // no strength translation
  });
});

// ── bangla templates ──────────────────────────────────────────────────────────
describe("bangla dose templates", () => {
  test("1+0+1 renders morning+night in Bangla", () => {
    const line = templateExplain([{ id: "1", brand: "Napa", brandRaw: "Napa", genericBangla: "প্যারাসিটামল", strength: "500mg", form: "tablet", dose: "1+0+1", duration: "5 days", meal: "after", therapeuticClass: "analgesic-paracetamol" }]);
    expect(line.items[0].bangla).toContain("সকালে ও রাতে");
    expect(line.items[0].bangla).toContain("খাবারের পরে");
    expect(line.items[0].bangla).toContain("৫ দিন");
    expect(line.items[0].note).toContain("২০০০ মিগ্রা");
  });
  test("bangla digit conversion", () => {
    expect(toBanglaDigits("500")).toBe("৫০০");
  });
});

// ── location dataset integrity ────────────────────────────────────────────────
describe("Bangladesh administrative dataset", () => {
  test("8 divisions", () => {
    expect(DIVISIONS).toHaveLength(8);
  });
  test("64 districts", () => {
    expect(DISTRICTS).toHaveLength(64);
  });
  test("every district belongs to a known division and has coords", () => {
    const names = new Set(DIVISIONS.map((d) => d.name));
    for (const d of DISTRICTS) {
      expect(names.has(d.division), d.name).toBe(true);
      expect(d.lat, d.name).toBeGreaterThan(20);
      expect(d.lat, d.name).toBeLessThan(27);
      expect(d.lng, d.name).toBeGreaterThan(88);
      expect(d.lng, d.name).toBeLessThan(93);
    }
  });
  test("no duplicate district names", () => {
    const set = new Set(DISTRICTS.map((d) => d.name));
    expect(set.size).toBe(64);
  });
  test("emergency numbers are the verified national set", () => {
    const phones = new Set(["999", "16263", "333", "10666", "109", "1098"]);
    expect(EMERGENCY_SERVICES.every((e) => phones.has(e.phone))).toBe(true);
    expect(EMERGENCY_SERVICES.length).toBeGreaterThanOrEqual(6);
  });
});

// ── password hashing (scrypt) ─────────────────────────────────────────────────
describe("password hashing", () => {
  test("scrypt hash verifies and rejects wrong password", async () => {
    const { hashPassword, verifyPassword } = await import("../src/lib/auth");
    const hash = await hashPassword("Patient#2026");
    expect(hash.startsWith("scrypt:")).toBe(true);
    expect(await verifyPassword("Patient#2026", hash)).toBe(true);
    expect(await verifyPassword("wrong", hash)).toBe(false);
  });
  test("unique salt per hash", async () => {
    const { hashPassword } = await import("../src/lib/auth");
    const [a, b] = await Promise.all([hashPassword("same"), hashPassword("same")]);
    expect(a).not.toBe(b);
  });
});

// ── national healthcare directory ─────────────────────────────────────────────
import { UPAZILAS } from "../src/lib/data/locations";
import {
  normalizeName, normalizePhoneBd, recordKey, qualityScore, parseCsv,
  googleMapsSearchUrl, googleMapsDirectionsUrl, isVerificationStatus, VERIFICATION_STATUSES,
  osmRouteUrl,
} from "../src/lib/directory";
import { coverageLevel } from "../src/lib/directory";

describe("directory: normalization & dedup", () => {
  test("normalizeName collapses suffix noise and punctuation", () => {
    expect(normalizeName("Dhaka Medical College Hospital")).toBe(normalizeName("dhaka medical college"));
    expect(normalizeName("Popular Diagnostic Centre Ltd.")).toBe(normalizeName("popular diagnostic centre limited"));
    expect(normalizeName("  Square   Hospital! ")).toBe("square");
  });

  test("normalizePhoneBd normalizes Bangladeshi numbers", () => {
    expect(normalizePhoneBd("+8801712345678")).toBe("8801712345678");
    expect(normalizePhoneBd("01712345678")).toBe("8801712345678");
    expect(normalizePhoneBd("01712-345 678")).toBe("8801712345678");
    expect(normalizePhoneBd("123")).toBeNull();
    expect(normalizePhoneBd("not-a-phone")).toBeNull();
  });

  test("recordKey matches same identity across name variants", () => {
    expect(recordKey("Dhaka Medical College Hospital", "Dhaka")).toBe(recordKey("Dhaka Medical College", "Dhaka"));
    expect(recordKey("X Clinic", "Dhaka")).not.toBe(recordKey("X Clinic", "Chattogram"));
    expect(recordKey("X Clinic", "Dhaka", "Savar")).not.toBe(recordKey("X Clinic", "Dhaka", "Dhamrai"));
  });
});

describe("directory: quality score & csv", () => {
  test("quality score is proportional and bounded", () => {
    const full = qualityScore({ name: true, nameBangla: true, type: true, ownership: true, division: true, district: true, upazila: true, address: true, latLng: true, phone: true, services: true, source: true, verified: true });
    const none = qualityScore({});
    expect(full).toBe(100);
    expect(none).toBe(0);
    const phoneWeight = qualityScore({ phone: true }) - qualityScore({});
    expect(phoneWeight).toBe(Math.round((12 / 100) * 100));
  });

  test("parseCsv handles quoted commas and CRLF", () => {
    const rows = parseCsv('name,address,phone\r\n" clinic, inc ",Mirpur 1,+8801700000000\nSecond,Dhaka,');
    expect(rows.length).toBe(3);
    expect(rows[1][0]).toBe(" clinic, inc ");
    expect(rows[2][1]).toBe("Dhaka");
  });

  test("google maps links are official universal formats", () => {
    expect(googleMapsSearchUrl("DMCH", "Dhaka")).toContain("google.com/maps/search/?api=1&query=");
    expect(googleMapsDirectionsUrl(23.81, 90.41)).toContain("google.com/maps/dir/?api=1&destination=23.81,90.41");
  });

  test("verification statuses whitelist", () => {
    for (const s of VERIFICATION_STATUSES) expect(isVerificationStatus(s)).toBe(true);
    expect(isVerificationStatus("MADE_UP_STATUS")).toBe(false);
  });
});

describe("directory: Bangladesh dataset integrity", () => {
  test("all 64 districts present across 8 divisions", () => {
    const divs = new Set(DIVISIONS.map((d) => d.name));
    expect(DIVISIONS.length).toBe(8);
    expect(DISTRICTS.length).toBe(64);
    for (const d of DISTRICTS) expect(divs.has(d.division)).toBe(true);
  });

  test("every upazila belongs to a known district with Bengali name", () => {
    const districtNames = new Set(DISTRICTS.map((d) => d.name));
    expect(UPAZILAS.length).toBeGreaterThanOrEqual(480);
    for (const u of UPAZILAS) {
      expect(districtNames.has(u.district)).toBe(true);
      expect(u.nameBangla.length).toBeGreaterThan(0);
    }
    // no duplicate upazila within a district
    const seen = new Set<string>();
    for (const u of UPAZILAS) {
      const k = `${u.district}::${u.name}`;
      expect(seen.has(k)).toBe(false);
      seen.add(k);
    }
  });
});

// ── Layer 3.6 additions: emergency finder, coverage levels, lite mode ─────────

describe("emergency finder helpers", () => {
  test("origin-aware directions link includes origin and destination", () => {
    const url = googleMapsDirectionsUrl(23.81, 90.41, { lat: 22.35, lng: 91.78 });
    expect(url).toContain("destination=23.81,90.41");
    expect(url).toContain("origin=22.35,91.78");
    expect(url).toContain("travelmode=driving");
    // without origin it degrades to the destination-only universal link
    expect(googleMapsDirectionsUrl(23.81, 90.41)).not.toContain("origin=");
  });

  test("OSM route link is a valid engine route with both points", () => {
    const url = osmRouteUrl({ lat: 23.8103, lng: 90.4125 }, { lat: 22.3569, lng: 91.7832 });
    expect(url).toContain("openstreetmap.org/directions");
    expect(url).toContain("route=23.81030%2C90.41250%2C22.35690%2C91.78320");
  });

  test("national hotlines are exactly the published numbers (no invention)", () => {
    const phones = EMERGENCY_SERVICES.map((s) => s.phone);
    for (const expected of ["999", "16263", "333", "10666", "109", "1098"]) {
      expect(phones).toContain(expected);
    }
    for (const s of EMERGENCY_SERVICES) {
      expect(s.name.length).toBeGreaterThan(3);
      expect(s.nameBangla.length).toBeGreaterThan(2);
    }
  });
});

describe("coverage level classification", () => {
  test("matches the documented honest thresholds", () => {
    expect(coverageLevel(0)).toBe("EMPTY");
    expect(coverageLevel(1)).toBe("MINIMAL");
    expect(coverageLevel(3)).toBe("MINIMAL");
    expect(coverageLevel(4)).toBe("LOW");
    expect(coverageLevel(11)).toBe("LOW");
    expect(coverageLevel(12)).toBe("MEDIUM");
    expect(coverageLevel(39)).toBe("MEDIUM");
    expect(coverageLevel(40)).toBe("HIGH");
    expect(coverageLevel(695)).toBe("HIGH");
  });
});

describe("i18n: new keys exist in both locales", () => {
  const newKeys = [
    "nav.emergency", "nav.coverage", "emergency.sos", "emergency.hotlines",
    "emergency.callNow", "lite.title", "lite.loadMap", "coverage.title",
    "coverage.level.EMPTY", "coverage.lowAreas", "emergency.straightLine",
  ] as const;
  test("en has every new key", () => {
    for (const k of newKeys) expect(typeof en[k]).toBe("string");
  });
  test("bn has every new key and non-empty values", () => {
    for (const k of newKeys) {
      expect(typeof bn[k]).toBe("string");
      expect((bn[k] as string).length).toBeGreaterThan(0);
    }
  });
});
