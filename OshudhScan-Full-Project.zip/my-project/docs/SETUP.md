# OshudhScan 2.0 — Environment, Setup & Development

## 1. Environment variables (`.env`)

```bash
# Database (Prisma). Sandbox uses SQLite; production uses PostgreSQL+PostGIS.
DATABASE_URL="file:/home/z/my-project/db/custom.db"
# Production example:
# DATABASE_URL="postgresql://oshudh:CHANGE_ME@localhost:5432/oshudhscan?schema=public"

# The z-ai-web-dev-sdk reads its own configuration (no secret in .env by design).
# If self-hosting outside the sandbox, configure the SDK credentials per its docs.
# Never put API keys in client-side code or in this repository.
```

Only `DATABASE_URL` is required in the sandbox. There are no other secrets in the codebase; session tokens are random per login and hashed at rest.

## 2. Setup (fresh machine)

```bash
# prerequisites: Node 20+/Bun 1.x, Python 3 (smoke tests), sqlite3 CLI (optional)
cd /home/z/my-project
bun install                 # install dependencies
bun run db:push             # create/refresh SQLite schema
bun run scripts/seed.ts     # seed users, pharmacies, KB, rules, locations, facilities
bun run dev                 # start Next.js dev server on :3000 (dev.log captures output)
```

Seeded demo accounts (all scrypt-hashed in DB):

| Role | Email | Password |
| --- | --- | --- |
| Patient | patient@oshudhscan.com | Patient#2026 |
| Pharmacy owner | pharmacy@oshudhscan.com | Pharma#2026 |
| Administrator | admin@oshudhscan.com | Admin#2026 |

## 3. Development workflow

```bash
bun run lint        # ESLint (Next.js rules) — must be clean before commit
bun test            # 48 unit tests (bun test runner)
bash tests/api-smoke.sh   # 54 end-to-end API checks against localhost:3000
```

Notes:
- The dev server logs to `dev.log`; read the tail for runtime errors after changes.
- **Login rate limit is 10 attempts / 15 min / IP.** Running the smoke suite twice within 15 minutes saturates it — restart the dev server (in-memory limiter clears) between full runs.
- Hot reload is on (Turbopack); schema changes need `bun run db:push` + client regenerate.

## 4. Conventions

- **Views** live in `src/components/rx/` and are switched via the zustand `view` router in `page.tsx` (no nested routing pages).
- **Every UI string** goes through `useI18n().t("dotted.key")`; add keys to both `src/lib/i18n/en.ts` (source of truth) and `bn.ts`. TypeScript enforces parity.
- **Medicine identity is never translated** — brand names, strengths, units and dose notation pass through verbatim in both languages.
- **New API endpoints** must use the `withApi` wrapper (auth, RBAC, rate limit, audit, zod) rather than raw handlers.
- **Clinical logic** goes in `src/lib/interactions.ts` / `src/lib/reminders.ts` as pure functions with unit tests; route handlers stay thin.
- **Design system**: use the utility classes in `globals.css` (`.hero-mesh`, `.panel-deep`, `.glass`, `.text-gradient`, `.card-hover`, `.shadow-soft`, `.stat-figure`, `.divider-label`, `.bottom-nav`). Custom classes must be defined **above** the `@layer base` block — this Tailwind v4 + Turbopack pipeline drops plain CSS declared after it (verified pitfall).
- Write test scripts to `tests/`, one-off utilities to `scripts/`; never commit generated PDFs or screenshots.

## Optional: Google Maps Platform

Set `GOOGLE_MAPS_API_KEY` (Places API **Text Search (New)** enabled) in `.env`
to enable live Google Places search. Without a key the platform stays fully
functional: places routes return `configured:false` and the UI uses registry
data with official Google Maps universal links. See docs/DIRECTORY.md §5.
