# OshudhScan 2.0 — Future Development Roadmap

Sequenced by dependency and impact. Every item preserves the founding constraint: **AI assists, deterministic rules and licensed professionals decide.**

## Phase P7 — Hardening for first real pharmacies (next 4–6 weeks)
1. **PostgreSQL + PostGIS migration** with reviewable SQL migrations and a restore drill (`docs/DATABASE.md` §2).
2. **SMS OTP + per-account lockout** on top of the existing rate limiter; optional push via FCM later.
3. **Backup/restore automation** + monitoring/error tracking wired to the `/api` health probe.
4. **CSP/HSTS finalization** at the edge; third-party audit of the auth flow.
5. **Visual regression suite** (agent-browser snapshots in CI) to protect the design system.

## Phase P8 — Verified network growth (1–3 months)
6. **Pharmacy onboarding at scale:** document upload checklist, DGDA license verification workflow (admin queue already built), re-verification calendar.
7. **Union/area geography completion** from an official dataset; postal-code search on top.
8. **Live inventory ops:** pharmacy POS-lite quick-entry, low-stock/expiry digest notifications (SMS), stock freshness SLA badges.
9. **Medicine KB expansion to 200+ SKUs** with an admin data-entry pipeline + `lastReviewed` governance.
10. **Doctor directory activation:** verified facility-fed doctor profiles; appointment requests routed to facility inboxes.

## Phase P9 — Clinical depth (3–6 months)
11. **Interaction rule base to 50+** with evidence-level metadata, dual-reviewer sign-off, and an exportable audit pack for DGDA conversations.
12. **Allergy & condition contraindication checks** using the patient profile (allergies/chronic fields already captured).
13. **Refill intelligence:** adherence-driven refill suggestions to pharmacies (opt-in, consent-gated), reusing reminder analytics.
14. **Arabic & Hindi locales** (architecture ready — typed dictionaries + fallback chain), plus an elderly-optimized "simplified mode" building on large-text.

## Phase P10 — Ecosystem & scale (6–12 months)
15. **Distributor integration:** substitution-aware purchase suggestions, rev-share accounting (Pricing module already sketches the model).
16. **POS integrations** (leading BD pharmacy software) for real-time stock instead of manual reporting.
17. **DGDA serialization alignment** for barcode authenticity signals.
18. **Offline-first PWA** for low-connectivity upazilas: cached medicine cards, queued reminder logs.
19. **Insight licensing** (anonymized availability heatmaps) as the second revenue line described in Pricing — strictly de-identified.

## Explicit non-goals (unchanged)
- No autonomous AI prescribing or diagnosis.
- No patient-data sale or ad targeting.
- No availability guarantees without pharmacy confirmation.
