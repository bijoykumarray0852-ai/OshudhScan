# OshudhScan 2.0 — Bangladesh National Healthcare Directory

Covers the location-based discovery module: administrative geography,
hospital / clinic / diagnostic / pharmacy directories, GPS nearby search,
Google Maps integration, data provenance, verification ladder, user reports,
ingestion pipeline and the admin coverage dashboard.

## 1. Administrative geography

- **Source**: Bangladesh Bureau of Statistics (BBS) administrative list.
- **Coverage**: 8 divisions, 64 districts, 489 upazilas — the complete BBS
  upazila list, each with Bengali + English names and `parentCode` hierarchy.
- **Coordinates** are approximate public centroids (distance ranking only,
  not cadastral boundaries). Unions/areas exist in the schema (`UNION`/`AREA`
  levels) and are added only when reliable data is imported — an empty list
  is an honest empty result, never fabricated rows.
- Models: `AdministrativeLocation` (`DIVISION|DISTRICT|UPAZILA|UNION|AREA`),
  seeded idempotently by `scripts/seed.ts` from `src/lib/data/locations.ts`.

## 1b. National OSM import (run 2025-11, `scripts/import-osm.ts`)

Real community-mapped data imported through the ingestion pipeline from the
HOT OSM export "Health Facilities of Bangladesh" (HDX, © OpenStreetMap
contributors, ODbL licence): **+2,942 facilities and +3,580 pharmacies**,
deduplicated against curated rows, all landing `UNVERIFIED` with per-record
source attribution. District/upazila assignment uses the export's own
administrative tags mapped onto the BBS canonical list (legacy names like
Jessore/Bogra/Nawabganj are aliased). Fully-generic names ("Clinic",
"Community clinic") are skipped. Coverage is now measured at **64/64
districts** — every row still awaits contact verification through the admin
queue, which the UI shows honestly.

## 2. Facility & pharmacy records

- Curated baseline (48 facilities, pre-dating the OSM import): government medical college hospitals,
  national specialized institutes (NICVD, NINS, NIKDU, NICRH, NIDCH, NIMH,
  NITOR, NIOH), upazila health complexes, BSMMU/BIRDEM/icddr,b, well-known
  private hospitals and diagnostic centres — address-level public knowledge.
- **Phones are NOT seeded** (except verified national hotlines) — the UI shows
  "Phone number unavailable" rather than inventing numbers. Exact campus
  coordinates/phones arrive through verified imports and admin checks.
- Every record carries: `source`, `sourceType`, `sourceUrl`,
  `verificationStatus`, `qualityScore` (0–100 field-completeness, NOT legal
  or clinical verification), `lastVerifiedAt`.

## 3. Verification ladder (provenance rules)

`OFFICIALLY_LISTED → MAP_LISTED → CONTACT_VERIFIED → LICENSE_VERIFIED →
ADMIN_VERIFIED`, plus `UNVERIFIED`, `TEMPORARILY_CLOSED`,
`PERMANENTLY_CLOSED`, `REPORTED_INCORRECT`.

Hard rules enforced in code and copy:
- DGHS listing ≠ phone verification; a Google Maps listing is NOT proof of a
  drug license; map presence ≠ licensed pharmacy.
- Every status change writes an immutable `VerificationEvent`
  (method, evidence URL, actor, timestamp).
- Phone numbers display a verification badge; unverified numbers are labelled.

## 4. User reports

Anyone can report wrong phone / wrong address / closures / duplicates /
wrong category / wrong location via `/api/reports` (rate limited, optional
auth). Reports land in the admin queue and are **never auto-applied**; the
admin applies corrections explicitly, which resets the record to
`UNVERIFIED` for re-check.

## 5. Google Maps Platform

- Server-side proxy routes: `/api/places/search`, `/api/places/details`,
  `/api/places/nearby`. The API key (`GOOGLE_MAPS_API_KEY`) never reaches the
  frontend.
- **Without a key** the routes return `configured: false` and the UI falls
  back to registry data + official Google Maps *universal links* built from
  name + address (`google.com/maps/search/?api=1&query=…`) and directions
  (`google.com/maps/dir/?api=1&destination=lat,lng`). No Place IDs are ever
  invented.
- With a key, Text Search (Places API New) responses are cached in
  `GooglePlaceRecord` (placeId kept separate from internal ids, per Google
  retention terms) and can be matched back to records by admins.

## 6. Map experience

Interactive map = Leaflet 1.9.4 (CDN, SRI-hashed) + OpenStreetMap tiles with
attribution, colour-coded circle markers per category, graceful static-OSM
iframe fallback when the CDN is unavailable, list/map toggle, GPS "near me".

## 7. Ingestion pipeline (admin)

`POST /api/admin/directory/import` accepts CSV or JSON rows for FACILITY /
PHARMACY entities:
- header-mapped fields (name, nameBangla, type, district, upazila, address,
  phone, license, lat/lng, ownership, services…),
- normalization (name, BD phone), duplicate detection (normalized
  name+district key, phone match), per-row errors logged to
  `DirectoryImportError`, quality score computed per row,
- imported rows land `UNVERIFIED` (except DGHS-sourced imports, which may be
  marked `OFFICIALLY_LISTED`), every run tracked as `DirectoryImportJob`.

## 8. Coverage honesty

The admin dashboard computes coverage from actual DB rows only: facilities by
type/category/division, verification ladder distribution, districts covered
of 64 ("measured, not claimed"), upazila count, missing-phone /
missing-coordinates gaps. No claim of full national coverage is made until it
is measured.

## 9. Related tests

- Unit: `tests/oshudhscan.test.ts` → directory block (normalization, dedup
  keys, quality score, CSV parser, map link formats, dataset integrity).
- E2E: `tests/api-smoke.sh` → "national healthcare directory" section
  (22 checks: locations cascade, directory search, GPS nearby, reports,
  verification, coverage, graceful Places mode).
