# OshudhScan 2.0 — Feature Implementation Report

Status legend: **Completed** (implemented, tested) · **Partial** (works, documented gaps) · **Blocked** (external dependency) · **Not Started**.

## A. Preserved v1 features — Completed

| Feature | Status | Files | Tests |
| --- | --- | --- | --- |
| GLM-4.5V prescription OCR (live photo path) | Completed | `src/app/api/decode/route.ts`, `ScanView.tsx` | smoke: `decode sample-c` |
| Brand resolver cascade (exact/alias/molecule/fuzzy, 72 % gate) | Completed | `src/lib/match.ts`, `src/lib/drug-db.ts` | unit: 9 resolver tests |
| Deterministic interaction engine (R1–R8) | Completed | `src/lib/interactions.ts` | unit + smoke R1 |
| Cumulative paracetamol guard (2 g / 3 g tiers) | Completed | `src/lib/interactions.ts` | smoke `dose-para` major |
| Bangla plain-language explanation + template fallback | Completed | `src/app/api/explain/route.ts`, `src/lib/bangla.ts` | smoke |
| Bangla TTS voice card (PCM→WAV, hardened with retry+timeout) | Completed | `src/app/api/tts/route.ts` | smoke (audio > 1 kB) |
| Pharmacy lead portal with SAFETY FLAG badges | Completed | `PortalView.tsx`, `src/app/api/pharmacies/[id]/leads` | smoke reservation flow |
| Generic price comparison + savings | Completed | `src/app/api/medicines/alternatives`, `MedicineView.tsx` | smoke |
| ROI calculator + pricing tiers | Completed | `src/lib/finance.ts`, `PricingView.tsx` (now localized) | manual |

## B. New 2.0 modules

| # | Module | Status | Key files | Tests |
| --- | --- | --- | --- | --- |
| A | **Multilingual system** — bn/en dictionaries, nav toggle, per-user locale, medicine identity never translated, large-text mode | Completed (ar/hi architecture-ready: typed dict + fallback chain) | `src/lib/i18n/*`, `src/hooks/use-i18n.ts`, `store.ts` | unit: i18n identity test |
| B | **Location system** — 8 divisions / 64 districts / upazilas, BBS-sourced, GPS + manual picker | Completed (union-level data: Partial — not in dataset yet) | `src/lib/data/locations.ts`, `src/app/api/locations`, `shared.tsx LocationPicker` | unit: dataset tests; smoke: 64 districts |
| C | **Patient dashboard** — overview, prescriptions, reminders, documents, family, notifications (12), profile 67 % completion, privacy | Completed | `PatientView.tsx`, `src/app/api/patients/profile` | smoke patient workflow |
| D | **Smart medicine reminder** — schedule from verified prescription, slots, custom times, taken/skip/snooze, missed detection, refill, stop | Completed | `src/lib/reminders.ts`, `src/app/api/reminders/*` | smoke: 8 checks incl. mismatch rejection |
| E | **Medicine intelligence** — 26-drug KB in DB, barcode lookup, expiry detection, interaction checker UI | Completed | `MedicineView.tsx`, `src/app/api/medicines/*` | smoke barcode honesty |
| F | **Pharmacy management** — registration, admin verification queue, batch inventory (expired rejected 422), sales FIFO, staff RBAC, branches, suppliers | Completed (POS/distributor integrations: Not Started) | `PortalView.tsx`, `src/app/api/pharmacies/[id]/*`, `admin/pharmacies` | smoke: 10 checks |
| G | **Availability search** — brand/generic/strength query, distance radius, freshness labels, reservation confirm flow | Completed | `FindView.tsx`, `src/app/api/availability`, `reservations` | smoke: availability + reservation RBAC |
| H | **AI health assistant** — guarded bn/en chat, KB citations, 999 emergency short-circuit, conversation history | Completed | `src/app/api/assistant`, `CareView.tsx` | smoke: emergency + citation checks |
| I | **Doctor & hospital finder** — facility directory (22 seeded Dhaka-area facilities w/ sources), filters, appointment requests (validated ids) | Completed (doctors: honest empty until verified data) | `CareView.tsx`, `src/app/api/healthcare/*` | smoke: directory + appointment |
| J | **Emergency directory** — verified national numbers, blood orgs, never simulates calls | Completed | `src/lib/data/emergency.ts`, `CareView.tsx` | unit: emergency dataset test |
| K | **Medical document vault** — private upload/download/delete, owner-only access (401/404 verified) | Completed | `PatientView.tsx`, `src/app/api/documents/*` | smoke: 5 vault checks |
| L | **Security & privacy** — scrypt, sessions, RBAC, rate limits, consent records, audit logs, account deletion | Completed (at-rest encryption: Partial, SQLite file-level) | `src/lib/auth.ts`, `api.ts`, consents/audit in schema | smoke RBAC + rate-limit checks |
| M | **Admin dashboard** — stats, verification queue, rule retire/enable, user management, audit log, facility management | Completed | `AdminView.tsx`, `src/app/api/admin/*` | smoke admin section |
| — | **National Healthcare Directory (this session)** — 8 divisions / 64 districts / 489 upazilas (BBS, bilingual); hospital/clinic/diagnostic/pharmacy directories with categories + ownership filters; GPS nearby; dependent Division→District→Upazila search; interactive Leaflet+OSM map with fallback; verification ladder with immutable provenance; public reports queue; CSV/JSON ingestion with dedup + quality scores; admin coverage dashboard ("measured, not claimed"); Google Places proxy with graceful no-key mode + official Maps links | Completed — coverage measured 64/64 districts after the OSM (HDX/ODbL) import of 2,942 facilities + 3,580 pharmacies (DGHS quality uplift + union data: Partial; live Google data needs `GOOGLE_MAPS_API_KEY`) | `src/lib/directory*.ts`, `src/app/api/{locations,directory,facilities,places,reports,admin/directory}`, `DirectoryView`, `MapView`, `DirectoryAdminTab`, `directory-ui` | unit: 9 directory tests; smoke: 22 directory checks | 
| N | **Analytics** — patient adherence, pharmacy sales/leads 14-day charts, de-identified admin analytics with privacy note | Completed | `src/app/api/analytics/*`, views | smoke both endpoints |
| — | **UI/UX redesign (this session)** — Clinical Emerald design system, gradient hero, glass header, mobile bottom nav, deep footer, premium cards, bn/en full localization of Home + Pricing | Completed | `globals.css`, `page.tsx`, `HomeView`, `PricingView`, `shared.tsx` | lint + browser-verified 375/1440 px |

## C. Known partial / honest gaps

1. **PostGIS** — schema is written to port; sandbox runs SQLite. Migration path documented in DATABASE.md.
0. **Directory data** — 54 curated facilities with full provenance + 2,942 facilities / 3,580 pharmacies from the HOT OSM export (ODbL, attributed per record), all UNVERIFIED pending contact checks. Complete BBS upazila list (489) seeded. Coverage honestly measured at 64/64 districts; quality uplift via DGHS registry import remains pipeline-ready.
2. **Union-level location data** — divisions/districts/upazilas seeded; union/area joins require an official dataset.
3. **Doctor directory** — intentionally empty (0 rows) until verified data is supplied; UI states this honestly.
4. **Barcode authenticity** — barcode lookup only retrieves registered product records; the UI explicitly states it never proves authenticity.
5. **External integrations** — SMS/push providers, POS, distributor APIs: correct interfaces defined, marked Not Started, never simulated as live.
