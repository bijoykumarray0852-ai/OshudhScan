# OshudhScan 2.0 — Project Architecture

> Status date: 2026-11-22 · Runtime: Next.js 16 (App Router, Turbopack), TypeScript 5, Prisma 6 + SQLite (sandbox), Tailwind CSS 4 + shadcn/ui.

## 1. Design philosophy

OshudhScan is a **modular monolith**: one Next.js app, one database, clear domain boundaries inside `src/`. AI (vision OCR, Bangla explanation, TTS, health assistant) sits **on top of a deterministic safety core** — the LLMs read and explain, a rule engine decides anything safety-relevant. Every clinical finding is auditable and reproducible.

```
┌────────────────────────── Browser (React 19) ──────────────────────────┐
│  page.tsx (shell: glass header, bottom nav, deep footer, i18n toggle)  │
│  Views: Home · Scan · Medicines · Find · Patient · Care · Portal ·     │
│         Pricing · Admin · Settings   (zustand view router)             │
└──────────────────────────────────┬─────────────────────────────────────┘
                                   │ apiFetch (JSON, same-origin)
┌──────────────────────────────────▼─────────────────────────────────────┐
│                     Next.js Route Handlers (/src/app/api)               │
│  auth · patients · pharmacies · locations · medicines · prescriptions  │
│  reminders · reservations · documents · healthcare · assistant ·       │
│  analytics · admin ·  decode/explain/tts (preserved v1 endpoints)      │
│  Cross-cutting: withApi wrapper (auth, RBAC, rate limit, audit, zod)   │
└───────┬────────────────────────┬───────────────────────┬───────────────┘
        │                        │                       │
┌───────▼────────┐   ┌───────────▼──────────┐   ┌────────▼────────┐
│ Deterministic  │   │ Prisma + SQLite       │   │ z-ai-web-dev-sdk│
│ safety core    │   │ (schema ports to      │   │ GLM-4.5V OCR ·  │
│ drug-db (26) · │   │ PostgreSQL + PostGIS) │   │ LLM explain ·   │
│ match ·        │   │ sessions, audit logs, │   │ TTS (PCM→WAV) · │
│ interactions   │   │ consents, soft delete │   │ assistant chat  │
└────────────────┘   └──────────────────────┘   └─────────────────┘
```

## 2. Source layout

| Path | Responsibility |
| --- | --- |
| `src/app/page.tsx` | App shell: frosted header, mobile bottom nav, deep-emerald footer, session bootstrap |
| `src/components/rx/*.tsx` | One file per view (`HomeView`, `ScanView`, `MedicineView`, `FindView`, `PatientView`, `CareView`, `PortalView`, `PricingView`, `AdminView`, `SettingsView`) + `shared.tsx` primitives (`PageHeader`, `StatCard`, `EmptyState`, `StockBadge`, `LocationPicker`, …) |
| `src/app/api/**` | Route handlers grouped by domain; legacy `decode/explain/tts` preserved at their v1 paths |
| `src/lib/interactions.ts` | Deterministic safety engine (interaction matrix, cumulative paracetamol guard, alcohol ban, duplicate detection) |
| `src/lib/drug-db.ts` | 26-drug Bangladesh demo formulary (brand → molecule → class → prices) |
| `src/lib/match.ts` | Fuzzy resolver cascade: exact → alias → molecule → Levenshtein (72 % confidence floor) |
| `src/lib/reminders.ts` | Schedule expansion, missed-dose detection, adherence math (never invents doses) |
| `src/lib/geo.ts` | Haversine distance, stock freshness, expiry math, OSM embed URL |
| `src/lib/i18n/{en,bn}.ts` | Central typed dictionaries (single source of truth: `en.ts`) |
| `src/lib/auth.ts` | scrypt password hashing, session tokens (SHA-256 hashed at rest), cookie options, RBAC helpers |
| `src/lib/api.ts` | `withApi` wrapper: zod parsing, RBAC roles, sliding-window rate limiting, audit hook, uniform error envelopes |
| `src/lib/data/locations.ts` | 8 divisions / 64 districts (BBS-sourced) with coordinates |
| `src/lib/data/emergency.ts` | Verified national emergency numbers (999, 16263, …) |
| `prisma/schema.prisma` | 30+ models — see [DATABASE.md](./DATABASE.md) |
| `tests/oshudhscan.test.ts` | 48 unit tests (bun test) |
| `tests/api-smoke.sh` | 54-check end-to-end API suite |
| `scripts/seed.ts` | Idempotent seed: users, pharmacies, inventory, facilities, rules, locations |

## 3. Key architectural decisions

1. **AI/determinism separation.** `/api/decode` never lets the vision model decide safety: OCR output is matched through the deterministic resolver, and every finding comes from versioned rules with reviewer metadata. The LLM only renders plain-language text (`/api/explain`, `/api/assistant`) and is always wrapped in timeout + deterministic fallback.
2. **Session auth without external services.** Opaque session tokens (SHA-256 hashed in DB), httpOnly cookie, scrypt password hashing — no third-party auth dependency, portable to production.
3. **Honest data surface.** Availability shows only pharmacy-reported stock with freshness timestamps (`STALE` after 24 h, `UNKNOWN` when unreported). Doctor directory ships empty until verified data exists. Barcodes that are not registered return `found:false` — never a guess.
4. **PostGIS-ready schema.** SQLite in the sandbox; lat/lng columns + indexes map 1:1 to `geography(Point)` + GIST in PostgreSQL (see DATABASE.md for the migration path).
5. **Mobile-first accessibility.** Bottom tab bar + safe-area padding on mobile, large-text mode, 44 px touch targets, Bangla font (Noto Sans Bengali) wired through `.font-bangla`.
