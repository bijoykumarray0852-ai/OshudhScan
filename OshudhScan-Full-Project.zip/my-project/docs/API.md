# OshudhScan 2.0 — API Documentation

All endpoints are same-origin route handlers under `/api`. Standard envelope:

```jsonc
// success
{ "ok": true, ...payload }
// error
{ "ok": false, "code": "VALIDATION|AUTH_REQUIRED|FORBIDDEN|NOT_FOUND|RATE_LIMITED|EXPIRED_BATCH|INTERNAL", "error": "human message" }
```

Cross-cutting (`src/lib/api.ts` `withApi`): zod body validation → optional auth (`getSessionUser`) → RBAC roles → sliding-window rate limit → audit write → uniform errors. Timestamps are ISO-8601. Pagination: `?page=1&pageSize=20` (default 20, max 100).

## Auth `/api/auth`
| Method + path | Auth | Notes |
| --- | --- | --- |
| `POST /api/auth?action=register` | — | name/email/password(≥8)/phone/locale → sets httpOnly `oshudh_session` cookie; creates PatientProfile + DATA_PROCESSING consent. Rate 5/h/IP |
| `POST /api/auth?action=login` | — | email+password → cookie. Rate 10/15 min/IP |
| `GET /api/auth/me` | cookie | current `SessionUser` (id, email, name, role, locale, largeText, phone) |
| `POST /api/auth/logout` | cookie | deletes session row |

## Patients & profile
| Endpoint | Auth | Notes |
| --- | --- | --- |
| `GET/PATCH /api/patients/profile` | PATIENT | profile fields, allergies, chronic conditions, emergency contact; `PATCH` accepts `consents:[{type,granted}]` |
| `GET/POST/DELETE /api/family` | PATIENT | family member profiles (`?id=` for delete) |
| `GET /api/notifications` · `PATCH` | signed-in | list / mark-read |

## Locations `/api/locations?level=DIVISION|DISTRICT|UPAZILA&division=&district=&q=`
Public. Returns `{ locations, total, source:"BBS administrative areas (public)" }`.

## Medicines
| Endpoint | Auth | Notes |
| --- | --- | --- |
| `GET /api/medicines?q=&page=` | public | KB search (brand/generic/strength/form) |
| `GET /api/medicines/alternatives?id=` | public | same-molecule brands + indicative prices + savingsPct |
| `POST /api/medicines/check` | public | `{items:[{name,dose?}]}` → deterministic findings (never LLM) |
| `GET /api/medicines/barcode?code=` | public | honest `{found:false}` for unregistered codes |
| `POST /api/medicines/scan-packet` | public | v1 packet: resolve + interactions + price totals |

## Prescriptions `/api/prescriptions`
`GET` (own history, paginated) · `POST` (save decoded rx + items + totals) · `DELETE ?id=`. Patient-scoped.

## Reminders
| Endpoint | Auth | Notes |
| --- | --- | --- |
| `POST /api/reminders/schedules` | PATIENT | `{medicineLabel, slots[], perDay, durationDays?, meal?, customTimes?, confirmed}` — **rejects slot/perDay mismatch** (never auto-expands ambiguous dosage) |
| `PATCH /api/reminders/schedules` | owner | `{id, action:"STOP|ACTIVATE|SET_STOCK"}` |
| `GET /api/reminders/due` | PATIENT | `{upcoming[], newlyMissed, unreadNotifications}` |
| `POST /api/reminders/logs` | PATIENT | `{reminderId, action:"TAKEN|SKIPPED|SNOOZED"}` — snooze creates follow-up reminder |

## Pharmacy finder & availability
| Endpoint | Auth | Notes |
| --- | --- | --- |
| `GET /api/pharmacies?lat=&lng=&distance=&q=&openNow=&verified=` | public | distance-filtered list, `isDemo` flag surfaced |
| `GET /api/availability?medicineId=&lat=&lng=&distance=` | public | only pharmacy-**reported** stock; `STALE` after 24 h |
| `POST/GET/PATCH /api/reservations` | patient / PHARMACY staff | patient creates; pharmacy confirms/fulfills; patient gets 403 on pharmacy actions (smoke-tested) |

## Pharmacy management (`/api/pharmacies/[id]/…`, staff-only unless noted)
`GET/POST/PATCH/DELETE inventory` (expired batch → 422 `EXPIRED_BATCH`; GET exposes purchase prices → staff-only) · `GET/POST sales` (FIFO decrement + movement ledger) · `GET/POST/PATCH branches` · `GET/POST/DELETE staff` (RBAC: owner/pharmacist/manager/inventory) · `GET/POST/PATCH suppliers` · `GET/POST/PATCH leads` · `POST verify` (documents) · `POST /api/pharmacies` (public registration → PENDING).

## Healthcare
| Endpoint | Auth | Notes |
| --- | --- | --- |
| `GET /api/healthcare/facilities?type=&district=&q=` | public | verified-status + source per row |
| `GET /api/healthcare/doctors` | public | honestly empty until verified data |
| `POST /api/healthcare/appointments` | optional | validates facilityId/doctorId exists (400 otherwise); request-only, no availability invented |

## Assistant `/api/assistant`
`POST {message, locale?, conversationId?}` — urgency keyword short-circuit (999), KB grounding + citations, LLM with 20 s timeout + deterministic fallback, non-diagnosis guardrails. Rate 15/5 min. `GET ?conversationId=` history.

## Documents vault
`POST /api/documents` (multipart, type+size validated) · `GET /api/documents` (own, filters) · `GET /api/documents/[id]` (owner-only download; 401 unauthenticated, 404 other users) · `DELETE /api/documents/[id]` (soft delete).

## Admin `/api/admin/*` (role ADMIN)
`stats` (counts, pending queue) · `pharmacies GET/PATCH` (approve/reject verification with reviewNote) · `rules GET/PATCH` (RETIRE/ENABLE — publication requires review) · `users GET/PATCH/DELETE` · `facilities GET/POST/PATCH` · `audit GET`.

## Analytics
`GET /api/analytics/pharmacy?pharmacyId=` (staff-only; 14-day daily series, month totals, lead funnel, inventory risk) · `GET /api/analytics/admin` (ADMIN; aggregated/de-identified + explicit `privacyNote`).

## National Healthcare Directory `/api/locations/*`, `/api/directory/*`, `/api/facilities/*`, `/api/pharmacies/*`, `/api/places/*`, `/api/reports`
| Endpoint | Auth | Notes |
| --- | --- | --- |
| `GET /api/locations/divisions` | — | 8 divisions (BBS) |
| `GET /api/locations/districts?division=` | — | districts of division (400 without param) |
| `GET /api/locations/upazilas?district=` / `?q=` | — | full BBS upazila list incl. Bengali names |
| `GET /api/locations/unions?upazila=` | — | union/area level; honest empty list until imported |
| `GET /api/directory/hospitals` | — | `q, division, district, upazila, category, ownership, emergency, lat/lng, page` → FacilityRow[] with verificationStatus, qualityScore, source, maps links |
| `GET /api/directory/clinics` / `/diagnostics` | — | same semantics |
| `GET /api/directory/search` | — | unified facilities+pharmacies search |
| `GET /api/directory/pharmacies` | — | pharmacy directory; `medicine=` matches reported stock |
| `GET /api/facilities/:id` | — | details + last 10 VerificationEvents |
| `GET /api/facilities/nearby?lat=&lng=&radius=&type=` | — | haversine GPS search (400 without coords) |
| `GET /api/pharmacies/nearby` | — | GPS pharmacy finder alias |
| `GET /api/pharmacies/availability`, `/api/pharmacies/reservations` | — | canonical aliases of `/api/availability`, `/api/reservations` |
| `GET /api/places/search|details|nearby` | — | Google Maps Platform proxy; `configured:false` without key — never fabricates Place IDs |
| `POST /api/reports` | optional | public report of wrong phone/address/closed/duplicate/category/location → admin queue (rate 10/h) |
| `GET /api/reports` | ADMIN | review queue |
| `GET /api/admin/directory/coverage` | ADMIN | coverage from real records (districts covered, gaps) |
| `POST /api/admin/directory/verify` | ADMIN | move record along verification ladder → writes VerificationEvent |
| `POST /api/admin/directory/reports` | ADMIN | resolve/reject/apply-correction (corrections reset to UNVERIFIED) |
| `POST /api/admin/directory/import` | ADMIN | CSV/JSON ingestion with dedup + quality scoring + error rows; `GET` lists jobs |

## Preserved AI endpoints
| Endpoint | Notes |
| --- | --- |
| `POST /api/decode` | photo upload (base64) → GLM-4.5V OCR → deterministic match + safety; `sampleId` path runs curated samples; `degraded` flag on OCR failure |
| `POST /api/explain` | LLM Bangla explanation per item with template fallback (`generatedBy: "llm"|"template"`) |
| `POST /api/tts` | Bangla text ≤1200 chars → PCM → WAV (`audio/wav`); SDK init + call both timeout-wrapped with 1 retry |

Example calls for every check live in `tests/api-smoke.sh` (82 assertions, all green).
