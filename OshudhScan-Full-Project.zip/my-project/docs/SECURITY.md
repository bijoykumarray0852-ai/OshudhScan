# OshudhScan 2.0 — Security Checklist

Status: **[x] implemented & smoke-tested** · **[~] partial** · **[ ] planned**

## Authentication & sessions
- [x] Passwords hashed with scrypt + per-user random salt (`src/lib/auth.ts`) — never reversible
- [x] Session tokens: 32-byte random, **SHA-256 hashed in DB**, httpOnly + SameSite=Lax cookie, `secure` in production, 14-day expiry
- [x] Login rate limit 10 / 15 min / IP; registration 5 / hour / IP (429 verified by smoke test)
- [x] Logout deletes the server-side session row
- [x] Account deletion workflow (password-confirmed, soft-deletes user, sessions revoked)

## Authorization (RBAC)
- [x] Roles: PATIENT, PHARMACY_OWNER, PHARMACY_STAFF, PHARMACIST, ADMIN
- [x] `withApi` role gate + `assertPharmacyAccess` per-pharmacy staff check (verified: patient → 403 on admin and inventory)
- [x] Patient records scoped server-side by owner; cross-user document access → 404 (verified)
- [x] Pharmacy-side reservation actions refused for patients → 403 (verified)
- [x] Clinical rule publish/retire restricted to ADMIN with reviewer + note (audit-logged)

## Input & API safety
- [x] zod validation on every route body (`parseJson`) with field-level messages
- [x] Uniform error envelope — no stack traces, no internal messages (`INTERNAL` is generic)
- [x] File upload validation: category/size/type checks; documents stored privately, served through authenticated handler only
- [x] Ambiguous dosages are **rejected, never auto-expanded** (slot/perDay mismatch → VALIDATION)
- [x] Expired inventory batches cannot be added or re-marked available (422 `EXPIRED_BATCH`)
- [x] Barcode lookups return honest `found:false`; no fabricated authenticity claims

## Data protection
- [~] Encryption in transit: HTTPS at the deployment edge (Caddy/preview); sandbox local traffic is plain HTTP
- [~] Encryption at rest: SQLite file permissions today; production path documented (PostgreSQL TDE/volume encryption) — not active in sandbox
- [x] Patient clinical data (prescriptions, documents, reminders) is isolated from lead/commercial tables by schema; leads carry item labels only, never identity
- [x] Consent records (`UserConsent`: DATA_PROCESSING, GPS…) with version + timestamp; profile PATCH records consent changes
- [x] No patient-identifiable data in analytics — admin analytics aggregated + de-identified with explicit `privacyNote` (verified)
- [x] Logs contain no passwords, tokens, or patient clinical content (audit rows store action/entity/id only)

## Audit & operations
- [x] `AuditLog` on auth events, inventory mutations, verification decisions, assistant use, appointment requests (verified populated in smoke run)
- [x] Admin audit viewer with pagination
- [x] Soft delete + timestamp columns for recoverability; seed is idempotent
- [ ] Backup/restore automation — planned for production deployment (documented in DEPLOYMENT.md)
- [ ] Security headers beyond Next.js defaults (CSP, HSTS policy) — to be finalized at deployment edge

## OWASP mapping (abbrev.)
- **A01 Broken Access Control** — RBAC + ownership scoping, smoke-tested
- **A02 Cryptographic Failures** — scrypt, hashed tokens; at-rest encryption partial
- **A03 Injection** — Prisma parameterization; zod inputs; no raw SQL
- **A04 Insecure Design** — deterministic safety engine; AI never makes clinical decisions
- **A05 Security Misconfiguration** — single cookie config source; secrets absent from repo
- **A07 Auth Failures** — rate limiting, generic credential errors, hashed tokens
- **A08 Data Integrity** — audit logs, reviewer metadata on clinical rules
- **A09 Logging Failures** — structured audit without sensitive payloads
- **A10 SSRF** — no server-side fetch of user-supplied URLs
