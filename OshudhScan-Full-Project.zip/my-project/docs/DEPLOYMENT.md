# OshudhScan 2.0 — Deployment Guide

## 1. Target topology (production)

```
Client (mobile/desktop, BD-wide)
   │ HTTPS
Caddy / Nginx edge (TLS 1.2+, HSTS, gzip/brotli)
   │
Next.js 16 standalone server (Node 20+, 1..n replicas)
   │
PostgreSQL 16 + PostGIS 3  (primary + PITR backups)
   │
Object storage for medical documents (private bucket, signed short-lived URLs)
```

The modular monolith runs as a single deployable; scale by replicas + connection pooling. No message broker is required for current features.

## 2. Build & run

```bash
bun install --production=false
bun run build          # next build + standalone output
# env required at runtime:
#   DATABASE_URL=postgresql://...  (PostGIS-enabled)
bun run start          # NODE_ENV=production bun .next/standalone/server.js
```

Steps to migrate the DB from SQLite → PostgreSQL+PostGIS:
1. Set `DATABASE_URL` to the Postgres instance; switch `provider = "postgresql"` in `prisma/schema.prisma`.
2. `bun run db:push` (or generate SQL migrations with `prisma migrate dev` for a reviewable history).
3. Apply the PostGIS column/index upgrade from `docs/DATABASE.md` §2 (geography point + GIST).
4. Run `bun run scripts/seed.ts` (seed is provider-agnostic and idempotent).

## 3. Reverse proxy notes (Caddy example)

```caddyfile
oshudhscan.example.com {
  encode zstd gzip
  reverse_proxy localhost:3000
  header {
    Strict-Transport-Security "max-age=31536000; includeSubDomains"
    X-Content-Type-Options nosniff
    Referrer-Policy strict-origin-when-cross-origin
  }
}
```

Session cookies become `Secure` automatically (`NODE_ENV=production`).

## 4. External services

| Dependency | Mode today | Production requirement |
| --- | --- | --- |
| z-ai-web-dev-sdk (OCR / explain / TTS / assistant) | sandbox-managed | configure SDK credentials per its docs; all four endpoints already timeout-wrap + fall back (template text, 999 short-circuit) |
| SMS / push notifications | interface defined, not live | pick a BD provider (e.g. SSL Wireless/AlphaNet); plug into the notification writer |
| Maps | OpenStreetMap embed via `osmEmbedUrl` (no key) | optional Google Maps key if required |
| Facility/doctor data | seeded public listings | data-entry workflow via Admin dashboard |

## 5. Operations checklist

- **Backups:** nightly `pg_dump` + WAL archiving (PITR); documents bucket versioning. Restore drill monthly.
- **Monitoring:** health endpoint `GET /api` (server "ok" probe used by dev launcher); add uptime probe + error tracking (Sentry-compatible) at deploy.
- **Rate limits:** login 10/15 min/IP, assistant 15/5 min, registration 5/h — tune per NAT realities (see LIMITATIONS.md).
- **Secrets:** none in repo; SDK credentials via environment only. Rotate DB credentials quarterly.
- **Zero-downtime:** standalone server behind the proxy allows blue-green swap; Prisma migrations are additive-first.
- **Log retention:** application logs 30 days; audit logs 1 year (regulatory posture), no patient clinical content in logs.

## 6. Bangladesh-specific operational notes

- Serve low-bandwidth users: images compressed (sharp), maps lazy-loaded, skeleton states already in place.
- Keep the Bangla font (Noto Sans Bengali) served locally (`public/fonts`) — no Google Fonts dependency at runtime.
- Legal review required before publishing the generic-substitution prompts at scale (pharmacist-confirmation flow is enforced in-product).
