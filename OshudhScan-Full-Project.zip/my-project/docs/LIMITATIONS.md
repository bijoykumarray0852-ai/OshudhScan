# OshudhScan 2.0 — Known Limitations

Honest inventory of what this build does **not** do. Nothing below is silently presented as working.

## Data & coverage
1. **Demo pharmacies.** The 5 seeded pharmacies (Mirpur/Dhaka) are demo records, flagged `isDemo` in API responses and badged in the UI. No real pharmacy is listed without registration + admin verification.
2. **Doctor directory is empty (0 rows).** UI states "no verified doctors yet" rather than inventing names or schedules.
3. **Union/area-level geography missing.** Divisions (8), districts (64) and upazilas are seeded from BBS data; union-level rows require an official dataset — the location picker stops at upazila today.
4. **Live inventory honesty.** Availability shows only pharmacy-reported stock; `STALE` appears after 24 h without updates and `UNKNOWN` where never reported. No promise of availability is made before a pharmacy confirms a reservation.
5. **Medicine KB is a 26-drug demo formulary.** Unmatched prescriptions go to pharmacist review by design; scaling the KB is a data-operations task (admin-managed), not automatic.

## Safety & clinical
6. **AI never decides safety.** Findings come only from the deterministic rule set (13 rules). The rules cover the major Bangladesh-specific traps (warfarin×NSAID, QT stacks, PPI/NSAID duplication, paracetamol cumulative dose, metronidazole-alcohol, duplicates) but are **not a complete pharmacopoeia** — the UI always requires pharmacist confirmation.
7. **OCR confidence gate.** Lines below 72 % match confidence are surfaced as "pharmacist review required" rather than guessed; handwriting quality still limits end-to-end automation.
8. **Barcode ≠ authenticity.** Barcode lookup retrieves registered product records only; the UI explicitly disclaims authenticity verification (DGDA serialization integration is future work).

## National directory (this module)
12. **Baseline directory data is curated, not exhaustive.** 54 real facilities (medical colleges, national institutes, UHCs, well-known private hospitals/diagnostics) carry full provenance and honest gaps — phones are deliberately NOT seeded ("Phone number unavailable" is shown) and exact coordinates await verified imports.
13. **OSM-derived records are community-mapped, not verified.** The 2025-11 HOT OSM import (HDX) brought real coverage to 64/64 districts, but names/positions come from crowd-sourced data: no phone numbers exist on those rows, some entries may be outdated or misplaced, and map presence is NOT proof of licensing. Everything lands UNVERIFIED and surfaces "Phone number unavailable" until contact verification happens through the admin queue.
13b. **DGHS bulk import remains a data-operations run.** `/api/admin/directory/import` + dedup + quality scoring + verification queue are built and smoke-tested; the authoritative DGHS facility registry import would further raise record quality on top of the OSM baseline.
14. **Google Places requires an API key.** Without `GOOGLE_MAPS_API_KEY`, places routes return `configured:false`; the UI uses registry data + official Google Maps universal links. No Place IDs are ever fabricated.
15. **Union/area navigation is schema-ready but data-empty.** The API returns an honest empty list with a note until an official union dataset is imported.
16. **Coverage is measured, not claimed.** The admin dashboard shows actual districts covered (currently 12/64) and field gaps instead of advertising full national coverage.

## Platform
9. **SQLite, not PostGIS, in the sandbox.** The schema and distance queries are written to port; the GIST/ST_DWithin path is documented but unexercised here.
10. **Login rate limiting is per-IP.** 10/15 min/IP protects credentials but is aggressive behind large shared NATs (some BD mobile carriers). Production should add per-account lockout + SMS OTP as a second factor.
11. **Notifications are in-app.** There is no SMS/push yet — the notification center and reminder engine are complete, delivery channels are interface-defined.
12. **Encryption at rest is file-level only** in the sandbox; production PostgreSQL volume encryption is a deployment task (documented in SECURITY.md).
13. **No automated visual-regression tests.** Browser verification is executed and documented per release manually (agent-browser), not in CI.
14. **Backup/restore automation is documented, not running** in the sandbox — it requires the production database environment.

## External integrations (interfaces ready, intentionally not simulated as live)
15. SMS / push providers, POS systems, distributor APIs, DGDA serialization, national health datasets — each has a correct integration surface and a safe fallback, and none pretends to be connected.
