# OshudhScan 2.0 — Testing Report

Execution date: 2026-11-22 · Commit state: working tree at final review.

## 1. Unit tests — `bun test` → **57 pass, 0 fail (2,677 assertions)** — includes the National Directory block (normalization/dedup, quality score, CSV parser, map-link formats, dataset integrity)

| Suite | Covers |
| --- | --- |
| brand resolver (9 tests) | exact/alias/molecule/fuzzy tiers, 72 % confidence gate, dose `1+0+1` parsing, duration parsing, normalization |
| safety engine (6 tests) | R1 warfarin×NSAID MAJOR, QT stack, duplicate detection, worstSeverity ordering, deterministic output |
| reminders (7 tests) | slot expansion, missed-dose window, course completion, refill threshold, adherence math |
| geo & hours (5 tests) | haversine, distance formatting, stock freshness (STALE), expired batch, OSM embed URL |
| i18n (4 tests) | bn/en parity, fallback chain, `isLocale`, **medicine identity never translated** |
| Bangla templates (2 tests) | `1+0+1` → Bangla slots, digit conversion |
| datasets (5 tests) | 8 divisions, 64 districts, parent linkage + coords, no duplicate names, verified emergency numbers |
| security primitives (2 tests) | scrypt verify + wrong-password rejection, unique salt |
| location picker / misc (8 tests) | picker selection logic, formatting helpers |

## 2. End-to-end API smoke — `tests/api-smoke.sh` → **84 pass, 0 fail — ALL GREEN** — includes the 22-check "national healthcare directory" section (locations cascade, directory search + filters, GPS nearby, reports queue, verification ladder, coverage honesty, graceful Places mode)

| Section (checks) | What is proven |
| --- | --- |
| auth (4) | login OK, cookie session persists, wrong password → 401 |
| rbac (3) | anonymous → 401; patient blocked from admin → 403; admin stats OK |
| rate limiting (1) | 13th rapid login → 429 |
| locations (1) | 64 districts served with `total` |
| medicines (5) | napa in KB, alternatives+savings, **R1 warfarin flag**, **cumulative paracetamol MAJOR (>3 g)**, honest unregistered barcode |
| finder + availability (2) | demo pharmacies within 5 km of Mirpur; Napa stock found with freshness |
| patient workflow (8) | prescription save/list, reminder schedule (5 d × 2 slots = 10 doses), **slot/perDay mismatch rejected**, due list, TAKEN log, snooze follow-up, schedule STOP |
| documents vault (5) | upload, owner download, **401 without auth**, **404 for other user**, delete |
| family + consent (2) | family member add, GPS consent recorded |
| reservation flow (3) | create, pharmacy CONFIRMED, **patient cannot fulfill → 403** |
| pharmacy management (6) | owner inventory access, **non-staff → 403**, expired batch → 422, batch add, sale, FIFO −3 decrement |
| admin queue (4) | pharmacy registration → PENDING, admin approve → VERIFIED, rule retire/re-enable, audit log populated |
| assistant guardrails (2) | chest-pain message → 999 short-circuit; "What is Napa?" → KB citation |
| healthcare (4) | Dhaka hospitals ≥ 8, doctor directory honestly 0, appointment accepted (real facility id), unknown facility → 400 |
| analytics (2) | pharmacy 14-day series; admin de-identified with privacyNote |
| preserved AI (3) | decode sample-c (warfarin case), explain endpoint, TTS returns > 1 kB audio |

### Defects found & fixed during this test round
1. **RBAC leak (high):** `GET /api/pharmacies/[id]/inventory` exposed purchase prices to any signed-in user → now staff-only (`assertPharmacyAccess`), patients use `/api/availability`.
2. **Analytics 500 (high):** `/api/analytics/pharmacy` read a dynamic `params.id` that doesn't exist on its static route → now reads `?pharmacyId=`.
3. **Appointment FK 500 (medium):** nonexistent `facilityId` caused an opaque 500 → explicit existence validation returns 400 `VALIDATION`.
4. **`/api/locations` missing `total`** → added (matches smoke + client usage).
5. **TTS hardening:** `ZAI.create()` was outside the timeout race → now both init and call are timeout-wrapped with one retry.
6. **Smoke harness J() (test-only):** jq-style vs python expressions, `d.items` dict-method shadowing, bool→"1" output, `.` stdin marker, `printf %PDF` — harness fixed to false-positive-free state.

## 3. Browser verification (agent-browser, Chromium)

| Check | Result |
| --- | --- |
| Home at 1440 px (hero mesh, gradient headline, stat band, pain cards, steps, deep panel, footer) | renders, no console errors |
| Home at 375 px (stacked layout, bottom tab bar, safe areas) | renders correctly |
| Find Pharmacy (filters, cards, stock badges) | renders, data loads |
| Scan & Decode → "Chronic pain (heart patient)" sample | live pipeline, **"Decoded — 1 MAJOR safety flag"** toast |
| Language toggle bn→en | nav + hero + auth switch instantly, no reload |
| Sign-in (demo patient) | session set, locale switches to user preference (bn), bell badge 9+ |
| Patient dashboard (signed in) | stat cards, 67 % profile completion, today's doses with TAKEN/SKIP, notifications (12) — all live data |
| `bun run lint` | clean |

## 4. Not yet covered (honest gaps)
- No automated screenshot/visual-regression suite (manual browser verification documented above).
- No load tests; rate-limiter behaviour under multi-IP NAT is untested in production conditions.
- OCR failure-path tests run against the curated `degraded` sample, not a statistically large handwritten corpus.
- PostGIS-specific queries untested (SQLite sandbox); the port is documented but not exercised.
