# OshudhScan 2.0 — Database Schema & Migrations

> ORM: Prisma 6. Sandbox provider: SQLite (`db/custom.db`). Production target: PostgreSQL 16 + PostGIS 3.

## 1. Model map (prisma/schema.prisma)

| Domain | Models |
| --- | --- |
| Identity & access | `User`, `Session`, `UserConsent`, `AuditLog`, `Notification` |
| Patient | `PatientProfile`, `FamilyMember`, `MedicalDocument`, `AssistantConversation`, `AssistantMessage` |
| Pharmacy | `Pharmacy`, `PharmacyBranch`, `PharmacyVerification`, `PharmacyStaff` |
| Medicine | `Medicine`, `MedicineBarcode`, `ClinicalRule`, `MedicineInteraction` |
| Prescribing | `Prescription`, `PrescriptionItem`, `DosageSchedule`, `MedicineReminder`, `ReminderLog` |
| Inventory & trade | `PharmacyInventory`, `InventoryMovement`, `PharmacySale`, `Supplier`, `MedicineReservation`, `Lead` |
| Healthcare | `HealthcareFacility`, `Doctor`, `AppointmentRequest` |
| Geography | `AdministrativeLocation` (8 divisions, 64 districts, upazilas) |

Conventions applied throughout: cuid primary keys, foreign keys with explicit relations, `createdAt/updatedAt`, soft delete (`deletedAt`) on `User`, `Pharmacy`, `MedicalDocument`; unique constraints (`User.email`, `Session.token`, `PharmacyInventory @@unique([pharmacyId, medicineId, batchNumber])`, `MedicineBarcode.barcode`); status enums as constrained strings (`ACTIVE/CANCELLED`, `PENDING/VERIFIED/REJECTED`, `IN_STOCK/LOW_STOCK/OUT_OF_STOCK/STALE/UNKNOWN`).

## 2. Geospatial design (SQLite now → PostGIS later)

Sandbox-safe columns today:

```prisma
model Pharmacy {
  lat Float
  lng Float
  @@index([lat, lng])
}
```

PostgreSQL migration path (documented, not yet executed — sandbox has no PostGIS):

```sql
ALTER TABLE "Pharmacy" ADD COLUMN geog geography(Point,4326);
UPDATE "Pharmacy" SET geog = ST_SetSRID(ST_MakePoint(lng, lat), 4326)::geography;
CREATE INDEX "Pharmacy_geog_gist" ON "Pharmacy" USING GIST (geog);
-- distance query replaces haversine():
-- SELECT * FROM "Pharmacy"
--  WHERE ST_DWithin(geog, ST_MakePoint(:lng,:lat)::geography, :meters);
```

`src/lib/geo.ts` haversine implementation is a drop-in replacement for the same radius filters and is what the sandbox endpoints use today (verified by smoke tests against seeded Mirpur coordinates).

## 3. Migration commands

```bash
bun run db:push       # push schema to SQLite (sandbox dev)
bun run db:generate   # regenerate Prisma client
bun run db:migrate    # prisma migrate dev (production flow)
bun run db:reset      # reset + reseed
bun run scripts/seed.ts   # idempotent seed (users, demo pharmacies, 22 facilities, 13 rules, locations)
```

## 4. Seeded data provenance

| Dataset | Source | Rows |
| --- | --- | --- |
| Administrative divisions/districts | Bangladesh Bureau of Statistics (BBS) public admin areas | 8 + 64 + upazilas (121 location rows) |
| Pharmacies | 5 demo records (`isDemo` badged) + 3,575 real OSM rows (UNVERIFIED, attributed) | 3,580 |
| Healthcare facilities | Curated institution directory + HOT OSM (ODbL) national import — full provenance columns (`source`, `sourceType`, `sourceUrl`, `verificationStatus`, `qualityScore`); phones deliberately not seeded on OSM rows | 2,942 (+6 national hotlines) |
| Medicine KB | Manual curation from DGDA-published retail price lists, `lastReviewed` column | 26 |
| Clinical rules | Curated from WHO/Bangladesh guidelines, each with `ruleId`, evidence source, reviewer, `lastReviewed` | 13 |
| Demo users | patient / pharmacy-owner / admin with scrypt-hashed passwords | 3 |
| Doctors | none — directory honestly empty until verified data exists | 0 |

## 4b. National directory tables (2.0 directory module)

| Table | Purpose |
| --- | --- |
| `AdministrativeLocation` | 8 divisions / 64 districts / 489 upazilas (BBS), `parentCode` hierarchy, bilingual names, `UNION`/`AREA` levels reserved |
| `HealthcareFacility` | + `hospitalCategory`, `sourceType/sourceUrl`, `verificationStatus`, `qualityScore`, `googlePlaceId`, website/email/emergencyPhone |
| `Pharmacy` | + `verificationStatus`, `sourceName/sourceUrl`, `googlePlaceId`, `qualityScore` |
| `FacilityReport` | public correction reports → admin queue (never auto-applied) |
| `VerificationEvent` | immutable provenance trail of every status change |
| `DirectoryImportJob` / `DirectoryImportError` | ingestion jobs with per-row error capture |
| `GooglePlaceRecord` | cached Google Places API responses (placeId separate from internal ids) |

## 5. Patient-data isolation

- Every patient-scoped query filters by `patientUserId` / owner relation server-side; cross-user access returns 404 (smoke-tested).
- `MedicalDocument` rows store metadata only; binary content is served through an authenticated handler — unauthenticated requests get 401 (smoke-tested).
- Marketing surfaces (`Lead`) never join patient clinical tables; leads carry prescription-derived **item labels only**, no patient identity.
