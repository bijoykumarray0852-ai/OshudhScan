import ZAI from 'z-ai-web-dev-sdk';
import { readFile } from 'fs/promises';
const b64 = (await readFile('/tmp/vision-test/sample-rx.png')).toString('base64');
const zai = await ZAI.create();
const completion = await zai.chat.completions.createVision({
  model: 'glm-4.5v',
  messages: [
    { role: 'assistant', content: 'Return strict JSON: {"medicines": [{"brand_raw": string}]}' },
    { role: 'user', content: [
      { type: 'text', text: 'List medicine brand names on this prescription.' },
      { type: 'image_url', image_url: { url: `data:image/png;base64,${b64}` } },
    ]},
  ],
  thinking: { type: 'disabled' },
});
console.log('OK:', completion?.choices?.[0]?.message?.content?.slice(0, 200));
