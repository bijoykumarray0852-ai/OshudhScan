// OshudhScan — Hackathon project write-up (.docx)
// Skill compliance: R1 cover recipe (design-system.md), MC-1 Medical Blue palette,
// Profile A formal fonts (Times New Roman, English doc), line 312 (1.3x),
// tables: PERCENTAGE widths + margins + ShadingType.CLEAR + tableHeader + cantSplit,
// cover section margin 0 + 16838 exact wrapper + allNoBorders. No TOC (short doc).
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  ImageRun, Header, Footer, PageNumber, NumberFormat, AlignmentType,
  HeadingLevel, WidthType, BorderStyle, ShadingType, TableLayoutType,
  LevelFormat,
} = require("docx");
const fs = require("fs");

// ---------- palette: MC-1 Medical Blue ----------
const PAL = {
  bg: "F5F8FC", primary: "1A5276", accent: "2E86C1",
  cover: { bg: "F5F8FC", titleColor: "1A5276", subtitleColor: "606060",
           metaColor: "707070", accent: "2E86C1", footerColor: "A0A0A0" },
  table: { headerBg: "2E86C1", headerText: "FFFFFF", accentLine: "1A5276",
           innerLine: "D0DDE8", surface: "EDF3F8" },
};
const TNR = { ascii: "Times New Roman", hAnsi: "Times New Roman" };

// ---------- border constants (mandatory allNoBorders) ----------
const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB,
                       insideHorizontal: NB, insideVertical: NB };

// ---------- design-system layout functions ----------
function estimateTextWidth(text, pt) {
  let width = 0;
  for (const ch of text) {
    const code = ch.codePointAt(0);
    const isCJK = (code >= 0x4E00 && code <= 0x9FFF) || (code >= 0x3400 && code <= 0x4DBF) ||
      (code >= 0x3000 && code <= 0x303F) || (code >= 0xFF00 && code <= 0xFFEF) ||
      (code >= 0x2E80 && code <= 0x2EFF);
    width += isCJK ? pt * 20 : pt * 11;
  }
  return width;
}

function splitTitleLines(title, charsPerLine) {
  if (title.length <= charsPerLine) return [title];
  const breakAfter = new Set([..."-_/ \t", ...",.;:!?"]);
  const lines = [];
  let remaining = title;
  while (remaining.length > charsPerLine) {
    let breakAt = -1;
    for (let i = charsPerLine; i >= Math.floor(charsPerLine * 0.6); i--) {
      if (i < remaining.length && breakAfter.has(remaining[i - 1])) { breakAt = i; break; }
    }
    if (breakAt === -1) {
      const limit = Math.min(remaining.length, Math.ceil(charsPerLine * 1.3));
      for (let i = charsPerLine + 1; i < limit; i++) {
        if (breakAfter.has(remaining[i - 1])) { breakAt = i; break; }
      }
    }
    if (breakAt === -1) breakAt = charsPerLine;
    lines.push(remaining.slice(0, breakAt).trim());
    remaining = remaining.slice(breakAt).trim();
  }
  if (remaining) lines.push(remaining);
  if (lines.length > 1 && lines[lines.length - 1].length <= 2) {
    const last = lines.pop();
    lines[lines.length - 1] += last;
  }
  return lines;
}

function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  // width-aware (Latin ~55% width) per design-system estimateTextWidth guidance
  const avgW = (pt) => Math.max(estimateTextWidth(title, pt) / Math.max([...title].length, 1), 1);
  const cpl = (pt) => Math.floor(maxWidthTwips / avgW(pt));
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    const c = cpl(titlePt);
    if (c < 2) { titlePt -= 2; continue; }
    lines = splitTitleLines(title, c);
    if (lines.length <= 3) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = splitTitleLines(title, cpl(minPt)); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}

function calcCoverSpacing(params) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
          metaLineCount = 0, fixedHeight = 800, pageHeight = 16838,
          marginTop = 0, marginBottom = 0 } = params;
  const SAFETY = 1200;
  const usableHeight = pageHeight - marginTop - marginBottom - SAFETY;
  const titleHeight = titleLineCount * (titlePt * 23 + 200);
  const subtitleHeight = hasSubtitle ? (12 * 23 + 600) : 0;
  const englishLabelHeight = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaHeight = metaLineCount * (10 * 23 + 100);
  const implicitParaHeight = 3 * 300;
  const contentHeight = titleHeight + subtitleHeight + englishLabelHeight +
                        metaHeight + fixedHeight + implicitParaHeight;
  const remainingSpace = usableHeight - contentHeight;
  const safeRemaining = Math.max(remainingSpace, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(safeRemaining * 0.45);
  const rawBottom = Math.floor(safeRemaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(safeRemaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

// ---------- Recipe R1: Pure Paragraph Left ----------
function buildCoverR1(config) {
  const P = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: P.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "),
        size: 18, color: P.accent, font: { ascii: "Calibri", eastAsia: "SimHei" },
        characterSpacing: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300,
                 line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true,
        color: P.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL }, spacing: { after: 800 },
      children: [new TextRun({ text: config.subtitle, size: 24, color: P.subtitleColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200 }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: P.metaColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: P.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: P.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        " }),
      new TextRun({ text: config.footerRight || "", size: 16, color: P.footerColor, font: { ascii: "Arial" } }),
    ],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.bg }, borders: noBorders,
        children,
      })],
    })],
  })];
}

// ---------- content helpers ----------
function runs(text, base = {}) {
  const parts = String(text).split("**");
  const out = [];
  for (let i = 0; i < parts.length; i++) {
    if (parts[i] === "") continue;
    out.push(new TextRun({
      text: parts[i],
      bold: i % 2 === 1 ? true : (base.bold || undefined),
      size: base.size || 24,
      color: base.color || "000000",
      italics: base.italics || undefined,
      font: TNR,
    }));
  }
  return out;
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: PAL.primary, font: TNR })],
  });
}

function body(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { after: 120, line: 312 },
    children: runs(text),
  });
}

function caption(text) {
  return new Paragraph({
    keepNext: true,
    spacing: { before: 200, after: 100, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: PAL.primary, font: TNR })],
  });
}

function makeTable(headers, rows, widths) {
  const cellPara = (text, isHeader) => new Paragraph({
    spacing: { line: 312 },
    children: [new TextRun({
      text, bold: isHeader || undefined, size: 21,
      color: isHeader ? PAL.table.headerText : "000000", font: TNR,
    })],
  });
  const mkCell = (text, i, isHeader) => new TableCell({
    width: { size: widths[i], type: WidthType.PERCENTAGE },
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    shading: isHeader ? { type: ShadingType.CLEAR, fill: PAL.table.headerBg } : undefined,
    children: [cellPara(text, isHeader)],
  });
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: PAL.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: PAL.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      insideVertical: NB,
    },
    rows: [
      new TableRow({
        tableHeader: true, cantSplit: true,
        children: headers.map((t, i) => mkCell(t, i, true)),
      }),
      ...rows.map(r => new TableRow({
        cantSplit: true,
        children: r.map((t, i) => mkCell(t, i, false)),
      })),
    ],
  });
}

function demoItem(text) {
  return new Paragraph({
    numbering: { reference: "list-demo", level: 0 },
    alignment: AlignmentType.LEFT,
    spacing: { after: 80, line: 312 },
    children: runs(text),
  });
}

// ---------- chart image ----------
const IMG_PATH = "/home/z/my-project/scripts/arr_chart.png";
const img = fs.readFileSync(IMG_PATH);
const iw = img.readUInt32BE(16), ih = img.readUInt32BE(20);
const dw = 520, dh = Math.round(dw * ih / iw);

// ---------- document body ----------
const bodyChildren = [];

// 1. Executive Summary
bodyChildren.push(h1("1. Executive Summary"));
bodyChildren.push(body(
  "OshudhScan is a point-of-care AI application that turns the smartphone already sitting on a pharmacy counter into a prescription safety net for Bangladesh. The pharmacist photographs a handwritten prescription; within roughly 2.5 seconds the system reads it, resolves every scribbled brand name against a curated Bangladesh drug knowledge base, screens the combination with a deterministic interaction and duplicate-therapy engine, and produces a plain-Bengali dosage card the patient can both read and hear. The same scan is routed to the pharmacy's own dashboard as a qualified lead, with safety flags marking exactly which lines need a second look before the medicine is handed over."));
bodyChildren.push(body(
  "This is a working demo, not a concept deck. The deployed application runs a live GLM-4.5V vision pipeline on real prescription photographs, a Bengali large language model (LLM) explainer with a deterministic template fallback, and Bengali text-to-speech (TTS) voice cards. The safety core is deliberately not generative: an auditable rules engine encodes 8 drug-class interaction rules, a cumulative paracetamol dose guard and a same-molecule duplicate detector over a 26-drug Bangladesh formulary, and it refuses to guess. Any brand it cannot resolve above a 72% confidence cutoff is escalated to pharmacist review."));
bodyChildren.push(body(
  "Commercially, OshudhScan is a business-to-business-to-consumer (B2B2C) subscription for pharmacies — a free Listing tier, Lead Engine Pro at BDT 1,999 per month and Chain at BDT 7,999 per month for up to five branches — plus a 6% platform fee on generic-substituted orders routed through partner distributors. An illustrative three-year projection, built from assumptions that are adjustable sliders inside the demo, reaches BDT 66.5M annual recurring revenue (ARR) by Year 3. The addressable base is more than 100,000 licensed retail pharmacies in a domestic pharmaceutical market worth USD 3.39 billion at the end of 2024 and growing 17.7% a year."));

// 2. Problem
bodyChildren.push(h1("2. The Problem: A Handwritten Prescription With No Safety Net"));
bodyChildren.push(body(
  "Almost every outpatient visit in Bangladesh ends with a handwritten prescription, written in a private shorthand of brand names and local dose notation such as **1+0+1** for morning, noon and night. The retail pharmacist is usually the first — and often the only — point of contact with the health system, and has seconds to interpret the handwriting with no clinical decision-support tool behind the counter. A misread strength, a misread drug class or a misread duration goes straight into a sale."));
bodyChildren.push(body(
  "Three failure modes dominate the counter. First, **duplicate therapy**: patients buy two brands of the same molecule because the names look different — Seclo and Losectil are both omeprazole 20 mg, a gastric-acid medicine — and pay double for zero added benefit. Second, **invisible interactions**: a patient on the anticoagulant Warf (warfarin, a blood thinner) is handed an NSAID (non-steroidal anti-inflammatory drug) painkiller such as Flexi, a pairing that multiplies the risk of serious gastrointestinal bleeding. Third, **unusable instructions**: the patient leaves with tablets but without a usable understanding of the dose, because the notation — and often the language — is not theirs."));
bodyChildren.push(body(
  "The bill is paid in adverse drug events, wasted household money and eroded trust. Bangladesh has more than 100,000 licensed retail pharmacies under the Directorate General of Drug Administration (DGDA), with an average purchase basket of about BDT 650, and today none of these checks happen systematically at the point of dispensing. That is the gap OshudhScan fills."));

// 3. What we built
bodyChildren.push(h1("3. What We Built: A Five-Stage Counter Pipeline"));
bodyChildren.push(body(
  "OshudhScan sits inside the pharmacy's existing workflow: one photograph, one screen, one decision. The pipeline below runs end-to-end in the demo application — every stage is real code with measured behaviour, not a mock-up. Table 1 summarises the stages, the technology behind each and the output that flows to the next stage."));
bodyChildren.push(caption("Table 1: The five-stage decoding and safety pipeline"));
bodyChildren.push(makeTable(
  ["Stage", "What happens", "Output"],
  [
    ["1. Capture & decode", "GLM-4.5V vision model reads the photographed prescription in about 2.5 seconds", "Doctor, date, drug lines, dose notation (1+0+1), duration"],
    ["2. Brand resolution", "Fuzzy match cascade — exact name, aliases, molecule name, edit distance — behind a 72% confidence gate", "Matched brand, generic molecule, class, unit price; low-confidence lines escalated"],
    ["3. Safety screen", "Deterministic rules engine: class interaction matrix, cumulative dose guard, duplicate detector", "Ranked findings (major / moderate / minor), each with a dispense action"],
    ["4. Explain & speak", "Bengali LLM explainer with deterministic template fallback; TTS voice card", "Plain-Bengali dosage card plus playable audio (24 kHz WAV)"],
    ["5. Complete the sale", "Inventory coverage check, generic substitution, lead routing", "Stock status, savings estimate, lead with safety flag pushed to the dashboard"],
  ],
  [16, 46, 38]));
bodyChildren.push(body(
  "Two design decisions carry the whole product. First, the AI does perception and language — reading and explaining — but it never decides safety; that stays with the deterministic engine, which is auditable line by line. Second, the resolver has a hard confidence gate: below 72% it says \"pharmacist review required\" instead of inventing a match. In a live end-to-end test with a photographed handwritten prescription, the pipeline resolved 4 of 4 brand lines and correctly triggered the paracetamol dose guard."));

// 4. Safety engine
bodyChildren.push(h1("4. The Safety Engine: Rules, Not Guesses"));
bodyChildren.push(body(
  "The core intellectual property is the rules layer, curated from standard clinical references and tuned to the pairings that actually harm patients in Bangladesh. It runs over a 26-drug demo formulary of widely used brands — Napa, Seclo, Flexi, Warf, Amodis, Zimax and others — each mapped from brand to generic molecule to therapeutic class to indicative retail and generic unit prices. Table 2 lists the interaction matrix and the standing guards."));
bodyChildren.push(caption("Table 2: Interaction matrix and dose guards (rule IDs as implemented)"));
bodyChildren.push(makeTable(
  ["Rule", "Trigger", "Severity", "Engine action"],
  [
    ["R1", "Warfarin (anticoagulant) + any NSAID", "MAJOR", "Do not dispense without prescriber confirmation; suggest paracetamol-based pain relief"],
    ["R2", "Warfarin + regular paracetamol above 1 g/day", "MODERATE", "Recommend a mid-course INR check (blood-clotting measure); counsel on bruising or bleeding"],
    ["R3", "Two NSAIDs on the same prescription", "MAJOR", "Dispense one only; confirm with the prescriber which to keep"],
    ["R4", "Two proton-pump inhibitor brands (duplicate class)", "MODERATE", "Dispense one brand; show the generic-equivalence card"],
    ["R5", "Two antihistamine brands", "MODERATE", "Keep one; confirm day/night intent with the prescriber"],
    ["R6", "Azithromycin + ondansetron (QT prolongation, a heart-rhythm risk)", "MODERATE", "Check heart medication and potassium; advise ECG follow-up if palpitations occur"],
    ["R7", "Losartan (blood-pressure medicine) + NSAID", "MODERATE", "Shortest NSAID course possible; monitor blood pressure at home"],
    ["R8", "Metronidazole + alcohol", "MAJOR", "Print the Bangla warning card; ban alcohol until 3 days after the last dose"],
    ["Dose guard", "Paracetamol accumulated across all items", "MAJOR above 3 g/day; monitor above 2 g/day", "Reduce to a single paracetamol source; never dispense as written above the threshold"],
  ],
  [10, 32, 20, 38]));
bodyChildren.push(body(
  "Beyond the class matrix, the engine runs a same-molecule duplicate detector (two brands, one identical generic), an azithromycin regimen sanity check — twice-daily dosing of a once-daily antibiotic usually means a misread digit — and a mandatory escalation path for every unmatched item. On the demo's Infection & Vomiting sample it catches the azithromycin–ondansetron QT pairing and fires the metronidazole alcohol guard on the same prescription; on Chronic Pain (Cardiac Patient) it blocks the warfarin-plus-NSAID combination, one of the classic near-misses at the counter."));

// 5. Patient card
bodyChildren.push(h1("5. A Dosage Card the Patient Can Actually Use"));
bodyChildren.push(body(
  "Decoding and safety are for the pharmacy; the patient-facing layer is deliberately Bengali-first and voice-first. The explainer turns each line into a plain sentence with the meal instruction, course length and relevant warning attached, for example: \"সকালে ১টি, রাতে ১টি • খাবারের ৩০ মিনিট আগে • ৫ দিন\" (one tablet in the morning and one at night, 30 minutes before food, for 5 days). When the LLM is unavailable, a deterministic template builds the same card from structured data, so the patient card cannot hallucinate."));
bodyChildren.push(body(
  "For low-literacy patients the card speaks: TTS renders the instructions as audio at the counter, so understanding does not depend on reading. Lifestyle bans are printed as bold Bangla warning lines — for metronidazole the card says \"মেট্রোনিডাজল খাওয়ার সময় ও শেষ ডোজের ৩ দিন পর্যন্ত অ্যালকোহল একদম নিষিদ্ধ\" (alcohol is strictly forbidden during treatment and for 3 days after the last dose). One photograph in, one spoken card out: that is the counter experience."));

// 6. Business
bodyChildren.push(h1("6. The Business: Pharmacies Pay for the Lead Flow"));
bodyChildren.push(body(
  "Revenue comes from the pharmacy's own hunger for footfall. Every decoded prescription is a qualified lead that arrives with clinical context — what the patient is buying and which safety flags are raised — so the counter can act on it immediately. Table 3 shows the subscription tiers and the distributor partnership."));
bodyChildren.push(caption("Table 3: Subscription tiers and partnership model"));
bodyChildren.push(makeTable(
  ["Tier", "Price", "What the pharmacy gets"],
  [
    ["Listing", "BDT 0 (free)", "Stock directory listing, 5 patient leads per month, generic-equivalence card with your price, basic footfall analytics"],
    ["Lead Engine Pro", "BDT 1,999 / month", "Unlimited safety-context leads, priority ranking in the stock matcher, refill reminders, WhatsApp lead cards, duplicate-and-interaction advisory badge"],
    ["Chain", "BDT 7,999 / month (up to 5 branches)", "Consolidated multi-branch dashboard, branch-level stock transfer suggestions, API webhook into your POS, co-branded dosage cards"],
    ["Distributor partnership", "6% platform fee", "Generic-substituted orders route through partner distributors at lower wholesale prices; the pharmacy keeps the margin"],
  ],
  [20, 22, 58]));
bodyChildren.push(body(
  "The unit economics are deliberately transparent. With the demo's default ROI assumptions — 45 decoded prescriptions per day within a 2 km radius, an 8% capture rate, 35% lead-to-fill conversion, a BDT 650 average basket and a 14% gross margin — a Pro pharmacy sees about 3.6 leads and 1.3 filled orders per day, roughly BDT 3,440 of monthly gross profit against the BDT 1,999 fee: a **1.7x return**, rising to about 2.0x with the 18% repeat-purchase uplift modelled for refill reminders. Every assumption is an adjustable slider in the demo, so partners audit the math instead of trusting a promise."));
bodyChildren.push(body(
  "The market context was verified against public reporting: a USD 3.39 billion domestic pharmaceutical market at the end of 2024, growing 17.7% a year, with more than 100,000 licensed retail pharmacies. The demo models a conservative BDT 90 value per qualified lead. Table 4 and Figure 1 show the illustrative three-year projection."));
bodyChildren.push(caption("Table 4: Illustrative 3-year ARR projection (assumptions stated in-app)"));
bodyChildren.push(makeTable(
  ["Year", "Pharmacies", "Subscription ARR (BDT M)", "Partnership & data (BDT M)", "Total (BDT M)"],
  [
    ["Year 1", "150", "3.60", "0", "3.6"],
    ["Year 2", "700", "17.64", "2.50", "20.1"],
    ["Year 3", "1,800", "47.52", "19.00", "66.5"],
  ],
  [16, 16, 26, 24, 18]));
bodyChildren.push(new Paragraph({
  keepNext: true,
  alignment: AlignmentType.CENTER,
  spacing: { before: 200, after: 60 },
  children: [new ImageRun({ data: img, transformation: { width: dw, height: dh }, type: "png" })],
}));
bodyChildren.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 200, line: 312 },
  children: [new TextRun({ text: "Figure 1: Stacked ARR projection — subscriptions plus partnership revenue (BDT million)", size: 21, color: "5B6B7D", font: TNR })],
}));

// 7. Architecture
bodyChildren.push(h1("7. Under the Hood: Architecture"));
bodyChildren.push(body(
  "The demo is a single Next.js 16 (React) application in TypeScript with three AI endpoints. /api/decode sends the prescription photo to GLM-4.5V for optical character recognition (OCR) and structured extraction; /api/explain generates the Bengali dosage card with a deterministic template fallback; /api/tts synthesises the voice card and wraps the returned audio stream in a 24 kHz WAV header for browser playback. All model calls go through the z-ai SDK."));
bodyChildren.push(body(
  "The decision layer is local, deterministic and inspectable: the drug knowledge base (26 entries), the interaction rules engine, the fuzzy brand resolver, inventory and lead routing for partner pharmacies, and a finance module that computes the ROI and the projection on the fly. The interface has five views — Home, Scan & Decode with live pipeline stages, AI Architecture including a knowledge-graph diagram, Pharmacy Portal with the lead inbox, and Pricing with the interactive ROI calculator — and stays responsive down to a 375-pixel mobile viewport."));

// 8. Demo script
bodyChildren.push(h1("8. What the Demo Shows: A One-Minute Walk-Through"));
bodyChildren.push(body("Judges can re-run the full story in about a minute:"));
bodyChildren.push(demoItem("Load the curated sample **Chronic Pain (Cardiac Patient)**: the engine raises the MAJOR warfarin-by-NSAID bleeding banner, adds the losartan advisory, and recommends calling the prescriber and switching to paracetamol-based pain relief."));
bodyChildren.push(demoItem("Open the **Pharmacy Portal**: the same scan arrives as a live lead wearing a SAFETY FLAG badge; accept it to complete the lead-routing flow."));
bodyChildren.push(demoItem("Back in **Scan & Decode**, upload any real prescription photograph: GLM-4.5V decodes it live in about 2.5 seconds, and unmatched lines stop at the 72% gate instead of being guessed."));
bodyChildren.push(demoItem("Play the **Bengali voice dosage card**: the counter audio reads the plain-Bengali instructions aloud."));
bodyChildren.push(demoItem("Run the **Fever & Gastric** sample for a clean decode: per-item generic savings are computed on screen; the live photo test returned a 62% basket-level saving."));
bodyChildren.push(demoItem("Open **Pricing**: drag the ROI sliders (1.7x at defaults) and watch the 3-year ARR chart climb from BDT 3.6M to 66.5M."));
bodyChildren.push(body(
  "Every step above was exercised end-to-end in the browser during testing — curated samples, real photo uploads, voice playback, lead acceptance, the ROI calculator and the 375-pixel mobile layout — so the same path can be demonstrated live without preparation."));

// 9. Impact
bodyChildren.push(h1("9. Impact, SDG Alignment and What Comes Next"));
bodyChildren.push(body(
  "The work maps directly to Sustainable Development Goal 3.8 — access to safe, effective and affordable essential medicines for all. Preventing a duplicate purchase or a dangerous pairing is harm reduction at the very last mile of the health system, and generic substitution converts straight into household savings: per-unit generic prices in the demo formulary run roughly **17% to 71%** below brand prices."));
bodyChildren.push(body(
  "For pharmacists, the product reframes the counter from a shop into a safety checkpoint. The advisory badge becomes a trust signal, refill reminders pull patients back for adherence, and the safety flag protects the pharmacy from dispensing errors. The pharmacy gets measurable footfall, the patient gets safer medicine, and the platform gets a repeatable revenue line."));
bodyChildren.push(body(
  "The demo is honest about its limits: the formulary is a 26-drug subset of the thousands of brands marketed in Bangladesh, prices are indicative rather than a live DGDA feed, and the pharmacist stays in the loop by design — every low-confidence line is escalated, never auto-dispensed. The roadmap follows those edges: full-formulary coverage synced with DGDA data, Bengali speech input for phone-in refills, wholesale feed integration with distributor partners, and a counter pilot with a chain pharmacy in Dhaka."));

// ---------- assemble ----------
const doc = new Document({
  numbering: {
    config: [{
      reference: "list-demo",
      levels: [{
        level: 0, format: LevelFormat.DECIMAL, text: "%1.",
        alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } },
      }],
    }],
  },
  styles: {
    default: {
      document: {
        run: { font: TNR, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: TNR, size: 32, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 } },
      },
      heading2: {
        run: { font: TNR, size: 28, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 } },
      },
    },
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 0, bottom: 0, left: 0, right: 0 },
        },
      },
      children: buildCoverR1({
        title: "OshudhScan",
        subtitle: "The Prescription Decoder & Medicine Safety Net",
        englishLabel: "PROJECT WRITE-UP",
        metaLines: [
          "Track: Digital Health — SDG 3, Good Health & Well-Being",
          "Live pipeline: GLM-4.5V vision OCR · Bengali LLM · Bengali TTS",
          "Deterministic safety engine · 26-drug Bangladesh formulary",
        ],
        footerLeft: "OshudhScan · Digital Health Track",
        footerRight: "November 2026",
        palette: PAL.cover,
      }),
    },
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
          pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: "OshudhScan — Project Write-Up", size: 18, color: "808080", font: TNR })],
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: TNR })],
          })],
        }),
      },
      children: bodyChildren,
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("/home/z/my-project/download/OshudhScan-Project-Writeup.docx", buf);
  console.log("DOCX written:", buf.length, "bytes; image", iw + "x" + ih, "->", dw + "x" + dh);
});
