#!/bin/bash
# OshudhScan API smoke test — exercises every major public workflow.
set -u
BASE="http://localhost:3000"
PASS=0; FAIL=0

check() { # name, expected_condition (0=ok)
  if [ "$2" = "0" ]; then PASS=$((PASS+1)); echo "PASS: $1";
  else FAIL=$((FAIL+1)); echo "FAIL: $1"; fi
}

j() { python3 -c "import json,sys; d=json.load(sys.stdin); print(eval(sys.argv[1]))" "$1" 2>/dev/null; }

echo "== 1. Locations cascade =="
R=$(curl -s "$BASE/api/locations/divisions")
check "divisions list (8)" "$([ "$(echo "$R" | j 'len(d["divisions"])')" = "8" ] && echo 0)"
R=$(curl -s "$BASE/api/locations/districts?division=Khulna")
N=$(echo "$R" | j 'len(d["districts"])')
check "districts of Khulna ($N > 0)" "$([ "$N" -gt 0 ] && echo 0)"
DIST=$(echo "$R" | j 'd["districts"][0]["name"]')
R=$(curl -s "$BASE/api/locations/upazilas?district=$DIST")
N=$(echo "$R" | j 'len(d["upazilas"])')
check "upazilas of $DIST ($N > 0)" "$([ "$N" -gt 0 ] && echo 0)"
R=$(curl -s "$BASE/api/locations/unions?upazila=Savar")
check "unions endpoint honest (empty ok, has note)" "$([ -n "$(echo "$R" | j 'str(d["total"])')" ] && echo 0)"

echo "== 2. Directory: division + district filters =="
R=$(curl -s "$BASE/api/directory/hospitals?division=Khulna&pageSize=5")
T=$(echo "$R" | j 'd["total"]'); D=$(echo "$R" | j 'd["hospitals"][0]["division"]')
check "hospitals division=Khulna → total=$T, first division=$D" "$([ "$D" = "Khulna" ] && echo 0)"
R=$(curl -s "$BASE/api/directory/hospitals?division=Barishal&district=Bhola&pageSize=5")
D=$(echo "$R" | j 'd["hospitals"][0]["district"]' 2>/dev/null)
check "hospitals district=Bhola → $D" "$([ "$D" = "Bhola" ] && echo 0)"
R=$(curl -s "$BASE/api/directory/hospitals?q=clinic&division=Sylhet&pageSize=5")
T=$(echo "$R" | j 'd["total"]')
check "name+division combined search Sylhet ($T results)" "$([ "$T" -ge 0 ] && echo 0)"

echo "== 3. Distance ranking near Dhaka =="
R=$(curl -s "$BASE/api/directory/search?lat=23.8103&lng=90.4125")
D1=$(echo "$R" | j 'd["pharmacies"]["rows"][0]["distanceKm"]')
DN=$(echo "$R" | j 'len(d["pharmacies"]["rows"])')
check "search returns $DN pharmacies, nearest ${D1}km ≤ 1" "$(python3 -c "print(0 if float('$D1' or 99) <= 1 else 1)")"

echo "== 4. Pharmacy finder with division =="
R=$(curl -s "$BASE/api/pharmacies?division=Rangpur&pageSize=5")
T=$(echo "$R" | j 'd["total"]'); D=$(echo "$R" | j 'd["pharmacies"][0]["division"]')
check "pharmacies division=Rangpur → total=$T division=$D" "$([ "$D" = "Rangpur" ] && echo 0)"
R=$(curl -s "$BASE/api/pharmacies?q=lazz&pageSize=5")
T=$(echo "$R" | j 'd["total"]')
check "pharmacy name search 'lazz' ($T hits)" "$([ "$T" -ge 1 ] && echo 0)"

echo "== 5. Medicine availability =="
R=$(curl -s "$BASE/api/availability?q=napa&district=Dhaka")
N=$(echo "$R" | j 'len(d["results"])')
check "availability napa in Dhaka ($N results)" "$([ "$N" -ge 1 ] && echo 0)"
R=$(curl -s "$BASE/api/availability?q=napa&division=Khulna")
N=$(echo "$R" | j 'len(d["results"])')
check "availability napa in Khulna division ($N results)" "$([ "$N" -ge 0 ] && echo 0)"

echo "== 6. Decode pipeline (sample) =="
R=$(curl -s -X POST "$BASE/api/decode" -H "Content-Type: application/json" -d '{"sampleId":"sample-a"}')
OK=$(echo "$R" | j 'd["ok"]'); MEDS=$(echo "$R" | j 'len(d["medicines"])')
check "decode sample ok=$OK meds=$MEDS" "$([ "$OK" = "True" ] && echo 0)"
RXID=$(echo "$R" | j 'str(d.get("prescriptionId") or "")')

echo "== 7. Explain =="
R=$(curl -s -X POST "$BASE/api/explain" -H "Content-Type: application/json" -d '{"items":[{"id":"m0","brand":"Napa","generic":"Paracetamol","strength":"500 mg","dose":"1+0+1","duration":"5 days","meal":"after","therapeuticClass":"Analgesic"}]}')
OK=$(echo "$R" | j 'd["ok"]')
check "explain ok=$OK" "$([ "$OK" = "True" ] && echo 0)"

echo "== 8. Medicines + checker + alternatives + barcode =="
R=$(curl -s "$BASE/api/medicines?q=napa")
N=$(echo "$R" | j 'len(d["medicines"])')
check "medicines search napa ($N)" "$([ "$N" -ge 1 ] && echo 0)"
MID=$(echo "$R" | j 'd["medicines"][0]["id"]')
R=$(curl -s "$BASE/api/medicines/alternatives?id=$MID")
ALT=$(echo "$R" | j 'len(d["alternatives"])')
check "alternatives for medicine ($ALT alts)" "$([ "$ALT" -ge 0 ] && echo 0)"
R=$(curl -s -X POST "$BASE/api/medicines/check" -H "Content-Type: application/json" -d '{"items":[{"name":"Napa"},{"name":"Seclo"}]}')
GEN=$(echo "$R" | j 'd["generatedBy"]')
check "interaction checker generatedBy=$GEN" "$([ -n "$GEN" ] && echo 0)"
R=$(curl -s "$BASE/api/medicines/barcode?code=8951000123456")
check "barcode lookup responds" "$([ -n "$(echo "$R" | j 'str(d.get("found"))')" ] && echo 0)"

echo "== 9. Coverage dashboard =="
R=$(curl -s "$BASE/api/directory/coverage")
F=$(echo "$R" | j 'd["national"]["total"]'); DC=$(echo "$R" | j 'd["national"]["districtsWithData"]')
check "coverage: records=$F districtsCovered=$DC/64" "$(python3 -c "print(0 if int('$F' or 0) > 1000 else 1)")"

echo "== 10. Reports + auth-gated endpoints behave =="
R=$(curl -s -X POST "$BASE/api/reports" -H "Content-Type: application/json" -d '{"entityType":"PHARMACY","entityId":"demo-pharmacy-1","reportType":"WRONG_PHONE","message":"Automated smoke test report — number disconnected","reporterContact":"smoke-test"}')
OK=$(echo "$R" | j 'd.get("ok") or d.get("report",{}).get("ok") or 0')
check "report submission accepted" "$([ "$OK" = "True" ] && echo 0)"
R=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/admin/stats")
check "admin/stats without auth → 401 ($R)" "$([ "$R" = "401" ] && echo 0)"
R=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/patients/profile")
check "patient profile without auth → 401 ($R)" "$([ "$R" = "401" ] && echo 0)"

echo "== 11. Auth flow (demo patient) =="
R=$(curl -s -c /tmp/smoke-cookies.txt -X POST "$BASE/api/auth" -H "Content-Type: application/json" -d '{"mode":"signin","email":"patient@oshudhscan.com","password":"Patient#2026"}')
OK=$(echo "$R" | j 'd["ok"]')
check "signin demo patient ok=$OK" "$([ "$OK" = "True" ] && echo 0)"
R=$(curl -s -b /tmp/smoke-cookies.txt "$BASE/api/auth/me")
U=$(echo "$R" | j 'd["user"]["role"]')
check "session role=$U" "$([ "$U" = "PATIENT" ] && echo 0)"
R=$(curl -s -b /tmp/smoke-cookies.txt "$BASE/api/prescriptions")
N=$(echo "$R" | j 'len(d.get("prescriptions", d.get("items", [])))')
check "prescription history ($N items)" "$([ "$N" -ge 0 ] && echo 0)"

echo "== 12. Pages render =="
for P in "/" ; do
  C=$(curl -s -o /dev/null -w "%{http_code}" "$BASE$P")
  check "page $P → $C" "$([ "$C" = "200" ] && echo 0)"
done

echo
echo "RESULT: $PASS passed, $FAIL failed"
exit $([ "$FAIL" = "0" ] && echo 0 || echo 1)
