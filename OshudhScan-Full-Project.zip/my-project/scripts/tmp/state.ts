import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const fac = await db.healthcareFacility.count({ where: { deletedAt: null } });
const ph = await db.pharmacy.count({ where: { deletedAt: null } });
const cov = (await db.healthcareFacility.groupBy({ by: ["district"], _count: true, where: { deletedAt: null, district: { not: null } } })).length;
process.stdout.write(`STATE: facilities=${fac} pharmacies=${ph} districtsCovered=${cov}/64\n`);
process.exit(0);
