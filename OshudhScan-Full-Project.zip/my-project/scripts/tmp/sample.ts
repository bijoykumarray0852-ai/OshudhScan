import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const mc = await db.healthcareFacility.findFirst({ where: { hospitalCategory: "MEDICAL_COLLEGE", sourceType: "OSM" }, select: { name: true, nameBangla: true, district: true, upazila: true, verificationStatus: true, qualityScore: true } });
  console.log("OSM medical college:", mc);
  const uhc = await db.healthcareFacility.findFirst({ where: { hospitalCategory: "UPAZILA_HEALTH_COMPLEX", sourceType: "OSM" }, select: { name: true, district: true, upazila: true } });
  console.log("OSM UHC:", uhc);
  const rural = await db.healthcareFacility.findMany({ where: { district: "Barguna" }, take: 4, select: { name: true, type: true, hospitalCategory: true } });
  console.log("Barguna facilities:", rural);
  const ruralPh = await db.pharmacy.count({ where: { district: "Barguna" } });
  const dhakaPh = await db.pharmacy.count({ where: { district: "Dhaka" } });
  console.log("pharmacies — Barguna:", ruralPh, "Dhaka:", dhakaPh);
  const byType = await db.healthcareFacility.groupBy({ by: ["type"], _count: true });
  console.log("facilities by type:", byType.map(t => `${t.type}:${t._count}`).join(", "));
}
main().finally(() => process.exit(0));
