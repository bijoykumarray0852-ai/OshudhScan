import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const GENERIC = new Set(["clinic","community clinic","hospital","health complex","community center","community centre","new clinic","health center","health centre","pharmacy","medical","dispensary","upazila health complex","district hospital","sadar hospital","blood bank","diagnostic centre","diagnostic center","laboratory","family welfare center","health care center"]);
async function main() {
  const facs = await db.healthcareFacility.findMany({ where: { sourceType: "OSM" }, select: { id: true, name: true } });
  const delF = facs.filter(f => GENERIC.has(f.name.toLowerCase().trim()));
  for (const f of delF) await db.healthcareFacility.delete({ where: { id: f.id } });
  const phs = await db.pharmacy.findMany({ where: { sourceType: "OSM" }, select: { id: true, name: true } });
  const delP = phs.filter(p => GENERIC.has(p.name.toLowerCase().trim()));
  for (const p of delP) await db.pharmacy.delete({ where: { id: p.id } });
  console.log(`removed generic: facilities=${delF.length}, pharmacies=${delP.length}`);
  console.log(`totals: facilities=${await db.healthcareFacility.count()}, pharmacies=${await db.pharmacy.count()}`);
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
