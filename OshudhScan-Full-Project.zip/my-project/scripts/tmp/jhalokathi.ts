import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import { recordKey, qualityScore } from "../../src/lib/directory";
const db = new PrismaClient();
const SOURCE = "OpenStreetMap contributors (ODbL) — HOT export via HDX";
const SOURCE_URL = "https://data.humdata.org/dataset/hotosm_bgd_health_facilities";
function centroid(g: { type: string; coordinates: unknown }) {
  if (g.type === "Point") { const [lng, lat] = g.coordinates as [number, number]; return { lat, lng }; }
  const ring = (g.coordinates as number[][][])[0] ?? [];
  let sLat = 0, sLng = 0;
  for (const [lng, lat] of ring) { sLat += lat; sLng += lng; }
  return ring.length ? { lat: sLat / ring.length, lng: sLng / ring.length } : null;
}
async function main() {
  const geo = JSON.parse(readFileSync("/tmp/hdx/health_facilities.geojson", "utf-8"));
  const existing = await db.healthcareFacility.findMany({ where: { district: "Jhalokathi", deletedAt: null }, select: { name: true } });
  const keys = new Set(existing.map(r => recordKey(r.name, "Jhalokathi")));
  let added = 0;
  for (const f of geo.features) {
    const p = f.properties;
    if ((p.adm2_name ?? "").toLowerCase().trim() !== "jhalokathi") continue;
    const am = p.amenity ?? ""; const hc = p.healthcare ?? "";
    const type = (am === "hospital" || hc === "hospital") ? "HOSPITAL" : (am === "clinic" || hc === "clinic") ? "CLINIC" : (am === "pharmacy" || hc === "pharmacy") ? null : (hc === "laboratory") ? "DIAGNOSTIC" : null;
    if (!type) continue;
    const name = (p.name_en || p.name || p.name_latin || "").trim();
    if (!name) continue;
    const geom = centroid(f.geometry); if (!geom) continue;
    const key = recordKey(name, "Jhalokathi");
    if (keys.has(key)) continue;
    keys.add(key);
    await db.healthcareFacility.create({ data: {
      name, nameBangla: (p.name_bn ?? "").trim() || null, type,
      hospitalCategory: type === "HOSPITAL" ? (/medical college/i.test(name) ? "MEDICAL_COLLEGE" : /upazila health complex/i.test(name) ? "UPAZILA_HEALTH_COMPLEX" : /district|sadar|general/i.test(name) ? "DISTRICT_HOSPITAL" : "OTHER") : null,
      ownership: p.operator_type === "government" || p.operator_type === "public" ? "PUBLIC" : p.operator_type === "private" ? "PRIVATE" : null,
      division: "Barishal", district: "Jhalokati" === "x" ? "" : "Jhalokathi", upazila: null, area: (p.adm3_name ?? "").trim() || null,
      addressLine: (p.addr_full || p.addr_city || (p.adm3_name ?? "") || "Jhalokathi").trim(),
      lat: Math.round(geom.lat * 100000) / 100000, lng: Math.round(geom.lng * 100000) / 100000,
      services: "[]", specialties: "[]", emergency: false, isDemo: false,
      source: SOURCE, sourceType: "OSM", sourceUrl: SOURCE_URL, verificationStatus: "UNVERIFIED",
      qualityScore: qualityScore({ name: true, nameBangla: Boolean(p.name_bn), type: true, ownership: Boolean(p.operator_type), division: true, district: true, upazila: false, address: true, latLng: true, phone: false, services: false, source: true, verified: false }),
    }});
    added++;
    console.log("added:", name, "|", type);
  }
  const cov = (await db.healthcareFacility.groupBy({ by: ["district"], _count: true, where: { deletedAt: null } })).length;
  console.log(`Jhalokathi facilities added: ${added} | districts covered: ${cov}/64`);
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
