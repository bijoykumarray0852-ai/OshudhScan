import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const groups = await db.healthcareFacility.groupBy({ by: ["district"], _count: true, where: { deletedAt: null } });
  const canonical = new Set((await db.administrativeLocation.findMany({ where: { level: "DISTRICT" }, select: { name: true } })).map(d => d.name));
  const unknown = groups.filter(g => !g.district || !canonical.has(g.district));
  console.log("non-canonical district groups:", JSON.stringify(unknown));
  const jh = await db.healthcareFacility.count({ where: { district: "Jhalokathi", deletedAt: null } });
  console.log("Jhalokathi facilities:", jh);
  const jhRows = await db.healthcareFacility.findMany({ where: { district: { contains: "Jhalok" } }, select: { name: true, district: true, type: true } });
  console.log("Jhalok* rows:", jhRows.slice(0, 8));
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
