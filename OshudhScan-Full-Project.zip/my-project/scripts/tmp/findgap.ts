import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const districts = await db.administrativeLocation.findMany({ where: { level: "DISTRICT" }, select: { name: true } });
  for (const d of districts) {
    const fac = await db.healthcareFacility.count({ where: { district: d.name, deletedAt: null } });
    if (fac === 0) {
      const ph = await db.pharmacy.count({ where: { district: d.name, deletedAt: null } });
      console.log("district with 0 facilities:", d.name, "| pharmacies:", ph);
    }
  }
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
