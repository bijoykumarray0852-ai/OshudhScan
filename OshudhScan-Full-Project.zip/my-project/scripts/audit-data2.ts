// Audit 2: demo flags, sources, verification status
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const facDemo = await prisma.healthcareFacility.groupBy({
    by: ["isDemo"],
    _count: { _all: true },
    where: { deletedAt: null },
  });
  console.log("=== Facility isDemo ===");
  for (const r of facDemo) console.log("isDemo:", r.isDemo, r._count._all);

  const facSource = await prisma.healthcareFacility.groupBy({
    by: ["sourceType"],
    _count: { _all: true },
    where: { deletedAt: null },
  });
  console.log("=== Facility sourceType ===");
  for (const r of facSource) console.log(r.sourceType, r._count._all);

  const facVerif = await prisma.healthcareFacility.groupBy({
    by: ["verificationStatus"],
    _count: { _all: true },
    where: { deletedAt: null },
  });
  console.log("=== Facility verificationStatus ===");
  for (const r of facVerif) console.log(r.verificationStatus, r._count._all);

  // Sample facilities outside Dhaka
  const sample = await prisma.healthcareFacility.findMany({
    where: { deletedAt: null, division: { not: "Dhaka" }, type: "HOSPITAL" },
    select: {
      name: true,
      division: true,
      district: true,
      upazila: true,
      hospitalCategory: true,
      ownership: true,
      sourceType: true,
      verificationStatus: true,
      lat: true,
      lng: true,
      phone: true,
    },
    take: 12,
    orderBy: { name: "asc" },
  });
  console.log("\n=== Sample non-Dhaka hospitals ===");
  for (const f of sample) console.log(JSON.stringify(f));

  const phDemo = await prisma.pharmacy.groupBy({
    by: ["isDemo"],
    _count: { _all: true },
    where: { deletedAt: null },
  });
  console.log("\n=== Pharmacy isDemo ===");
  for (const r of phDemo) console.log("isDemo:", r.isDemo, r._count._all);

  const phByDiv = await prisma.pharmacy.groupBy({
    by: ["division"],
    _count: { _all: true },
    where: { deletedAt: null },
  });
  console.log("=== Pharmacy by division ===");
  for (const r of phByDiv) console.log(r.division ?? "(null)", r._count._all);

  // Sample pharmacies outside Dhaka
  const phSample = await prisma.pharmacy.findMany({
    where: { deletedAt: null, division: { not: "Dhaka" } },
    select: {
      name: true,
      division: true,
      district: true,
      upazila: true,
      addressLine: true,
      lat: true,
      lng: true,
      contactPhone: true,
      status: true,
    },
    take: 8,
    orderBy: { name: "asc" },
  });
  console.log("\n=== Sample non-Dhaka pharmacies ===");
  for (const p of phSample) console.log(JSON.stringify(p));

  // check upazila sample names + parent codes
  const upz = await prisma.administrativeLocation.findMany({
    where: { level: "UPAZILA" },
    select: { code: true, name: true, nameBangla: true, parentCode: true, division: true, district: true },
    take: 6,
    orderBy: { code: "asc" },
  });
  console.log("\n=== Sample upazilas ===");
  for (const u of upz) console.log(JSON.stringify(u));
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
