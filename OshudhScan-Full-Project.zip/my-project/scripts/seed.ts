/**
 * OshudhScan 2.0 database seed — idempotent.
 * Seeds ONLY verified/curated data:
 *  - BBS administrative geography (8 divisions, 64 districts, verified upazila subset)
 *  - 26-drug demo knowledge base (from src/lib/drug-db.ts) + class-level clinical info
 *  - Clinical rules registry (mirrors the deterministic engine's R1–R8 + guards)
 *  - National emergency hotlines (verified public numbers)
 *  - Major public/private facilities (address-level public knowledge, phones left unverified)
 *  - 5 demo pharmacies (clearly marked isDemo) with demo inventory
 *  - Demo accounts: admin / patient / pharmacy owner
 *
 * Run: bun run scripts/seed.ts
 */
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";
import { DRUG_DB } from "../src/lib/drug-db";
import { PHARMACIES } from "../src/lib/pharmacies";
import { DIVISIONS, DISTRICTS, UPAZILAS } from "../src/lib/data/locations";
import { EMERGENCY_SERVICES, FACILITIES } from "../src/lib/data/emergency";

const db = new PrismaClient();

// Field-completeness quality score (0–100) — mirrors lib/directory.ts so the
// seed and the ingestion API produce identical values.
function qualityScore(fields: {
  name: boolean; nameBangla: boolean; type: boolean; ownership: boolean;
  division: boolean; district: boolean; upazila: boolean; address: boolean;
  latLng: boolean; phone: boolean; services: boolean; source: boolean; verified: boolean;
}): number {
  const weights = { name: 10, nameBangla: 8, type: 6, ownership: 6, division: 4, district: 6, upazila: 4, address: 10, latLng: 10, phone: 12, services: 8, source: 6, verified: 10 };
  const total = Object.values(weights).reduce((a, b) => a + b, 0);
  const got = Object.entries(fields).filter(([, v]) => v).reduce((a, [k]) => a + weights[k as keyof typeof weights], 0);
  return Math.round((got / total) * 100);
}

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64);
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

// Class-level clinical info — standard, textbook-level pharmacology statements.
const CLASS_INFO: Record<string, { indications: string; contraindications: string; sideEffects: string; storage: string }> = {
  "analgesic-paracetamol": {
    indications: "Fever, mild to moderate pain (headache, body ache, dental pain)",
    contraindications: "Severe liver disease; avoid extra paracetamol from combination products",
    sideEffects: "Rare at normal doses — nausea, rash; overdose causes liver damage",
    storage: "Store below 30°C, away from moisture",
  },
  ppi: {
    indications: "Acid reflux (GERD), gastric and duodenal ulcers, H. pylori regimens",
    contraindications: "Known hypersensitivity; long-term use needs medical review",
    sideEffects: "Headache, diarrhoea, nausea; long-term: low B12/magnesium",
    storage: "Store below 30°C, protect from moisture",
  },
  antihistamine: {
    indications: "Allergic rhinitis, urticaria, itching, common-cold allergy symptoms",
    contraindications: "Caution with sedatives/alcohol; severe liver impairment",
    sideEffects: "Drowsiness (some), dry mouth, dizziness",
    storage: "Store below 30°C",
  },
  ltra: {
    indications: "Asthma prevention (maintenance), allergic rhinitis",
    contraindications: "Not for acute asthma attacks; hypersensitivity",
    sideEffects: "Headache, abdominal pain; rarely mood changes",
    storage: "Store below 30°C",
  },
  saba: {
    indications: "Quick relief of asthma symptoms, bronchospasm",
    contraindications: "Not for daily maintenance without controller therapy; caution in heart disease",
    sideEffects: "Tremor, palpitations, restlessness",
    storage: "Keep inhaler below 30°C, away from direct sunlight; do not puncture",
  },
  nsaid: {
    indications: "Pain and inflammation (arthritis, musculoskeletal pain, dental pain)",
    contraindications: "Active peptic ulcer, severe kidney disease, aspirin-sensitive asthma, third trimester pregnancy",
    sideEffects: "Stomach pain, gastritis, indigestion; long-term: ulcer/bleeding risk",
    storage: "Store below 30°C",
  },
  "nsaid-combo": {
    indications: "Pain with inflammation, when a single analgesic is insufficient",
    contraindications: "As for NSAIDs; note fixed-dose combos add a second active ingredient — check total paracetamol dose",
    sideEffects: "As for NSAIDs plus paracetamol-related liver caution if doubled up",
    storage: "Store below 30°C",
  },
  ccb: {
    indications: "High blood pressure, angina",
    contraindications: "Severe hypotension; caution in advanced aortic stenosis",
    sideEffects: "Ankle swelling, flushing, headache, dizziness",
    storage: "Store below 30°C",
  },
  arb: {
    indications: "High blood pressure, heart failure, kidney protection in diabetes",
    contraindications: "Pregnancy (2nd/3rd trimester), bilateral renal artery stenosis",
    sideEffects: "Dizziness, hyperkalaemia (rare), fatigue",
    storage: "Store below 30°C",
  },
  statin: {
    indications: "High cholesterol, cardiovascular risk reduction",
    contraindications: "Active liver disease, pregnancy; caution with some antibiotics (call pharmacist)",
    sideEffects: "Muscle aches; rarely serious muscle damage — report unexplained pain",
    storage: "Store below 30°C",
  },
  biguanide: {
    indications: "Type 2 diabetes (first-line)",
    contraindications: "Severe kidney impairment, severe liver disease; pause before contrast scans — follow doctor's instruction",
    sideEffects: "Nausea, metallic taste, loose motion (usually temporary); lactic acidosis is rare but serious",
    storage: "Store below 30°C",
  },
  macrolide: {
    indications: "Respiratory, skin and soft-tissue infections",
    contraindications: "Hypersensitivity; caution with QT-prolonging medicines — tell the pharmacist all current medicines",
    sideEffects: "Nausea, abdominal pain, diarrhoea",
    storage: "Store below 30°C; suspension often needs reconstitution — check pack",
  },
  cephalosporin: {
    indications: "Bacterial infections (urinary, respiratory, typhoid)",
    contraindications: "Serious penicillin/cephalosporin allergy history",
    sideEffects: "Diarrhoea, rash, nausea",
    storage: "Tablets below 30°C; suspension refrigerate after mixing and finish within the pack label period",
  },
  nitroimidazole: {
    indications: "Amoebiasis, giardiasis, anaerobic bacterial infections, dental infection",
    contraindications: "Alcohol during therapy and 3 days after; first trimester (consult doctor)",
    sideEffects: "Metallic taste, nausea, dark urine; disulfiram-like reaction with alcohol",
    storage: "Store below 30°C",
  },
  "antiemetic-5ht3": {
    indications: "Nausea and vomiting (including chemotherapy, post-operative)",
    contraindications: "Hypersensitivity; caution with QT-prolonging medicines",
    sideEffects: "Headache, constipation",
    storage: "Store below 30°C",
  },
  antacid: {
    indications: "Heartburn, acid indigestion",
    contraindications: "Severe kidney disease (aluminium/magnesium content); separate 2 hours from other medicines",
    sideEffects: "Constipation or loose motion depending on salt",
    storage: "Store below 30°C",
  },
  vitamin: {
    indications: "Vitamin/nutrient supplementation, neuropathy support",
    contraindications: "Rare hypersensitivity",
    sideEffects: "Generally well tolerated",
    storage: "Store below 30°C, away from light",
  },
  benzodiazepine: {
    indications: "Anxiety, seizures, short-term insomnia (prescription-only)",
    contraindications: "Do not combine with alcohol or opioids; dependence risk with long use",
    sideEffects: "Drowsiness, dizziness, memory gaps",
    storage: "Store below 30°C, locked away from children",
  },
  ors: {
    indications: "Dehydration from diarrhoea/vomiting",
    contraindications: "Not a substitute for medical care in severe dehydration — go to a hospital",
    sideEffects: "None at correct dilution; vomiting may need small frequent sips",
    storage: "Cool dry place; use prepared solution within 24 hours",
  },
  anticoagulant: {
    indications: "Blood clot prevention (atrial fibrillation, mechanical valves, DVT)",
    contraindications: "Active bleeding; many interactions — always tell the pharmacist before adding any medicine",
    sideEffects: "Bleeding/bruising — report unusual bleeding immediately",
    storage: "Store below 30°C",
  },
};

async function main() {
  console.log("Seeding OshudhScan database…");

  // 1. Geography ─────────────────────────────────────────────────────────────
  for (const d of DIVISIONS) {
    await db.administrativeLocation.upsert({
      where: { code: `DIV-${d.name.toUpperCase()}` },
      create: { code: `DIV-${d.name.toUpperCase()}`, level: "DIVISION", name: d.name, nameBangla: d.nameBangla, lat: d.lat, lng: d.lng, source: "BBS administrative areas (public)", verifiedAt: new Date() },
      update: { nameBangla: d.nameBangla, lat: d.lat, lng: d.lng },
    });
  }
  for (const d of DISTRICTS) {
    await db.administrativeLocation.upsert({
      where: { code: `DIS-${d.name.toUpperCase().replace(/[^A-Z]/g, "")}` },
      create: { code: `DIS-${d.name.toUpperCase().replace(/[^A-Z]/g, "")}`, level: "DISTRICT", name: d.name, nameBangla: d.nameBangla, parentCode: `DIV-${d.division.toUpperCase()}`, division: d.division, district: d.name, lat: d.lat, lng: d.lng, source: "BBS administrative areas (public)", verifiedAt: new Date() },
      update: { nameBangla: d.nameBangla, lat: d.lat, lng: d.lng, parentCode: `DIV-${d.division.toUpperCase()}` },
    });
  }
  for (const u of UPAZILAS) {
    const districtCode = `DIS-${u.district.toUpperCase().replace(/[^A-Z]/g, "")}`;
    await db.administrativeLocation.upsert({
      where: { code: `UPZ-${u.district.toUpperCase().replace(/[^A-Z]/g, "")}-${u.name.toUpperCase().replace(/[^A-Z]/g, "")}` },
      create: { code: `UPZ-${u.district.toUpperCase().replace(/[^A-Z]/g, "")}-${u.name.toUpperCase().replace(/[^A-Z]/g, "")}`, level: "UPAZILA", name: u.name, nameBangla: u.nameBangla, parentCode: districtCode, division: DISTRICTS.find((d) => d.name === u.district)?.division, district: u.district, source: "BBS administrative areas (public)", verifiedAt: new Date() },
      update: { nameBangla: u.nameBangla, district: u.district, parentCode: districtCode },
    });
  }
  console.log(`  geography: ${DIVISIONS.length} divisions, ${DISTRICTS.length} districts, ${UPAZILAS.length} upazilas`);

  // 2. Medicines (from the existing DRUG_DB demo knowledge base) ─────────────
  for (const drug of DRUG_DB) {
    const info = CLASS_INFO[drug.therapeuticClass];
    const meal = drug.meal === "after" ? "AFTER_MEAL" : drug.meal === "before" ? "BEFORE_MEAL" : "ANY";
    await db.medicine.upsert({
      where: { legacyId: drug.id },
      create: {
        legacyId: drug.id,
        brand: drug.brand,
        generic: drug.generic,
        genericBangla: drug.genericBangla,
        strength: drug.strengths[0] ?? null,
        strengths: JSON.stringify(drug.strengths),
        form: drug.form,
        therapeuticClass: drug.therapeuticClass,
        manufacturer: drug.manufacturer,
        aliases: drug.aliases ? JSON.stringify(drug.aliases) : null,
        unitPriceBdt: drug.unitPriceBdt,
        genericUnitPriceBdt: drug.genericUnitPriceBdt,
        meal,
        indications: info?.indications ?? null,
        contraindications: info?.contraindications ?? null,
        sideEffects: info?.sideEffects ?? null,
        storage: info?.storage ?? null,
        source: "OshudhScan demo knowledge base — verify against DGDA package insert",
        lastReviewedAt: new Date("2026-06-01"),
        isDemo: true,
      },
      update: { unitPriceBdt: drug.unitPriceBdt, genericUnitPriceBdt: drug.genericUnitPriceBdt, indications: info?.indications, contraindications: info?.contraindications, sideEffects: info?.sideEffects, storage: info?.storage },
    });
  }
  console.log(`  medicines: ${DRUG_DB.length}`);

  // 3. Clinical rules registry (governance layer for the deterministic engine)
  const RULES = [
    { ruleId: "R1", title: "Blood thinner + NSAID painkiller (bleeding risk)", severity: "MAJOR", trigger: "Anticoagulant brand co-prescribed with an NSAID", explanation: "Warfarin plus any NSAID multiplies serious GI bleeding risk; the NSAID also displaces warfarin from plasma proteins, pushing INR up unpredictably.", action: "Do NOT dispense the NSAID without prescriber confirmation; suggest paracetamol-based pain relief and contact the prescriber.", evidenceSource: "Standard anticoagulation guidance (curated); confirm against current BNF/MIMS Bangladesh", evidenceLevel: "Class recommendation (curated)" },
    { ruleId: "R2", title: "Regular paracetamol while on warfarin", severity: "MODERATE", trigger: "Anticoagulant present AND estimated paracetamol >1000 mg/day", explanation: "Regular paracetamol (>2g/day for several days) can raise INR in warfarin patients.", action: "Pharmacist to recommend an INR check mid-course; patient to report unusual bruising/bleeding.", evidenceSource: "Standard anticoagulation guidance (curated)", evidenceLevel: "Class recommendation (curated)" },
    { ruleId: "R3", title: "Two NSAIDs prescribed together", severity: "MAJOR", trigger: "Two distinct NSAID/NSAID-combo brand lines", explanation: "Two NSAIDs add ulcer, kidney and bleeding risk without added pain relief — a common handwritten-prescription mix-up.", action: "Dispense only ONE NSAID; confirm with the prescriber which to keep.", evidenceSource: "Standard NSAID safety guidance (curated)", evidenceLevel: "Class recommendation (curated)" },
    { ruleId: "R4", title: "PPI duplicate therapy", severity: "MODERATE", trigger: "Two PPI brands on one prescription", explanation: "Two proton-pump-inhibitor brands duplicate therapy; patients buy both because names look different.", action: "Dispense one brand only; show the generic-equivalence card.", evidenceSource: "Duplicate-therapy review (curated)", evidenceLevel: "Practice guidance (curated)" },
    { ruleId: "R5", title: "Duplicate antihistamines", severity: "MODERATE", trigger: "Two antihistamine brands on one prescription", explanation: "Two antihistamines stack sedation and anticholinergic effects without added benefit.", action: "Keep one; confirm daytime/night split with the prescriber if intended.", evidenceSource: "Duplicate-therapy review (curated)", evidenceLevel: "Practice guidance (curated)" },
    { ruleId: "R6", title: "Additive QT-prolongation (macrolide + 5HT3 antiemetic)", severity: "MODERATE", trigger: "Macrolide antibiotic co-prescribed with a 5-HT3 antiemetic", explanation: "Azithromycin and ondansetron both prolong the QT interval; combined use raises torsades risk, especially with electrolyte disturbance.", action: "Pharmacist to check heart medicines/potassium; advise ECG follow-up if palpitations or fainting.", evidenceSource: "QT-prolongation reference lists (curated)", evidenceLevel: "Class recommendation (curated)" },
    { ruleId: "R7", title: "ARB + NSAID (BP and kidney effect)", severity: "MODERATE", trigger: "ARB brand co-prescribed with an NSAID", explanation: "NSAIDs blunt losartan's effect and can strain kidney function, especially in older or dehydrated patients.", action: "Advise the shortest NSAID course; home BP monitoring; report swelling or reduced urination.", evidenceSource: "Standard hypertension/NSAID guidance (curated)", evidenceLevel: "Class recommendation (curated)" },
    { ruleId: "R8", title: "Metronidazole + alcohol strictly forbidden", severity: "MAJOR", trigger: "Nitroimidazole brand present", explanation: "Alcohol during metronidazole therapy (and up to 3 days after) causes a disulfiram-like reaction: flushing, severe vomiting, headache, rapid heartbeat.", action: "Counsel the patient with the Bangla alcohol-ban card.", evidenceSource: "Standard metronidazole labelling (curated)", evidenceLevel: "Label warning (curated)" },
    { ruleId: "P1", title: "Paracetamol cumulative overdose risk", severity: "MAJOR", trigger: "Estimated paracetamol >3000 mg/day across all items", explanation: "Total paracetamol exceeds the routine 3g/day caution line; patients unknowingly combine Napa with combo painkillers.", action: "Do not dispense as written; reduce to a single paracetamol source under 3g/day (2g if elderly/liver issues).", evidenceSource: "Standard paracetamol dosing guidance (curated)", evidenceLevel: "Dose threshold (curated)" },
    { ruleId: "P2", title: "Paracetamol monitoring threshold", severity: "MINOR", trigger: "Estimated paracetamol >2000 mg/day", explanation: "Within the 4g ceiling but above the 2g/day caution line for long courses, elderly or liver disease.", action: "Confirm course length with the prescriber; counsel not to add other paracetamol-containing medicines.", evidenceSource: "Standard paracetamol dosing guidance (curated)", evidenceLevel: "Dose threshold (curated)" },
    { ruleId: "D1", title: "Same generic under two brand names", severity: "MODERATE", trigger: "Two matched brands share the same molecule", explanation: "Different brand names, identical molecule — the classic double-dose/double-pay pharmacy counter error.", action: "Dispense one brand only; show the generic-equivalence card.", evidenceSource: "Duplicate-therapy review (curated)", evidenceLevel: "Practice guidance (curated)" },
    { ruleId: "A1", title: "Unusual azithromycin regimen", severity: "MINOR", trigger: "Macrolide written with a twice-daily style dose", explanation: "Common adult azithromycin 500mg course is once daily for 3 days; twice-daily suggests a misread digit or special indication.", action: "Pharmacist to confirm with the prescriber before dispensing more than 3 tablets.", evidenceSource: "Standard azithromycin regimens (curated)", evidenceLevel: "Regimen sanity check (curated)" },
    { ruleId: "U1", title: "Unrecognized medicine line", severity: "MINOR", trigger: "OCR line scored below the 72% resolver confidence cutoff", explanation: "The line may be a brand outside the current knowledge base, or OCR noise.", action: "Pharmacist review required before dispensing this line.", evidenceSource: "OshudhScan resolver confidence policy", evidenceLevel: "System policy" },
  ];
  for (const r of RULES) {
    await db.clinicalRule.upsert({
      where: { ruleId: r.ruleId },
      create: {
        ruleId: r.ruleId, title: r.title, severity: r.severity,
        triggerDescription: r.trigger, clinicalExplanation: r.explanation,
        recommendedAction: r.action, evidenceSource: r.evidenceSource,
        evidenceLevel: r.evidenceLevel, lastReviewedAt: new Date("2026-06-01"),
        status: "PUBLISHED", enabled: true,
      },
      update: { title: r.title, triggerDescription: r.trigger, clinicalExplanation: r.explanation, recommendedAction: r.action, evidenceSource: r.evidenceSource, evidenceLevel: r.evidenceLevel },
    });
  }
  console.log(`  clinical rules: ${RULES.length}`);

  // 4. Emergency services + facilities ────────────────────────────────────────
  for (const e of EMERGENCY_SERVICES) {
    const existing = await db.healthcareFacility.findFirst({ where: { name: e.name, type: e.type } });
    if (!existing) {
      await db.healthcareFacility.create({
        data: {
          name: e.name, nameBangla: e.nameBangla, type: e.type, ownership: "PUBLIC",
          division: null, district: null, addressLine: "Nationwide hotline",
          phone: e.phone, isPhoneVerified: true, emergency: true,
          services: JSON.stringify([e.description]),
          source: "National helpline directory (public)", verifiedAt: new Date(),
        },
      });
    }
  }
  for (const f of FACILITIES) {
    const facilityData = {
      name: f.name, nameBangla: f.nameBangla, type: f.type, ownership: f.ownership,
      division: f.division, district: f.district, upazila: f.upazila ?? null, area: f.area,
      addressLine: f.addressLine, lat: f.lat, lng: f.lng,
      phone: null, isPhoneVerified: false, emergency: f.emergency,
      hospitalCategory: f.hospitalCategory ?? null,
      website: f.website ?? null,
      specialties: JSON.stringify(f.specialties),
      services: JSON.stringify(f.services.concat(f.bloodBank ? ["blood_transfusion"] : [])),
      source: "Public institution directory (address-level); verify phone before dispatch",
      sourceType: "DGHS_REGISTRY",
      sourceUrl: "https://hris.mohfw.gov.bd/public/facility-registry/",
      verificationStatus: "OFFICIALLY_LISTED",
      qualityScore: qualityScore({ name: true, nameBangla: Boolean(f.nameBangla), type: true, ownership: true, division: true, district: true, upazila: Boolean(f.upazila), address: true, latLng: true, phone: false, services: true, source: true, verified: true }),
      verifiedAt: new Date(),
      lastVerifiedAt: new Date(),
    };
    const existing = await db.healthcareFacility.findFirst({ where: { name: f.name } });
    if (!existing) {
      await db.healthcareFacility.create({ data: facilityData });
    } else {
      await db.healthcareFacility.update({ where: { id: existing.id }, data: facilityData });
    }
  }
  console.log(`  emergency: ${EMERGENCY_SERVICES.length}, facilities: ${FACILITIES.length}`);

  // 5. Demo accounts ─────────────────────────────────────────────────────────
  const admin = await db.user.upsert({
    where: { email: "admin@oshudhscan.com" },
    create: { email: "admin@oshudhscan.com", name: "Platform Admin", passwordHash: hashPassword("Admin#2026"), role: "ADMIN", locale: "en" },
    update: {},
  });
  const patient = await db.user.upsert({
    where: { email: "patient@oshudhscan.com" },
    create: {
      email: "patient@oshudhscan.com", name: "Rahima Akter", passwordHash: hashPassword("Patient#2026"),
      role: "PATIENT", locale: "bn",
    },
    update: {},
  });
  await db.patientProfile.upsert({
    where: { userId: patient.id },
    create: { userId: patient.id, gender: "FEMALE", bloodGroup: "B+", weightKg: 58, heightCm: 158, district: "Dhaka", division: "Dhaka", area: "Mirpur", allergies: JSON.stringify(["Dust"]), chronicConditions: JSON.stringify([]) },
    update: {},
  });
  const owner = await db.user.upsert({
    where: { email: "pharmacy@oshudhscan.com" },
    create: { email: "pharmacy@oshudhscan.com", name: "Medinova Owner", passwordHash: hashPassword("Pharma#2026"), role: "PHARMACY_OWNER", locale: "en" },
    update: {},
  });
  await db.userConsent.upsert({
    where: { id: `consent-${patient.id}-DATA_PROCESSING` },
    create: { id: `consent-${patient.id}-DATA_PROCESSING`, userId: patient.id, consentType: "DATA_PROCESSING", granted: true, version: "1.0" },
    update: {},
  });

  // 6. Demo pharmacies + inventory (from the existing demo network) ───────────
  const medicines = await db.medicine.findMany({ where: { legacyId: { not: null } } });
  const medByLegacy = new Map(medicines.map((m) => [m.legacyId, m]));
  let invCount = 0;
  for (const [i, ph] of PHARMACIES.entries()) {
    const row = await db.pharmacy.upsert({
      where: { id: `demo-pharmacy-${i + 1}` },
      create: {
        id: `demo-pharmacy-${i + 1}`,
        name: ph.name,
        contactPhone: ph.phone,
        addressLine: ph.address,
        division: "Dhaka", // demo network is Mirpur/Savar — both in Dhaka division
        district: ph.district,
        area: ph.area,
        lat: ph.lat,
        lng: ph.lng,
        openingHours: JSON.stringify({ open: "08:00", close: "23:00" }),
        services: JSON.stringify(ph.open24h ? ["home_delivery", "24_hours"] : ph.homeDelivery ? ["home_delivery", "card_payment"] : ["card_payment"]),
        status: "VERIFIED",
        isVerified: true,
        isDemo: true,
        rating: ph.rating,
        licenseNumber: "DEMO-" + (100 + i),
        ownerUserId: i === 0 ? owner.id : null,
      },
      update: { lat: ph.lat, lng: ph.lng, isDemo: true },
    });
    if (i === 0 && !row.ownerUserId) await db.pharmacy.update({ where: { id: row.id }, data: { ownerUserId: owner.id } });
    await db.pharmacyStaff.upsert({
      where: { pharmacyId_userId: { pharmacyId: row.id, userId: owner.id } },
      create: { pharmacyId: row.id, userId: owner.id, role: "OWNER" },
      update: {},
    });
    for (const drugId of ph.stock) {
      const med = medByLegacy.get(drugId);
      if (!med) continue;
      const qty = drugId === "warf" ? 4 : drugId === "flexi" ? 7 : 18 + ((i * 7 + drugId.length) % 25);
      const exists = await db.pharmacyInventory.findFirst({ where: { pharmacyId: row.id, medicineId: med.id } });
      if (!exists) {
        await db.pharmacyInventory.create({
          data: {
            pharmacyId: row.id, medicineId: med.id,
            batchNumber: `DEMO-B${1000 + invCount}`,
            expiryDate: new Date(2027 + (invCount % 2), invCount % 12, 15),
            purchasePrice: Math.round(med.unitPriceBdt * 0.85),
            sellingPrice: med.unitPriceBdt,
            quantity: qty,
            lowStockThreshold: 10,
            status: "ACTIVE",
          },
        });
        invCount++;
      }
    }
    await db.subscription.upsert({
      where: { pharmacyId: row.id },
      create: { pharmacyId: row.id, plan: i < 2 ? "PRO" : "FREE", status: "ACTIVE" },
      update: {},
    });
    await db.pharmacyVerification.upsert({
      where: { id: `demo-verification-${i + 1}` },
      create: { id: `demo-verification-${i + 1}`, pharmacyId: row.id, licenseNumber: "DEMO-" + (100 + i), licenseType: "RETAIL", status: "APPROVED", reviewedById: admin.id, reviewedAt: new Date(), pharmacistName: "Demo Pharmacist", pharmacistReg: "DEMO-A-1234" },
      update: {},
    });
  }
  console.log(`  pharmacies: ${PHARMACIES.length} (demo), inventory rows: ${invCount}`);

  console.log("Seed complete.");
  console.log("  Admin   : admin@oshudhscan.com / Admin#2026");
  console.log("  Patient : patient@oshudhscan.com / Patient#2026");
  console.log("  Pharmacy: pharmacy@oshudhscan.com / Pharma#2026");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
