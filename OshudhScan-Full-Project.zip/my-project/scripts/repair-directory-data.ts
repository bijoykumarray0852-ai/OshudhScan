/**
 * Directory data repair — fixes the OSM import coordinate bug and improves
 * record quality across all 8 divisions / 64 districts.
 *
 * ROOT CAUSE FIXED HERE:
 *   import-osm.ts stored lat/lng as Math.round(v*6)/10**5 instead of a
 *   6-decimal rounding, collapsing every coordinate into the Gulf of Guinea
 *   (lat≈0.0014, lng≈0.0053). The exact inverse is  value * 10**5 / 6.
 *
 * Also:
 *   1. cleans tag-suffixed names ("X, Hospital" → "X"),
 *   2. removes junk records (coordinate-named pharmacies, animal hospitals),
 *   3. reclassifies hospital categories / ownership / emergency flags,
 *   4. publishes verified-source phones for the 8 divisional medical college
 *      hospitals (official hospital websites / public directories),
 *   5. imports real Lazz Pharma Ltd branches (official website branch list —
 *      Bangladesh's first DGDA Model Pharmacy chain), phone + address only,
 *      NO invented coordinates (lat/lng stay null),
 *   6. soft-deletes duplicates created by name cleanup,
 *   7. recomputes quality scores and writes DirectoryImportJob audit rows.
 *
 * Run: bun scripts/repair-directory-data.ts
 */
import { PrismaClient } from "@prisma/client";
import { qualityScore, facilityQualityFields, recordKey } from "../src/lib/directory";

const db = new PrismaClient();

const BD_BOUNDS = { latMin: 18.5, latMax: 27.5, lngMin: 85.0, lngMax: 94.6 };

function inBangladesh(lat: number, lng: number): boolean {
  return lat >= BD_BOUNDS.latMin && lat <= BD_BOUNDS.latMax && lng >= BD_BOUNDS.lngMin && lng <= BD_BOUNDS.lngMax;
}

/** Exact inverse of the buggy transform (round(v*6)/10**5). */
function repairCoord(v: number): number {
  return Math.round((v * 10 ** 5) / 6 * 10 ** 6) / 10 ** 6;
}

// ── verified phone data for divisional medical college hospitals ─────────────
// Sources: official hospital websites (dmch.gov.bd, cmch.gov.bd, mmch.gov.bd,
// somch.gov.bd, sbmc contact page) and public directories (daktardekhaben.com,
// doctoraidbd.com) for the two that publish no official site phone.
const MCH_PHONES: Record<string, { phone: string; sourceUrl: string }> = {
  "Dhaka Medical College Hospital": { phone: "0255165001", sourceUrl: "https://dmch.gov.bd/contact" },
  "Chittagong Medical College Hospital": { phone: "0241356220", sourceUrl: "https://cmch.gov.bd/contact" },
  "Sylhet MAG Osmani Medical College Hospital": { phone: "02996631213", sourceUrl: "https://www.somch.gov.bd" },
  "Sher-e-Bangla Medical College Hospital": { phone: "0431-2173547", sourceUrl: "https://sbmc.gov.bd" },
  "Rajshahi Medical College Hospital": { phone: "0721-760254", sourceUrl: "https://rmc.gov.bd" },
  "Mymensingh Medical College Hospital": { phone: "091-67001", sourceUrl: "https://mmch.gov.bd" },
  "Khulna Medical College Hospital": { phone: "041-761535", sourceUrl: "https://kmc.gov.bd" },
  "Rangpur Medical College Hospital": { phone: "02589961571", sourceUrl: "https://rpmc.edu.bd" },
};

// ── real Lazz Pharma branches (official website, lazzpharma.com/BranchLocation)
// Contact phone + branch address as published by the operator. Coordinates are
// deliberately NOT provided — we never invent them.
const LAZZ_BRANCHES: Array<{
  branch: string; phone: string; address: string; district: string; division: string;
  upazila?: string; area?: string;
}> = [
  { branch: "Barishal (Chawck Bazar)", phone: "01318337191", address: "Folpotti Road, Chawck Bazar, Barishal", district: "Barishal", division: "Barishal", area: "Chawck Bazar" },
  { branch: "Barishal (Rupatoli)", phone: "01318337201", address: "9/5 Rupatoli Housing, Ward 24, Barishal", district: "Barishal", division: "Barishal", area: "Rupatoli" },
  { branch: "Jhalokathi", phone: "01901444871", address: "15 Ronaldos Road, Amtola Road, Jhalokathi", district: "Jhalokathi", division: "Barishal" },
  { branch: "Bhola", phone: "01740390588", address: "41 Cape Town Market, Bangla School Mor, Bhola", district: "Bhola", division: "Barishal" },
  { branch: "Sylhet", phone: "01764305082", address: "R249, Sylhet", district: "Sylhet", division: "Sylhet" },
  { branch: "Beanibazar", phone: "01754137636", address: "Beanibazar, Sylhet", district: "Sylhet", division: "Sylhet", upazila: "Beanibazar" },
  { branch: "Bogura (Sherpur Road)", phone: "01305507056", address: "Sherpur Road, Bogura", district: "Bogura", division: "Rajshahi", area: "Sherpur Road" },
  { branch: "Chattogram (Halishahar)", phone: "01332562557", address: "House-01, Road-3, Lane-1B, Block-K, Halishahar Housing Estate, Chattogram", district: "Chattogram", division: "Chattogram", area: "Halishahar" },
  { branch: "Chattogram (O.R. Nizam Road)", phone: "01911699933", address: "Opposite Metropolitan Hospital, G.C More, 949 O.R. Nizam Road, Chattogram", district: "Chattogram", division: "Chattogram", area: "O.R. Nizam Road" },
  { branch: "Chandpur", phone: "01300466256", address: "Dhali Plaza, Stadium Road, Chandpur", district: "Chandpur", division: "Chattogram" },
  { branch: "Cumilla", phone: "01714030099", address: "A K Fazlul Huq Road, Cumilla", district: "Cumilla", division: "Chattogram" },
  { branch: "Feni", phone: "01714046601", address: "Jobbar Market, Shahid Shahidullah Kaisar Road, Feni", district: "Feni", division: "Chattogram" },
  { branch: "Noakhali (Maijdee)", phone: "01841730302", address: "Zafar Plaza, Shaheed Bhulu Stadium, Maijdee, Noakhali", district: "Noakhali", division: "Chattogram", area: "Maijdee" },
  { branch: "Noakhali (Choumuhani)", phone: "01872888080", address: "East Market, Golabaria Road, Choumuhani, Begumganj, Noakhali", district: "Noakhali", division: "Chattogram", upazila: "Begumganj" },
  { branch: "Lakshmipur", phone: "01711151544", address: "R145, Lakshmipur", district: "Lakshmipur", division: "Chattogram" },
  { branch: "Dinajpur", phone: "01737121121", address: "Sadar Hospital Road (opposite Dinajpur Zilla School), Dinajpur", district: "Dinajpur", division: "Rangpur" },
  { branch: "Kurigram", phone: "01333904601", address: "Babor Tower (former Mitali Hall), near Shapla Chattar, Kurigram", district: "Kurigram", division: "Rangpur" },
  { branch: "Rangpur (Radhaballav)", phone: "01730597046", address: "RDRS, Radhaballav Road, Rangpur", district: "Rangpur", division: "Rangpur", area: "Radhaballav" },
  { branch: "Rangpur (DLS Ray Road)", phone: "01323551155", address: "DLS Ray Road (Jahan Company Shopping Complex), Rangpur", district: "Rangpur", division: "Rangpur" },
  { branch: "Khulna (Khan Jahan Ali Rd)", phone: "01707070157", address: "305 Khan Jahan Ali Road, Khulna", district: "Khulna", division: "Khulna", area: "Khan Jahan Ali Road" },
  { branch: "Khulna (Sonadanga)", phone: "01707070153", address: "Sonadanga, Khulna", district: "Khulna", division: "Khulna", area: "Sonadanga" },
  { branch: "Khulna (Boyra)", phone: "01714082045", address: "Holding-71, Choto Boyra Bazar Road, Khulna", district: "Khulna", division: "Khulna", area: "Boyra" },
  { branch: "Khulna (Moylapota)", phone: "01324713482", address: "Moylapota, Khulna", district: "Khulna", division: "Khulna", area: "Moylapota" },
  { branch: "Khulna (Daulatpur)", phone: "01715567678", address: "447 Jessore Road, Daulatpur, Khulna", district: "Khulna", division: "Khulna", area: "Daulatpur" },
  { branch: "Kushtia", phone: "01711111236", address: "Bani Hall Road, Kushtia", district: "Kushtia", division: "Khulna" },
  { branch: "Kushtia (5 Rasta Mor)", phone: "01404010002", address: "5 Rasta Mor, Kushtia", district: "Kushtia", division: "Khulna" },
  { branch: "Magura", phone: "01776500230", address: "165/51 M R Road, Magura", district: "Magura", division: "Khulna" },
  { branch: "Narail", phone: "01771555757", address: "286 Sadar Hospital Road, Anowara Awal Mondal Complex, Narail", district: "Narail", division: "Khulna" },
  { branch: "Satkhira (Kaliganj)", phone: "01714082045", address: "371 Polashpol, Kaliganj, Satkhira", district: "Satkhira", division: "Khulna", upazila: "Kaliganj" },
  { branch: "Rajshahi (Kadirganj)", phone: "01766765252", address: "159/A Kadirganj, Rajshahi 6000", district: "Rajshahi", division: "Rajshahi", area: "Kadirganj" },
  { branch: "Rajshahi (Ghosh Para)", phone: "01332562555", address: "Crystal Wahab Tower, 110 Ghoshpara Road, Rajshahi 6000", district: "Rajshahi", division: "Rajshahi", area: "Ghosh Para" },
  { branch: "Rajshahi (Rajpara)", phone: "01711244163", address: "Crystal Wahab Tower, Medical Ghosh Para, Rajpara, Rajshahi", district: "Rajshahi", division: "Rajshahi", area: "Rajpara" },
  { branch: "Pangsha", phone: "01720575157", address: "Bismillah Tower, Main Road, Pangsha, Rajbari", district: "Rajbari", division: "Rajshahi", upazila: "Pangsha" },
  { branch: "Rajbari", phone: "01319060503", address: "120 Khondokar Plaza, Boropol, Rajbari", district: "Rajbari", division: "Rajshahi" },
  { branch: "Gopalganj", phone: "01776276449", address: "Model School Road, Gopalganj", district: "Gopalganj", division: "Dhaka" },
  { branch: "Faridpur", phone: "01786305412", address: "Lazz Pharma Ltd, Faridpur", district: "Faridpur", division: "Dhaka" },
  { branch: "Faridpur (Medical Gate)", phone: "01309017517", address: "Barisal Road, Faridpur 7800", district: "Faridpur", division: "Dhaka" },
  { branch: "Madaripur", phone: "01334811134", address: "Puraton Stand, Prodhan Shorok, Madaripur", district: "Madaripur", division: "Dhaka" },
  { branch: "Shariatpur", phone: "01617954083", address: "Mannan Square, Sadar Road, Shariatpur", district: "Shariatpur", division: "Dhaka" },
  { branch: "Manikganj", phone: "01316133300", address: "207 Shahid Rafique Sarak, Manikganj", district: "Manikganj", division: "Dhaka" },
  { branch: "Munshiganj", phone: "01950406066", address: "605 Sadar Hospital Road, Munshiganj", district: "Munshiganj", division: "Dhaka" },
  { branch: "Tangail", phone: "01616796912", address: "Tangail Branch, Tangail", district: "Tangail", division: "Dhaka" },
  { branch: "Gazipur (Joydebpur)", phone: "01741940471", address: "Gazipur Sadar, Gazipur", district: "Gazipur", division: "Dhaka", upazila: "Gazipur Sadar" },
  { branch: "Tongi (Station Road)", phone: "01332502441", address: "Hazi Gofur Market, Station Road, Tongi, Gazipur", district: "Gazipur", division: "Dhaka", area: "Tongi" },
  { branch: "Mawna (Kaliakair)", phone: "01893301060", address: "Mawna, Fulbaria, Kaliakair, Gazipur", district: "Gazipur", division: "Dhaka", area: "Mawna" },
  { branch: "Savar", phone: "01977410450", address: "Thana Road, Savar, Dhaka", district: "Dhaka", division: "Dhaka", upazila: "Savar" },
  { branch: "Keraniganj (Ati Bazar)", phone: "01341731106", address: "Islam Plaza, Keraniganj, Dhaka", district: "Dhaka", division: "Dhaka", upazila: "Keraniganj" },
  { branch: "Mymensingh (Chorpara)", phone: "01994219219", address: "Chorpara, Mymensingh", district: "Mymensingh", division: "Mymensingh", area: "Chorpara" },
  { branch: "Mymensingh (Sotobazar)", phone: "01994218218", address: "Chorpara, Dhaka-Mymensingh Road, Mymensingh 2200", district: "Mymensingh", division: "Mymensingh", area: "Sotobazar" },
  { branch: "Netrokona", phone: "01625709708", address: "274 Choto Bazar, Netrokona", district: "Netrokona", division: "Mymensingh" },
  { branch: "Narayanganj (Chasara)", phone: "01308031214", address: "Balur Math, 26 Bhasha Sainik Road, Narayanganj 1400", district: "Narayanganj", division: "Dhaka", area: "Chasara" },
  { branch: "Narayanganj (Hirajheel)", phone: "01826656746", address: "MGW5+769, Hirajheel, Chittagong Road, Narayanganj", district: "Narayanganj", division: "Dhaka", area: "Hirajheel" },
  { branch: "Narsingdi (Brahmondi)", phone: "01847093090", address: "Khalpar, West Brahmondi, Narsingdi", district: "Narsingdi", division: "Dhaka" },
  { branch: "Kishoreganj", phone: "01737025762", address: "Station Road, Kishoreganj", district: "Kishoreganj", division: "Dhaka" },
  { branch: "Dhaka (Mirpur-10)", phone: "01790745120", address: "Plot 20 & 21, Senpara Parbata, Mirpur-10, Dhaka 1216", district: "Dhaka", division: "Dhaka", area: "Mirpur" },
  { branch: "Dhaka (Dhanmondi)", phone: "01741486695", address: "743 Satmasjid Road, Dhanmondi, Dhaka", district: "Dhaka", division: "Dhaka", area: "Dhanmondi" },
  { branch: "Dhaka (Gulshan-1)", phone: "01915486880", address: "Silver Tower, 52 Gulshan, Dhaka", district: "Dhaka", division: "Dhaka", area: "Gulshan" },
  { branch: "Dhaka (Motijheel)", phone: "01979949952", address: "292 Toyenbee Circular Road, Motijheel, Dhaka", district: "Dhaka", division: "Dhaka", area: "Motijheel" },
  { branch: "Dhaka (Farmgate)", phone: "01332502423", address: "82 West Tejturi Bazar, Farmgate, Dhaka 1215", district: "Dhaka", division: "Dhaka", area: "Farmgate" },
];

function cleanName(name: string, district: string | null): string {
  let n = name.trim();
  // strip amenity-tag suffixes produced by the OSM export ("X, Hospital")
  n = n.replace(/,\s*(government\s+)?(hospital|clinic|pharmacy|diagnostic\s+cent(re|er)|blood\s+bank|laboratory)\s*$/i, "");
  // strip a duplicated district suffix ("Bagerhat Eye Hospital, Bagerhat")
  if (district) {
    const esc = district.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    n = n.replace(new RegExp(`,\\s*${esc}\\s*$`, "i"), "");
  }
  return n.trim();
}

function hospitalCategoryOf(name: string): string | null {
  if (/medical college/i.test(name)) return "MEDICAL_COLLEGE";
  if (/upazila health complex/i.test(name)) return "UPAZILA_HEALTH_COMPLEX";
  if (/district (sadar )?hospital|sadar hospital|general hospital|district headquarters|\d+\s*bed hospital/i.test(name)) return "DISTRICT_HOSPITAL";
  if (/special/i.test(name)) return "SPECIALIZED";
  return null; // no evidence → keep existing category
}

function isJunkFacilityName(name: string): boolean {
  return /animal hospital|veterinary|vet clinic|livestock|cattle/i.test(name);
}

async function main() {
  const t0 = Date.now();
  const stats = {
    facCoords: 0, facCoordsNulled: 0, phCoords: 0, phCoordsNulled: 0,
    facNames: 0, phNames: 0, junkDeleted: 0, reclassified: 0,
    phonesSet: 0, lazzAdded: 0, lazzSkipped: 0, dupsSoftDeleted: 0,
  };

  const jobRepair = await db.directoryImportJob.create({
    data: { sourceType: "DATA_REPAIR", entityType: "FACILITY", fileName: "coordinate-repair-2026-11-23", status: "RUNNING", totalRows: 0 },
  });

  // ── 1. repair OSM coordinates (facilities) ──────────────────────────────────
  const facs = await db.healthcareFacility.findMany({ where: { deletedAt: null } });
  const facKeyCounts = new Map<string, number>();
  for (const f of facs) {
    const k = recordKey(f.name, f.district, f.upazila);
    facKeyCounts.set(k, (facKeyCounts.get(k) ?? 0) + 1);
  }

  for (const f of facs) {
    const updates: Record<string, unknown> = {};
    const isOsm = f.sourceType === "OSM";

    // 1a. coordinate repair
    if (f.lat != null && f.lng != null && Math.abs(f.lat) < 2 && Math.abs(f.lng) < 2) {
      const lat = repairCoord(f.lat), lng = repairCoord(f.lng);
      if (inBangladesh(lat, lng)) { updates.lat = lat; updates.lng = lng; stats.facCoords++; }
      else { updates.lat = null; updates.lng = null; stats.facCoordsNulled++; }
    }

    // 1b. name cleaning
    const cleaned = cleanName(f.name, f.district);
    if (cleaned && cleaned !== f.name) {
      // keep the record only if the cleaned name does not collide with a sibling
      const k = recordKey(cleaned, f.district, f.upazila);
      if (facKeyCounts.has(k) || isJunkFacilityName(cleaned)) {
        await db.healthcareFacility.update({ where: { id: f.id }, data: { deletedAt: new Date() } });
        stats.dupsSoftDeleted++;
        continue;
      }
      updates.name = cleaned;
      facKeyCounts.set(k, (facKeyCounts.get(k) ?? 0) + 1);
      stats.facNames++;
    }

    // 1c. junk removal (animal hospitals etc.)
    const effectiveName = (updates.name as string) ?? f.name;
    if (isJunkFacilityName(effectiveName)) {
      await db.healthcareFacility.update({ where: { id: f.id }, data: { deletedAt: new Date() } });
      stats.junkDeleted++;
      continue;
    }

    // 1d. reclassify hospital categories from cleaned names
    if (f.type === "HOSPITAL") {
      const cat = hospitalCategoryOf(effectiveName);
      if (cat && cat !== f.hospitalCategory) { updates.hospitalCategory = cat; stats.reclassified++; }
      if (cat === "UPAZILA_HEALTH_COMPLEX" || cat === "DISTRICT_HOSPITAL") {
        if (!f.ownership && !updates.ownership) updates.ownership = "PUBLIC";
      }
      if (/government/i.test(effectiveName) && !f.ownership) updates.ownership = "PUBLIC";
      // government hospital tiers with 24/7 casualty departments
      if (["MEDICAL_COLLEGE", "DISTRICT_HOSPITAL", "SPECIALIZED"].includes(cat ?? "") && !f.emergency) updates.emergency = true;
    }

    // 1e. divisional MCH phones (official/published sources)
    const mch = MCH_PHONES[effectiveName];
    if (mch && !f.phone) { updates.phone = mch.phone; stats.phonesSet++; }

    if (Object.keys(updates).length > 0) {
      const merged = { ...f, ...updates } as typeof f;
      updates.qualityScore = qualityScore(facilityQualityFields(merged));
      await db.healthcareFacility.update({ where: { id: f.id }, data: updates });
    }
  }

  // ── 2. repair OSM coordinates + clean pharmacy rows ─────────────────────────
  const phs = await db.pharmacy.findMany({ where: { deletedAt: null } });
  const phKeyCounts = new Map<string, number>();
  for (const p of phs) {
    const k = recordKey(p.name, p.district, p.upazila);
    phKeyCounts.set(k, (phKeyCounts.get(k) ?? 0) + 1);
  }
  const coordAsName = /^\s*\d{1,3}\.\d+,\s*\d{1,3}\.\d+\s*$/;

  for (const p of phs) {
    // coordinate-named junk first
    if (coordAsName.test(p.name)) {
      await db.pharmacy.update({ where: { id: p.id }, data: { deletedAt: new Date() } });
      stats.junkDeleted++;
      continue;
    }
    const updates: Record<string, unknown> = {};

    if (p.lat != null && p.lng != null && Math.abs(p.lat) < 2 && Math.abs(p.lng) < 2) {
      const lat = repairCoord(p.lat), lng = repairCoord(p.lng);
      if (inBangladesh(lat, lng)) { updates.lat = lat; updates.lng = lng; stats.phCoords++; }
      else { updates.lat = null; updates.lng = null; stats.phCoordsNulled++; }
    }

    const cleaned = cleanName(p.name, p.district);
    if (cleaned && cleaned !== p.name) {
      const k = recordKey(cleaned, p.district, p.upazila);
      if (phKeyCounts.has(k)) {
        await db.pharmacy.update({ where: { id: p.id }, data: { deletedAt: new Date() } });
        stats.dupsSoftDeleted++;
        continue;
      }
      updates.name = cleaned;
      phKeyCounts.set(k, (phKeyCounts.get(k) ?? 0) + 1);
      stats.phNames++;
    }

    if (Object.keys(updates).length > 0) {
      const merged = { ...p, ...updates } as typeof p;
      updates.qualityScore = qualityScore({
        name: true, nameBangla: Boolean(merged.nameBangla), type: true, ownership: true,
        division: Boolean(merged.division), district: Boolean(merged.district),
        upazila: Boolean(merged.upazila), address: Boolean(merged.addressLine),
        latLng: merged.lat != null && merged.lng != null, phone: Boolean(merged.contactPhone),
        services: Boolean(merged.services && merged.services !== "[]"), source: Boolean(merged.sourceName),
        verified: Boolean(merged.isVerified),
      });
      await db.pharmacy.update({ where: { id: p.id }, data: updates });
    }
  }

  // ── 3. import real Lazz Pharma branches (official website) ──────────────────
  const lazzSource = "Lazz Pharma Ltd — official website branch list";
  const lazzUrl = "https://www.lazzpharma.com/BranchLocation";
  for (const b of LAZZ_BRANCHES) {
    const name = `Lazz Pharma Ltd (${b.branch})`;
    const k = recordKey(name, b.district, b.upazila ?? null);
    if (phKeyCounts.has(k)) { stats.lazzSkipped++; continue; }
    const exists = await db.pharmacy.findFirst({
      where: { deletedAt: null, district: b.district, name: { contains: name.slice(0, 40) } },
      select: { id: true },
    });
    if (exists) { stats.lazzSkipped++; continue; }
    await db.pharmacy.create({
      data: {
        name,
        contactPhone: b.phone,
        addressLine: b.address,
        division: b.division,
        district: b.district,
        upazila: b.upazila ?? null,
        area: b.area ?? null,
        lat: null, lng: null, // honest: no coordinates — never invented
        openingHours: null,
        services: JSON.stringify(["home_delivery"]),
        licenseNumber: null,
        status: "PENDING",
        isVerified: false,
        verificationStatus: "UNVERIFIED",
        isDemo: false,
        sourceName: lazzSource,
        sourceUrl: lazzUrl,
        sourceType: "OFFICIAL_WEBSITE",
        qualityScore: qualityScore({
          name: true, nameBangla: false, type: true, ownership: true,
          division: true, district: true, upazila: Boolean(b.upazila), address: true,
          latLng: false, phone: true, services: true, source: true, verified: false,
        }),
      },
    });
    phKeyCounts.set(k, (phKeyCounts.get(k) ?? 0) + 1);
    stats.lazzAdded++;
  }

  // ── 4. final consistency pass: recompute quality scores that changed ────────
  const fixedFacs = await db.healthcareFacility.findMany({ where: { deletedAt: null } });
  for (const f of fixedFacs) {
    const qs = qualityScore(facilityQualityFields(f));
    if (f.qualityScore !== qs) {
      await db.healthcareFacility.update({ where: { id: f.id }, data: { qualityScore: qs } });
    }
  }

  await db.directoryImportJob.update({
    where: { id: jobRepair.id },
    data: {
      status: "COMPLETED",
      totalRows: fixedFacs.length,
      importedRows: stats.facCoords,
      summary: JSON.stringify({ ...stats, note: "OSM coordinate repair + cleanup + Lazz branch import" }),
      finishedAt: new Date(),
    },
  });

  console.log("REPAIR COMPLETE", JSON.stringify(stats));
  console.log(`took ${Math.round((Date.now() - t0) / 1000)}s`);
  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
