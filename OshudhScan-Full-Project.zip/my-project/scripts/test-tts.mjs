// Tests Bangla TTS via z-ai-web-dev-sdk; TTS returns raw Response object
import ZAI from 'z-ai-web-dev-sdk';
import { writeFile } from 'fs/promises';

const text = 'নাপা ৫০০ — খাবারের পরে দিনে তিনবার। সেকলো ২০ — খাবারের আধা ঘণ্টা আগে, সকালে ও রাতে।';

async function main() {
  const zai = await ZAI.create();
  const t0 = Date.now();
  const res = await zai.audio.tts.create({ input: text, voice: 'tongtong', speed: 0.9 });
  const ct = res.headers?.get?.('content-type');
  const buf = await res.arrayBuffer();
  console.log('elapsed ms:', Date.now() - t0, 'content-type:', ct, 'bytes:', buf.byteLength);
  if (buf.byteLength > 1000) {
    await writeFile('/tmp/vision-test/tts-test.mp3', Buffer.from(buf));
    console.log('saved /tmp/vision-test/tts-test.mp3');
  } else {
    console.log('preview:', Buffer.from(buf).toString('utf8').slice(0, 300));
  }
}
main().catch((e) => { console.error('TTS_TEST_FAILED:', e?.message || e); process.exit(1); });
