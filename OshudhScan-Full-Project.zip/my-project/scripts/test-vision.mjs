// Tests z-ai-web-dev-sdk createVision on a synthetic prescription image (OCR feasibility check)
import ZAI from 'z-ai-web-dev-sdk';
import { readFile } from 'fs/promises';

const SYSTEM = `You are an OCR engine for Bangladeshi medical prescriptions. Read the image and return STRICT JSON only (no markdown, no commentary) with this shape:
{"doctor": string|null, "date": string|null, "medicines": [{"brand_raw": string, "strength": string|null, "dose": string|null, "duration": string|null}]}
Dose uses Bangladesh notation like "1+0+1". If unreadable, use null.`;

async function main() {
  const b64 = (await readFile('/tmp/vision-test/sample-rx.png')).toString('base64');
  const zai = await ZAI.create();
  const t0 = Date.now();
  const completion = await zai.chat.completions.createVision({
    messages: [
      { role: 'assistant', content: SYSTEM },
      {
        role: 'user',
        content: [
          { type: 'text', text: 'Extract all medicines from this prescription photo.' },
          { type: 'image_url', image_url: { url: `data:image/png;base64,${b64}` } },
        ],
      },
    ],
    thinking: { type: 'disabled' },
  });
  const ms = Date.now() - t0;
  const content = completion?.choices?.[0]?.message?.content;
  console.log('--- elapsed ms:', ms);
  console.log('--- raw content:');
  console.log(content);
}
main().catch((e) => { console.error('VISION_TEST_FAILED:', e?.message || e); process.exit(1); });
