# ARR projection chart for OshudhScan write-up (MC-1 Medical Blue palette)
# Data mirrors src/lib/finance.ts PROJECTION (illustrative assumptions stated in app)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

years = ["Year 1", "Year 2", "Year 3"]
subscription = [3.60, 17.64, 47.52]   # 150 / 700 / 1800 pharmacies x fee x 12
partnership = [0.0, 2.50, 19.00]      # data licensing + distributor rev-share
totals = [s + p for s, p in zip(subscription, partnership)]

fig, ax = plt.subplots(figsize=(9, 5), dpi=200, constrained_layout=True)
ax.bar(years, subscription, width=0.5, color="#2E86C1", label="Subscription ARR")
ax.bar(years, partnership, width=0.5, bottom=subscription, color="#1A5276",
       label="Partnership & data ARR")
for x, t in enumerate(totals):
    ax.annotate(f"{t:.1f}", (x, t), textcoords="offset points", xytext=(0, 6),
                ha="center", fontsize=12, fontweight="bold", color="#1A5276")
ax.set_ylabel("ARR (BDT million)", fontsize=12)
ax.set_title("OshudhScan - 3-Year ARR Projection (illustrative, assumptions in-app)",
             fontsize=12.5, fontweight="bold", color="#1A5276")
ax.set_ylim(0, 78)
ax.grid(axis="y", color="#D0DDE8", linewidth=0.8)
ax.set_axisbelow(True)
for spine in ("top", "right"):
    ax.spines[spine].set_visible(False)
ax.legend(loc="upper left", frameon=False, fontsize=10)
fig.savefig("/home/z/my-project/scripts/arr_chart.png")
print("chart saved; totals:", [round(t, 2) for t in totals])

# ---- verify every number quoted in the write-up ----
leads = 45 * 8 / 100                      # capture 8% of 45 decoded Rx/day
orders = leads * 35 / 100                 # 35% fill
monthly = orders * 650 * 0.14 * 30        # basket 650, margin 14%
print(f"leads/day={leads}, orders/day={orders}, monthly_profit={monthly:.1f}, "
      f"roi={monthly/1999:.2f}x, roi_refill={monthly*1.18/1999:.2f}x")

prices = [(1.2, .8), (7.5, 2.5), (6.8, 2.5), (9.5, 4), (9, 4), (8.5, 3.5),
          (3.5, 1), (9, 3), (20, 8), (350, 200), (8.5, 4), (6.5, 3), (10, 5),
          (5, 2), (7.5, 3), (10.5, 5), (3, 1.5), (40, 20), (45, 25), (3.5, 1.5),
          (12, 5), (45, 25), (4.5, 2.5), (3.5, 1.5), (6, 5), (2.5, 1.2)]
pcts = sorted((1 - g / b) * 100 for b, g in prices)
print(f"generic savings range: {pcts[0]:.1f}% .. {pcts[-1]:.1f}%")
