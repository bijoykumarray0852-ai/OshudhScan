// Audit current data distribution: locations, facilities, pharmacies
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const locLevels = await prisma.administrativeLocation.groupBy({
    by: ["level"],
    _count: { _all: true },
  });
  console.log("=== AdministrativeLocation by level ===");
  for (const r of locLevels) console.log(r.level, r._count._all);

  const divs = await prisma.administrativeLocation.findMany({
    where: { level: "DIVISION" },
    select: { name: true, nameBangla: true, code: true },
  });
  console.log("\n=== Divisions ===");
  for (const d of divs) console.log(d.code, d.name, d.nameBangla);

  const districts = await prisma.administrativeLocation.count({
    where: { level: "DISTRICT" },
  });
  console.log("districts:", districts);

  const upazilas = await prisma.administrativeLocation.count({
    where: { level: "UPAZILA" },
  });
  console.log("upazilas:", upazilas);

  const facByDiv = await prisma.healthcareFacility.groupBy({
    by: ["division"],
    _count: { _all: true },
    where: { deletedAt: null },
  });
  console.log("\n=== HealthcareFacility by division ===");
  for (const r of facByDiv) console.log(r.division ?? "(null)", r._count._all);

  const facByDistrict = await prisma.healthcareFacility.groupBy({
    by: ["district"],
    _count: { _all: true },
    where: { deletedAt: null },
    orderBy: { _count: { district: "desc" } },
  });
  console.log("\n=== HealthcareFacility by district (top 50) ===");
  for (const r of facByDistrict.slice(0, 50))
    console.log(r.district ?? "(null)", r._count._all);

  const phByDistrict = await prisma.pharmacy.groupBy({
    by: ["district"],
    _count: { _all: true },
    where: { deletedAt: null },
  });
  console.log("\n=== Pharmacy by district ===");
  for (const r of phByDistrict) console.log(r.district ?? "(null)", r._count._all);

  const totalFac = await prisma.healthcareFacility.count({ where: { deletedAt: null } });
  const totalPh = await prisma.pharmacy.count({ where: { deletedAt: null } });
  console.log("\ntotal facilities:", totalFac, "| total pharmacies:", totalPh);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
