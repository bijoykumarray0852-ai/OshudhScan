/**
 * HOT OSM Bangladesh health-facilities import (next-steps execution).
 *
 * Source: Humanitarian Data Exchange (HDX) — "Health Facilities of Bangladesh"
 * HOT OSM export (GeoJSON), © OpenStreetMap contributors, ODbL licence.
 * https://data.humdata.org/dataset/hotosm_bgd_health_facilities
 *
 * Everything imported is REAL community-mapped data with full provenance.
 * Rows land UNVERIFIED (map presence ≠ official listing ≠ license verified)
 * and flow into the existing admin verification queue. Dedup uses the shared
 * recordKey pipeline (normalized name + district + upazila).
 *
 * Run: bun scripts/import-osm.ts /tmp/hdx/health_facilities.geojson
 */
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import { recordKey, qualityScore } from "../src/lib/directory";

const db = new PrismaClient();

const SOURCE_NAME = "OpenStreetMap contributors (ODbL) — HOT export via HDX";
const SOURCE_URL = "https://data.humdata.org/dataset/hotosm_bgd_health_facilities";
const SOURCE_TYPE = "OSM";

// OSM legacy/alternate district names → canonical district names (BBS list).
const DISTRICT_ALIASES: Record<string, string> = {
  barisal: "Barishal",
  chittagong: "Chattogram",
  brahamanbaria: "Brahmanbaria",
  brahmanbaria: "Brahmanbaria",
  comilla: "Cumilla",
  jessore: "Jashore",
  bogra: "Bogura",
  netrakona: "Netrokona",
  maulvibazar: "Moulvibazar",
  nawabganj: "Chapainawabganj", // appears only under Rajshahi division in the export
  chapainawabganj: "Chapainawabganj",
  jhalokati: "Jhalokathi", // OSM spelling (canonical BBS: Jhalokathi)
};

function norm(s: string): string {
  return s.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "");
}

// Fully-generic OSM names carry no directory value — skip them honestly.
const GENERIC_NAMES = new Set([
  "clinic", "community clinic", "hospital", "health complex", "community center",
  "community centre", "new clinic", "health center", "health centre", "pharmacy",
  "medical", "dispensary", "upazila health complex", "district hospital",
  "sadar hospital", "blood bank", "diagnostic centre", "diagnostic center",
  "laboratory", "family welfare center", "health care center",
]);
function isGenericName(name: string): boolean {
  return GENERIC_NAMES.has(name.toLowerCase().trim());
}

type OsmProps = {
  id?: string; name?: string; name_en?: string; name_bn?: string; name_latin?: string;
  amenity?: string; healthcare?: string; operator_type?: string;
  addr_full?: string; addr_city?: string;
  adm1_name?: string; adm2_name?: string; adm3_name?: string;
};

function kindOf(p: OsmProps): "HOSPITAL" | "CLINIC" | "PHARMACY" | "DIAGNOSTIC" | "BLOOD_BANK" | null {
  const am = p.amenity ?? "";
  const hc = p.healthcare ?? "";
  if (am === "hospital" || hc === "hospital" || hc === "primary hospital") return "HOSPITAL";
  if (am === "clinic" || hc === "clinic") return "CLINIC";
  if (am === "pharmacy" || hc === "pharmacy") return "PHARMACY";
  if (hc === "laboratory" || hc === "sample_collection") return "DIAGNOSTIC";
  if (hc === "blood_donation") return "BLOOD_BANK";
  return null; // dentist/doctors/alternative/centre/yes/… deliberately skipped
}

function hospitalCategoryOf(name: string): string | null {
  if (/medical college/i.test(name)) return "MEDICAL_COLLEGE";
  if (/upazila health complex/i.test(name)) return "UPAZILA_HEALTH_COMPLEX";
  if (/district (sadar )?hospital|sadar hospital|general hospital/i.test(name)) return "DISTRICT_HOSPITAL";
  if (/special/i.test(name)) return "SPECIALIZED";
  return "OTHER";
}

function ownershipOf(p: OsmProps): string | null {
  switch (p.operator_type) {
    case "government": case "public": return "PUBLIC";
    case "private": return "PRIVATE";
    case "private_non_profit": case "community": case "association": return "NGO";
    default: return null;
  }
}

function centroid(geometry: { type: string; coordinates: unknown }): { lat: number; lng: number } | null {
  if (geometry.type === "Point") {
    const [lng, lat] = geometry.coordinates as [number, number];
    return { lat, lng };
  }
  if (geometry.type === "Polygon") {
    const ring = (geometry.coordinates as number[][][])[0] ?? [];
    if (!ring.length) return null;
    let sLat = 0, sLng = 0;
    for (const [lng, lat] of ring) { sLat += lat; sLng += lng; }
    return { lat: sLat / ring.length, lng: sLng / ring.length };
  }
  return null;
}

async function main() {
  const file = process.argv[2] ?? "/tmp/hdx/health_facilities.geojson";
  const geo = JSON.parse(readFileSync(file, "utf-8")) as { features: Array<{ properties: OsmProps; geometry: { type: string; coordinates: unknown } }> };
  console.log(`Loaded ${geo.features.length} features from ${file}`);

  const districts = await db.administrativeLocation.findMany({ where: { level: "DISTRICT" }, select: { name: true, division: true } });
  const districtByKey = new Map(districts.map((d) => [norm(d.name), d]));
  const upazilas = await db.administrativeLocation.findMany({ where: { level: "UPAZILA" }, select: { name: true, district: true } });
  const upaByDistrict = new Map<string, Set<string>>();
  for (const u of upazilas) {
    if (!upaByDistrict.has(u.district)) upaByDistrict.set(u.district, new Set());
    upaByDistrict.get(u.district)!.add(norm(u.name));
  }

  // group features by resolved kind + district
  type Row = {
    name: string; nameBangla: string | null; kind: string; district: string; division: string | null;
    upazila: string | null; area: string | null; addressLine: string; lat: number | null; lng: number | null;
    ownership: string | null; key: string;
  };
  const facilityRows = new Map<string, Row>();   // dedup key → row
  const pharmacyRows = new Map<string, Row>();
  let skippedUnnamed = 0, skippedUnknownDistrict = 0, skippedOtherType = 0, skippedBadGeom = 0;

  for (const f of geo.features) {
    const p = f.properties;
    const kind = kindOf(p);
    if (!kind) { skippedOtherType++; continue; }
    const name = (p.name_en || p.name || p.name_latin || "").trim();
    if (!name) { skippedUnnamed++; continue; }
    if (isGenericName(name)) { skippedUnnamed++; continue; }

    // district resolution via alias map + canonical list
    const adm2 = (p.adm2_name ?? "").trim();
    const resolved = districtByKey.get(norm(adm2)) ?? districtByKey.get(DISTRICT_ALIASES[norm(adm2)] ? norm(DISTRICT_ALIASES[norm(adm2)]) : "");
    if (!resolved) { skippedUnknownDistrict++; continue; }
    if (norm(adm2) === "nawabganj" && norm(p.adm1_name ?? "") !== "rajshahi") { skippedUnknownDistrict++; continue; }

    const geom = centroid(f.geometry);
    if (!geom) { skippedBadGeom++; continue; }

    // upazila only when it matches the verified upazila list of that district
    const adm3 = (p.adm3_name ?? "").trim();
    const upaSet = upaByDistrict.get(resolved.name);
    const upazila = adm3 && upaSet?.has(norm(adm3)) ? adm3 : null;

    const addressLine = (p.addr_full || p.addr_city || [adm3, adm2].filter(Boolean).join(", ") || resolved.name).trim();
    const nameBangla = (p.name_bn ?? "").trim() || null;

    const row: Row = {
      name, nameBangla, kind,
      district: resolved.name, division: resolved.division,
      upazila, area: p.addr_city?.trim() || adm3 || null,
      addressLine, lat: Math.round(geom.lat * 10 ** 6) / 10 ** 6, lng: Math.round(geom.lng * 10 ** 6) / 10 ** 6,
      ownership: ownershipOf(p), key: "",
    };
    row.key = recordKey(row.name, row.district, row.upazila);
    const target = kind === "PHARMACY" ? pharmacyRows : facilityRows;
    if (target.has(row.key)) continue; // in-dataset duplicate
    target.set(row.key, row);
  }

  // existing DB keys per district for cross-source dedup
  const existingFacilityKeys = new Set<string>();
  const existingPharmacyKeys = new Set<string>();
  for (const d of districts) {
    for (const r of await db.healthcareFacility.findMany({ where: { district: d.name, deletedAt: null }, select: { name: true, upazila: true, district: true } })) {
      existingFacilityKeys.add(recordKey(r.name, r.district, r.upazila));
    }
    for (const r of await db.pharmacy.findMany({ where: { district: d.name, deletedAt: null }, select: { name: true, upazila: true, district: true } })) {
      existingPharmacyKeys.add(recordKey(r.name, r.district, r.upazila));
    }
  }

  const jobFac = await db.directoryImportJob.create({
    data: { sourceType: SOURCE_TYPE, entityType: "FACILITY", fileName: "hotosm_bgd_health_facilities_osm.geojson", status: "RUNNING", totalRows: facilityRows.size },
  });
  const jobPh = await db.directoryImportJob.create({
    data: { sourceType: SOURCE_TYPE, entityType: "PHARMACY", fileName: "hotosm_bgd_health_facilities_osm.geojson", status: "RUNNING", totalRows: pharmacyRows.size },
  });

  let fNew = 0, fDup = 0, pNew = 0, pDup = 0;
  const facBatch: Record<string, unknown>[] = [];
  for (const row of facilityRows.values()) {
    if (existingFacilityKeys.has(row.key)) { fDup++; continue; }
    existingFacilityKeys.add(row.key);
    facBatch.push({
      name: row.name, nameBangla: row.nameBangla, type: row.kind,
      hospitalCategory: row.kind === "HOSPITAL" ? hospitalCategoryOf(row.name) : null,
      ownership: row.ownership, division: row.division, district: row.district, upazila: row.upazila,
      area: row.area, addressLine: row.addressLine, lat: row.lat, lng: row.lng,
      services: "[]", specialties: "[]", emergency: false, isDemo: false,
      source: SOURCE_NAME, sourceType: SOURCE_TYPE, sourceUrl: SOURCE_URL,
      verificationStatus: "UNVERIFIED",
      qualityScore: qualityScore({ name: true, nameBangla: Boolean(row.nameBangla), type: true, ownership: Boolean(row.ownership), division: true, district: true, upazila: Boolean(row.upazila), address: true, latLng: true, phone: false, services: false, source: true, verified: false }),
    });
    fNew++;
  }
  // insert in chunks
  for (let i = 0; i < facBatch.length; i += 200) {
    await db.healthcareFacility.createMany({ data: facBatch.slice(i, i + 200) as never });
  }

  const phBatch: Record<string, unknown>[] = [];
  for (const row of pharmacyRows.values()) {
    if (existingPharmacyKeys.has(row.key)) { pDup++; continue; }
    existingPharmacyKeys.add(row.key);
    phBatch.push({
      name: row.name, nameBangla: row.nameBangla, contactPhone: "",
      addressLine: row.addressLine, division: row.division, district: row.district, upazila: row.upazila,
      area: row.area, lat: row.lat, lng: row.lng, status: "PENDING", isVerified: false,
      verificationStatus: "UNVERIFIED", isDemo: false,
      sourceName: SOURCE_NAME, sourceType: SOURCE_TYPE, sourceUrl: SOURCE_URL,
      qualityScore: qualityScore({ name: true, nameBangla: Boolean(row.nameBangla), type: true, ownership: true, division: true, district: true, upazila: Boolean(row.upazila), address: true, latLng: true, phone: false, services: false, source: true, verified: false }),
    });
    pNew++;
  }
  for (let i = 0; i < phBatch.length; i += 200) {
    await db.pharmacy.createMany({ data: phBatch.slice(i, i + 200) as never });
  }

  await db.directoryImportJob.update({
    where: { id: jobFac.id },
    data: {
      status: "COMPLETED", importedRows: fNew, duplicateRows: fDup, errorRows: skippedUnknownDistrict,
      summary: JSON.stringify({ source: SOURCE_NAME, skippedUnnamed, skippedOtherType, skippedBadGeom, imported: fNew, duplicates: fDup }),
      finishedAt: new Date(),
    },
  });
  await db.directoryImportJob.update({
    where: { id: jobPh.id },
    data: {
      status: "COMPLETED", importedRows: pNew, duplicateRows: pDup, errorRows: 0,
      summary: JSON.stringify({ source: SOURCE_NAME, imported: pNew, duplicates: pDup }),
      finishedAt: new Date(),
    },
  });

  console.log(`Facilities: +${fNew} imported, ${fDup} duplicates (skipped: unnamed=${skippedUnnamed}, unknown-district=${skippedUnknownDistrict}, other-type=${skippedOtherType}, bad-geom=${skippedBadGeom})`);
  console.log(`Pharmacies: +${pNew} imported, ${pDup} duplicates`);
  const [divs, dists, upzs, fac, ph] = await Promise.all([
    db.administrativeLocation.count({ where: { level: "DIVISION" } }),
    db.administrativeLocation.count({ where: { level: "DISTRICT" } }),
    db.administrativeLocation.count({ where: { level: "UPAZILA" } }),
    db.healthcareFacility.count({ where: { deletedAt: null } }),
    db.pharmacy.count({ where: { deletedAt: null } }),
  ]);
  const covered = (await db.healthcareFacility.groupBy({ by: ["district"], _count: true, where: { deletedAt: null, district: { not: null } } })).length;
  console.log(`Directory now: ${divs} divisions, ${dists} districts, ${upzs} upazilas, ${fac} facilities, ${ph} pharmacies, ${covered}/64 districts covered`);
  process.exit(0);
}

main().catch((e) => { console.error(e); process.exit(1); });
