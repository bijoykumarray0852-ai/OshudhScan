// Generates a realistic "handwritten prescription" test image (SVG -> PNG) for OCR testing
import sharp from 'sharp';

const svg = `
<svg width="800" height="560" xmlns="http://www.w3.org/2000/svg">
  <rect width="800" height="560" fill="#fdfaf3"/>
  <rect x="24" y="24" width="752" height="512" fill="none" stroke="#2f4f6f" stroke-width="2"/>
  <line x1="24" y1="120" x2="776" y2="120" stroke="#2f4f6f" stroke-width="1.5"/>
  <text x="40" y="70" font-family="DejaVu Serif" font-size="34" font-style="italic" font-weight="bold" fill="#1a3353">Dr. A. Rahman Chowdhury</text>
  <text x="40" y="102" font-family="DejaVu Serif" font-size="20" font-style="italic" fill="#1a3353">MBBS (DMC), FCPS — Medicine</text>
  <text x="560" y="70" font-family="DejaVu Serif" font-size="18" font-style="italic" fill="#555">Chamber: Mirpur-10, Dhaka</text>
  <text x="560" y="100" font-family="DejaVu Serif" font-size="18" font-style="italic" fill="#555">Reg: A-51234</text>
  <text x="40" y="160" font-family="DejaVu Serif" font-size="18" font-style="italic" fill="#333">Patient:</text>
  <text x="150" y="160" font-family="DejaVu Serif" font-size="20" font-style="italic" font-weight="bold" fill="#000">Md. Kamal Hossain, 45y, M</text>
  <text x="600" y="160" font-family="DejaVu Serif" font-size="18" font-style="italic" fill="#333">Date: 18-11-2026</text>
  <text x="60" y="230" font-family="DejaVu Serif" font-size="26" font-style="italic" fill="#0b3d91">1) Napa 500</text>
  <text x="440" y="230" font-family="DejaVu Serif" font-size="26" font-style="italic" fill="#0b3d91">1+1+1 — 5 days</text>
  <text x="60" y="290" font-family="DejaVu Serif" font-size="26" font-style="italic" fill="#0b3d91">2) Seclo 20</text>
  <text x="440" y="290" font-family="DejaVu Serif" font-size="26" font-style="italic" fill="#0b3d91">1+0+1 — 30 days</text>
  <text x="60" y="350" font-family="DejaVu Serif" font-size="26" font-style="italic" fill="#0b3d91">3) Alatrol 10</text>
  <text x="440" y="350" font-family="DejaVu Serif" font-size="26" font-style="italic" fill="#0b3d91">0+0+1 — 7 days</text>
  <text x="60" y="410" font-family="DejaVu Serif" font-size="26" font-style="italic" fill="#0b3d91">4) Flexi</text>
  <text x="440" y="410" font-family="DejaVu Serif" font-size="26" font-style="italic" fill="#0b3d91">1+1+1 — 7 days</text>
  <text x="40" y="480" font-family="DejaVu Serif" font-size="20" font-style="italic" fill="#8a2be2">Fx: come again after 7 days</text>
  <text x="560" y="500" font-family="DejaVu Serif" font-size="22" font-style="italic" font-weight="bold" fill="#8a2be2">Dr. A. R. Chowdhury</text>
</svg>`;

await sharp(Buffer.from(svg)).png().toFile('/tmp/vision-test/sample-rx.png');
console.log('written /tmp/vision-test/sample-rx.png');
