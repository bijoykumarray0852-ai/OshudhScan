/* Data-coverage audit: how spread is directory data across divisions/districts? */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const byLevel = await db.administrativeLocation.groupBy({ by: ["level"], _count: true });
  console.log("=== AdministrativeLocation by level ===");
  byLevel.forEach((d) => console.log(`  ${d.level}: ${d._count}`));

  const facByDiv = await db.healthcareFacility.groupBy({
    by: ["division"],
    _count: true,
    where: { deletedAt: null },
  });
  const phByDiv = await db.pharmacy.groupBy({
    by: ["division"],
    _count: true,
    where: { deletedAt: null },
  });
  console.log("=== Facilities by division ===");
  facByDiv.forEach((d) => console.log(`  ${d.division}: ${d._count}`));
  console.log("=== Pharmacies by division ===");
  phByDiv.forEach((d) => console.log(`  ${d.division}: ${d._count}`));

  const facByDist = await db.healthcareFacility.groupBy({
    by: ["district"],
    _count: true,
    where: { deletedAt: null },
    orderBy: { _count: { district: "desc" } },
  });
  const phByDist = await db.pharmacy.groupBy({
    by: ["district"],
    _count: true,
    where: { deletedAt: null },
    orderBy: { _count: { district: "desc" } },
  });
  console.log(`=== Facilities by district (${facByDist.length} districts) ===`);
  facByDist.slice(0, 15).forEach((d) => console.log(`  ${d.district}: ${d._count}`));
  console.log(`=== Pharmacies by district (${phByDist.length} districts) ===`);
  phByDist.slice(0, 15).forEach((d) => console.log(`  ${d.district}: ${d._count}`));

  // name-normalization hazards: do facility/pharmacy names match location rows?
  const adminDivisions = await db.administrativeLocation.findMany({
    where: { level: "DIVISION" },
    select: { name: true },
  });
  const adminDistricts = await db.administrativeLocation.findMany({
    where: { level: "DISTRICT" },
    select: { name: true, parentName: true },
  });
  const adminDivNames = new Set(adminDivisions.map((d) => d.name));
  const adminDistNames = new Set(adminDistricts.map((d) => d.name));
  const orphanFacDiv = facByDiv.filter((d) => d.division && !adminDivNames.has(d.division));
  const orphanFacDist = facByDist.filter((d) => d.district && !adminDistNames.has(d.district));
  const orphanPhDist = phByDist.filter((d) => d.district && !adminDistNames.has(d.district));
  console.log("=== Facility divisions NOT in location table ===", orphanFacDiv.map((d) => d.division));
  console.log("=== Facility districts NOT in location table ===", orphanFacDist.map((d) => d.district));
  console.log("=== Pharmacy districts NOT in location table ===", orphanPhDist.map((d) => d.district));
  console.log("=== Null/empty division (facilities) ===", facByDiv.filter((d) => !d.division).length > 0 ? facByDiv.filter((d) => !d.division).map(d=>d._count) : "none");

  const facTotal = await db.healthcareFacility.count({ where: { deletedAt: null } });
  const phTotal = await db.pharmacy.count({ where: { deletedAt: null } });
  console.log("=== Totals ===", { facTotal, phTotal });

  const noGeoFac = await db.healthcareFacility.count({ where: { deletedAt: null, OR: [{ lat: null }, { lng: null }] } });
  const noGeoPh = await db.pharmacy.count({ where: { deletedAt: null, OR: [{ lat: null }, { lng: null }] } });
  console.log("=== Missing coordinates ===", { noGeoFac, noGeoPh });
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
