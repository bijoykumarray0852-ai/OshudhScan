import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const j = JSON.stringify;
(async () => {
  const facByType = await db.healthcareFacility.groupBy({ by: ["type"], _count: true, where: { deletedAt: null } });
  console.log("FACILITIES BY TYPE:", j(facByType));
  const facByDistrict = await db.healthcareFacility.groupBy({ by: ["district"], _count: true, where: { deletedAt: null }, _where: undefined });
  console.log("FACILITY DISTRICTS (" + facByDistrict.length + "):", j(facByDistrict));
  const phByDistrict = await db.pharmacy.groupBy({ by: ["district"], _count: true, where: { deletedAt: null } });
  console.log("PHARMACY DISTRICTS (" + phByDistrict.length + "):", j(phByDistrict));
  const div = await db.location.groupBy({ by: ["type"], _count: true });
  console.log("LOCATIONS:", j(div));
  const emerg = await db.healthcareFacility.count({ where: { emergency: true, deletedAt: null } });
  console.log("EMERGENCY FACILITIES:", emerg);
  const reports = await db.userReport.count();
  console.log("USER REPORTS:", reports);
  await db.$disconnect();
})().catch((e) => { console.error(e.message); process.exit(1); });
